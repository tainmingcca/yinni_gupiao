-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: aaaa
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `st_admin_access`
--

DROP TABLE IF EXISTS `st_admin_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_admin_access` (
  `module` varchar(16) NOT NULL DEFAULT '' COMMENT '模型名称',
  `group` varchar(16) NOT NULL DEFAULT '' COMMENT '权限分组标识',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `nid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '授权节点id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='统一授权表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_admin_access`
--

LOCK TABLES `st_admin_access` WRITE;
/*!40000 ALTER TABLE `st_admin_access` DISABLE KEYS */;
INSERT INTO `st_admin_access` VALUES ('admin.lvmaque','1',1,1),('cms','group',3,2),('cms','group',3,3);
/*!40000 ALTER TABLE `st_admin_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_admin_action`
--

DROP TABLE IF EXISTS `st_admin_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_admin_action` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(16) NOT NULL DEFAULT '' COMMENT '所属模块名',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '行为标题',
  `remark` varchar(128) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_admin_action`
--

LOCK TABLES `st_admin_action` WRITE;
/*!40000 ALTER TABLE `st_admin_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_admin_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_admin_attachment`
--

DROP TABLE IF EXISTS `st_admin_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_admin_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '文件名',
  `module` varchar(32) NOT NULL DEFAULT '' COMMENT '模块名，由哪个模块上传的',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '文件路径',
  `thumb` varchar(255) NOT NULL DEFAULT '' COMMENT '缩略图路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '文件链接',
  `mime` varchar(128) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `ext` char(8) NOT NULL DEFAULT '' COMMENT '文件类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT 'sha1 散列值',
  `driver` varchar(16) NOT NULL DEFAULT 'local' COMMENT '上传驱动',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='附件表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_admin_attachment`
--

LOCK TABLES `st_admin_attachment` WRITE;
/*!40000 ALTER TABLE `st_admin_attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_admin_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_admin_bank`
--

DROP TABLE IF EXISTS `st_admin_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_admin_bank` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payee` varchar(200) NOT NULL DEFAULT '' COMMENT '收款人',
  `card` varchar(255) NOT NULL COMMENT '银行卡号',
  `bank_name` varchar(25) NOT NULL COMMENT '所属银行',
  `open_bank` varchar(60) NOT NULL COMMENT '开户行',
  `notes` varchar(255) DEFAULT NULL COMMENT '说明',
  `create_time` int(11) DEFAULT NULL COMMENT '建立时间',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态 默认1：启用 0：禁用',
  `group_ids` varchar(200) NOT NULL DEFAULT '0',
  `type` char(10) DEFAULT NULL,
  `class` varchar(100) DEFAULT '',
  `value` int(11) DEFAULT NULL,
  `sort` int(11) DEFAULT '0',
  `icon` varchar(100) DEFAULT NULL,
  `is_recharge` tinyint(3) DEFAULT '1' COMMENT '充值禁用 1启用 2禁用',
  `is_cash` tinyint(3) DEFAULT '1' COMMENT '提现禁用 1启用 2禁用',
  `is_bm` tinyint(3) DEFAULT '0' COMMENT '0不需要银行编码    1需要银行编码',
  `bank_code` text COMMENT '银行编码',
  PRIMARY KEY (`id`),
  KEY `payee` (`payee`),
  KEY `card` (`card`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COMMENT='平台银行卡';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_admin_bank`
--

LOCK TABLES `st_admin_bank` WRITE;
/*!40000 ALTER TABLE `st_admin_bank` DISABLE KEYS */;
INSERT INTO `st_admin_bank` VALUES (5,'fantasy','asdkljaskl456156165qweqwe','USDT-TRC20','TRC','USDT-TRC',1744704666,0,'','usdt','Bank',5,1,'/static/bank/rp.png',1,1,0,NULL),(6,'USDT-ERC20','ASDJASD1321321adasdasd','USDT-ERC20','USDT-ERC20','USDT-ERC',1744704662,0,'','usdt','Bank',6,2,'/static/bank/rp.png',1,1,0,NULL),(8,'PT INFINITAS SELALU MAJU','033601005059308','Transfer Bank-02','Bank Rakyat Indonesia','Bank Rakyat Indonesia',1761488759,0,'0','bank','Bank',8,99,'/static/bank/rp.png',1,1,0,NULL),(10,'Dompet Digital ','HzPay-13001','Dompet Digital ','HzPay-13001','海贼-13001',1758524832,0,'13001','zx','HzPay',9,10,'/static/bank/rp.png',2,2,1,'[{\"code\":\"116\",\"name\":\"Bank Aceh Syariah\"},{\"code\":\"1160\",\"name\":\"Bank Agris UUS\"},{\"code\":\"945\",\"name\":\"Bank IBK Indonesia\"},{\"code\":\"494\",\"name\":\"Bank Agroniaga\"},{\"code\":\"466\",\"name\":\"Bank Andara\"},{\"code\":\"531\",\"name\":\"Anglomas International Bank\"},{\"code\":\"061\",\"name\":\"Bank ANZ Indonesia\"},{\"code\":\"020\",\"name\":\"Bank Arta Niaga Kencana\"},{\"code\":\"037\",\"name\":\"Bank Artha Graha Internasional\"},{\"code\":\"542\",\"name\":\"Bank ARTOS\\/ Bank Jago\"},{\"code\":\"129\",\"name\":\"BPD Bali\"},{\"code\":\"459\",\"name\":\"Bank Bisnis Internasional\"},{\"code\":\"040\",\"name\":\"Bangkok Bank\"},{\"code\":\"014\",\"name\":\"Bank Central Asia(BCA)\"},{\"code\":\"536\",\"name\":\"Bank Central Asia (BCA) Syariah\"},{\"code\":\"133\",\"name\":\"Bank Bengkulu\"},{\"code\":\"110\",\"name\":\"Bank Jawa Barat(BJB)\"},{\"code\":\"425\",\"name\":\"Bank BJB Syariah\"},{\"code\":\"009\",\"name\":\"Bank Negara Indonesia(BNI)\"},{\"code\":\"427\",\"name\":\"Bank BNI Syariah\"},{\"code\":\"069\",\"name\":\"BANK OF CHINA LIMITED\"},{\"code\":\"002\",\"name\":\"Bank Rakyat Indonesia(BRI)\"},{\"code\":\"422\",\"name\":\"Bank BRI Syariah\"},{\"code\":\"1450\",\"name\":\"Bank BNP Paribas\"},{\"code\":\"4510\",\"name\":\"Bank Syariah Indonesia(BSI)\"},{\"code\":\"200\",\"name\":\"Bank Tabungan Negara (BTN)\"},{\"code\":\"2000\",\"name\":\"Bank Tabungan Negara (BTN) UUS\"},{\"code\":\"213\",\"name\":\"Bank BTPN\"},{\"code\":\"5470\",\"name\":\"BTPN Syariah\"},{\"code\":\"547\",\"name\":\"Bank BTPN Syariah\"},{\"code\":\"441\",\"name\":\"Wokee\\/Bukopin\"},{\"code\":\"521\",\"name\":\"Bank Bukopin Syariah\"},{\"code\":\"076\",\"name\":\"Bank Bumi Arta\"},{\"code\":\"054\",\"name\":\"Bank Capital Indonesia\"},{\"code\":\"949\",\"name\":\"CTBC Indonesia\"},{\"code\":\"559\",\"name\":\"Centratama Nasional Bank(CNB)\"},{\"code\":\"022\",\"name\":\"Bank CIMB Niaga\"},{\"code\":\"0220\",\"name\":\"Bank CIMB Niaga UUS\"},{\"code\":\"031\",\"name\":\"Citibank\"},{\"code\":\"950\",\"name\":\"Bank Commonwealth\"},{\"code\":\"112\",\"name\":\"BPD DIY\"},{\"code\":\"011\",\"name\":\"Bank Danamon\"},{\"code\":\"0110\",\"name\":\"Bank Danamon UUS\"},{\"code\":\"046\",\"name\":\"Bank DBS Indonesia\"},{\"code\":\"526\",\"name\":\"Bank Dinar Indonesia\"},{\"code\":\"111\",\"name\":\"Bank DKI\"},{\"code\":\"778\",\"name\":\"Bank DKI UUS\"},{\"code\":\"562\",\"name\":\"Bank Fama International\"},{\"code\":\"699\",\"name\":\"Bank EKA\"},{\"code\":\"161\",\"name\":\"Bank Ganesha\"},{\"code\":\"484\",\"name\":\"LINE Bank\\/KEB Hana\"},{\"code\":\"567\",\"name\":\"Allo Bank\\/Bank Harda Internasional\"},{\"code\":\"2120\",\"name\":\"Bank Himpunan Saudara 1906\"},{\"code\":\"041\",\"name\":\"HSBC\"},{\"code\":\"164\",\"name\":\"Bank ICBC Indonesia\"},{\"code\":\"513\",\"name\":\"Bank Ina Perdana\"},{\"code\":\"555\",\"name\":\"Bank Index Selindo\"},{\"code\":\"146\",\"name\":\"Bank of India Indonesia\"},{\"code\":\"115\",\"name\":\"Bank Jambi\"},{\"code\":\"472\",\"name\":\"Bank Jasa Jakarta\"},{\"code\":\"113\",\"name\":\"Bank Jateng\"},{\"code\":\"114\",\"name\":\"Bank Jatim\"},{\"code\":\"095\",\"name\":\"Bank JTrust Indonesia\"},{\"code\":\"123\",\"name\":\"BPD Kalimantan Barat\\/Kalbar\"},{\"code\":\"1230\",\"name\":\"BPD Kalimantan Barat UUS\"},{\"code\":\"122\",\"name\":\"BPD Kalimantan Selatan\\/Kalsel\"},{\"code\":\"1220\",\"name\":\"BPD Kalimantan Selatan UUS\"},{\"code\":\"125\",\"name\":\"BPD Kalimantan Tengah (Kalteng)\"},{\"code\":\"124\",\"name\":\"BPD Kalimantan Timur\"},{\"code\":\"1240\",\"name\":\"BPD Kalimantan Timur UUS\"},{\"code\":\"535\",\"name\":\"Seabank\\/Bank Kesejahteraan Ekonomi(BKE)\"},{\"code\":\"121\",\"name\":\"BPD Lampung\"},{\"code\":\"131\",\"name\":\"Bank Maluku\"},{\"code\":\"008\",\"name\":\"Bank Mandiri\"},{\"code\":\"564\",\"name\":\"Bank MANTAP\"},{\"code\":\"548\",\"name\":\"Bank Multi Arta Sentosa(MAS)\"},{\"code\":\"157\",\"name\":\"Bank Maspion Indonesia\"},{\"code\":\"097\",\"name\":\"Bank Mayapada\"},{\"code\":\"016\",\"name\":\"Bank Maybank\"},{\"code\":\"947\",\"name\":\"Bank Maybank Syariah Indonesia\"},{\"code\":\"553\",\"name\":\"Bank Mayora Indonesia\"},{\"code\":\"426\",\"name\":\"Bank Mega\"},{\"code\":\"506\",\"name\":\"Bank Mega Syariah\"},{\"code\":\"151\",\"name\":\"Bank Mestika Dharma\"},{\"code\":\"485\",\"name\":\"Motion\\/Bank MNC Internasional\"},{\"code\":\"147\",\"name\":\"Bank Muamalat Indonesia\"},{\"code\":\"491\",\"name\":\"Bank Mitra Niaga\"},{\"code\":\"048\",\"name\":\"Bank Mizuho Indonesia\"},{\"code\":\"503\",\"name\":\"Bank National Nobu\"},{\"code\":\"128\",\"name\":\"BPD Nusa Tenggara Barat(NTB)\"},{\"code\":\"1280\",\"name\":\"BPD Nusa Tenggara Barat (NTB) UUS\"},{\"code\":\"130\",\"name\":\"BPD Nusa Tenggara Timur(NTT)\"},{\"code\":\"145\",\"name\":\"Bank Nusantara Parahyangan\"},{\"code\":\"028\",\"name\":\"Bank OCBC NISP\"},{\"code\":\"0280\",\"name\":\"Bank OCBC NISP UUS\"},{\"code\":\"019\",\"name\":\"Bank Panin\"},{\"code\":\"517\",\"name\":\"Panin Dubai Syariah\"},{\"code\":\"132\",\"name\":\"Bank Papua\"},{\"code\":\"013\",\"name\":\"Bank Permata\"},{\"code\":\"0130\",\"name\":\"Bank Permata UUS\"},{\"code\":\"520\",\"name\":\"Bank Prima Master\"},{\"code\":\"167\",\"name\":\"QNB KESAWAN\"},{\"code\":\"1670\",\"name\":\"QNB Indonesia\"},{\"code\":\"5260\",\"name\":\"Bank Oke Indonesia\"},{\"code\":\"089\",\"name\":\"Rabobank International Indonesia\"},{\"code\":\"047\",\"name\":\"Bank Resona Perdania\"},{\"code\":\"119\",\"name\":\"BPD Riau Dan Kepri\"},{\"code\":\"1190\",\"name\":\"BPD Riau Dan Kepri UUS\"},{\"code\":\"5010\",\"name\":\"Blu\\/BCA Digital\"},{\"code\":\"523\",\"name\":\"Bank Sahabat Sampoerna\"},{\"code\":\"498\",\"name\":\"Bank SBI Indonesia\"},{\"code\":\"152\",\"name\":\"Bank Shinhan Indonesia\"},{\"code\":\"153\",\"name\":\"Bank Sinarmas\"},{\"code\":\"050\",\"name\":\"Standard Chartered Bank\"},{\"code\":\"134\",\"name\":\"Bank Sulteng\"},{\"code\":\"135\",\"name\":\"Bank Sultra\"},{\"code\":\"126\",\"name\":\"Bank Sulselbar\"},{\"code\":\"1260\",\"name\":\"Bank Sulselbar UUS\"},{\"code\":\"127\",\"name\":\"BPD Sulawesi Utara(SulutGo)\"},{\"code\":\"118\",\"name\":\"BPD Sumatera Barat\"},{\"code\":\"1180\",\"name\":\"BPD Sumatera Barat UUS\"},{\"code\":\"120\",\"name\":\"BPD Sumsel Babel\"},{\"code\":\"1200\",\"name\":\"Bank Sumsel Babel UUS\"},{\"code\":\"117\",\"name\":\"Bank Sumut\"},{\"code\":\"1170\",\"name\":\"Bank Sumut UUS\"},{\"code\":\"1530\",\"name\":\"Bank Sinarmas UUS\"},{\"code\":\"045\",\"name\":\"Bank Sumitomo Mitsui Indonesia\"},{\"code\":\"451\",\"name\":\"Bank Syariah Mandiri(BSM)\"},{\"code\":\"042\",\"name\":\"Bank of Tokyo\"},{\"code\":\"023\",\"name\":\"TMRW\\/Bank UOB Indonesia\"},{\"code\":\"566\",\"name\":\"Bank Victoria International\"},{\"code\":\"405\",\"name\":\"Bank Victoria Syariah\"},{\"code\":\"212\",\"name\":\"Bank Woori Saudara\"},{\"code\":\"490\",\"name\":\"Neo Commerce\\/Bank Yudha Bhakti\"},{\"code\":\"1120\",\"name\":\"BPD_Daerah_Istimewa_Yogyakarta_(DIY)\"},{\"code\":\"5590\",\"name\":\"Bank Centratama\"},{\"code\":\"088\",\"name\":\"CCB Indonesia\"},{\"code\":\"067\",\"name\":\"Deutsche Bank\"},{\"code\":\"032\",\"name\":\"JPMORGAN CHASE BANK\"},{\"code\":\"5640\",\"name\":\"Bank Mandiri Taspen Pos\"},{\"code\":\"501\",\"name\":\"Royal Bank of Scotland (RBS)\"},{\"code\":\"10001\",\"name\":\"OVO\"},{\"code\":\"10002\",\"name\":\"DANA\"},{\"code\":\"10003\",\"name\":\"GOPAY\"},{\"code\":\"10006\",\"name\":\"Bank MULTICOR\"},{\"code\":\"10008\",\"name\":\"SHOPEEPAY\"},{\"code\":\"10009\",\"name\":\"LINKAJA\"},{\"code\":\"10010\",\"name\":\"Bank MUTIARA\"}]'),(11,'HzPay-13002','HzPay-13002','HzPay-13002','HzPay-13002','HzPay-13002',1747293231,0,'13002','zx','HzPay',10,0,'/static/bank/rp.png',2,0,0,NULL),(12,'HzPay-13003','HzPay-13003','HzPay-13003','HzPay-13003','HzPay-13003',1747293236,0,'13003','zx','HzPay',11,0,'/static/bank/rp.png',2,0,0,NULL),(13,'HzPay-13004','HzPay-13004','HzPay-13004','HzPay-13004','HzPay-13004',1747293239,0,'13004','zx','HzPay',12,0,'/static/bank/rp.png',2,0,0,NULL),(14,'Dompet Digital','HzPay-13005','Dompet Digital','HzPay-13005','HzPay-13005',1752824326,0,'13005','zx','HzPay',13,0,'/static/bank/rp.png',2,2,0,NULL),(15,'HzPay-13006','HzPay-13006','HzPay-13006','HzPay-13006','HzPay-13006',1747293244,0,'13006','zx','HzPay',14,0,'/static/bank/rp.png',2,0,0,NULL),(16,'HzPay-13007','HzPay-13007','HzPay-13007','HzPay-13007','HzPay-13007',1747293253,0,'13007','zx','HzPay',15,0,'/static/bank/rp.png',2,0,0,NULL),(17,'Pindai QR ','HtPay-0231','Pindai QR ','HtPay-0231','宏图代付-0231',1764347559,0,'0231','zx','HtPay',16,47,'/static/bank/rp.png',2,2,1,'[{\"code\":\"OCBC\",\"name\":\"OCBC\"},{\"code\":\"BANK BCA\",\"name\":\"BANK BCA\"},{\"code\":\"BANK CIMB NIAGA\",\"name\":\"BANK CIMB NIAGA\"},{\"code\":\"BANK BRI\",\"name\":\"BANK BRI\"},{\"code\":\"BANK MANDIRI\",\"name\":\"BANK MANDIRI\"},{\"code\":\"BANK BNI\",\"name\":\"BANK BNI\"},{\"code\":\"BANK SEABANK INDONESIA\",\"name\":\"BANK SEABANK INDONESIA\"},{\"code\":\"BANK SYARIAH INDONESIA\",\"name\":\"BANK SYARIAH INDONESIA\"},{\"code\":\"BANK PERMATA\",\"name\":\"BANK PERMATA\"},{\"code\":\"BANK BTN\",\"name\":\"BANK BTN\"},{\"code\":\"BANK JAGO\",\"name\":\"BANK JAGO\"},{\"code\":\"BANK ACEH SYARIAH\",\"name\":\"BANK ACEH SYARIAH\"},{\"code\":\"BANK ALADIN\",\"name\":\"BANK ALADIN\"},{\"code\":\"BANK AMAR INDONESIA\",\"name\":\"BANK AMAR INDONESIA\"},{\"code\":\"BANK ANZ\",\"name\":\"BANK ANZ\"},{\"code\":\"BANK ARTHA GRAHA\",\"name\":\"BANK ARTHA GRAHA\"},{\"code\":\"BANK BANTEN\",\"name\":\"BANK BANTEN\"},{\"code\":\"BANK BCA SYARIAH\",\"name\":\"BANK BCA SYARIAH\"},{\"code\":\"BANK BENGKULU\",\"name\":\"BANK BENGKULU\"},{\"code\":\"BANK BJB\",\"name\":\"BANK BJB\"},{\"code\":\"BANK BJB SYARIAH\",\"name\":\"BANK BJB SYARIAH\"},{\"code\":\"BANK BNP PARIBAS\",\"name\":\"BANK BNP PARIBAS\"},{\"code\":\"BANK BPR KS\",\"name\":\"BANK BPR KS\"},{\"code\":\"BANK BTN SYARIAH\",\"name\":\"BANK BTN SYARIAH\"},{\"code\":\"BANK BTPN SYARIAH\",\"name\":\"BANK BTPN SYARIAH\"},{\"code\":\"BANK BUKOPIN SYARIAH\",\"name\":\"BANK BUKOPIN SYARIAH\"},{\"code\":\"BANK BUMI ARTA\",\"name\":\"BANK BUMI ARTA\"},{\"code\":\"BANK CAPITAL\",\"name\":\"BANK CAPITAL\"},{\"code\":\"BANK CHINATRUST\",\"name\":\"BANK CHINATRUST\"},{\"code\":\"BANK CIMB NIAGA SYARIAH\",\"name\":\"BANK CIMB NIAGA SYARIAH\"},{\"code\":\"BANK DANAMON\",\"name\":\"BANK DANAMON\"},{\"code\":\"BANK DANAMON SYARIAH\",\"name\":\"BANK DANAMON SYARIAH\"},{\"code\":\"BANK DBS\",\"name\":\"BANK DBS\"},{\"code\":\"BANK DEUTSCHE\",\"name\":\"BANK DEUTSCHE\"},{\"code\":\"BANK DIGITAL BCA\",\"name\":\"BANK DIGITAL BCA\"},{\"code\":\"BANK DKI\",\"name\":\"BANK DKI\"},{\"code\":\"BANK DKI SYARIAH\",\"name\":\"BANK DKI SYARIAH\"},{\"code\":\"BANK EKA\",\"name\":\"BANK EKA\"},{\"code\":\"BANK GANESHA\",\"name\":\"BANK GANESHA\"},{\"code\":\"BANK ICBC\",\"name\":\"BANK ICBC\"},{\"code\":\"BANK INA PERDANA\",\"name\":\"BANK INA PERDANA\"},{\"code\":\"BANK INDEX\",\"name\":\"BANK INDEX\"},{\"code\":\"BANK INTERIM INDONESIA\",\"name\":\"BANK INTERIM INDONESIA\"},{\"code\":\"BANK JAGO UU SYARIAH\",\"name\":\"BANK JAGO UU SYARIAH\"},{\"code\":\"BANK JASA JAKARTA\",\"name\":\"BANK JASA JAKARTA\"},{\"code\":\"BANK JATENG\",\"name\":\"BANK JATENG\"},{\"code\":\"BANK JATENG SYARIAH\",\"name\":\"BANK JATENG SYARIAH\"},{\"code\":\"BANK JATIM\",\"name\":\"BANK JATIM\"},{\"code\":\"BANK JATIM SYARIAH\",\"name\":\"BANK JATIM SYARIAH\"},{\"code\":\"BANK JTRUST INDONESIA\",\"name\":\"BANK JTRUST INDONESIA\"},{\"code\":\"BANK KALBAR\",\"name\":\"BANK KALBAR\"},{\"code\":\"BANK KALBAR SYARIAH\",\"name\":\"BANK KALBAR SYARIAH\"},{\"code\":\"BANK KALTENG\",\"name\":\"BANK KALTENG\"},{\"code\":\"BANK KB BUKOPIN\",\"name\":\"BANK KB BUKOPIN\"},{\"code\":\"BANK KEB HANA\",\"name\":\"BANK KEB HANA\"},{\"code\":\"BANK MANDIRI TASPEN\",\"name\":\"BANK MANDIRI TASPEN\"},{\"code\":\"BANK MAS\",\"name\":\"BANK MAS\"},{\"code\":\"BANK MASPION INDONESIA\",\"name\":\"BANK MASPION INDONESIA\"},{\"code\":\"BANK MAYAPADA\",\"name\":\"BANK MAYAPADA\"},{\"code\":\"BANK MAYBANK\",\"name\":\"BANK MAYBANK\"},{\"code\":\"BANK MAYBANK UU SYARIAH\",\"name\":\"BANK MAYBANK UU SYARIAH\"},{\"code\":\"BANK MEGA\",\"name\":\"BANK MEGA\"},{\"code\":\"BANK MEGA SYARIAH\",\"name\":\"BANK MEGA SYARIAH\"},{\"code\":\"BANK MESTIKA DHARMA\",\"name\":\"BANK MESTIKA DHARMA\"},{\"code\":\"BANK MIZUHO\",\"name\":\"BANK MIZUHO\"},{\"code\":\"BANK MNC INTERNASIONAL\",\"name\":\"BANK MNC INTERNASIONAL\"},{\"code\":\"BANK MUAMALAT\",\"name\":\"BANK MUAMALAT\"},{\"code\":\"BANK NAGARI\",\"name\":\"BANK NAGARI\"},{\"code\":\"BANK NAGARI SYARIAH\",\"name\":\"BANK NAGARI SYARIAH\"},{\"code\":\"BANK NEO COMMERCE\",\"name\":\"BANK NEO COMMERCE\"},{\"code\":\"BANK NOBU\",\"name\":\"BANK NOBU\"},{\"code\":\"BANK OF AMERICA\",\"name\":\"BANK OF AMERICA\"},{\"code\":\"BANK OF CHINA (HKG)\",\"name\":\"BANK OF CHINA (HKG)\"},{\"code\":\"BANK OF INDIA INDONESIA\",\"name\":\"BANK OF INDIA INDONESIA\"},{\"code\":\"BANK OF TOKYO MITSUBISHI UF]\",\"name\":\"BANK OF TOKYO MITSUBISHI UF]\"},{\"code\":\"BANK OKE\",\"name\":\"BANK OKE\"},{\"code\":\"BANK PANIN\",\"name\":\"BANK PANIN\"},{\"code\":\"BANK PANIN SYARIAH\",\"name\":\"BANK PANIN SYARIAH\"},{\"code\":\"BANK PERMATA SYARIAH\",\"name\":\"BANK PERMATA SYARIAH\"},{\"code\":\"BANK ONB INDONESIA\",\"name\":\"BANK ONB INDONESIA\"},{\"code\":\"BANK RAYA INDONESIA\",\"name\":\"BANK RAYA INDONESIA\"},{\"code\":\"BANK RESONA PERDANIA\",\"name\":\"BANK RESONA PERDANIA\"},{\"code\":\"BANK SAHABAT SAMPOERNA\",\"name\":\"BANK SAHABAT SAMPOERNA\"},{\"code\":\"BANK SBIINDONESIA\",\"name\":\"BANK SBIINDONESIA\"},{\"code\":\"BANK SHINHAN INDONESIA\",\"name\":\"BANK SHINHAN INDONESIA\"},{\"code\":\"BANK SINARMAS\",\"name\":\"BANK SINARMAS\"},{\"code\":\"BANK SUMSEL BABEL\",\"name\":\"BANK SUMSEL BABEL\"},{\"code\":\"BANK SUMSEL BABEL SYARIAH\",\"name\":\"BANK SUMSEL BABEL SYARIAH\"},{\"code\":\"BANK UOB\",\"name\":\"BANK UOB\"},{\"code\":\"BANK VICTORIA\",\"name\":\"BANK VICTORIA\"},{\"code\":\"BANK VICTORIA SYARIAH\",\"name\":\"BANK VICTORIA SYARIAH\"},{\"code\":\"BANK WOORI SAUDARA\",\"name\":\"BANK WOORI SAUDARA\"},{\"code\":\"BPD BALI\",\"name\":\"BPD BALI\"},{\"code\":\"BPD DIY\",\"name\":\"BPD DIY\"},{\"code\":\"BPD DIY SYARIAH\",\"name\":\"BPD DIY SYARIAH\"},{\"code\":\"BPD JAMBI\",\"name\":\"BPD JAMBI\"},{\"code\":\"BPD KALSEL\",\"name\":\"BPD KALSEL\"},{\"code\":\"BPD KALSEL SYARIAH\",\"name\":\"BPD KALSEL SYARIAH\"},{\"code\":\"BPD KALTIM KALTARA\",\"name\":\"BPD KALTIM KALTARA\"},{\"code\":\"BPD KALTIM SYARIAH\",\"name\":\"BPD KALTIM SYARIAH\"},{\"code\":\"BPD LAMPUNG\",\"name\":\"BPD LAMPUNG\"},{\"code\":\"BPD MALUKU\",\"name\":\"BPD MALUKU\"},{\"code\":\"BPD NTBS\",\"name\":\"BPD NTBS\"},{\"code\":\"BPD NTT\",\"name\":\"BPD NTT\"},{\"code\":\"BPD PAPUA\",\"name\":\"BPD PAPUA\"},{\"code\":\"BPD RIAU KEPRI\",\"name\":\"BPD RIAU KEPRI\"},{\"code\":\"BPD SULAWESI SELATAN\",\"name\":\"BPD SULAWESI SELATAN\"},{\"code\":\"BPD SULAWESI TENGAH\",\"name\":\"BPD SULAWESI TENGAH\"},{\"code\":\"BPD SULAWESI TENGGARA\",\"name\":\"BPD SULAWESI TENGGARA\"},{\"code\":\"BPD SUMUT\",\"name\":\"BPD SUMUT\"},{\"code\":\"BPD SUMUT SYARIAH\",\"name\":\"BPD SUMUT SYARIAH\"},{\"code\":\"BPR DANAGUNG ABADI\",\"name\":\"BPR DANAGUNG ABADI\"},{\"code\":\"BPR DANAGUNG BAKTI\",\"name\":\"BPR DANAGUNG BAKTI\"},{\"code\":\"BPR DANAGUNG RAMULTI\",\"name\":\"BPR DANAGUNG RAMULTI\"},{\"code\":\"BPR SUPRA\",\"name\":\"BPR SUPRA\"},{\"code\":\"Bank Krom Indonesia\",\"name\":\"Bank Krom Indonesia\"},{\"code\":\"Bank SulutGo\",\"name\":\"Bank SulutGo\"},{\"code\":\"Bank Super indonesia\",\"name\":\"Bank Super indonesia\"},{\"code\":\"CITIBANK\",\"name\":\"CITIBANK\"},{\"code\":\"DOKU\",\"name\":\"DOKU\"},{\"code\":\"HSBC INDONESIA\",\"name\":\"HSBC INDONESIA\"},{\"code\":\"JPMORGAN CHASE BANK\",\"name\":\"JPMORGAN CHASE BANK\"},{\"code\":\"LINKAJA\",\"name\":\"LINKAJA\"},{\"code\":\"PAYPRO\",\"name\":\"PAYPRO\"},{\"code\":\"PT ALLO BANK INDONESIA\",\"name\":\"PT ALLO BANK INDONESIA\"},{\"code\":\"PT BANK NANO SYARIAH\",\"name\":\"PT BANK NANO SYARIAH\"},{\"code\":\"PT BANK SMBC INDONESIA TBK\",\"name\":\"PT BANK SMBC INDONESIA TBK\"},{\"code\":\"PT Bank Hibank Indonesia\",\"name\":\"PT Bank Hibank Indonesia\"},{\"code\":\"PT. BANK CHINA CONSTRUCTION INDONESIA(CCBI)\",\"name\":\"PT. BANK CHINA CONSTRUCTION INDONESIA(CCBI)\"},{\"code\":\"PT. BANK IBK INDONESIA\",\"name\":\"PT. BANK IBK INDONESIA\"},{\"code\":\"STANDARD CHARTERED\",\"name\":\"STANDARD CHARTERED\"},{\"code\":\"LinkAja\",\"name\":\"LinkAja\"},{\"code\":\"OVO\",\"name\":\"OVO\"},{\"code\":\"ShopeePay\",\"name\":\"ShopeePay\"},{\"code\":\"i.saku\",\"name\":\"i.saku\"},{\"code\":\"Gopay Customer\",\"name\":\"Gopay Customer\"},{\"code\":\"DANA\",\"name\":\"DANA\"}]'),(18,'HtPay-0230','HtPay-0230','HtPay-0230','HtPay-0230','宏图代付-0230',1758702587,0,'0230','zx','HtPay',17,46,'/static/bank/rp.png',2,1,1,'[{\"code\":\"OCBC\",\"name\":\"OCBC\"},{\"code\":\"BANK BCA\",\"name\":\"BANK BCA\"},{\"code\":\"BANK CIMB NIAGA\",\"name\":\"BANK CIMB NIAGA\"},{\"code\":\"BANK BRI\",\"name\":\"BANK BRI\"},{\"code\":\"BANK MANDIRI\",\"name\":\"BANK MANDIRI\"},{\"code\":\"BANK BNI\",\"name\":\"BANK BNI\"},{\"code\":\"BANK SEABANK INDONESIA\",\"name\":\"BANK SEABANK INDONESIA\"},{\"code\":\"BANK SYARIAH INDONESIA\",\"name\":\"BANK SYARIAH INDONESIA\"},{\"code\":\"BANK PERMATA\",\"name\":\"BANK PERMATA\"},{\"code\":\"BANK BTN\",\"name\":\"BANK BTN\"},{\"code\":\"BANK JAGO\",\"name\":\"BANK JAGO\"},{\"code\":\"BANK ACEH SYARIAH\",\"name\":\"BANK ACEH SYARIAH\"},{\"code\":\"BANK ALADIN\",\"name\":\"BANK ALADIN\"},{\"code\":\"BANK AMAR INDONESIA\",\"name\":\"BANK AMAR INDONESIA\"},{\"code\":\"BANK ANZ\",\"name\":\"BANK ANZ\"},{\"code\":\"BANK ARTHA GRAHA\",\"name\":\"BANK ARTHA GRAHA\"},{\"code\":\"BANK BANTEN\",\"name\":\"BANK BANTEN\"},{\"code\":\"BANK BCA SYARIAH\",\"name\":\"BANK BCA SYARIAH\"},{\"code\":\"BANK BENGKULU\",\"name\":\"BANK BENGKULU\"},{\"code\":\"BANK BJB\",\"name\":\"BANK BJB\"},{\"code\":\"BANK BJB SYARIAH\",\"name\":\"BANK BJB SYARIAH\"},{\"code\":\"BANK BNP PARIBAS\",\"name\":\"BANK BNP PARIBAS\"},{\"code\":\"BANK BPR KS\",\"name\":\"BANK BPR KS\"},{\"code\":\"BANK BTN SYARIAH\",\"name\":\"BANK BTN SYARIAH\"},{\"code\":\"BANK BTPN SYARIAH\",\"name\":\"BANK BTPN SYARIAH\"},{\"code\":\"BANK BUKOPIN SYARIAH\",\"name\":\"BANK BUKOPIN SYARIAH\"},{\"code\":\"BANK BUMI ARTA\",\"name\":\"BANK BUMI ARTA\"},{\"code\":\"BANK CAPITAL\",\"name\":\"BANK CAPITAL\"},{\"code\":\"BANK CHINATRUST\",\"name\":\"BANK CHINATRUST\"},{\"code\":\"BANK CIMB NIAGA SYARIAH\",\"name\":\"BANK CIMB NIAGA SYARIAH\"},{\"code\":\"BANK DANAMON\",\"name\":\"BANK DANAMON\"},{\"code\":\"BANK DANAMON SYARIAH\",\"name\":\"BANK DANAMON SYARIAH\"},{\"code\":\"BANK DBS\",\"name\":\"BANK DBS\"},{\"code\":\"BANK DEUTSCHE\",\"name\":\"BANK DEUTSCHE\"},{\"code\":\"BANK DIGITAL BCA\",\"name\":\"BANK DIGITAL BCA\"},{\"code\":\"BANK DKI\",\"name\":\"BANK DKI\"},{\"code\":\"BANK DKI SYARIAH\",\"name\":\"BANK DKI SYARIAH\"},{\"code\":\"BANK EKA\",\"name\":\"BANK EKA\"},{\"code\":\"BANK GANESHA\",\"name\":\"BANK GANESHA\"},{\"code\":\"BANK ICBC\",\"name\":\"BANK ICBC\"},{\"code\":\"BANK INA PERDANA\",\"name\":\"BANK INA PERDANA\"},{\"code\":\"BANK INDEX\",\"name\":\"BANK INDEX\"},{\"code\":\"BANK INTERIM INDONESIA\",\"name\":\"BANK INTERIM INDONESIA\"},{\"code\":\"BANK JAGO UU SYARIAH\",\"name\":\"BANK JAGO UU SYARIAH\"},{\"code\":\"BANK JASA JAKARTA\",\"name\":\"BANK JASA JAKARTA\"},{\"code\":\"BANK JATENG\",\"name\":\"BANK JATENG\"},{\"code\":\"BANK JATENG SYARIAH\",\"name\":\"BANK JATENG SYARIAH\"},{\"code\":\"BANK JATIM\",\"name\":\"BANK JATIM\"},{\"code\":\"BANK JATIM SYARIAH\",\"name\":\"BANK JATIM SYARIAH\"},{\"code\":\"BANK JTRUST INDONESIA\",\"name\":\"BANK JTRUST INDONESIA\"},{\"code\":\"BANK KALBAR\",\"name\":\"BANK KALBAR\"},{\"code\":\"BANK KALBAR SYARIAH\",\"name\":\"BANK KALBAR SYARIAH\"},{\"code\":\"BANK KALTENG\",\"name\":\"BANK KALTENG\"},{\"code\":\"BANK KB BUKOPIN\",\"name\":\"BANK KB BUKOPIN\"},{\"code\":\"BANK KEB HANA\",\"name\":\"BANK KEB HANA\"},{\"code\":\"BANK MANDIRI TASPEN\",\"name\":\"BANK MANDIRI TASPEN\"},{\"code\":\"BANK MAS\",\"name\":\"BANK MAS\"},{\"code\":\"BANK MASPION INDONESIA\",\"name\":\"BANK MASPION INDONESIA\"},{\"code\":\"BANK MAYAPADA\",\"name\":\"BANK MAYAPADA\"},{\"code\":\"BANK MAYBANK\",\"name\":\"BANK MAYBANK\"},{\"code\":\"BANK MAYBANK UU SYARIAH\",\"name\":\"BANK MAYBANK UU SYARIAH\"},{\"code\":\"BANK MEGA\",\"name\":\"BANK MEGA\"},{\"code\":\"BANK MEGA SYARIAH\",\"name\":\"BANK MEGA SYARIAH\"},{\"code\":\"BANK MESTIKA DHARMA\",\"name\":\"BANK MESTIKA DHARMA\"},{\"code\":\"BANK MIZUHO\",\"name\":\"BANK MIZUHO\"},{\"code\":\"BANK MNC INTERNASIONAL\",\"name\":\"BANK MNC INTERNASIONAL\"},{\"code\":\"BANK MUAMALAT\",\"name\":\"BANK MUAMALAT\"},{\"code\":\"BANK NAGARI\",\"name\":\"BANK NAGARI\"},{\"code\":\"BANK NAGARI SYARIAH\",\"name\":\"BANK NAGARI SYARIAH\"},{\"code\":\"BANK NEO COMMERCE\",\"name\":\"BANK NEO COMMERCE\"},{\"code\":\"BANK NOBU\",\"name\":\"BANK NOBU\"},{\"code\":\"BANK OF AMERICA\",\"name\":\"BANK OF AMERICA\"},{\"code\":\"BANK OF CHINA (HKG)\",\"name\":\"BANK OF CHINA (HKG)\"},{\"code\":\"BANK OF INDIA INDONESIA\",\"name\":\"BANK OF INDIA INDONESIA\"},{\"code\":\"BANK OF TOKYO MITSUBISHI UF]\",\"name\":\"BANK OF TOKYO MITSUBISHI UF]\"},{\"code\":\"BANK OKE\",\"name\":\"BANK OKE\"},{\"code\":\"BANK PANIN\",\"name\":\"BANK PANIN\"},{\"code\":\"BANK PANIN SYARIAH\",\"name\":\"BANK PANIN SYARIAH\"},{\"code\":\"BANK PERMATA SYARIAH\",\"name\":\"BANK PERMATA SYARIAH\"},{\"code\":\"BANK ONB INDONESIA\",\"name\":\"BANK ONB INDONESIA\"},{\"code\":\"BANK RAYA INDONESIA\",\"name\":\"BANK RAYA INDONESIA\"},{\"code\":\"BANK RESONA PERDANIA\",\"name\":\"BANK RESONA PERDANIA\"},{\"code\":\"BANK SAHABAT SAMPOERNA\",\"name\":\"BANK SAHABAT SAMPOERNA\"},{\"code\":\"BANK SBIINDONESIA\",\"name\":\"BANK SBIINDONESIA\"},{\"code\":\"BANK SHINHAN INDONESIA\",\"name\":\"BANK SHINHAN INDONESIA\"},{\"code\":\"BANK SINARMAS\",\"name\":\"BANK SINARMAS\"},{\"code\":\"BANK SUMSEL BABEL\",\"name\":\"BANK SUMSEL BABEL\"},{\"code\":\"BANK SUMSEL BABEL SYARIAH\",\"name\":\"BANK SUMSEL BABEL SYARIAH\"},{\"code\":\"BANK UOB\",\"name\":\"BANK UOB\"},{\"code\":\"BANK VICTORIA\",\"name\":\"BANK VICTORIA\"},{\"code\":\"BANK VICTORIA SYARIAH\",\"name\":\"BANK VICTORIA SYARIAH\"},{\"code\":\"BANK WOORI SAUDARA\",\"name\":\"BANK WOORI SAUDARA\"},{\"code\":\"BPD BALI\",\"name\":\"BPD BALI\"},{\"code\":\"BPD DIY\",\"name\":\"BPD DIY\"},{\"code\":\"BPD DIY SYARIAH\",\"name\":\"BPD DIY SYARIAH\"},{\"code\":\"BPD JAMBI\",\"name\":\"BPD JAMBI\"},{\"code\":\"BPD KALSEL\",\"name\":\"BPD KALSEL\"},{\"code\":\"BPD KALSEL SYARIAH\",\"name\":\"BPD KALSEL SYARIAH\"},{\"code\":\"BPD KALTIM KALTARA\",\"name\":\"BPD KALTIM KALTARA\"},{\"code\":\"BPD KALTIM SYARIAH\",\"name\":\"BPD KALTIM SYARIAH\"},{\"code\":\"BPD LAMPUNG\",\"name\":\"BPD LAMPUNG\"},{\"code\":\"BPD MALUKU\",\"name\":\"BPD MALUKU\"},{\"code\":\"BPD NTBS\",\"name\":\"BPD NTBS\"},{\"code\":\"BPD NTT\",\"name\":\"BPD NTT\"},{\"code\":\"BPD PAPUA\",\"name\":\"BPD PAPUA\"},{\"code\":\"BPD RIAU KEPRI\",\"name\":\"BPD RIAU KEPRI\"},{\"code\":\"BPD SULAWESI SELATAN\",\"name\":\"BPD SULAWESI SELATAN\"},{\"code\":\"BPD SULAWESI TENGAH\",\"name\":\"BPD SULAWESI TENGAH\"},{\"code\":\"BPD SULAWESI TENGGARA\",\"name\":\"BPD SULAWESI TENGGARA\"},{\"code\":\"BPD SUMUT\",\"name\":\"BPD SUMUT\"},{\"code\":\"BPD SUMUT SYARIAH\",\"name\":\"BPD SUMUT SYARIAH\"},{\"code\":\"BPR DANAGUNG ABADI\",\"name\":\"BPR DANAGUNG ABADI\"},{\"code\":\"BPR DANAGUNG BAKTI\",\"name\":\"BPR DANAGUNG BAKTI\"},{\"code\":\"BPR DANAGUNG RAMULTI\",\"name\":\"BPR DANAGUNG RAMULTI\"},{\"code\":\"BPR SUPRA\",\"name\":\"BPR SUPRA\"},{\"code\":\"Bank Krom Indonesia\",\"name\":\"Bank Krom Indonesia\"},{\"code\":\"Bank SulutGo\",\"name\":\"Bank SulutGo\"},{\"code\":\"Bank Super indonesia\",\"name\":\"Bank Super indonesia\"},{\"code\":\"CITIBANK\",\"name\":\"CITIBANK\"},{\"code\":\"DOKU\",\"name\":\"DOKU\"},{\"code\":\"HSBC INDONESIA\",\"name\":\"HSBC INDONESIA\"},{\"code\":\"JPMORGAN CHASE BANK\",\"name\":\"JPMORGAN CHASE BANK\"},{\"code\":\"LINKAJA\",\"name\":\"LINKAJA\"},{\"code\":\"PAYPRO\",\"name\":\"PAYPRO\"},{\"code\":\"PT ALLO BANK INDONESIA\",\"name\":\"PT ALLO BANK INDONESIA\"},{\"code\":\"PT BANK NANO SYARIAH\",\"name\":\"PT BANK NANO SYARIAH\"},{\"code\":\"PT BANK SMBC INDONESIA TBK\",\"name\":\"PT BANK SMBC INDONESIA TBK\"},{\"code\":\"PT Bank Hibank Indonesia\",\"name\":\"PT Bank Hibank Indonesia\"},{\"code\":\"PT. BANK CHINA CONSTRUCTION INDONESIA(CCBI)\",\"name\":\"PT. BANK CHINA CONSTRUCTION INDONESIA(CCBI)\"},{\"code\":\"PT. BANK IBK INDONESIA\",\"name\":\"PT. BANK IBK INDONESIA\"},{\"code\":\"STANDARD CHARTERED\",\"name\":\"STANDARD CHARTERED\"},{\"code\":\"LinkAja\",\"name\":\"LinkAja\"},{\"code\":\"OVO\",\"name\":\"OVO\"},{\"code\":\"ShopeePay\",\"name\":\"ShopeePay\"},{\"code\":\"i.saku\",\"name\":\"i.saku\"},{\"code\":\"Gopay Customer\",\"name\":\"Gopay Customer\"},{\"code\":\"DANA\",\"name\":\"DANA\"}]'),(19,'Pindai QR-04','Pindai QR-04','Pindai QR-04','NasklPay-104004','博创-104004',1764347569,0,'104004','zx','NasklPay',18,51,'/static/bank/rp.png',2,2,0,NULL),(20,'NasklPay-104007','NasklPay-104007','NasklPay-104007','NasklPay-104007','NasklPay-104007',1758448222,0,'104007','zx','NasklPay',19,0,'/static/bank/rp.png',2,2,0,NULL),(21,'Dompet Digital','Dompet Digital','Dompet Digital','NasklPay-202001','博创代付-202001',1764347621,1,'202001','zx','NasklPay',20,49,'/static/bank/rp.png',2,1,1,'[{\"code\":\"BANK_IF1\",\"name\":\"Bank IF1\"},{\"code\":\"BANK_HAGA\",\"name\":\"Bank Haga\"},{\"code\":\"BANK_ANTAR\",\"name\":\"Bank Antardaeah\"},{\"code\":\"BANK_EKONOMI\",\"name\":\"Bank Ekonomi\"},{\"code\":\"BUMI_ARTA\",\"name\":\"Bank Bumi Arta\"},{\"code\":\"BOC\",\"name\":\"Bank OF China\"},{\"code\":\"BANK_WOOR\",\"name\":\"Bank Woori Indonesia\"},{\"code\":\"DEUTSCHE\",\"name\":\"Deutsche Bank AG.\"},{\"code\":\"BANK_ANZ\",\"name\":\"Bank ANZ Indonesia\"},{\"code\":\"BANK_DANAMON\",\"name\":\"Korea Exchange Bank Danamon\"},{\"code\":\"BNP_PARIBAS\",\"name\":\"Bank BNP Paribas Indonesia\"},{\"code\":\"CAPITAL\",\"name\":\"Bank Capital Indonesia\"},{\"code\":\"BANK_KEPPEL\",\"name\":\"Bank Keppel Tatlee Buana\"},{\"code\":\"BANK_A\",\"name\":\"Bank ABN Amro\"},{\"code\":\"STANDARD_CHARTERED\",\"name\":\"Standard Chartered Bank\"},{\"code\":\"MIZUHO\",\"name\":\"Bank Mizuho Indonesia\"},{\"code\":\"RESONA\",\"name\":\"Bank Resona Perdania\"},{\"code\":\"DBS\",\"name\":\"Bank DBS Indonesia\"},{\"code\":\"MITSUI\",\"name\":\"Bank Sumitomo Mitsui Indonesia\"},{\"code\":\"BANK_TOKYO\",\"name\":\"The Bank of Tokyo Mitsubishi UFJ LTD\"},{\"code\":\"HSBC\",\"name\":\"The Hongkong & Shanghai B.C. (Bank HSBC)\"},{\"code\":\"BANK_COMP\",\"name\":\"The Bangkok Bank Comp. LTD\"},{\"code\":\"BANK_C_AGR\",\"name\":\"Credit Agricole Indosuez\"},{\"code\":\"ARTHA\",\"name\":\"Bank Artha Graha Internasional\"},{\"code\":\"BANK_ING\",\"name\":\"ING Indonesia Bank\"},{\"code\":\"BAML\",\"name\":\"Bank of America, N.A\"},{\"code\":\"JPMORGAN\",\"name\":\"JP. Morgan Chase Bank, N.A\"},{\"code\":\"CITIBANK\",\"name\":\"Citibank\"},{\"code\":\"NISP\",\"name\":\"Bank OCBC NISP\"},{\"code\":\"BANK_LIPPO\",\"name\":\"Bank Lippo\"},{\"code\":\"CIMB\",\"name\":\"Bank CIMB Niaga\"},{\"code\":\"ARTA_NIAGA_KENCANA\",\"name\":\"Bank Arta Niaga Kencana\"},{\"code\":\"PANIN\",\"name\":\"Bank Panin\"},{\"code\":\"MAYBANK\",\"name\":\"Bank Bll Maybank\"},{\"code\":\"BCA\",\"name\":\"Bank BCA\"},{\"code\":\"PERMATA\",\"name\":\"Permata Bank\"},{\"code\":\"DANAMON\",\"name\":\"Bank Danamon\"},{\"code\":\"BNI\",\"name\":\"Bank BNI\"},{\"code\":\"MANDIRI\",\"name\":\"Bank Mandiri\"},{\"code\":\"EXIMBANK\",\"name\":\"Bank Ekspor Indonesia\"},{\"code\":\"BRI\",\"name\":\"Bank BRI\"},{\"code\":\"BANK_BUANA\",\"name\":\"Bank UOB Indonesia\"},{\"code\":\"AGRONIAGA\",\"name\":\"Bank BRI Agro\"},{\"code\":\"BANK_ABN\",\"name\":\"Bank ABN Amro\"},{\"code\":\"BANK_SEA\",\"name\":\"SEABANK INDONESIA\"},{\"code\":\"CHINATRUST\",\"name\":\"Bank CTBC (China Trust) Indonesia\"},{\"code\":\"BANK_MAYBANK\",\"name\":\"Bank Maybank Indocorp\"},{\"code\":\"BANK_MERIN\",\"name\":\"Bank Merincorp\"},{\"code\":\"BANK_AGRIS\",\"name\":\"Bank Agris\"},{\"code\":\"DOMPETKU\",\"name\":\"Indosat Dompetku\"},{\"code\":\"BPR_KS\",\"name\":\"BPR KS\"},{\"code\":\"HARDA_INTERNASIONAL\",\"name\":\"Bank Harda\"},{\"code\":\"BANK_VICTORIA\",\"name\":\"Bank Victoria International\"},{\"code\":\"MANDIRI_TASPEN\",\"name\":\"Bank Mandiri Taspen Pos\"},{\"code\":\"FAMA\",\"name\":\"Bank Fama Internasional\"},{\"code\":\"CENTRATAMA\",\"name\":\"Centratama Nasional Bank\"},{\"code\":\"INDEX_SELINDO\",\"name\":\"Bank Index Selindo\"},{\"code\":\"MAYORA\",\"name\":\"Bank Mayora Indonesia\"},{\"code\":\"MULTI_ARTA_SENTOSA\",\"name\":\"Bank Multi Arta Sentosa\"},{\"code\":\"BTPN_SYARIAH\",\"name\":\"Bank Purba Danarta\"},{\"code\":\"ARTOS\",\"name\":\"Bank Artos IND\"},{\"code\":\"BCA_SYR\",\"name\":\"Bank BCA Syariah\"},{\"code\":\"KESEJAHTERAAN_EKONOMI\",\"name\":\"Bank Kesejahteraan Ekonomi\"},{\"code\":\"BANK_ANGLOMAS\",\"name\":\"Anglomas Internasional Bank\"},{\"code\":\"BALI_BPD\",\"name\":\"Bali\"},{\"code\":\"BPD_NTB\",\"name\":\"Bank NTB, NTB Syariah\"},{\"code\":\"SUMSEL_DAN_BABEL_SULUT\",\"name\":\"Bank Sulut Gorontalo\"},{\"code\":\"SULSELBAR\",\"name\":\"Bank Sulsel dan Barat\"},{\"code\":\"BPD_KALTENG\",\"name\":\"Bank Kalteng\"},{\"code\":\"BPD_KAITIM\",\"name\":\"Bank Kalimantan Timur dan Utara\"},{\"code\":\"KALIMANTAN_BARAT\",\"name\":\"Bank Kalimantan Barat\"},{\"code\":\"BPD_KALSEL\",\"name\":\"Bank Kalsel\"},{\"code\":\"LAMPUNG\",\"name\":\"Bank Lampung\"},{\"code\":\"SUMSEL_DAN_BABEL\",\"name\":\"Bank Sumsel Babel\"},{\"code\":\"RIAU_DAN_KEPRI\",\"name\":\"Bank Riau\"},{\"code\":\"BANK_NAGARI\",\"name\":\"Bank Nagari\"},{\"code\":\"SUMUT\",\"name\":\"Bank Sumut\"},{\"code\":\"ACEHBPDAceh\",\"name\":\"BPD Aceh Syariah\"},{\"code\":\"JAMBI\",\"name\":\"BPD Jambi\"},{\"code\":\"BANK_JATIM\",\"name\":\"Bank Jatim\"},{\"code\":\"BANK_JATENG\",\"name\":\"Bank Jateng\"},{\"code\":\"DAERAH_ISTIMEWA\",\"name\":\"BPD DIY\"},{\"code\":\"DKI\",\"name\":\"Bank DKI\"},{\"code\":\"BANK_JABAR\",\"name\":\"Bank Jabar dan Banten (BJB)\"},{\"code\":\"MAYAPADA\",\"name\":\"Bank Mayapada\"},{\"code\":\"JTRUST\",\"name\":\"Bank JTRUST\"},{\"code\":\"BANK_SWAGUNA\",\"name\":\"Bank Swaguna\"},{\"code\":\"JENIUS\",\"name\":\"JENIUS\"},{\"code\":\"BANK_HIM\",\"name\":\"Bank Himpunan Saudara 1906\"},{\"code\":\"BTN\",\"name\":\"Bank Tabungan Negara (BTN)\"},{\"code\":\"QNB_INDONESIA\",\"name\":\"Bank QNB Kesawan (Bank QNB Indonesia)\"},{\"code\":\"BANK_HARM\",\"name\":\"Bank Harmoni International\"},{\"code\":\"ICBC Halim Indonesia\",\"name\":\"Bank (Bank ICBC Indonesia)\"},{\"code\":\"CCB\",\"name\":\"Bank Windu Kentjana\"},{\"code\":\"GANESHA\",\"name\":\"Bank Ganesha\"},{\"code\":\"BANK_HAGAKITA\",\"name\":\"Bank Hagakita\"},{\"code\":\"MASPION\",\"name\":\"Bank Maspion Indonesia\"},{\"code\":\"SINARMAS_UUS\",\"name\":\"Bank Sinarmas\"},{\"code\":\"SHINHAN\",\"name\":\"Bank Metro Express (Bank Shinhan Indonesia)\"},{\"code\":\"MESTIKA_DHARMA\",\"name\":\"Bank Mestika Dharma\"},{\"code\":\"MUAMALAT\",\"name\":\"Bank Muamalat\"},{\"code\":\"BANK_OF_INDIA\",\"name\":\"Bank of India Indonesia\"},{\"code\":\"NUSANTARA_PARAHYANGAN\",\"name\":\"Bank Nusantara Parahyangan\"},{\"code\":\"BANK_SULTRA\",\"name\":\"Bank Sultra\"},{\"code\":\"SULAWESI\",\"name\":\"Bank Sulawesi Tengah\"},{\"code\":\"BENGKULU\",\"name\":\"Bank Bengkulu\"},{\"code\":\"PAPUA\",\"name\":\"Bank Papua\"},{\"code\":\"MALUKU\",\"name\":\"Bank Maluku Malut\"},{\"code\":\"BANK_NTT\",\"name\":\"Bank NTT\"},{\"code\":\"BANK_LIMAN\",\"name\":\"Liman International Bank\"},{\"code\":\"BANK_AKITA\",\"name\":\"Bank Akita\"},{\"code\":\"OCBC\",\"name\":\"Bank Dipo International (Bank Sahabat Sampoerna)\"},{\"code\":\"BANK_PERSY\",\"name\":\"Bank Persyarikatan Indonesia\"},{\"code\":\"PRIMA_MASTER\",\"name\":\"Prima Master Bank\"},{\"code\":\"BANK_HARFA\",\"name\":\"Bank Harfa\"},{\"code\":\"BANK_INA\",\"name\":\"Bank Ina Perdana\"},{\"code\":\"MEGA_SYR\",\"name\":\"Bank Syariah Mega\"},{\"code\":\"NATIONALNOBU\",\"name\":\"Bank Alfindo (Bank National Nobu)\"},{\"code\":\"ROYAL\",\"name\":\"Bank Royal Indonesia\"},{\"code\":\"BANK_INDOMONEX\",\"name\":\"ank Indomonex (Bank SBI Indonesia)\"},{\"code\":\"BANK_YUDHA\",\"name\":\"Bank Yudha Bhakti\"},{\"code\":\"BANK_BUMPUTERA\",\"name\":\"Bank MNC \\/ Bank Bumiputera\"},{\"code\":\"BANK_BINTANG\",\"name\":\"Bank Bintang Manunggal\"},{\"code\":\"JASA_JAKARTA\",\"name\":\"Bank Jasa Jakarta\"},{\"code\":\"BANK_SRI_PARTHA\",\"name\":\"Bank Sri Partha\"},{\"code\":\"BISNIS_INTERNASION\",\"name\":\"Bank Bisnis Internasional\"},{\"code\":\"MANDIRI_SYR\",\"name\":\"Bank Syariah Mandiri(BSI)\"},{\"code\":\"BUKOPIN\",\"name\":\"Bank Bukopin\"},{\"code\":\"BNI_SYR\",\"name\":\"Bank BNI Syariah\"},{\"code\":\"BCA\",\"name\":\"BCA Virtual Account\"},{\"code\":\"M1\",\"name\":\"Mandiri Virtual Account\"},{\"code\":\"NBT\",\"name\":\"Permata Bank Virtual Account\"},{\"code\":\"B1\",\"name\":\"CIMB Niaga Virtual Account\"},{\"code\":\"I1\",\"name\":\"BNI Virtual Account\"},{\"code\":\"VA\",\"name\":\"Maybank Virtual Account\"},{\"code\":\"BRI\",\"name\":\"BRI Virtual Account\"},{\"code\":\"I2\",\"name\":\"Danamon Virtual Account\"},{\"code\":\"BNC\",\"name\":\"BANK NEO COMMERCE\"},{\"code\":\"LINKAJA\",\"name\":\"LINKAJA钱包\"},{\"code\":\"OVO\",\"name\":\"OVO电子钱包\"},{\"code\":\"DANA\",\"name\":\"DANA电子钱包\"},{\"code\":\"GOPAY\",\"name\":\"GOPAY电子钱包\"},{\"code\":\"SHOPEEPAY\",\"name\":\"SHOPEEPAY电子钱包\"},{\"code\":\"LINKAJA\",\"name\":\"LINKAJA钱包\"}]'),(22,'Dompet Digital-01','Dompet Digital-01','Dompet Digital-01','NasklPay-104001','博创-104001',1760525065,0,'104001','zx','NasklPay',21,50,'/static/bank/rp.png',2,2,0,NULL),(23,'Ht-AD999','Ht-AD999','Ht-AD999','Ht-AD999','宏图代付-AD999',1761567088,0,'AD999','zx','HtPay',22,45,'/static/bank/rp.png',2,1,1,'[{\"code\":\"OCBC\",\"name\":\"OCBC\"},{\"code\":\"BANK BCA\",\"name\":\"BANK BCA\"},{\"code\":\"BANK CIMB NIAGA\",\"name\":\"BANK CIMB NIAGA\"},{\"code\":\"BANK BRI\",\"name\":\"BANK BRI\"},{\"code\":\"BANK MANDIRI\",\"name\":\"BANK MANDIRI\"},{\"code\":\"BANK BNI\",\"name\":\"BANK BNI\"},{\"code\":\"BANK SEABANK INDONESIA\",\"name\":\"BANK SEABANK INDONESIA\"},{\"code\":\"BANK SYARIAH INDONESIA\",\"name\":\"BANK SYARIAH INDONESIA\"},{\"code\":\"BANK PERMATA\",\"name\":\"BANK PERMATA\"},{\"code\":\"BANK BTN\",\"name\":\"BANK BTN\"},{\"code\":\"BANK JAGO\",\"name\":\"BANK JAGO\"},{\"code\":\"BANK ACEH SYARIAH\",\"name\":\"BANK ACEH SYARIAH\"},{\"code\":\"BANK ALADIN\",\"name\":\"BANK ALADIN\"},{\"code\":\"BANK AMAR INDONESIA\",\"name\":\"BANK AMAR INDONESIA\"},{\"code\":\"BANK ANZ\",\"name\":\"BANK ANZ\"},{\"code\":\"BANK ARTHA GRAHA\",\"name\":\"BANK ARTHA GRAHA\"},{\"code\":\"BANK BANTEN\",\"name\":\"BANK BANTEN\"},{\"code\":\"BANK BCA SYARIAH\",\"name\":\"BANK BCA SYARIAH\"},{\"code\":\"BANK BENGKULU\",\"name\":\"BANK BENGKULU\"},{\"code\":\"BANK BJB\",\"name\":\"BANK BJB\"},{\"code\":\"BANK BJB SYARIAH\",\"name\":\"BANK BJB SYARIAH\"},{\"code\":\"BANK BNP PARIBAS\",\"name\":\"BANK BNP PARIBAS\"},{\"code\":\"BANK BPR KS\",\"name\":\"BANK BPR KS\"},{\"code\":\"BANK BTN SYARIAH\",\"name\":\"BANK BTN SYARIAH\"},{\"code\":\"BANK BTPN SYARIAH\",\"name\":\"BANK BTPN SYARIAH\"},{\"code\":\"BANK BUKOPIN SYARIAH\",\"name\":\"BANK BUKOPIN SYARIAH\"},{\"code\":\"BANK BUMI ARTA\",\"name\":\"BANK BUMI ARTA\"},{\"code\":\"BANK CAPITAL\",\"name\":\"BANK CAPITAL\"},{\"code\":\"BANK CHINATRUST\",\"name\":\"BANK CHINATRUST\"},{\"code\":\"BANK CIMB NIAGA SYARIAH\",\"name\":\"BANK CIMB NIAGA SYARIAH\"},{\"code\":\"BANK DANAMON\",\"name\":\"BANK DANAMON\"},{\"code\":\"BANK DANAMON SYARIAH\",\"name\":\"BANK DANAMON SYARIAH\"},{\"code\":\"BANK DBS\",\"name\":\"BANK DBS\"},{\"code\":\"BANK DEUTSCHE\",\"name\":\"BANK DEUTSCHE\"},{\"code\":\"BANK DIGITAL BCA\",\"name\":\"BANK DIGITAL BCA\"},{\"code\":\"BANK DKI\",\"name\":\"BANK DKI\"},{\"code\":\"BANK DKI SYARIAH\",\"name\":\"BANK DKI SYARIAH\"},{\"code\":\"BANK EKA\",\"name\":\"BANK EKA\"},{\"code\":\"BANK GANESHA\",\"name\":\"BANK GANESHA\"},{\"code\":\"BANK ICBC\",\"name\":\"BANK ICBC\"},{\"code\":\"BANK INA PERDANA\",\"name\":\"BANK INA PERDANA\"},{\"code\":\"BANK INDEX\",\"name\":\"BANK INDEX\"},{\"code\":\"BANK INTERIM INDONESIA\",\"name\":\"BANK INTERIM INDONESIA\"},{\"code\":\"BANK JAGO UU SYARIAH\",\"name\":\"BANK JAGO UU SYARIAH\"},{\"code\":\"BANK JASA JAKARTA\",\"name\":\"BANK JASA JAKARTA\"},{\"code\":\"BANK JATENG\",\"name\":\"BANK JATENG\"},{\"code\":\"BANK JATENG SYARIAH\",\"name\":\"BANK JATENG SYARIAH\"},{\"code\":\"BANK JATIM\",\"name\":\"BANK JATIM\"},{\"code\":\"BANK JATIM SYARIAH\",\"name\":\"BANK JATIM SYARIAH\"},{\"code\":\"BANK JTRUST INDONESIA\",\"name\":\"BANK JTRUST INDONESIA\"},{\"code\":\"BANK KALBAR\",\"name\":\"BANK KALBAR\"},{\"code\":\"BANK KALBAR SYARIAH\",\"name\":\"BANK KALBAR SYARIAH\"},{\"code\":\"BANK KALTENG\",\"name\":\"BANK KALTENG\"},{\"code\":\"BANK KB BUKOPIN\",\"name\":\"BANK KB BUKOPIN\"},{\"code\":\"BANK KEB HANA\",\"name\":\"BANK KEB HANA\"},{\"code\":\"BANK MANDIRI TASPEN\",\"name\":\"BANK MANDIRI TASPEN\"},{\"code\":\"BANK MAS\",\"name\":\"BANK MAS\"},{\"code\":\"BANK MASPION INDONESIA\",\"name\":\"BANK MASPION INDONESIA\"},{\"code\":\"BANK MAYAPADA\",\"name\":\"BANK MAYAPADA\"},{\"code\":\"BANK MAYBANK\",\"name\":\"BANK MAYBANK\"},{\"code\":\"BANK MAYBANK UU SYARIAH\",\"name\":\"BANK MAYBANK UU SYARIAH\"},{\"code\":\"BANK MEGA\",\"name\":\"BANK MEGA\"},{\"code\":\"BANK MEGA SYARIAH\",\"name\":\"BANK MEGA SYARIAH\"},{\"code\":\"BANK MESTIKA DHARMA\",\"name\":\"BANK MESTIKA DHARMA\"},{\"code\":\"BANK MIZUHO\",\"name\":\"BANK MIZUHO\"},{\"code\":\"BANK MNC INTERNASIONAL\",\"name\":\"BANK MNC INTERNASIONAL\"},{\"code\":\"BANK MUAMALAT\",\"name\":\"BANK MUAMALAT\"},{\"code\":\"BANK NAGARI\",\"name\":\"BANK NAGARI\"},{\"code\":\"BANK NAGARI SYARIAH\",\"name\":\"BANK NAGARI SYARIAH\"},{\"code\":\"BANK NEO COMMERCE\",\"name\":\"BANK NEO COMMERCE\"},{\"code\":\"BANK NOBU\",\"name\":\"BANK NOBU\"},{\"code\":\"BANK OF AMERICA\",\"name\":\"BANK OF AMERICA\"},{\"code\":\"BANK OF CHINA (HKG)\",\"name\":\"BANK OF CHINA (HKG)\"},{\"code\":\"BANK OF INDIA INDONESIA\",\"name\":\"BANK OF INDIA INDONESIA\"},{\"code\":\"BANK OF TOKYO MITSUBISHI UF]\",\"name\":\"BANK OF TOKYO MITSUBISHI UF]\"},{\"code\":\"BANK OKE\",\"name\":\"BANK OKE\"},{\"code\":\"BANK PANIN\",\"name\":\"BANK PANIN\"},{\"code\":\"BANK PANIN SYARIAH\",\"name\":\"BANK PANIN SYARIAH\"},{\"code\":\"BANK PERMATA SYARIAH\",\"name\":\"BANK PERMATA SYARIAH\"},{\"code\":\"BANK ONB INDONESIA\",\"name\":\"BANK ONB INDONESIA\"},{\"code\":\"BANK RAYA INDONESIA\",\"name\":\"BANK RAYA INDONESIA\"},{\"code\":\"BANK RESONA PERDANIA\",\"name\":\"BANK RESONA PERDANIA\"},{\"code\":\"BANK SAHABAT SAMPOERNA\",\"name\":\"BANK SAHABAT SAMPOERNA\"},{\"code\":\"BANK SBIINDONESIA\",\"name\":\"BANK SBIINDONESIA\"},{\"code\":\"BANK SHINHAN INDONESIA\",\"name\":\"BANK SHINHAN INDONESIA\"},{\"code\":\"BANK SINARMAS\",\"name\":\"BANK SINARMAS\"},{\"code\":\"BANK SUMSEL BABEL\",\"name\":\"BANK SUMSEL BABEL\"},{\"code\":\"BANK SUMSEL BABEL SYARIAH\",\"name\":\"BANK SUMSEL BABEL SYARIAH\"},{\"code\":\"BANK UOB\",\"name\":\"BANK UOB\"},{\"code\":\"BANK VICTORIA\",\"name\":\"BANK VICTORIA\"},{\"code\":\"BANK VICTORIA SYARIAH\",\"name\":\"BANK VICTORIA SYARIAH\"},{\"code\":\"BANK WOORI SAUDARA\",\"name\":\"BANK WOORI SAUDARA\"},{\"code\":\"BPD BALI\",\"name\":\"BPD BALI\"},{\"code\":\"BPD DIY\",\"name\":\"BPD DIY\"},{\"code\":\"BPD DIY SYARIAH\",\"name\":\"BPD DIY SYARIAH\"},{\"code\":\"BPD JAMBI\",\"name\":\"BPD JAMBI\"},{\"code\":\"BPD KALSEL\",\"name\":\"BPD KALSEL\"},{\"code\":\"BPD KALSEL SYARIAH\",\"name\":\"BPD KALSEL SYARIAH\"},{\"code\":\"BPD KALTIM KALTARA\",\"name\":\"BPD KALTIM KALTARA\"},{\"code\":\"BPD KALTIM SYARIAH\",\"name\":\"BPD KALTIM SYARIAH\"},{\"code\":\"BPD LAMPUNG\",\"name\":\"BPD LAMPUNG\"},{\"code\":\"BPD MALUKU\",\"name\":\"BPD MALUKU\"},{\"code\":\"BPD NTBS\",\"name\":\"BPD NTBS\"},{\"code\":\"BPD NTT\",\"name\":\"BPD NTT\"},{\"code\":\"BPD PAPUA\",\"name\":\"BPD PAPUA\"},{\"code\":\"BPD RIAU KEPRI\",\"name\":\"BPD RIAU KEPRI\"},{\"code\":\"BPD SULAWESI SELATAN\",\"name\":\"BPD SULAWESI SELATAN\"},{\"code\":\"BPD SULAWESI TENGAH\",\"name\":\"BPD SULAWESI TENGAH\"},{\"code\":\"BPD SULAWESI TENGGARA\",\"name\":\"BPD SULAWESI TENGGARA\"},{\"code\":\"BPD SUMUT\",\"name\":\"BPD SUMUT\"},{\"code\":\"BPD SUMUT SYARIAH\",\"name\":\"BPD SUMUT SYARIAH\"},{\"code\":\"BPR DANAGUNG ABADI\",\"name\":\"BPR DANAGUNG ABADI\"},{\"code\":\"BPR DANAGUNG BAKTI\",\"name\":\"BPR DANAGUNG BAKTI\"},{\"code\":\"BPR DANAGUNG RAMULTI\",\"name\":\"BPR DANAGUNG RAMULTI\"},{\"code\":\"BPR SUPRA\",\"name\":\"BPR SUPRA\"},{\"code\":\"Bank Krom Indonesia\",\"name\":\"Bank Krom Indonesia\"},{\"code\":\"Bank SulutGo\",\"name\":\"Bank SulutGo\"},{\"code\":\"Bank Super indonesia\",\"name\":\"Bank Super indonesia\"},{\"code\":\"CITIBANK\",\"name\":\"CITIBANK\"},{\"code\":\"DOKU\",\"name\":\"DOKU\"},{\"code\":\"HSBC INDONESIA\",\"name\":\"HSBC INDONESIA\"},{\"code\":\"JPMORGAN CHASE BANK\",\"name\":\"JPMORGAN CHASE BANK\"},{\"code\":\"LINKAJA\",\"name\":\"LINKAJA\"},{\"code\":\"PAYPRO\",\"name\":\"PAYPRO\"},{\"code\":\"PT ALLO BANK INDONESIA\",\"name\":\"PT ALLO BANK INDONESIA\"},{\"code\":\"PT BANK NANO SYARIAH\",\"name\":\"PT BANK NANO SYARIAH\"},{\"code\":\"PT BANK SMBC INDONESIA TBK\",\"name\":\"PT BANK SMBC INDONESIA TBK\"},{\"code\":\"PT Bank Hibank Indonesia\",\"name\":\"PT Bank Hibank Indonesia\"},{\"code\":\"PT. BANK CHINA CONSTRUCTION INDONESIA(CCBI)\",\"name\":\"PT. BANK CHINA CONSTRUCTION INDONESIA(CCBI)\"},{\"code\":\"PT. BANK IBK INDONESIA\",\"name\":\"PT. BANK IBK INDONESIA\"},{\"code\":\"STANDARD CHARTERED\",\"name\":\"STANDARD CHARTERED\"},{\"code\":\"LinkAja\",\"name\":\"LinkAja\"},{\"code\":\"OVO\",\"name\":\"OVO\"},{\"code\":\"ShopeePay\",\"name\":\"ShopeePay\"},{\"code\":\"i.saku\",\"name\":\"i.saku\"},{\"code\":\"Gopay Customer\",\"name\":\"Gopay Customer\"},{\"code\":\"DANA\",\"name\":\"DANA\"}]\n'),(24,'Ht-9230','Ht-9230','Ht-9230','Ht-9230','宏图代付-9230',1761567083,0,'9230','zx','HtPay',23,44,'/static/bank/rp.png',0,1,1,'[{\"code\":\"OCBC\",\"name\":\"OCBC\"},{\"code\":\"BANK BCA\",\"name\":\"BANK BCA\"},{\"code\":\"BANK CIMB NIAGA\",\"name\":\"BANK CIMB NIAGA\"},{\"code\":\"BANK BRI\",\"name\":\"BANK BRI\"},{\"code\":\"BANK MANDIRI\",\"name\":\"BANK MANDIRI\"},{\"code\":\"BANK BNI\",\"name\":\"BANK BNI\"},{\"code\":\"BANK SEABANK INDONESIA\",\"name\":\"BANK SEABANK INDONESIA\"},{\"code\":\"BANK SYARIAH INDONESIA\",\"name\":\"BANK SYARIAH INDONESIA\"},{\"code\":\"BANK PERMATA\",\"name\":\"BANK PERMATA\"},{\"code\":\"BANK BTN\",\"name\":\"BANK BTN\"},{\"code\":\"BANK JAGO\",\"name\":\"BANK JAGO\"},{\"code\":\"BANK ACEH SYARIAH\",\"name\":\"BANK ACEH SYARIAH\"},{\"code\":\"BANK ALADIN\",\"name\":\"BANK ALADIN\"},{\"code\":\"BANK AMAR INDONESIA\",\"name\":\"BANK AMAR INDONESIA\"},{\"code\":\"BANK ANZ\",\"name\":\"BANK ANZ\"},{\"code\":\"BANK ARTHA GRAHA\",\"name\":\"BANK ARTHA GRAHA\"},{\"code\":\"BANK BANTEN\",\"name\":\"BANK BANTEN\"},{\"code\":\"BANK BCA SYARIAH\",\"name\":\"BANK BCA SYARIAH\"},{\"code\":\"BANK BENGKULU\",\"name\":\"BANK BENGKULU\"},{\"code\":\"BANK BJB\",\"name\":\"BANK BJB\"},{\"code\":\"BANK BJB SYARIAH\",\"name\":\"BANK BJB SYARIAH\"},{\"code\":\"BANK BNP PARIBAS\",\"name\":\"BANK BNP PARIBAS\"},{\"code\":\"BANK BPR KS\",\"name\":\"BANK BPR KS\"},{\"code\":\"BANK BTN SYARIAH\",\"name\":\"BANK BTN SYARIAH\"},{\"code\":\"BANK BTPN SYARIAH\",\"name\":\"BANK BTPN SYARIAH\"},{\"code\":\"BANK BUKOPIN SYARIAH\",\"name\":\"BANK BUKOPIN SYARIAH\"},{\"code\":\"BANK BUMI ARTA\",\"name\":\"BANK BUMI ARTA\"},{\"code\":\"BANK CAPITAL\",\"name\":\"BANK CAPITAL\"},{\"code\":\"BANK CHINATRUST\",\"name\":\"BANK CHINATRUST\"},{\"code\":\"BANK CIMB NIAGA SYARIAH\",\"name\":\"BANK CIMB NIAGA SYARIAH\"},{\"code\":\"BANK DANAMON\",\"name\":\"BANK DANAMON\"},{\"code\":\"BANK DANAMON SYARIAH\",\"name\":\"BANK DANAMON SYARIAH\"},{\"code\":\"BANK DBS\",\"name\":\"BANK DBS\"},{\"code\":\"BANK DEUTSCHE\",\"name\":\"BANK DEUTSCHE\"},{\"code\":\"BANK DIGITAL BCA\",\"name\":\"BANK DIGITAL BCA\"},{\"code\":\"BANK DKI\",\"name\":\"BANK DKI\"},{\"code\":\"BANK DKI SYARIAH\",\"name\":\"BANK DKI SYARIAH\"},{\"code\":\"BANK EKA\",\"name\":\"BANK EKA\"},{\"code\":\"BANK GANESHA\",\"name\":\"BANK GANESHA\"},{\"code\":\"BANK ICBC\",\"name\":\"BANK ICBC\"},{\"code\":\"BANK INA PERDANA\",\"name\":\"BANK INA PERDANA\"},{\"code\":\"BANK INDEX\",\"name\":\"BANK INDEX\"},{\"code\":\"BANK INTERIM INDONESIA\",\"name\":\"BANK INTERIM INDONESIA\"},{\"code\":\"BANK JAGO UU SYARIAH\",\"name\":\"BANK JAGO UU SYARIAH\"},{\"code\":\"BANK JASA JAKARTA\",\"name\":\"BANK JASA JAKARTA\"},{\"code\":\"BANK JATENG\",\"name\":\"BANK JATENG\"},{\"code\":\"BANK JATENG SYARIAH\",\"name\":\"BANK JATENG SYARIAH\"},{\"code\":\"BANK JATIM\",\"name\":\"BANK JATIM\"},{\"code\":\"BANK JATIM SYARIAH\",\"name\":\"BANK JATIM SYARIAH\"},{\"code\":\"BANK JTRUST INDONESIA\",\"name\":\"BANK JTRUST INDONESIA\"},{\"code\":\"BANK KALBAR\",\"name\":\"BANK KALBAR\"},{\"code\":\"BANK KALBAR SYARIAH\",\"name\":\"BANK KALBAR SYARIAH\"},{\"code\":\"BANK KALTENG\",\"name\":\"BANK KALTENG\"},{\"code\":\"BANK KB BUKOPIN\",\"name\":\"BANK KB BUKOPIN\"},{\"code\":\"BANK KEB HANA\",\"name\":\"BANK KEB HANA\"},{\"code\":\"BANK MANDIRI TASPEN\",\"name\":\"BANK MANDIRI TASPEN\"},{\"code\":\"BANK MAS\",\"name\":\"BANK MAS\"},{\"code\":\"BANK MASPION INDONESIA\",\"name\":\"BANK MASPION INDONESIA\"},{\"code\":\"BANK MAYAPADA\",\"name\":\"BANK MAYAPADA\"},{\"code\":\"BANK MAYBANK\",\"name\":\"BANK MAYBANK\"},{\"code\":\"BANK MAYBANK UU SYARIAH\",\"name\":\"BANK MAYBANK UU SYARIAH\"},{\"code\":\"BANK MEGA\",\"name\":\"BANK MEGA\"},{\"code\":\"BANK MEGA SYARIAH\",\"name\":\"BANK MEGA SYARIAH\"},{\"code\":\"BANK MESTIKA DHARMA\",\"name\":\"BANK MESTIKA DHARMA\"},{\"code\":\"BANK MIZUHO\",\"name\":\"BANK MIZUHO\"},{\"code\":\"BANK MNC INTERNASIONAL\",\"name\":\"BANK MNC INTERNASIONAL\"},{\"code\":\"BANK MUAMALAT\",\"name\":\"BANK MUAMALAT\"},{\"code\":\"BANK NAGARI\",\"name\":\"BANK NAGARI\"},{\"code\":\"BANK NAGARI SYARIAH\",\"name\":\"BANK NAGARI SYARIAH\"},{\"code\":\"BANK NEO COMMERCE\",\"name\":\"BANK NEO COMMERCE\"},{\"code\":\"BANK NOBU\",\"name\":\"BANK NOBU\"},{\"code\":\"BANK OF AMERICA\",\"name\":\"BANK OF AMERICA\"},{\"code\":\"BANK OF CHINA (HKG)\",\"name\":\"BANK OF CHINA (HKG)\"},{\"code\":\"BANK OF INDIA INDONESIA\",\"name\":\"BANK OF INDIA INDONESIA\"},{\"code\":\"BANK OF TOKYO MITSUBISHI UF]\",\"name\":\"BANK OF TOKYO MITSUBISHI UF]\"},{\"code\":\"BANK OKE\",\"name\":\"BANK OKE\"},{\"code\":\"BANK PANIN\",\"name\":\"BANK PANIN\"},{\"code\":\"BANK PANIN SYARIAH\",\"name\":\"BANK PANIN SYARIAH\"},{\"code\":\"BANK PERMATA SYARIAH\",\"name\":\"BANK PERMATA SYARIAH\"},{\"code\":\"BANK ONB INDONESIA\",\"name\":\"BANK ONB INDONESIA\"},{\"code\":\"BANK RAYA INDONESIA\",\"name\":\"BANK RAYA INDONESIA\"},{\"code\":\"BANK RESONA PERDANIA\",\"name\":\"BANK RESONA PERDANIA\"},{\"code\":\"BANK SAHABAT SAMPOERNA\",\"name\":\"BANK SAHABAT SAMPOERNA\"},{\"code\":\"BANK SBIINDONESIA\",\"name\":\"BANK SBIINDONESIA\"},{\"code\":\"BANK SHINHAN INDONESIA\",\"name\":\"BANK SHINHAN INDONESIA\"},{\"code\":\"BANK SINARMAS\",\"name\":\"BANK SINARMAS\"},{\"code\":\"BANK SUMSEL BABEL\",\"name\":\"BANK SUMSEL BABEL\"},{\"code\":\"BANK SUMSEL BABEL SYARIAH\",\"name\":\"BANK SUMSEL BABEL SYARIAH\"},{\"code\":\"BANK UOB\",\"name\":\"BANK UOB\"},{\"code\":\"BANK VICTORIA\",\"name\":\"BANK VICTORIA\"},{\"code\":\"BANK VICTORIA SYARIAH\",\"name\":\"BANK VICTORIA SYARIAH\"},{\"code\":\"BANK WOORI SAUDARA\",\"name\":\"BANK WOORI SAUDARA\"},{\"code\":\"BPD BALI\",\"name\":\"BPD BALI\"},{\"code\":\"BPD DIY\",\"name\":\"BPD DIY\"},{\"code\":\"BPD DIY SYARIAH\",\"name\":\"BPD DIY SYARIAH\"},{\"code\":\"BPD JAMBI\",\"name\":\"BPD JAMBI\"},{\"code\":\"BPD KALSEL\",\"name\":\"BPD KALSEL\"},{\"code\":\"BPD KALSEL SYARIAH\",\"name\":\"BPD KALSEL SYARIAH\"},{\"code\":\"BPD KALTIM KALTARA\",\"name\":\"BPD KALTIM KALTARA\"},{\"code\":\"BPD KALTIM SYARIAH\",\"name\":\"BPD KALTIM SYARIAH\"},{\"code\":\"BPD LAMPUNG\",\"name\":\"BPD LAMPUNG\"},{\"code\":\"BPD MALUKU\",\"name\":\"BPD MALUKU\"},{\"code\":\"BPD NTBS\",\"name\":\"BPD NTBS\"},{\"code\":\"BPD NTT\",\"name\":\"BPD NTT\"},{\"code\":\"BPD PAPUA\",\"name\":\"BPD PAPUA\"},{\"code\":\"BPD RIAU KEPRI\",\"name\":\"BPD RIAU KEPRI\"},{\"code\":\"BPD SULAWESI SELATAN\",\"name\":\"BPD SULAWESI SELATAN\"},{\"code\":\"BPD SULAWESI TENGAH\",\"name\":\"BPD SULAWESI TENGAH\"},{\"code\":\"BPD SULAWESI TENGGARA\",\"name\":\"BPD SULAWESI TENGGARA\"},{\"code\":\"BPD SUMUT\",\"name\":\"BPD SUMUT\"},{\"code\":\"BPD SUMUT SYARIAH\",\"name\":\"BPD SUMUT SYARIAH\"},{\"code\":\"BPR DANAGUNG ABADI\",\"name\":\"BPR DANAGUNG ABADI\"},{\"code\":\"BPR DANAGUNG BAKTI\",\"name\":\"BPR DANAGUNG BAKTI\"},{\"code\":\"BPR DANAGUNG RAMULTI\",\"name\":\"BPR DANAGUNG RAMULTI\"},{\"code\":\"BPR SUPRA\",\"name\":\"BPR SUPRA\"},{\"code\":\"Bank Krom Indonesia\",\"name\":\"Bank Krom Indonesia\"},{\"code\":\"Bank SulutGo\",\"name\":\"Bank SulutGo\"},{\"code\":\"Bank Super indonesia\",\"name\":\"Bank Super indonesia\"},{\"code\":\"CITIBANK\",\"name\":\"CITIBANK\"},{\"code\":\"DOKU\",\"name\":\"DOKU\"},{\"code\":\"HSBC INDONESIA\",\"name\":\"HSBC INDONESIA\"},{\"code\":\"JPMORGAN CHASE BANK\",\"name\":\"JPMORGAN CHASE BANK\"},{\"code\":\"LINKAJA\",\"name\":\"LINKAJA\"},{\"code\":\"PAYPRO\",\"name\":\"PAYPRO\"},{\"code\":\"PT ALLO BANK INDONESIA\",\"name\":\"PT ALLO BANK INDONESIA\"},{\"code\":\"PT BANK NANO SYARIAH\",\"name\":\"PT BANK NANO SYARIAH\"},{\"code\":\"PT BANK SMBC INDONESIA TBK\",\"name\":\"PT BANK SMBC INDONESIA TBK\"},{\"code\":\"PT Bank Hibank Indonesia\",\"name\":\"PT Bank Hibank Indonesia\"},{\"code\":\"PT. BANK CHINA CONSTRUCTION INDONESIA(CCBI)\",\"name\":\"PT. BANK CHINA CONSTRUCTION INDONESIA(CCBI)\"},{\"code\":\"PT. BANK IBK INDONESIA\",\"name\":\"PT. BANK IBK INDONESIA\"},{\"code\":\"STANDARD CHARTERED\",\"name\":\"STANDARD CHARTERED\"},{\"code\":\"LinkAja\",\"name\":\"LinkAja\"},{\"code\":\"OVO\",\"name\":\"OVO\"},{\"code\":\"ShopeePay\",\"name\":\"ShopeePay\"},{\"code\":\"i.saku\",\"name\":\"i.saku\"},{\"code\":\"Gopay Customer\",\"name\":\"Gopay Customer\"},{\"code\":\"DANA\",\"name\":\"DANA\"}]\n\n'),(25,'GPay-银行','GPay','GPay','GPay-银行','GPay',1758721166,0,'INDONESIA_BANK','zx','GPay',24,0,'/static/bank/rp.png',1,0,0,NULL),(26,'GPay-印尼电子钱包DANA','GPay-印尼电子钱包DANA','GPay-印尼电子钱包DANA','GPay-印尼电子钱包DANA','GPay-印尼电子钱包DANA',1761395961,0,'INDONESIA_EWALLET_DANA','zx','GPay',25,0,'/static/bank/rp.png',2,1,0,NULL),(27,'GPay-印尼电子钱包OVO','GPay-印尼电子钱包OVO','GPay-印尼电子钱包OVO','GPay-印尼电子钱包OVO','GPay-印尼电子钱包OVO',1758721166,0,'INDONESIA_EWALLET_OVO','zx','GPay',26,0,'/static/bank/rp.png',1,0,0,NULL),(28,'Dompet Digital-11','Dompet Digital-11','Dompet Digital-11','GPay','GPay-扫码',1760523264,1,'INDONESIA_QRIS','zx','GPay',27,52,'/static/bank/rp.png',1,0,0,NULL),(29,'GPay-钱包DANA代付','GPay-钱包DANA代付','GPay-钱包DANA代付','GPay-钱包DANA代付','GPay-钱包DANA代付',1758721166,0,'INDONESIA_EWALLET_DANA','zx','GPay',28,0,'/static/bank/rp.png',0,1,0,'[{\"code\": \"ACEH_SYARIAH\", \"name\": \"BANK_ACEH_SYARIAH\"}, {\"code\": \"AGRIS\", \"name\": \"BANK_AGRIS\"}, {\"code\": \"ALADIN_SYARIAH\", \"name\": \"BANK_ALADIN_SYARIAH\"}, {\"code\": \"AMAR_INDONESIA\", \"name\": \"BANK_AMAR_INDONESIA\"}, {\"code\": \"ANZ_INDONESIA\", \"name\": \"BANK_ANZ_INDONESIA\"}, {\"code\": \"ARTHA_GRAHA\", \"name\": \"BANK_ARTHA_GRAHA\"}, {\"code\": \"ARTOS_INDONESIA\", \"name\": \"BANK_ARTOS_INDONESIA\"}, {\"code\": \"BANGKOK\", \"name\": \"BANK_BANGKOK\"}, {\"code\": \"BCA\", \"name\": \"BANK_BCA\"}, {\"code\": \"BCA_SYARIAH\", \"name\": \"BANK_BCA_SYARIAH\"}, {\"code\": \"BISNIS_INTERNASIONAL\", \"name\": \"BANK_BISNIS_INTERNASIONAL\"}, {\"code\": \"BNI\", \"name\": \"BANK_BNI\"}, {\"code\": \"BNI_SYARIAH\", \"name\": \"BANK_BNI_SYARIAH\"}, {\"code\": \"BNP_PARIBAS_INDONESIA\", \"name\": \"BANK_BNP_PARIBAS_INDONESIA\"}, {\"code\": \"BPD_BALI\", \"name\": \"BANK_BPD_BALI\"}, {\"code\": \"BPD_BANTEN\", \"name\": \"BANK_BPD_BANTEN\"}, {\"code\": \"BPD_BENGKULU\", \"name\": \"BANK_BPD_BENGKULU\"}, {\"code\": \"BPD_JAMBI\", \"name\": \"BANK_BPD_JAMBI\"}, {\"code\": \"BPD_JATENG_UUS\", \"name\": \"BANK_BPD_JATENG_UUS\"}, {\"code\": \"BPD_JAWA_TENGAH\", \"name\": \"BANK_BPD_JAWA_TENGAH\"}, {\"code\": \"BPD_KALBAR\", \"name\": \"BANK_BPD_KALBAR\"}, {\"code\": \"BPD_KALBAR_SYARIAH\", \"name\": \"BANK_BPD_KALBAR_SYARIAH\"}, {\"code\": \"BPD_KALSEL\", \"name\": \"BANK_BPD_KALSEL\"}, {\"code\": \"BPD_KALSEL_SYARIAH\", \"name\": \"BANK_BPD_KALSEL_SYARIAH\"}, {\"code\": \"BPD_KALTENG\", \"name\": \"BANK_BPD_KALTENG\"}, {\"code\": \"BPD_KALTIM\", \"name\": \"BANK_BPD_KALTIM\"}, {\"code\": \"BPD_KALTIM_SYARIAH\", \"name\": \"BANK_BPD_KALTIM_SYARIAH\"}, {\"code\": \"BPD_LAMPUNG\", \"name\": \"BANK_BPD_LAMPUNG\"}, {\"code\": \"BPD_MALUKU\", \"name\": \"BANK_BPD_MALUKU\"}, {\"code\": \"BPD_NTB\", \"name\": \"BANK_BPD_NTB\"}, {\"code\": \"BPD_NTT\", \"name\": \"BANK_BPD_NTT\"}, {\"code\": \"BPD_PAPUA\", \"name\": \"BANK_BPD_PAPUA\"}, {\"code\": \"BPD_RIAU_KEPRI\", \"name\": \"BANK_BPD_RIAU_KEPRI\"}, {\"code\": \"BPD_SULAWESI_TENGAH\", \"name\": \"BANK_BPD_SULAWESI_TENGAH\"}, {\"code\": \"BPD_SULAWESI_TENGGARA\", \"name\": \"BANK_BPD_SULAWESI_TENGGARA\"}, {\"code\": \"BPD_SULAWESI_UTARA\", \"name\": \"BANK_BPD_SULAWESI_UTARA\"}, {\"code\": \"BPD_SUMATERA_BARAT\", \"name\": \"BANK_BPD_SUMATERA_BARAT\"}, {\"code\": \"BPD_SUMATERA_BARAT_SYARIAH\", \"name\": \"BANK_BPD_SUMATERA_BARAT_SYARIAH\"}, {\"code\": \"BPD_SUMATERA_SELATAN_BABEL\", \"name\": \"BANK_BPD_SUMATERA_SELATAN_BABEL\"}, {\"code\": \"BPD_SUMATERA_SELATAN_SYARIAH\", \"name\": \"BANK_BPD_SUMATERA_SELATAN_SYARIAH\"}, {\"code\": \"BPD_SUMATERA_UTARA\", \"name\": \"BANK_BPD_SUMATERA_UTARA\"}, {\"code\": \"BPD_SUMUT_UNIT_SYARIAH\", \"name\": \"BANK_BPD_SUMUT_UNIT_SYARIAH\"}, {\"code\": \"BPD_YOGYAKARTA\", \"name\": \"BANK_BPD_YOGYAKARTA\"}, {\"code\": \"BPD_YOGYAKARTA_SYARIAH\", \"name\": \"BANK_BPD_YOGYAKARTA_SYARIAH\"}, {\"code\": \"BRI\", \"name\": \"BANK_BRI\"}, {\"code\": \"BRI_AGRONIAGA\", \"name\": \"BANK_BRI_AGRONIAGA\"}, {\"code\": \"BTN\", \"name\": \"BANK_BTN\"}, {\"code\": \"BTN_SYARIAH\", \"name\": \"BANK_BTN_SYARIAH\"}, {\"code\": \"BTPN\", \"name\": \"BANK_BTPN\"}, {\"code\": \"BTPN_SYARIAH\", \"name\": \"BANK_BTPN_SYARIAH\"}, {\"code\": \"BUKOPIN\", \"name\": \"BANK_BUKOPIN\"}, {\"code\": \"BUMI_ARTA\", \"name\": \"BANK_BUMI_ARTA\"}, {\"code\": \"CAPITAL_INDONESIA\", \"name\": \"BANK_CAPITAL_INDONESIA\"}, {\"code\": \"CENTRATAMA\", \"name\": \"BANK_CENTRATAMA\"}, {\"code\": \"CHINA_CONSTRUCTION_INDONESIA\", \"name\": \"BANK_CHINA_CONSTRUCTION_INDONESIA\"}, {\"code\": \"CIMB\", \"name\": \"BANK_CIMB\"}, {\"code\": \"CIMB_NIAGA_SYARIAH\", \"name\": \"BANK_CIMB_NIAGA_SYARIAH\"}, {\"code\": \"CITIBANK\", \"name\": \"BANK_CITIBANK\"}, {\"code\": \"COMMONWEALTH\", \"name\": \"BANK_COMMONWEALTH\"}, {\"code\": \"CTBC_INDONESIA\", \"name\": \"BANK_CTBC_INDONESIA\"}, {\"code\": \"DANAMON\", \"name\": \"BANK_DANAMON\"}, {\"code\": \"DANAMON_SYARIAH\", \"name\": \"BANK_DANAMON_SYARIAH\"}, {\"code\": \"DBS_INDONESIA\", \"name\": \"BANK_DBS_INDONESIA\"}, {\"code\": \"DEUTSCHE_AG\", \"name\": \"BANK_DEUTSCHE_AG\"}, {\"code\": \"DKI\", \"name\": \"BANK_DKI\"}, {\"code\": \"DKI_SYARIAH\", \"name\": \"BANK_DKI_SYARIAH\"}, {\"code\": \"FAMA\", \"name\": \"BANK_FAMA\"}, {\"code\": \"GANESHA\", \"name\": \"BANK_GANESHA\"}, {\"code\": \"HARDA_INTERNASIONAL\", \"name\": \"BANK_HARDA_INTERNASIONAL\"}, {\"code\": \"HARMONI_INTERNATIONAL\", \"name\": \"BANK_HARMONI_INTERNATIONAL\"}, {\"code\": \"HSBC_INDONESIA\", \"name\": \"BANK_HSBC_INDONESIA\"}, {\"code\": \"ICBC_INDONESIA\", \"name\": \"BANK_ICBC_INDONESIA\"}, {\"code\": \"INA_PERDANA\", \"name\": \"BANK_INA_PERDANA\"}, {\"code\": \"INDEX_SELINDO\", \"name\": \"BANK_INDEX_SELINDO\"}, {\"code\": \"INTERIM_INDONESIA\", \"name\": \"BANK_INTERIM_INDONESIA\"}, {\"code\": \"JABAR_BANTEN\", \"name\": \"BANK_JABAR_BANTEN\"}, {\"code\": \"JABAR_BANTEN_SYARIAH\", \"name\": \"BANK_JABAR_BANTEN_SYARIAH\"}, {\"code\": \"JASA_JAKARTA\", \"name\": \"BANK_JASA_JAKARTA\"}, {\"code\": \"JATIM\", \"name\": \"BANK_JATIM\"}, {\"code\": \"JATIM_SYARIAH\", \"name\": \"BANK_JATIM_SYARIAH\"}, {\"code\": \"JP_MORGAN\", \"name\": \"BANK_JP_MORGAN\"}, {\"code\": \"JTRUST_INDONESIA\", \"name\": \"BANK_JTRUST_INDONESIA\"}, {\"code\": \"KEB_HANA\", \"name\": \"BANK_KEB_HANA\"}, {\"code\": \"KESEJAHTERAAN\", \"name\": \"BANK_KESEJAHTERAAN\"}, {\"code\": \"MANDIRI\", \"name\": \"BANK_MANDIRI\"}, {\"code\": \"MANDIRI_TASPEN\", \"name\": \"BANK_MANDIRI_TASPEN\"}, {\"code\": \"MASPION_INDONESIA\", \"name\": \"BANK_MASPION_INDONESIA\"}, {\"code\": \"MAYAPADA\", \"name\": \"BANK_MAYAPADA\"}, {\"code\": \"MAYINDONESIA\", \"name\": \"BANK_MAYINDONESIA\"}, {\"code\": \"MAYINDONESIA_UUS\", \"name\": \"BANK_MAYINDONESIA_UUS\"}, {\"code\": \"MAYSYARIAH_INDONESIA\", \"name\": \"BANK_MAYSYARIAH_INDONESIA\"}, {\"code\": \"MAYORA\", \"name\": \"BANK_MAYORA\"}, {\"code\": \"MEGA_SYARIAH\", \"name\": \"BANK_MEGA_SYARIAH\"}, {\"code\": \"MEGA_TBK\", \"name\": \"BANK_MEGA_TBK\"}, {\"code\": \"MESTIKA_DHARMA\", \"name\": \"BANK_MESTIKA_DHARMA\"}, {\"code\": \"MITRANIAGA\", \"name\": \"BANK_MITRANIAGA\"}, {\"code\": \"MIZUHO_INDONESIA\", \"name\": \"BANK_MIZUHO_INDONESIA\"}, {\"code\": \"MNC_INTERNATIONAL\", \"name\": \"BANK_MNC_INTERNATIONAL\"}, {\"code\": \"MUAMALAT\", \"name\": \"BANK_MUAMALAT\"}, {\"code\": \"MUFG_LTD\", \"name\": \"BANK_MUFG_LTD\"}, {\"code\": \"MULTI_ARTA_SENTOSA\", \"name\": \"BANK_MULTI_ARTA_SENTOSA\"}, {\"code\": \"NOBU_NATIONAL\", \"name\": \"BANK_NOBU_NATIONAL\"}, {\"code\": \"NTB_SYARIAH\", \"name\": \"BANK_NTB_SYARIAH\"}, {\"code\": \"NUSANTARA\", \"name\": \"BANK_NUSANTARA\"}, {\"code\": \"OCBC_NISP\", \"name\": \"BANK_OCBC_NISP\"}, {\"code\": \"OCBC_NISP_SYARIAH\", \"name\": \"BANK_OCBC_NISP_SYARIAH\"}, {\"code\": \"OF_AMERICA\", \"name\": \"BANK_OF_AMERICA\"}, {\"code\": \"OF_CHINA\", \"name\": \"BANK_OF_CHINA\"}, {\"code\": \"OF_INDIA_INDONESIA\", \"name\": \"BANK_OF_INDIA_INDONESIA\"}, {\"code\": \"OKE_INDONESIA\", \"name\": \"BANK_OKE_INDONESIA\"}, {\"code\": \"PANIN_SYARIAH\", \"name\": \"BANK_PANIN_SYARIAH\"}, {\"code\": \"PAN_INDONESIA_PANIN\", \"name\": \"BANK_PAN_INDONESIA_PANIN\"}, {\"code\": \"PERMATA\", \"name\": \"BANK_PERMATA\"}, {\"code\": \"PERMATA_SYARIAH\", \"name\": \"BANK_PERMATA_SYARIAH\"}, {\"code\": \"PIKKO\", \"name\": \"BANK_PIKKO\"}, {\"code\": \"PRIMA_MASTER\", \"name\": \"BANK_PRIMA_MASTER\"}, {\"code\": \"QNB_INDONESIA\", \"name\": \"BANK_QNB_INDONESIA\"}, {\"code\": \"RESONA_PERDANIA\", \"name\": \"BANK_RESONA_PERDANIA\"}, {\"code\": \"ROYAL_INDONESIA\", \"name\": \"BANK_ROYAL_INDONESIA\"}, {\"code\": \"SAHABAT_SAMPOERNA\", \"name\": \"BANK_SAHABAT_SAMPOERNA\"}, {\"code\": \"SBI_INDONESIA\", \"name\": \"BANK_SBI_INDONESIA\"}, {\"code\": \"SHINHAN_INDONESIA\", \"name\": \"BANK_SHINHAN_INDONESIA\"}, {\"code\": \"SINARMAS\", \"name\": \"BANK_SINARMAS\"}, {\"code\": \"STANDARD_CHARTERED\", \"name\": \"BANK_STANDARD_CHARTERED\"}, {\"code\": \"SULSELBAR\", \"name\": \"BANK_SULSELBAR\"}, {\"code\": \"SYARIAH_BRI\", \"name\": \"BANK_SYARIAH_BRI\"}, {\"code\": \"SYARIAH_BUKOPIN\", \"name\": \"BANK_SYARIAH_BUKOPIN\"}, {\"code\": \"SYARIAH_INDONESIA\", \"name\": \"BANK_SYARIAH_INDONESIA\"}, {\"code\": \"SYARIAH_MANDIRI\", \"name\": \"BANK_SYARIAH_MANDIRI\"}, {\"code\": \"UOB_INDONESIA\", \"name\": \"BANK_UOB_INDONESIA\"}, {\"code\": \"VICTORIA_INTERNATIONAL\", \"name\": \"BANK_VICTORIA_INTERNATIONAL\"}, {\"code\": \"VICTORIA_SYARIAH\", \"name\": \"BANK_VICTORIA_SYARIAH\"}, {\"code\": \"WOORI_SAUDARA_INDONESIA\", \"name\": \"BANK_WOORI_SAUDARA_INDONESIA\"}, {\"code\": \"BSI\", \"name\": \"BANK_BSI\"}, {\"code\": \"OVO\", \"name\": \"电子钱包_OVO\"}, {\"code\": \"DANA\", \"name\": \"电子钱包_DANA\"}, {\"code\": \"GOPAY\", \"name\": \"电子钱包_GOPAY\"}, {\"code\": \"SHOPEEPAY\", \"name\": \"电子钱包_SHOPEEPAY\"}, {\"code\": \"LINKAJA\", \"name\": \"电子钱包_LINKAJA\"}]'),(30,'GPay-钱包OVO代付','GPay-钱包OVO代付','GPay-钱包OVO代付','GPay-钱包OVO代付','GPay-钱包OVO代付',1758721166,0,'INDONESIA_EWALLET_DANA','zx','GPay',29,0,'/static/bank/rp.png',0,1,0,NULL),(31,'GPay-钱包GOPAY代付','GPay-钱包GOPAY代付GPay-钱包GOPAY代付','GPay-钱包GOPAY代付','GPay-钱包GOPAY代付','GPay-钱包GOPAY代付',1758721166,0,'INDONESIA_EWALLET_DANA','zx','GPay',30,0,'/static/bank/rp.png',0,1,0,NULL),(32,'GPay-银行代付','GPay-银行代付','GPay-银行代付','GPay-银行代付','GPay-银行代付',1764347598,1,'INDONESIA_PAYOUT','zx','GPay',31,48,'/static/bank/rp.png',2,1,1,'[{\"code\": \"002\", \"name\": \"Bank Rakyat Indonesia\"}, {\"code\": \"008\", \"name\": \"Bank Mandiri\"}, {\"code\": \"011\", \"name\": \"Bank Danamon Indonesia\"}, {\"code\": \"013\", \"name\": \"Bank Permata\"}, {\"code\": \"016\", \"name\": \"Maybank\"}, {\"code\": \"009\", \"name\": \"Bank Negara Indonesia\"}, {\"code\": \"014\", \"name\": \"Bank Central Asia\"}, {\"code\": \"019\", \"name\": \"PaninBank\"}, {\"code\": \"028\", \"name\": \"Bank OCBC NISP\"}, {\"code\": \"037\", \"name\": \"Bank Artha Graha Internasional\"}, {\"code\": \"022\", \"name\": \"Bank CIMB Niaga\"}, {\"code\": \"023\", \"name\": \"United Overseas Bank Limited\"}, {\"code\": \"031\", \"name\": \"Citibank\"}, {\"code\": \"042\", \"name\": \"THE BANK OF TOKYO MITSUBISHI UFJ\"}, {\"code\": \"050\", \"name\": \"Standard Chartered Bank\"}, {\"code\": \"041\", \"name\": \"HSBC Holdings PLC\"}, {\"code\": \"046\", \"name\": \"DBS Bank\"}, {\"code\": \"069\", \"name\": \"BANK OF CHINA\"}, {\"code\": \"054\", \"name\": \"Bank Capital Indonesia\"}, {\"code\": \"060\", \"name\": \"Rabobank\"}, {\"code\": \"061\", \"name\": \"Bank ANZ Indonesia\"}, {\"code\": \"097\", \"name\": \"Bank Mayapada\"}, {\"code\": \"110\", \"name\": \"Bank BJB\"}, {\"code\": \"114\", \"name\": \"Bank Jatim\"}, {\"code\": \"113\", \"name\": \"Bank Jateng\"}, {\"code\": \"116\", \"name\": \"Bank Aceh\"}, {\"code\": \"121\", \"name\": \"Bank Lampung\"}, {\"code\": \"129\", \"name\": \"Bank BPD Bali\"}, {\"code\": \"132\", \"name\": \"Bank Papua\"}, {\"code\": \"145\", \"name\": \"Bank Nusantara Parahyangan\"}, {\"code\":\"128\",\"name\":\"BPD Nusa Tenggara Barat\"}, {\"code\":\"131\",\"name\":\"Bank Maluku Malut\"}, {\"code\":\"147\",\"name\":\"Bank Muamalat Indonesia\"}, {\"code\":\"151\",\"name\":\"Bank Mestika\"}, {\"code\":\"153\",\"name\":\"Bank Sinarmas\"}, {\"code\":\"157\",\"name\":\"Bank Maspion\"}, {\"code\":\"161\",\"name\":\"Bank Ganesha\"}, {\"code\":\"167\",\"name\":\"Bank QNB Indonesia\"}, {\"code\":\"213\",\"name\":\"Bank BTPN\"}, {\"code\":\"425\",\"name\":\"Bank Jabar Banten Syariah\"}, {\"code\":\"164\",\"name\":\"Bank ICBC Indonesia\"}, {\"code\":\"200\",\"name\":\"Bank Tabungan Negara Syariah\"}, {\"code\":\"212\",\"name\":\"Bank Woori Saudara Indonesia 1906\"}, {\"code\":\"426\",\"name\":\"Bank Mega\"}, {\"code\":\"441\",\"name\":\"Bank KB Bukopin\"}, {\"code\":\"451\",\"name\":\"Bank Syariah Indonesia\"}, {\"code\":\"472\",\"name\":\"Bank Jasa Jakarta\"}, {\"code\":\"490\",\"name\":\"Bank Neo Commerce\"}, {\"code\":\"484\",\"name\":\"Hana Bank\"}, {\"code\":\"498\",\"name\":\"State Bank of India\"}, {\"code\":\"501\",\"name\":\"Bank Digital BCA\"}, {\"code\":\"503\",\"name\":\"Bank Nationalnobu\"}, {\"code\":\"506\",\"name\":\"Bank Mega Syariah\"}, {\"code\":\"521\",\"name\":\"KB Bukopin Syariah\"}, {\"code\":\"523\",\"name\":\"Bank Sahabat Sampoerna\"}, {\"code\":\"535\",\"name\":\"PT Bank Seabank Indonesia\"}, {\"code\":\"513\",\"name\":\"Bank Ina Perdana\"}, {\"code\":\"536\",\"name\":\"BCA Syariah\"}, {\"code\":\"542\",\"name\":\"Bank Jago\"}, {\"code\":\"553\",\"name\":\"Hibank\"}, {\"code\": \"949\", \"name\": \"Bank CTBC Indonesia\"}, {\"code\": \"555\", \"name\": \"Bank Index Selindo\"}, {\"code\": \"566\", \"name\": \"Bank Victoria International\"}, {\"code\": \"950\", \"name\": \"Commonwealth Bank\"}, {\"code\": \"DANA\", \"name\": \"DANA\"}, {\"code\": \"GOPAY\", \"name\": \"GOPAY\"}, {\"code\": \"OVO\", \"name\": \"OVO\"}, {\"code\": \"LINKAJA\", \"name\": \"LINKAJA\"}, {\"code\": \"SHOPEEPAY\", \"name\": \"SHOPEEPAY\"}]'),(33,'PT GLOBAL GARUDA INVESTAMA','034501001790561','Transfer Bank-01','Bank Rakyat Indonesia','Bank Rakyat Indonesia',1760853552,1,'','bank','Bank',4,100,'/static/bank/rp.png',1,1,0,NULL);
/*!40000 ALTER TABLE `st_admin_bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_admin_config`
--

DROP TABLE IF EXISTS `st_admin_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_admin_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '标题',
  `group` varchar(32) NOT NULL DEFAULT '' COMMENT '配置分组',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '类型',
  `value` text NOT NULL COMMENT '配置值',
  `options` text NOT NULL COMMENT '配置项',
  `tips` varchar(256) NOT NULL DEFAULT '' COMMENT '配置提示',
  `ajax_url` varchar(256) NOT NULL DEFAULT '' COMMENT '联动下拉框ajax地址',
  `next_items` varchar(256) NOT NULL DEFAULT '' COMMENT '联动下拉框的下级下拉框名，多个以逗号隔开',
  `param` varchar(32) NOT NULL DEFAULT '' COMMENT '联动下拉框请求参数名',
  `format` varchar(32) NOT NULL DEFAULT '' COMMENT '格式，用于格式文本',
  `table` varchar(32) NOT NULL DEFAULT '' COMMENT '表名，只用于快速联动类型',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '联动级别，只用于快速联动类型',
  `key` varchar(32) NOT NULL DEFAULT '' COMMENT '键字段，只用于快速联动类型',
  `option` varchar(32) NOT NULL DEFAULT '' COMMENT '值字段，只用于快速联动类型',
  `pid` varchar(32) NOT NULL DEFAULT '' COMMENT '父级id字段，只用于快速联动类型',
  `ak` varchar(32) NOT NULL DEFAULT '' COMMENT '百度地图appkey',
  `create_time` varchar(50) DEFAULT NULL COMMENT '创建时间',
  `update_time` varchar(50) DEFAULT NULL COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态：0禁用，1启用',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='系统配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_admin_config`
--

LOCK TABLES `st_admin_config` WRITE;
/*!40000 ALTER TABLE `st_admin_config` DISABLE KEYS */;
INSERT INTO `st_admin_config` VALUES (1,'web_site_status','站点开关','base','radio','1','','站点关闭后前台将不能访问，后台可正常登录','','','','','',2,'','','','','01/01/1970 07:00','1763297883',1,1),(2,'web_site_title','站点标题','base','text','最新股票配资','','调用方式：sysConfig(\'web_site_title\')','','','','','',2,'','','','','01/01/1970 07:00','1763297883',2,1),(3,'web_site_slogan','站点标语','base','text','股票配资','','站点口号，调用方式：sysConfig(\'web_site_slogan\')','','','','','',2,'','','','','1475240994','1477710357',3,0),(4,'web_site_logo','站点LOGO','base','image','434','','','','','','','',2,'','','','','1475241067','1475241067',4,0),(5,'web_site_description','站点描述','base','textarea','我公司互联网配资平台,为投资者提供杠杆投资资金通道,构建安全可信、便捷快速的杠杆配资交易环境','','网站描述，有利于搜索引擎抓取相关信息','','','','','',2,'','','','','1475241186','1475241186',6,0),(6,'web_site_keywords','站点关键词','base','text','股票配资,配资公司,配资平台','','网站搜索引擎关键字','','','','','',2,'','','','','1475241328','1475241328',7,0),(7,'web_site_copyright','版权信息','base','text','Copyright © 2022-2024 股票配资 All rights reserved.          ','','调用方式：sysConfig(\'web_site_copyright\')','','','','','',2,'','','','','01/01/1970 07:00','1763297883',8,1),(8,'web_site_icp','备案信息','base','text','ICP备123123123号','','调用方式：sysConfig(\'web_site_icp\')','','','','','',2,'','','','','01/01/1970 07:00','1763297883',9,1),(9,'web_site_statistics','站点统计','base','textarea','','','网站统计代码，支持百度、Google、cnzz等，调用方式：<code>config(\'web_site_statistics\')</code>','','','','','',2,'','','','','1475241498','1477710455',10,0),(10,'config_group','配置分组','system','array','base:基本\r\nsystem:系统\r\nupload:上传\r\ndevelop:开发\r\ndatabase:数据库\r\nstock:配资管理\r\nsms:短信接口\r\nsms_admin_template:管理员短信模板\r\nsms_user_template:用户短信模板\r\napp:app配置\r\nshare:分享配置\r\nonlinerecharge:线上充值\r\ngive:活动赠送\r\nrecharge:充值赠送','','','','','','','',2,'','','','','1475241716','1557735171',100,0),(11,'form_item_type','配置类型','system','array','text:单行文本\r\ntextarea:多行文本\r\nstatic:静态文本\r\npassword:密码\r\ncheckbox:复选框\r\nradio:单选按钮\r\ndate:日期\r\ndatetime:日期+时间\r\nhidden:隐藏\r\nswitch:开关\r\narray:数组\r\nselect:下拉框\r\nlinkage:普通联动下拉框\r\nlinkages:快速联动下拉框\r\nimage:单张图片\r\nimages:多张图片\r\nfile:单个文件\r\nfiles:多个文件\r\nueditor:UEditor 编辑器\r\nwangeditor:wangEditor 编辑器\r\neditormd:markdown 编辑器\r\nckeditor:ckeditor 编辑器\r\nicon:字体图标\r\ntags:标签\r\nnumber:数字\r\nbmap:百度地图\r\ncolorpicker:取色器\r\njcrop:图片裁剪\r\nmasked:格式文本\r\nrange:范围\r\ntime:时间','','','','','','','',2,'','','','','1475241835','1495853193',100,0),(12,'upload_file_size','文件上传大小限制','upload','text','0','','0为不限制大小，单位：kb','','','','','',2,'','','','','1475241897','1477663520',100,1),(13,'upload_file_ext','允许上传的文件后缀','upload','tags','doc,docx,xls,xlsx,ppt,pptx,pdf,wps,txt,rar,zip,gz,bz2,7z','','多个后缀用逗号隔开，不填写则不限制类型','','','','','',2,'','','','','1475241975','1477649489',100,1),(14,'upload_image_size','图片上传大小限制','upload','text','100000','','0为不限制大小，单位：kb','','','','','',2,'','','','','1475242015','1477663529',100,1),(15,'upload_image_ext','允许上传的图片后缀','upload','tags','gif,jpg,jpeg,bmp,png','','多个后缀用逗号隔开，不填写则不限制类型','','','','','',2,'','','','','1475242056','1477649506',100,1),(16,'list_rows','分页数量','system','number','20','','每页的记录数','','','','','',2,'','','','','1475242066','1476074507',101,0),(17,'system_color','后台配色方案','system','radio','default','default:Default\namethyst:Amethyst\ncity:City\nflat:Flat\nmodern:Modern\nsmooth:Smooth','','','','','','',2,'','','','','1475250066','1477316689',102,0),(18,'develop_mode','开发模式','develop','radio','0','0:关闭\n1:开启','','','','','','',2,'','','','','1476864205','1476864231',100,1),(19,'app_trace','显示页面Trace','develop','radio','0','0:否\n1:是','','','','','','',2,'','','','','1476866355','1476866355',100,1),(21,'data_backup_path','数据库备份根路径','database','text','data/','','路径必须以 / 结尾','','','','','',2,'','','','','1477017745','1585656637',100,1),(22,'data_backup_part_size','数据库备份卷大小','database','text','20971520','','该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M','','','','','',2,'','','','','1477017886','1477017886',100,1),(23,'data_backup_compress','数据库备份文件是否启用压缩','database','radio','1','0:否\n1:是','压缩备份文件需要PHP环境支持 <code>gzopen</code>, <code>gzwrite</code>函数','','','','','',2,'','','','','1477017978','1477018172',100,1),(24,'data_backup_compress_level','数据库备份文件压缩级别','database','radio','9','1:最低\n4:一般\n9:最高','数据库备份文件的压缩级别，该配置在开启压缩时生效','','','','','',2,'','','','','1477018083','1477018083',100,1),(25,'top_menu_max','顶部导航模块数量','system','text','15','','设置顶部导航默认显示的模块数量','','','','','',2,'','','','','1477579289','1477579289',103,0),(26,'web_site_logo_text','站点LOGO文字','base','image','','','','','','','','',2,'','','','','1477620643','1477620643',5,0),(27,'upload_image_thumb','缩略图尺寸','upload','text','','','不填写则不生成缩略图，如需生成 <code>300x300</code> 的缩略图，则填写 <code>300,300</code> ，请注意，逗号必须是英文逗号','','','','','',2,'','','','','1477644150','1477649513',100,1),(28,'upload_image_thumb_type','缩略图裁剪类型','upload','radio','1','1:等比例缩放\n2:缩放后填充\n3:居中裁剪\n4:左上角裁剪\n5:右下角裁剪\n6:固定尺寸缩放','该项配置只有在启用生成缩略图时才生效','','','','','',2,'','','','','1477646271','1477649521',100,1),(29,'upload_thumb_water','添加水印','upload','switch','0','','','','','','','',2,'','','','','1477649648','1477649648',100,1),(30,'upload_thumb_water_pic','水印图片','upload','image','14','','只有开启水印功能才生效','','','','','',2,'','','','','1477656390','1477656390',100,1),(31,'upload_thumb_water_position','水印位置','upload','radio','9','1:左上角\n2:上居中\n3:右上角\n4:左居中\n5:居中\n6:右居中\n7:左下角\n8:下居中\n9:右下角','只有开启水印功能才生效','','','','','',2,'','','','','1477656528','1477656528',100,1),(32,'upload_thumb_water_alpha','水印透明度','upload','text','50','','请输入0~100之间的数字，数字越小，透明度越高','','','','','',2,'','','','','1477656714','1477661309',100,1),(33,'wipe_cache_type','清除缓存类型','system','checkbox','TEMP_PATH','TEMP_PATH:应用缓存\nLOG_PATH:应用日志\nCACHE_PATH:项目模板缓存','清除缓存时，要删除的缓存类型','','','','','',2,'','','','','1477727305','1477727305',100,0),(34,'captcha_signin','后台验证码开关','system','radio','0','','后台登录时是否需要验证码','','','','','',2,'','','','','01/01/1970 07:32','1755232774',5,1),(35,'home_default_module','前台默认模块','system','select','index','','前台默认访问的模块，该模块必须有Index控制器和index方法','','','','','',0,'','','','','1486714723','1486715620',104,0),(36,'minify_status','开启minify','system','radio','0','','开启minify会压缩合并js、css文件，可以减少资源请求次数，如果不支持minify，可关闭','','','','','',0,'','','','','1487035843','1487035843',99,0),(37,'upload_driver','上传驱动','upload','radio','local','local:本地\nqiniu:七牛云','图片或文件上传驱动','','','','','',0,'','','','','1501488567','1501490821',100,1),(39,'day_loss','预警线|平仓线（按天）','stock','text','50|20','','如60|50，以|分割','','','','','',0,'','','','','01/01/1970 07:32','1750420420',62,1),(40,'commission','佣金设置','stock','number','20','','交易佣金（单位：万分之几，如:8 表示交易佣金费率为万分之八）','','','','','',0,'','','','','1970-01-01 08:32:50','1679569677',50,0),(41,'limit_fee','每笔最低佣金','stock','number','5','','股票交易每笔的最低收取的佣金（单位：元，如：5 表示每笔交易最低收取5元）','','','','','',0,'','','','','1970-01-01 08:32:50','1679569677',51,0),(42,'stamp_duty','印花税','stock','number','0','','印花税（单位：千分之几 如：1 表示卖出时收取交易金额的千分之一） 印花税=成交金额×印花税率','','','','','',0,'','','','','01/01/1970 07:32','1750420420',52,1),(43,'transfer_fee','过户费','stock','number','0','','过户费（单位：千分之几），小于1 时为比例，大于1 时为具体金额：0.002%(十万分之二)，值为零表示不收费。','','','','','',0,'','','','','01/01/1970 07:32','1750420420',53,1),(44,'day_rate','按天配资管理费率设置','stock','array','1:0.092\r\n2:0.092\r\n3:0.092\r\n4:0.092\r\n5:0.092\r\n6:0.092\r\n7:0.092\r\n8:0.092\r\n9:0.092\r\n10:0.092','1:0.10\r\n2:0.10\r\n3:0.09\r\n4:0.09\r\n5:0.08\r\n6:0.08\r\n7:0.07\r\n8:0.07\r\n9:0.06\r\n10:0.06','按天配资费率（单位：%） 根据配资资金的杠杆比例不同设置的费率也不同。1:0.35 表示平台一倍杠杆比例进行配资收取的天利率为0.35%','','','','','',0,'','','','','01/01/1970 07:32','1750420420',100,1),(45,'week_rate','按周配资管理费率设置','stock','array','1:0.92\r\n2:0.92\r\n3:0.92\r\n4:0.92\r\n5:0.92\r\n6:0.92\r\n7:0.92\r\n8:0.92\r\n9:0.92\r\n10:0.92','1:0.50\r\n2:0.50\r\n3:0.45\r\n4:0.45\r\n5:0.40\r\n6:0.40\r\n7:0.35\r\n8:0.35\r\n9:0.30\r\n10:0.30','按周配资（单位：%）根据配资资金的杠杆比例不同设置的费率也不同。1:1.66 表示平台一倍杠杆比例进行配资收取的周利率为1.66%','','','','','',0,'','','','','01/01/1970 07:32','1750420420',100,1),(46,'month_rate','按月配资管理费率设置','stock','array','1:0.92\r\n2:0.92\r\n3:0.92\r\n4:0.92\r\n5:0.92\r\n6:0.92\r\n7:0.92\r\n8:0.92\r\n9:0.92\r\n10:0.92','1:1.00\r\n2:1.00\r\n3:0.90\r\n4:0.90\r\n5:0.80\r\n6:0.80\r\n7:0.70\r\n8:0.70\r\n9:0.60\r\n10:0.60','按月配资（单位：%）根据配资资金的杠杆比例不同设置的费率也不同。1:1.66 表示平台一倍杠杆比例进行配资收取的月利率为1.66%','','','','','',0,'','','','','01/01/1970 07:32','1750420420',100,1),(47,'profit_share','盈利分成比例','share','radio','0','0:不分成\n1:2/8分成\n2:3/7分成\n3:5/5分成','盈利分成比例（单位：%） 0:不分成 表示不分成，收益全归配资人，1:2/8分成 表示平台分享配资人总盈利的20%','','','','','',0,'','','','','1970','1665229507',0,1),(48,'day_position','单股持仓比例设置（按天）','stock','array','1:100\r\n2:100\r\n3:100\r\n4:100\r\n5:100\r\n6:100\r\n7:100\r\n8:100\r\n9:100\r\n10:100','','根据不同配资杠杆比例，单股持仓仓位最大限制设置（单位：%）1:90 表示一倍杠杆按天配资时，单只股票最大持仓比例为90%','','','','','',0,'','','','','01/01/1970 07:32','1750420420',100,1),(49,'week_position','单股持仓比例设置（按周）','stock','array','1:100\r\n2:100\r\n3:100\r\n4:100\r\n5:100\r\n6:100\r\n7:100\r\n8:100\r\n9:100\r\n10:100','','','','','','','',0,'','','','','01/01/1970 07:32','1750420420',100,1),(50,'month_position','单股持仓比例设置（按月）','stock','array','1:100\r\n2:100\r\n3:100\r\n4:100\r\n5:100\r\n6:100\r\n7:100\r\n8:100\r\n9:100\r\n10:100','','','','','','','',0,'','','','','01/01/1970 07:32','1750420420',100,1),(51,'money_range','配资金额范围','stock','text','100|20000000|100','','如100|1000000|100，以|分割第一个参数是配资最低金额，第二个参数是最大金额，第三个参数代表只能以100的整数倍递增','','','','','',0,'','','','','01/01/1970 07:32','1750420420',100,1),(52,'stop_fee','提前终止扣除利息','stock','number','100','','如20，提前终止将扣除剩余利息的20%','','','','','',0,'','','','','01/01/1970 07:32','1750420420',100,1),(53,'stock_count','配资次数限制','stock','number','10','','使用中的配资次数限制,配资结算后可继续申请','','','','','',0,'','','','','01/01/1970 07:32','1750420420',100,1),(54,'free_set','免息配资设置','stock','text','5|20|80','','免息配资固定杠杆|免息配资天数 如 5|20 表示配资5倍杠杆，配资20天，盈利的70%返还给客户','','','','','',0,'','','','','01/01/1970 07:32','1750420420',100,1),(55,'rebate','推荐人佣金','share','number','0','','每次被推荐人投资，推荐人可获得的佣金比例（配资管理费的 5%）','','','','','',0,'','','','','1970','1665229507',100,1),(56,'day_use_time','使用期限（按天）','stock','text','2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30','','如2|20，以|分割，最小使用期限为2天，最大使用期限为20天','','','','','',0,'','','','','01/01/1970 07:32','1750420420',100,1),(57,'month_use_time','使用期限（按月）','stock','text','1|2|3|4|5|6|7|8|9|10|11|12','','如1|12，以|分割，最小使用期限为1月，最大使用期限为12月','','','','','',0,'','','','','01/01/1970 07:32','1750420420',100,1),(58,'week_use_time','使用期限（按周）','stock','text','1|2|3|4|5|6|7|8|9|10|11|12','','如1|3，以|分割，最小使用期限为1周，最大使用期限为3周','','','','','',0,'','','','','01/01/1970 07:32','1750420420',100,1),(59,'month_loss','预警线|平仓线（按月）','stock','text','50|20','','如60|50，以|分割','','','','','',0,'','','','','01/01/1970 07:32','1750420420',64,1),(60,'week_loss','预警线|平仓线（按周）','stock','text','50|20','','如60|50，以|分割','','','','','',0,'','','','','01/01/1970 07:32','1750420420',63,1),(61,'free_loss','预警线|平仓线（免息）','stock','text','50|20','','如60|50，以|分割','','','','','',0,'','','','','01/01/1970 07:32','1750420420',61,1),(62,'system_log','后台操作日志','system','radio','0','','是否开启系统日志功能','','','','','',0,'','','','','2017','1659625863',6,0),(66,'market_data_in','行情数据源','system','radio','1','1:腾讯 \r\n2:新浪','行情数据交易数据来源','','','','','',0,'','','','','1515663631','1642766330',100,0),(67,'web_bank','提现银行参数','money','array','BMRI:Bank Mandiri|img:008\nBRI:Bank Rakyat Indonesia|img:002\nBCA:Bank Central Asia|img:014\nBNI:Bank Negara Indonesia|img:009\nBTN:Bank Tabungan Negara|img:200\nBSI:Bank Syariah Indonesia|img:451\nCIMB:Bank CIMB Niaga|img:022\nOCBC NISP:Bank OCBC NISP|img:028\nPermata:Bank Permata|img:013\nDanamon:Bank Danamon|img:011\nBank Lain:Bank Lain|img:000','','银行卡 web_bank 调用方法 sysConfig(\'web_bank \')','','','','','',0,'','','','','01/01/1970 07:00','1763979197',100,1),(69,'legal_holiday','国家法定假日','system','textarea','0101,0127,0128,0129,0328,0331,0401,0402,0403,0404,0407,0418,0501,0512,0513,0529,0530,0606,0609,0627,0818,0905,1225,1226,1231','0101,0128,0129,0130,0131,0201,0202,0203,0204,0404,0405,0406,0501,0502,0503,0504,0505,0531,0601,0602,1001,1002,1003,1004,1005,1006,1007,1008','国家法定假日 需要每年年初手动更新','','','','','',0,'','','','','01/01/1970 07:32','1755232774',100,1),(70,'web_site_telephone','客服电话','base','text','400-1234-888','','客服电话','','','','','',0,'','','','','01/01/1970 07:00','1763297883',11,1),(71,'web_site_service_time','客服时间','base','text','周一至周五09:00-20:00（工作日）','','客服时间','','','','','',0,'','','','','01/01/1970 07:00','1763297883',12,1),(72,'web_real_api','实盘接口','system','radio','1','1:交易通\n2:网格','选择实盘交易接口   注意选择前需要运行对应的实盘接口程序','','','','','',0,'','','','','1525423627','1525423627',100,0),(73,'web_site_account','是否开启充值','money','radio','1','0:关闭\n1:开启\n','调用方式：sysConfig(\'web_site_account\')','','','','','',0,'','','','','01/01/1970 07:00','1763979197',0,1),(74,'set_site_company_name','平台运营公司名','base','text','金狐创投','','配置名称：set_site_company_name','','','','','',0,'','','','','1526711616','1526711616',100,0),(75,'web_site_address','平台运营公司地址','base','text','400-1234-888','','配置名：web_site_address','','','','','',0,'','','','','1526711907','1526711907',100,0),(76,'web_site_mock','模拟操盘金额','stock','text','1','','单位万元 调用方法config(\'web_site_mock\')','','','','','',0,'','','','','1527746692','1527746692',100,0),(77,'web_mock_set','模拟盘会员中心显示开关','stock','radio','1','1:开启\n0:关闭','模拟盘会员中心显示开关 调用方法config(\'web_mock_set\')','','','','','',0,'','','','','1527838638','1528095548',100,0),(80,'member_back_rate','普通用户佣金比例','share','number','10','','普通用户佣金比例（单位：%）','','','','','',0,'','','','','1970','1665229507',1,1),(82,'agent_back_rate','总返佣比例','share','number','50','','总返佣（单位：%）','','','','','',0,'','','','','1970','1665229507',3,1),(85,'member_back_time','普通用户返佣期限','share','text','1','','普通用户返佣期限 member_back_time (单位： 月)','','','','','',0,'','','','','1970','1665229507',100,1),(86,'web_site_holiday_service_time','客服假期在线时间','base','text','12:00 - 20:00','0','客服时间','','','','','',0,'','','','','1524624886','1616474638',100,0),(87,'web_pcdownurl_set','电脑版下载链接','system','text','','','调用方法：config(\'web_pcdownurl_set\')','','','','','',0,'','','','','1530610115','1530610115',100,0),(88,'app_open','APP开关','app','radio','1','0|关闭\n1|开启\n','关闭后APP将无法与后台通信','','','','','',0,'','','','','01/01/1970 07:00','1762503007',0,1),(89,'app_name','APP名称','app','text','Sbcprime','','APP名称可在APP代码中设置，非必填','','','','','',0,'','','','','01/01/1970 07:00','1762503007',0,1),(90,'android_down','安卓升级地址','app','text','','','','','','','','',0,'','','','','01/01/1970 07:00','1762503007',1,1),(91,'android_power','安卓强制升级','app','radio','0','','','','','','','',0,'','','','','01/01/1970 07:00','1762503007',2,1),(92,'android_version_name','安卓版本','app','text','2.1.0','','','','','','','',0,'','','','','01/01/1970 07:00','1762503007',3,1),(94,'android_description','安卓更新描述','app','textarea','1、修复已知BUG\n2、提高兼容性\n3、优化启动速度\n4、优化K线图打开速度\n5、增加在线版本热更新功能\n','','','','','','','',0,'','','','','01/01/1970 07:00','1762503007',5,1),(96,'ios_power','苹果强制升级','app','radio','0','','','','','','','',0,'','','','','01/01/1970 07:00','1762503007',12,1),(97,'ios_version_name','苹果版本','app','text','1.0.7','','','','','','','',0,'','','','','01/01/1970 07:00','1762503007',13,1),(98,'ios_description','苹果更新描述','app','textarea','1、修复已知BUG\n2、提高兼容性\n3、优化启动速度\n4、优化K线图打开速度\n5、增加在线版本热更新功能\n','','','','','','','',0,'','','','','01/01/1970 07:00','1762503007',15,1),(99,'web_site_front_end_logo','前台首页LOGO','base','image','435','','调用方法：config(\'web_site_front end_logo\')','','','','','',0,'','','','','1531209442','1531217926',4,0),(100,'web_money_tip','充值/提现说明','money','textarea','1、周一至周五09:00-20:00（工作日）。\n2、单笔充值/提现不能小于100元，不大于100万元。\n3、充值或提现24小时之内到账，遇节假日顺延。','','充值提现说明 web_money_tip','','','','','',0,'','','','','01/01/1970 07:00','1763979197',100,1),(101,'web_trade_port','交易端口号','base','text','8282','','','','','','','',0,'','','','','1531474868','1531474868',100,0),(102,'ios_down','苹果升级地址','app','text','','','','','','','','',0,'','','','','01/01/1970 07:00','1762503007',11,1),(103,'web_virtual_borrow_num','首页-累计配资人数-虚拟基数','stock','text','2222222','','','','','','','',0,'','','','','1532077460','1532077460',30,0),(104,'web_stock_operation_amount','首页-累计操盘资金-虚拟基数','stock','text','1111111','','','','','','','',0,'','','','','1532077488','1532077488',31,0),(105,'share_title','分享标题','share','text','帮您解锁了一个赚钱姿势，收益多赚10倍的方法！','','','','','','','',0,'','','','','1970','1665229507',100,1),(106,'share_content','分享内容','share','textarea','猛戳该分享链接，脱贫致富的秘诀，就在这里！严格风控，亏损有限，盈利无限！快来点击注册吧！','','','','','','','',0,'','','','','1970','1665229507',100,1),(107,'sms_use','短信接口账号','sms','text','','','注册短信平台后可获取。【短信平台：https://www.smsbao.com/】','','','','','',0,'','','','','1970-01-01 08:32','1732034333',100,1),(108,'sms_pwd','短信接口密码','sms','text','','','注册短信平台后获可取。【短信平台：https://www.smsbao.com/】','','','','','',0,'','','','','1970-01-01 08:32','1732034333',100,1),(110,'sms_status','短信接口开关','sms','radio','1','0|关闭\n1|开启','关闭后，短信接口失效。【短信平台：https://www.smsbao.com/】','','','','','',0,'','','','','1970-01-01 08:32','1732034333',1,1),(111,'web_pcdownurl_set','电脑版下载链接','base','text','','','调用方法：config(\'web_pcdownurl_set\')','','','','','',0,'','','','','1533781198','1533781198',15,0),(112,'share_logo','分享图片','share','text','https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fhbimg.huabanimg.com%2F9940ab69f0ba8f3d9275ac6feb8d65dd11f8dd994acfa-HP338O_fw658&refer=http%3A%2F%2Fhbimg.huabanimg.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1667821484&t=5f5987c0da64d588bf0898073975b00b','','','','','','','',0,'','','','','1970','1665229507',100,1),(113,'trust_active_time','委托有效时间','stock','text','60','30','单位分钟，如30表示30分钟内有效。0表示默认10分钟。','','','','','',0,'','','','','01/01/1970 07:32','1750420420',100,1),(114,'online_recharge_switch','开启线上充值','onlinerecharge','switch','1','','默认关闭，开启后前台显示线上充值页面','','','','','',0,'','','','','1534152269','1534152301',100,1),(115,'merchant_id','商户号','onlinerecharge','text','','','','','','','','',0,'','','','','1534152404','1534152404',100,1),(116,'private_key','商户私钥','onlinerecharge','textarea','','','','','','','','',0,'','','','','1534152463','1534152463',100,1),(117,'public_key','支付公钥','onlinerecharge','textarea','','','','','','','','',0,'','','','','1534152578','1534152578',100,1),(118,'app_share_address','App分享地址','share','text','','','','','','','','',0,'','','','','2018','1665229507',100,1),(119,'sms_sign','发送短信签名','sms','text','','','例如：【配资平台】','','','','','',0,'','','','','1970-01-01 08:32','1732034333',100,1),(120,'stock_expend','扩大配资申请模板','sms_admin_template','text','会员#var#申请了扩大配资,扩大金额#amount#元','','','','','','','',0,'','','','','1534900832','1534900832',100,0),(122,'stock_addmoney','追加保证金申请模板','sms_admin_template','text','会员#var#申请了追加保证金,追加金额#amount#元','','','','','','','',0,'','','','','1534901332','1534901332',100,0),(123,'stock_drawprofit','申请提取收益模板','sms_admin_template','text','会员#var#申请了提取收益#amount#元','','','','','','','',0,'','','','','1534901431','1534901431',100,0),(124,'stock_renewal','配资延期申请模板','sms_admin_template','text','会员#var#申请了配资延期','','','','','','','',0,'','','','','1534901461','1534901461',100,0),(125,'stock_stop','终止配资申请模板','sms_admin_template','text','会员#var#申请了终止配资','','','','','','','',0,'','','','','1534901511','1534901511',100,0),(126,'stock_borrow_endedit','配资使用期限结束','sms_admin_template','text','会员#var#配资使用期限结束','','','','','','','',0,'','','','','1534902035','1534902035',100,0),(127,'stock_handle_applySave','申请配资模板','sms_admin_template','text','会员#var#申请了配资','','','','','','','',0,'','','','','1534902100','1534902100',100,0),(128,'stock_realname','申请实名认证模板','sms_admin_template','text','会员#var#,申请了实名认证.','','','','','','','',0,'','','','','1534905595','1534905595',100,0),(129,'stock_withdraw','申请提现模板','sms_admin_template','text','会员#var#申请了提现,提现金额#amount#元.','','','','','','','',0,'','','','','1534905667','1534905667',100,0),(130,'stock_offline','线下充值申请模板','sms_admin_template','text','会员#var#申请了线下充值,充值金额#amount#元.','','','','','','','',0,'','','','','1534905694','1534905694',100,0),(131,'register','会员注册验证码模板','sms_user_template','text','尊敬的会员#var#您好,您正在平台系统申请手机验证,验证码为','','','','','','','',0,'','','','','1534989593','1534989593',100,1),(132,'stock_auditing','配资审核通过模板','sms_user_template','text','尊敬的会员#var#,您的订单号#order_id#的配资审核通过','','','','','','','',0,'','','','','1534989657','1534989657',100,1),(133,'stock_addfinancing_saveAddfinancing','追加配资审核不通过模板','sms_user_template','text','尊敬的会员#var#,您的订单号#order_id#的扩大配资审核不通过,释放冻结资金','','','','','','','',0,'','','','','1534989685','1534989685',100,1),(134,'stock_addmoney_saveAddmoney','追加保证金审核通过模板','sms_user_template','text','尊敬的会员#var#,您的订单号#order_id#的追加保证金审核通过','','','','','','','',0,'','','','','1534990173','1534990173',100,1),(135,'stock_drawprofit_saveDrawprofit','提取盈利审核通过模板','sms_user_template','text','尊敬的会员#var#,您的订单号#order_id#的提取盈利审核通过','','','','','','','',0,'','','','','1534990202','1541731507',100,1),(136,'stock_renewal_saveRenewal','扩大续期审核不通过模板','sms_user_template','text','尊敬的会员#var#,您的订单号#order_id#的续期申请审核未通过,释放冻结服务费','','','','','','','',0,'','','','','1534990260','1534990260',100,1),(137,'stock_offline_auditing_success','线下充值审核通过模板','sms_user_template','text','尊敬的会员#var#,线下充值金额#amount#元审核通过.','','','','','','','',0,'','','','','1534990292','1534990292',100,1),(138,'stock_offline_auditing_fail','线下充值审核失败','sms_user_template','text','尊敬的会员#var#,线下充值金额#amount#元审核失败.','','','','','','','',0,'','','','','1534990327','1534990327',100,1),(139,'stock_withdraw_auditing_success','提现审核通过','sms_user_template','text','尊敬的会员#var#,提现金额#amount#元审核通过.','','','','','','','',0,'','','','','1534990349','1534990349',100,1),(140,'stock_withdraw_auditing_fail','提现审核失败','sms_user_template','text','尊敬的会员#var#,提现金额#amount#元审核失败.','','','','','','','',0,'','','','','1534990372','1534990372',100,1),(141,'stock_loss_warn','低于预警线短信','sms_user_template','text','尊敬的会员#var#,您的订单号#order_id#的配资,操盘总资产已经低于预警线,请及时追加保证金','','','','','','','',0,'','','','','1534990396','1534990396',100,1),(142,'stock_loss_close','低于止损线短信','sms_user_template','text','尊敬的会员#var#,您的订单号#order_id#的配资,配资总资产低于平仓线,将被自动平仓','','','','','','','',0,'','','','','1534990412','1564560395',100,1),(144,'stock_auditing_fail','配资审核失败模板','sms_user_template','text','尊敬的会员#var#,您的订单号#order_id#的配资审核失败','','','','','','','',0,'','','','','1535356482','1535356482',100,1),(145,'ios_tcode','ios二维码','app','image','395','','','','','','','',0,'','','','','1536132531','1536132531',16,0),(146,'Android_tcode','Android','app','image','395','','','','','','','',0,'','','','','1536132628','1536132628',6,0),(147,'low_withdrawal_amount','最低提现金额','money','text','100000','','','','','','','',0,'','','','','01/01/1970 07:00','1763979197',100,1),(148,'stock_addfinancing_success','扩大配资成功模板','sms_user_template','text','尊敬的会员#var#,您的订单号#order_id#追加配资审核通过','','','','','','','',0,'','','','','1541729637','1541729637',100,1),(149,'stock_renewal_success','续期审核通过模板','sms_user_template','text','尊敬的会员#var#,您的订单号#order_id#续期审核通过','','','','','','','',2,'','','','','1541730171','1545892408',100,1),(150,'give_reg','注册赠送管理费','give','text','0','','','','','','','',0,'','','','','1970-01-01 08:33:39','1677235426',100,1),(151,'give_realname','实名认证赠送管理费','give','text','0','','','','','','','',0,'','','','','1970-01-01 08:33:39','1677235426',100,1),(152,'give_firstborrow','首次配资赠送管理费','give','text','0','','','','','','','',0,'','','','','1970-01-01 08:33:39','1677235426',100,1),(153,'give_firstcharge','首次充值赠送管理费','give','text','0','','','','','','','',0,'','','','','1970-01-01 08:33:39','1677235426',100,1),(154,'give_bankcard','绑定银行卡赠送管理费','give','text','0','','','','','','','',0,'','','','','1970-01-01 08:33:39','1677235426',100,1),(155,'give_firstaddborrow','首次追加配资赠送管理费','give','text','0','','','','','','','',0,'','','','','1970-01-01 08:33:39','1677235426',100,1),(156,'give_firstaddmoney','首次追加保证金赠送管理费','give','text','0','','','','','','','',0,'','','','','1970-01-01 08:33:39','1677235426',100,1),(157,'give_firstdrawprofit','首次提盈赠送管理费','give','text','0','','','','','','','',0,'','','','','1970-01-01 08:33:39','1677235426',100,1),(159,'give_open','是否开启','give','radio','1','1:开启\n0:关闭','','','','','','',0,'','','','','1970-01-01 08:33:39','1677235426',110,1),(161,'give_one_offset','单次抵扣额度','give','text','0','','单次配资最多能抵扣的管理费 (数值小于1为百分比，比如0.1为 10%；数值大于1时为具体额度，比如100为 ￥100）','','','','','',0,'','','','','1970-01-01 08:33:39','1677235426',100,1),(162,'give_scale','赠送现金比例','give','text','1000','','赠送比例%','','','','','',0,'','','','','1970-01-01 08:33:39','1677235426',100,1),(163,'give_bankcharge','充值比例','give','text','0','','充值赠送百分比%','','','','','',0,'','','','','2019-05-13 16:14:32','1677235426',98,1),(165,'give_charge','赠送管理费比例','give','text','0','','赠送管理费比例%(需要在活动赠送，开启管理费赠送后才会赠送)','','','','','',0,'','','','','2019-05-13 16:24:24','1677235426',99,1),(166,'stock_buy_price','股票买入价格设定','stock','text','1','','小于设定值的股票将不能买入','','','','','',0,'','','','','01/01/1970 07:32','1750420420',100,1),(167,'stock_auto_renewal_success','自动续费成功','sms_user_template','text','尊敬的会员#var#,您的订单号#order_id#自动续期成功','','','','','','','',0,'','','','','1559804369','1559804369',100,1),(168,'stock_limit_trade','逾期限制交易','sms_user_template','text','尊敬的会员#var#,您的订单号#order_id#的配资已逾期，交易将被限制，请及时续费','','','','','','','',0,'','','','','1559804401','1559804401',100,1),(169,'site_trade_buy','全站允许买入股票','system','radio','1','1:允许\r\n0:禁止','关闭后所有股票将禁止买入','','','','','',0,'','','','','01/01/1970 07:32','1755232774',100,1),(170,'site_trade_sell','全站允许卖出股票','system','radio','1','1:允许\r\n0:禁止','关闭后所有股票将禁止卖出','','','','','',0,'','','','','01/01/1970 07:32','1755232774',100,1),(171,'web_admin_login','后台允许登录ip','system','text','127.0.0.1','','后台可登录的IP','','','','','',0,'','','','','1563685075','1563685075',100,0),(172,'web_chat_link','客服链接','base','text','https://direct.lc.chat/19159404/','','将客服平台提供的链接地址填在此处','','','','','',0,'','','','','01/01/1970 07:00','1763297883',13,1),(176,'agent_back_rate1','一级代理返佣比例','share','text','50','','一级代理返佣比例（单位：%）','','','','','',0,'','','','','1970','1665229507',2,1),(177,'sms_type','短信接口','sms','radio','1','1:默认接口\r\n','','','','','','',0,'','','','','1586776282','1588656905',100,0),(179,'web_reg_code','短信注册开关','system','radio','0','1:开启\r\n0:关闭\r\n','关闭后不再验证短信验证码','','','','','',0,'','','','','01/01/1970 07:32','1755232774',4,1),(181,'deposit_money','免费操盘体验金','stock','text','100','','免费操盘体验金（自己出的钱）','','','','','',0,'','','','','1610783929','1610783929',100,0),(182,'borrow_money','借款体验金额','stock','text','10000','','免费操盘（平台出资）','','','','','',0,'','','','','01/01/1970 07:32','1750420420',100,1),(183,'taste_day','体验天数','stock','text','3','','免费体验操盘天数','','','','','',0,'','','','','1610784125','1610784125',100,0),(185,'app_market','APP行情页大盘数据开关','app','radio','1','0|关闭\r\n1|开启','app_market','','','','','',0,'','','','','1610784473','1610784473',100,0),(186,'free_isopen','免费操盘板块显示开关','app','radio','1','0|关闭\r\n1|开启\r\n','free_isopen','','','','','',0,'','','','','2021','1660026220',101,0),(187,'is_reg','全站注册开关','system','radio','1','1:开启\r\n0:关闭','全站注册开关,关闭后前台无法注册','','','','','',0,'','','','','01/01/1970 07:32','1755232774',2,1),(188,'is_recommend','邀请注册开关','system','radio','1','1:开启\r\n0:关闭','邀请注册开关','','','','','',0,'','','','','01/01/1970 07:32','1755232774',3,1),(189,'app_url','本站网址','app','text','https://www.fundiqsbc.com','','(例：http://www.xxxxx.com)调用方法：sysConfig(\'app_url\')','','','','','',0,'','','','','01/01/1970 07:00','1762503007',0,1),(190,'app_ips','服务器IP地址','app','text','','','调用方法：sysConfig(\'app_ips\')','','','','','',0,'','','','','01/01/1970 07:00','1762503007',0,1),(191,'app_key','APP通信秘钥','app','text','8cfa519d3ce5415dc54df51cdda02e97','','(请联系开发者)调用方法：sysConfig(\'app_key\')','','','','','',0,'','','','','1618287693','1618287693',100,0),(192,'apk_down_url','安卓下载地址','app','text','','','调用方法：sysConfig(\'apk_down_url\')','','','','','',0,'','','','','01/01/1970 07:00','1762503007',6,1),(193,'ios_down_url','苹果下载地址','app','text','','','调用方法：sysConfig(\'ios_down_url\')','','','','','',0,'','','','','01/01/1970 07:00','1762503007',100,1),(194,'android_version','安卓版本号','app','text','210','','安卓版本号，调用方法：sysConfig(\'android_version\')','','','','','',0,'','','','','01/01/1970 07:00','1762503007',4,1),(195,'ios_version','苹果版本号','app','text','107','','苹果版本号，调用方法：sysConfig(\'ios_version\')','','','','','',0,'','','','','01/01/1970 07:00','1762503007',14,1),(196,'news_url','首页资讯中心采集地址','app','text','https://www.jin10.com/example/jin10.com.html?fontSize=14px&theme=white','','','','','','','',0,'','','','','1635262233','1635262233',100,0),(197,'commission_scale','佣金比例','stock','number','0','佣金比例（单位：万分之几） 如：5 代表万分之五','佣金比例（单位：万分之几） 如：5 代表万分之五','','','','','',0,'','','','','01/01/1970 07:32','1750420420',54,1),(198,'single_desc','跟单介绍','base','richText','<p>Klik \"Ikuti Investasi\" untuk melihat informasi detail tentang investor unggulan dan masuk ke halaman pengajuan untuk melanjutkan. Harap diperhatikan, hanya setelah Anda mengonfirmasi untuk ikut berinvestasi, maka trader akan mulai mengelola dana investasi Anda. Jika konfirmasi dilakukan terlalu lambat, Anda mungkin akan melewatkan kesempatan pembelian pada hari yang sama. Silakan ajukan tepat waktu.</p>','跟单页面 跟单操作介绍','跟单页面 跟单操作介绍','','','','','',0,'','','','','01/01/1970 07:00','1763297883',30,1),(199,'qizhang_token','启涨数据Token','base','text','','启涨数据查询个股分笔交易密钥','启涨数据查询个股分笔交易密钥','','','','','',0,'','','','','01/01/1970 07:00','1763297883',50,1),(200,'web_login_ip','后台登录IP','base','text','45.198.2.204,45.198.2.174,45.198.2.235,45.198.2.137,64.176.52.204,45.198.2.199,45.198.2.217,27.109.113.204,185.18.222.170,45.198.2.152,45.198.2.169,154.222.64.69,8.217.218.48,47.242.100.58,45.198.2.196,45.198.2.248,203.176.134.132,154.222.64.68,202.93.13.40','多个ip请用英文逗号分割(127.0.0.1,127.0.0.2)','多个ip请用英文逗号分割(127.0.0.1,127.0.0.2)','','','','','',0,'','','','','01/01/1970 07:00','1763297883',52,1),(201,'lv_1','直接上级','stock','text','6','直接上级分佣获得比例','直接上级分佣获得比例','','','','','',0,'','','','',NULL,'1750420420',100,1),(202,'lv_2','次级上级','stock','text','3','次级上级分佣获得比例','次级上级分佣获得比例','','','','','',0,'','','','',NULL,'1750420420',100,1),(203,'lv_3','三级上级','stock','text','2','三级上级分佣获得\r\n','三级上级分佣获得','','','','','',0,'','','','',NULL,'1750420420',100,1),(204,'recharge_min','最低充值','money','number','100000','最低充值','最低充值','','','','','',2,'','','','',NULL,'1763979197',100,1),(205,'bank_count','绑卡数量','money','number','2','绑卡数量','绑卡数量','','','','','',2,'','','','',NULL,'1763979197',100,1),(206,'ip_count','同IP注册数量','base','number','20','同IP注册数量','同IP注册数量','','','','','',2,'','','','',NULL,'1763297883',100,1);
/*!40000 ALTER TABLE `st_admin_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_admin_hook`
--

DROP TABLE IF EXISTS `st_admin_hook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_admin_hook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `plugin` varchar(32) NOT NULL DEFAULT '' COMMENT '钩子来自哪个插件',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子描述',
  `system` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统钩子',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='钩子表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_admin_hook`
--

LOCK TABLES `st_admin_hook` WRITE;
/*!40000 ALTER TABLE `st_admin_hook` DISABLE KEYS */;
INSERT INTO `st_admin_hook` VALUES (1,'admin_index','','后台首页',1,1468174214,1555463975,1),(2,'plugin_index_tab_list','','插件扩展tab钩子',1,1468174214,1468174214,1),(3,'module_index_tab_list','','模块扩展tab钩子',1,1468174214,1468174214,1),(4,'page_tips','','每个页面的提示',1,1468174214,1468174214,1),(5,'signin_footer','','登录页面底部钩子',1,1479269315,1479269315,1),(6,'signin_captcha','','登录页面验证码钩子',1,1479269315,1479269315,1),(7,'signin','','登录控制器钩子',1,1479386875,1479386875,1),(8,'upload_attachment','','附件上传钩子',1,1501493808,1501493808,1),(9,'page_plugin_js','','页面插件js钩子',1,1503633591,1503633591,1),(10,'page_plugin_css','','页面插件css钩子',1,1503633591,1503633591,1),(11,'signin_sso','','单点登录钩子',1,1503633591,1503633591,1),(12,'signout_sso','','单点退出钩子',1,1503633591,1503633591,1),(13,'user_add','','添加用户钩子',1,1503633591,1503633591,1),(14,'user_edit','','编辑用户钩子',1,1503633591,1503633591,1),(15,'user_delete','','删除用户钩子',1,1503633591,1503633591,1),(16,'user_enable','','启用用户钩子',1,1503633591,1503633591,1),(17,'user_disable','','禁用用户钩子',1,1503633591,1503633591,1);
/*!40000 ALTER TABLE `st_admin_hook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_admin_hook_plugin`
--

DROP TABLE IF EXISTS `st_admin_hook_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_admin_hook_plugin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(32) NOT NULL DEFAULT '' COMMENT '钩子id',
  `plugin` varchar(32) NOT NULL DEFAULT '' COMMENT '插件标识',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(10) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='钩子-插件对应表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_admin_hook_plugin`
--

LOCK TABLES `st_admin_hook_plugin` WRITE;
/*!40000 ALTER TABLE `st_admin_hook_plugin` DISABLE KEYS */;
INSERT INTO `st_admin_hook_plugin` VALUES (1,'admin_index','SystemInfo',1477757503,1477757503,1,1),(5,'upload_attachment','QiNiu',1514519779,1514519779,100,1),(8,'page_tips','GreenSparrow',1514971688,1514971688,100,1),(9,'my_hook','GreenSparrow',1514971688,1514971688,100,1),(10,'admin_index','Statistics',1526870610,1526870610,3,1),(11,'admin_index','waitingProcess',1526955705,1526955705,2,1);
/*!40000 ALTER TABLE `st_admin_hook_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_admin_log`
--

DROP TABLE IF EXISTS `st_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_admin_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` varchar(50) NOT NULL DEFAULT '0' COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` longtext NOT NULL COMMENT '日志备注',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`),
  KEY `model` (`model`),
  KEY `idx_recordid_model` (`record_id`,`model`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='行为日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_admin_log`
--

LOCK TABLES `st_admin_log` WRITE;
/*!40000 ALTER TABLE `st_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_admin_menu`
--

DROP TABLE IF EXISTS `st_admin_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_admin_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级菜单id',
  `module` varchar(16) NOT NULL DEFAULT '' COMMENT '模块名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '菜单标题',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '菜单图标',
  `url_type` varchar(16) NOT NULL DEFAULT '' COMMENT '链接类型（link：外链，module：模块）',
  `url_value` varchar(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `url_target` varchar(16) NOT NULL DEFAULT '_self' COMMENT '链接打开方式：_blank,_self',
  `online_hide` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '网站上线后是否隐藏',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `system_menu` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统菜单，系统菜单不可删除',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  `params` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1078 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='后台菜单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_admin_menu`
--

LOCK TABLES `st_admin_menu` WRITE;
/*!40000 ALTER TABLE `st_admin_menu` DISABLE KEYS */;
INSERT INTO `st_admin_menu` VALUES (1,0,'admin','首页','fa fa-fw fa-home','module_admin','admin/index/index','_self',0,1467617722,1513151565,1,1,1,''),(2,1,'admin','快捷操作','fa fa-fw fa-folder-open-o','module_admin','','_self',0,1467618170,1477710695,1,1,1,''),(3,2,'admin','清空缓存','fa fa-fw fa-trash-o','module_admin','admin/index/wipecache','_self',0,1467618273,1489049773,3,1,1,''),(4,0,'admin','系统','fa fa-fw fa-gear','module_admin','admin/system/index','_self',0,1467618361,1513151565,2,1,1,''),(5,4,'admin','系统功能','si si-wrench','module_admin','','_self',0,1467618441,1477710695,1,1,1,''),(6,5,'admin','系统设置','fa fa-fw fa-wrench','module_admin','admin/system/index','_self',0,1467618490,1477710695,1,1,1,''),(7,5,'admin','配置管理','fa fa-fw fa-gears','module_admin','admin/config/index','_self',0,1467618618,1477710695,2,1,1,''),(8,7,'admin','新增','','module_admin','admin/config/add','_self',0,1467618648,1477710695,1,1,1,''),(9,7,'admin','编辑','','module_admin','admin/config/edit','_self',0,1467619566,1477710695,2,1,1,''),(10,7,'admin','删除','','module_admin','admin/config/delete','_self',0,1467619583,1477710695,3,1,1,''),(11,7,'admin','启用','','module_admin','admin/config/enable','_self',0,1467619609,1477710695,4,1,1,''),(12,7,'admin','禁用','','module_admin','admin/config/disable','_self',0,1467619637,1477710695,5,1,1,''),(13,5,'admin','节点管理','fa fa-fw fa-bars','module_admin','admin/menu/index','_self',0,1467619882,1477710695,3,1,1,''),(14,13,'admin','新增','','module_admin','admin/menu/add','_self',0,1467619902,1477710695,1,1,1,''),(15,13,'admin','编辑','','module_admin','admin/menu/edit','_self',0,1467620331,1477710695,2,1,1,''),(16,13,'admin','删除','','module_admin','admin/menu/delete','_self',0,1467620363,1477710695,3,1,1,''),(17,13,'admin','启用','','module_admin','admin/menu/enable','_self',0,1467620386,1477710695,4,1,1,''),(18,13,'admin','禁用','','module_admin','admin/menu/disable','_self',0,1467620404,1477710695,5,1,1,''),(19,68,'user','权限管理','fa fa-fw fa-key','module_admin','','_self',0,1467688065,1477710702,1,1,1,''),(20,19,'user','用户管理','fa fa-fw fa-user','module_admin','user/index/index','_self',0,1467688137,1477710702,1,1,1,''),(21,20,'user','新增','','module_admin','user/index/add','_self',0,1467688177,1477710702,1,1,1,''),(22,20,'user','编辑','','module_admin','user/index/edit','_self',0,1467688202,1477710702,2,1,1,''),(23,20,'user','删除','','module_admin','user/index/delete','_self',0,1467688219,1477710702,3,1,1,''),(24,20,'user','启用','','module_admin','user/index/enable','_self',0,1467688238,1477710702,4,1,1,''),(25,20,'user','禁用','','module_admin','user/index/disable','_self',0,1467688256,1477710702,5,1,1,''),(32,4,'admin','扩展中心','si si-social-dropbox','module_admin','','_self',0,1467688853,1477710695,2,1,1,''),(33,32,'admin','模块管理','fa fa-fw fa-th-large','module_admin','admin/module/index','_self',0,1467689008,1477710695,1,1,1,''),(34,33,'admin','导入','','module_admin','admin/module/import','_self',0,1467689153,1477710695,1,1,1,''),(35,33,'admin','导出','','module_admin','admin/module/export','_self',0,1467689173,1477710695,2,1,1,''),(36,33,'admin','安装','','module_admin','admin/module/install','_self',0,1467689192,1477710695,3,1,1,''),(37,33,'admin','卸载','','module_admin','admin/module/uninstall','_self',0,1467689241,1477710695,4,1,1,''),(38,33,'admin','启用','','module_admin','admin/module/enable','_self',0,1467689294,1477710695,5,1,1,''),(39,33,'admin','禁用','','module_admin','admin/module/disable','_self',0,1467689312,1477710695,6,1,1,''),(40,33,'admin','更新','','module_admin','admin/module/update','_self',0,1467689341,1477710695,7,1,1,''),(41,32,'admin','插件管理','fa fa-fw fa-puzzle-piece','module_admin','admin/plugin/index','_self',0,1467689527,1477710695,2,1,1,''),(42,41,'admin','导入','','module_admin','admin/plugin/import','_self',0,1467689650,1477710695,1,1,1,''),(43,41,'admin','导出','','module_admin','admin/plugin/export','_self',0,1467689665,1477710695,2,1,1,''),(44,41,'admin','安装','','module_admin','admin/plugin/install','_self',0,1467689680,1477710695,3,1,1,''),(45,41,'admin','卸载','','module_admin','admin/plugin/uninstall','_self',0,1467689700,1477710695,4,1,1,''),(46,41,'admin','启用','','module_admin','admin/plugin/enable','_self',0,1467689730,1477710695,5,1,1,''),(47,41,'admin','禁用','','module_admin','admin/plugin/disable','_self',0,1467689747,1477710695,6,1,1,''),(48,41,'admin','设置','','module_admin','admin/plugin/config','_self',0,1467689789,1477710695,7,1,1,''),(49,41,'admin','管理','','module_admin','admin/plugin/manage','_self',0,1467689846,1477710695,8,1,1,''),(50,5,'admin','附件管理','fa fa-fw fa-cloud-upload','module_admin','admin/attachment/index','_self',0,1467690161,1477710695,4,1,1,''),(51,70,'admin','文件上传','','module_admin','admin/attachment/upload','_self',0,1467690240,1489049773,1,1,1,''),(52,50,'admin','下载','','module_admin','admin/attachment/download','_self',0,1467690334,1477710695,2,1,1,''),(53,50,'admin','启用','','module_admin','admin/attachment/enable','_self',0,1467690352,1477710695,3,1,1,''),(54,50,'admin','禁用','','module_admin','admin/attachment/disable','_self',0,1467690369,1477710695,4,1,1,''),(55,50,'admin','删除','','module_admin','admin/attachment/delete','_self',0,1467690396,1477710695,5,1,1,''),(56,41,'admin','删除','','module_admin','admin/plugin/delete','_self',0,1467858065,1477710695,11,1,1,''),(57,41,'admin','编辑','','module_admin','admin/plugin/edit','_self',0,1467858092,1477710695,10,1,1,''),(60,41,'admin','新增','','module_admin','admin/plugin/add','_self',0,1467858421,1477710695,9,1,1,''),(61,41,'admin','执行','','module_admin','admin/plugin/execute','_self',0,1467879016,1477710695,14,1,1,''),(62,13,'admin','保存','','module_admin','admin/menu/save','_self',0,1468073039,1477710695,6,1,1,''),(64,5,'admin','系统日志','fa fa-fw fa-book','module_admin','admin/log/index','_self',0,1476111944,1477710695,6,0,1,''),(65,5,'admin','数据库管理','fa fa-fw fa-database','module_admin','admin/database/index','_self',0,1476111992,1477710695,8,0,1,''),(66,32,'admin','数据包管理','fa fa-fw fa-database','module_admin','admin/packet/index','_self',0,1476112326,1477710695,4,0,1,''),(67,19,'user','角色管理','fa fa-fw fa-users','module_admin','user/role/index','_self',0,1476113025,1477710702,3,0,1,''),(68,0,'user','后台管理员','fa fa-fw fa-user','module_admin','user/index/index','_self',0,1476193348,1527904014,3,0,1,''),(69,32,'admin','钩子管理','fa fa-fw fa-anchor','module_admin','admin/hook/index','_self',0,1476236193,1477710695,3,0,1,''),(70,2,'admin','后台首页','fa fa-fw fa-tachometer','module_admin','admin/index/index','_self',0,1476237472,1569806309,1,0,1,''),(71,67,'user','新增','','module_admin','user/role/add','_self',0,1476256935,1477710702,1,0,1,''),(72,67,'user','编辑','','module_admin','user/role/edit','_self',0,1476256968,1477710702,2,0,1,''),(73,67,'user','删除','','module_admin','user/role/delete','_self',0,1476256993,1477710702,3,0,1,''),(74,67,'user','启用','','module_admin','user/role/enable','_self',0,1476257023,1477710702,4,0,1,''),(75,67,'user','禁用','','module_admin','user/role/disable','_self',0,1476257046,1477710702,5,0,1,''),(76,20,'user','授权','','module_admin','user/index/access','_self',0,1476375187,1477710702,6,0,1,''),(77,69,'admin','新增','','module_admin','admin/hook/add','_self',0,1476668971,1477710695,1,0,1,''),(78,69,'admin','编辑','','module_admin','admin/hook/edit','_self',0,1476669006,1477710695,2,0,1,''),(79,69,'admin','删除','','module_admin','admin/hook/delete','_self',0,1476669375,1477710695,3,0,1,''),(80,69,'admin','启用','','module_admin','admin/hook/enable','_self',0,1476669427,1477710695,4,0,1,''),(81,69,'admin','禁用','','module_admin','admin/hook/disable','_self',0,1476669564,1477710695,5,0,1,''),(183,66,'admin','安装','','module_admin','admin/packet/install','_self',0,1476851362,1477710695,1,0,1,''),(184,66,'admin','卸载','','module_admin','admin/packet/uninstall','_self',0,1476851382,1477710695,2,0,1,''),(185,5,'admin','行为管理','fa fa-fw fa-bug','module_admin','admin/action/index','_self',0,1476882441,1477710695,7,0,1,''),(186,185,'admin','新增','','module_admin','admin/action/add','_self',0,1476884439,1477710695,1,0,1,''),(187,185,'admin','编辑','','module_admin','admin/action/edit','_self',0,1476884464,1477710695,2,0,1,''),(188,185,'admin','启用','','module_admin','admin/action/enable','_self',0,1476884493,1477710695,3,0,1,''),(189,185,'admin','禁用','','module_admin','admin/action/disable','_self',0,1476884534,1477710695,4,0,1,''),(190,185,'admin','删除','','module_admin','admin/action/delete','_self',0,1476884551,1477710695,5,0,1,''),(191,65,'admin','备份数据库','','module_admin','admin/database/export','_self',0,1476972746,1477710695,1,0,1,''),(192,65,'admin','还原数据库','','module_admin','admin/database/import','_self',0,1476972772,1477710695,2,0,1,''),(193,65,'admin','优化表','','module_admin','admin/database/optimize','_self',0,1476972800,1477710695,3,0,1,''),(194,65,'admin','修复表','','module_admin','admin/database/repair','_self',0,1476972825,1477710695,4,0,1,''),(195,65,'admin','删除备份','','module_admin','admin/database/delete','_self',0,1476973457,1477710695,5,0,1,''),(207,69,'admin','快速编辑','','module_admin','admin/hook/quickedit','_self',0,1477713770,1477713770,100,0,1,''),(208,7,'admin','快速编辑','','module_admin','admin/config/quickedit','_self',0,1477713808,1477713808,100,0,1,''),(209,185,'admin','快速编辑','','module_admin','admin/action/quickedit','_self',0,1477713939,1477713939,100,0,1,''),(210,41,'admin','快速编辑','','module_admin','admin/plugin/quickedit','_self',0,1477713981,1477713981,100,0,1,''),(211,64,'admin','日志详情','','module_admin','admin/log/details','_self',0,1480299320,1480299320,100,0,1,''),(212,2,'admin','个人设置','fa fa-fw fa-user','module_admin','admin/index/profile','_self',0,1489049767,1489049773,2,0,1,''),(213,70,'admin','检查版本更新','','module_admin','admin/index/checkupdate','_self',0,1490588610,1490588610,100,0,1,''),(214,0,'cms','门户','fa fa-fw fa-newspaper-o','module_admin','cms/index/index','_self',0,1512457289,1513151565,4,0,1,''),(215,214,'cms','常用操作','fa fa-fw fa-folder-open-o','module_admin','','_self',0,1512457289,1512457289,100,0,1,''),(216,215,'cms','仪表盘','fa fa-fw fa-tachometer','module_admin','cms/index/index','_self',0,1512457289,1512457289,100,0,1,''),(217,215,'cms','发布文档','fa fa-fw fa-plus','module_admin','cms/document/add','_self',0,1512457289,1512457289,100,0,1,''),(218,215,'cms','文档列表','fa fa-fw fa-list','module_admin','cms/document/index','_self',0,1512457289,1512457289,100,0,1,''),(219,218,'cms','编辑','','module_admin','cms/document/edit','_self',0,1512457289,1512457289,100,0,1,''),(220,218,'cms','删除','','module_admin','cms/document/delete','_self',0,1512457289,1512457289,100,0,1,''),(221,218,'cms','启用','','module_admin','cms/document/enable','_self',0,1512457289,1512457289,100,0,1,''),(222,218,'cms','禁用','','module_admin','cms/document/disable','_self',0,1512457289,1512457289,100,0,1,''),(223,218,'cms','快速编辑','','module_admin','cms/document/quickedit','_self',0,1512457289,1512457289,100,0,1,''),(224,215,'cms','单页管理','fa fa-fw fa-file-word-o','module_admin','cms/page/index','_self',0,1512457289,1512457289,100,0,1,''),(225,224,'cms','新增','','module_admin','cms/page/add','_self',0,1512457289,1512457289,100,0,1,''),(226,224,'cms','编辑','','module_admin','cms/page/edit','_self',0,1512457289,1512457289,100,0,1,''),(227,224,'cms','删除','','module_admin','cms/page/delete','_self',0,1512457289,1512457289,100,0,1,''),(228,224,'cms','启用','','module_admin','cms/page/enable','_self',0,1512457289,1512457289,100,0,1,''),(229,224,'cms','禁用','','module_admin','cms/page/disable','_self',0,1512457289,1512457289,100,0,1,''),(230,224,'cms','快速编辑','','module_admin','cms/page/quickedit','_self',0,1512457289,1512457289,100,0,1,''),(231,215,'cms','回收站','fa fa-fw fa-recycle','module_admin','cms/recycle/index','_self',0,1512457289,1512457289,100,0,1,''),(232,231,'cms','删除','','module_admin','cms/recycle/delete','_self',0,1512457289,1512457289,100,0,1,''),(233,231,'cms','还原','','module_admin','cms/recycle/restore','_self',0,1512457289,1512457289,100,0,1,''),(234,214,'cms','内容管理','fa fa-fw fa-th-list','module_admin','','_self',0,1512457289,1512457289,100,0,1,''),(235,214,'cms','营销管理','fa fa-fw fa-money','module_admin','','_self',0,1512457289,1512457289,100,0,1,''),(236,235,'cms','广告管理','fa fa-fw fa-handshake-o','module_admin','cms/advert/index','_self',0,1512457289,1512457289,100,0,1,''),(237,236,'cms','新增','','module_admin','cms/advert/add','_self',0,1512457289,1512457289,100,0,1,''),(238,236,'cms','编辑','','module_admin','cms/advert/edit','_self',0,1512457289,1512457289,100,0,1,''),(239,236,'cms','删除','','module_admin','cms/advert/delete','_self',0,1512457289,1512457289,100,0,1,''),(240,236,'cms','启用','','module_admin','cms/advert/enable','_self',0,1512457289,1512457289,100,0,1,''),(241,236,'cms','禁用','','module_admin','cms/advert/disable','_self',0,1512457289,1512457289,100,0,1,''),(242,236,'cms','快速编辑','','module_admin','cms/advert/quickedit','_self',0,1512457289,1512457289,100,0,1,''),(243,236,'cms','广告分类','','module_admin','cms/advert_type/index','_self',0,1512457289,1512457289,100,0,1,''),(244,243,'cms','新增','','module_admin','cms/advert_type/add','_self',0,1512457289,1512457289,100,0,1,''),(245,243,'cms','编辑','','module_admin','cms/advert_type/edit','_self',0,1512457289,1512457289,100,0,1,''),(246,243,'cms','删除','','module_admin','cms/advert_type/delete','_self',0,1512457289,1512457289,100,0,1,''),(247,243,'cms','启用','','module_admin','cms/advert_type/enable','_self',0,1512457289,1512457289,100,0,1,''),(248,243,'cms','禁用','','module_admin','cms/advert_type/disable','_self',0,1512457289,1512457289,100,0,1,''),(249,243,'cms','快速编辑','','module_admin','cms/advert_type/quickedit','_self',0,1512457289,1512457289,100,0,1,''),(250,235,'cms','滚动图片','fa fa-fw fa-photo','module_admin','cms/slider/index','_self',0,1512457289,1512457289,100,0,1,''),(251,250,'cms','新增','','module_admin','cms/slider/add','_self',0,1512457289,1512457289,100,0,1,''),(252,250,'cms','编辑','','module_admin','cms/slider/edit','_self',0,1512457289,1512457289,100,0,1,''),(253,250,'cms','删除','','module_admin','cms/slider/delete','_self',0,1512457289,1512457289,100,0,1,''),(254,250,'cms','启用','','module_admin','cms/slider/enable','_self',0,1512457289,1512457289,100,0,1,''),(255,250,'cms','禁用','','module_admin','cms/slider/disable','_self',0,1512457289,1512457289,100,0,1,''),(256,250,'cms','快速编辑','','module_admin','cms/slider/quickedit','_self',0,1512457289,1512457289,100,0,1,''),(257,235,'cms','友情链接','fa fa-fw fa-link','module_admin','cms/link/index','_self',0,1512457289,1512457289,100,0,1,''),(258,257,'cms','新增','','module_admin','cms/link/add','_self',0,1512457289,1512457289,100,0,1,''),(259,257,'cms','编辑','','module_admin','cms/link/edit','_self',0,1512457289,1512457289,100,0,1,''),(260,257,'cms','删除','','module_admin','cms/link/delete','_self',0,1512457289,1512457289,100,0,1,''),(261,257,'cms','启用','','module_admin','cms/link/enable','_self',0,1512457289,1512457289,100,0,1,''),(262,257,'cms','禁用','','module_admin','cms/link/disable','_self',0,1512457289,1512457289,100,0,1,''),(263,257,'cms','快速编辑','','module_admin','cms/link/quickedit','_self',0,1512457289,1512457289,100,0,1,''),(264,235,'cms','客服管理','fa fa-fw fa-commenting','module_admin','cms/support/index','_self',0,1512457289,1512457289,100,0,1,''),(265,264,'cms','新增','','module_admin','cms/support/add','_self',0,1512457289,1512457289,100,0,1,''),(266,264,'cms','编辑','','module_admin','cms/support/edit','_self',0,1512457289,1512457289,100,0,1,''),(267,264,'cms','删除','','module_admin','cms/support/delete','_self',0,1512457289,1512457289,100,0,1,''),(268,264,'cms','启用','','module_admin','cms/support/enable','_self',0,1512457289,1512457289,100,0,1,''),(269,264,'cms','禁用','','module_admin','cms/support/disable','_self',0,1512457289,1512457289,100,0,1,''),(270,264,'cms','快速编辑','','module_admin','cms/support/quickedit','_self',0,1512457289,1512457289,100,0,1,''),(271,214,'cms','门户设置','fa fa-fw fa-sliders','module_admin','','_self',0,1512457289,1512457289,100,0,1,''),(272,271,'cms','栏目分类','fa fa-fw fa-sitemap','module_admin','cms/column/index','_self',1,1512457289,1512457289,100,0,1,''),(273,272,'cms','新增','','module_admin','cms/column/add','_self',0,1512457289,1512457289,100,0,1,''),(274,272,'cms','编辑','','module_admin','cms/column/edit','_self',0,1512457289,1512457289,100,0,1,''),(275,272,'cms','删除','','module_admin','cms/column/delete','_self',0,1512457289,1512457289,100,0,1,''),(276,272,'cms','启用','','module_admin','cms/column/enable','_self',0,1512457289,1512457289,100,0,1,''),(277,272,'cms','禁用','','module_admin','cms/column/disable','_self',0,1512457289,1512457289,100,0,1,''),(278,272,'cms','快速编辑','','module_admin','cms/column/quickedit','_self',0,1512457289,1512457289,100,0,1,''),(279,271,'cms','内容模型','fa fa-fw fa-th-large','module_admin','cms/model/index','_self',0,1512457289,1512457289,100,0,1,''),(280,279,'cms','新增','','module_admin','cms/model/add','_self',0,1512457289,1512457289,100,0,1,''),(281,279,'cms','编辑','','module_admin','cms/model/edit','_self',0,1512457289,1512457289,100,0,1,''),(282,279,'cms','删除','','module_admin','cms/model/delete','_self',0,1512457289,1512457289,100,0,1,''),(283,279,'cms','启用','','module_admin','cms/model/enable','_self',0,1512457289,1512457289,100,0,1,''),(284,279,'cms','禁用','','module_admin','cms/model/disable','_self',0,1512457289,1512457289,100,0,1,''),(285,279,'cms','快速编辑','','module_admin','cms/model/quickedit','_self',0,1512457289,1512457289,100,0,1,''),(286,279,'cms','字段管理','','module_admin','cms/field/index','_self',0,1512457289,1512457289,100,0,1,''),(287,286,'cms','新增','','module_admin','cms/field/add','_self',0,1512457289,1512457289,100,0,1,''),(288,286,'cms','编辑','','module_admin','cms/field/edit','_self',0,1512457289,1512457289,100,0,1,''),(289,286,'cms','删除','','module_admin','cms/field/delete','_self',0,1512457289,1512457289,100,0,1,''),(290,286,'cms','启用','','module_admin','cms/field/enable','_self',0,1512457289,1512457289,100,0,1,''),(291,286,'cms','禁用','','module_admin','cms/field/disable','_self',0,1512457289,1512457289,100,0,1,''),(292,286,'cms','快速编辑','','module_admin','cms/field/quickedit','_self',0,1512457289,1512457289,100,0,1,''),(293,271,'cms','导航管理','fa fa-fw fa-map-signs','module_admin','cms/nav/index','_self',0,1512457289,1512457289,100,0,1,''),(294,293,'cms','新增','','module_admin','cms/nav/add','_self',0,1512457289,1512457289,100,0,1,''),(295,293,'cms','编辑','','module_admin','cms/nav/edit','_self',0,1512457289,1512457289,100,0,1,''),(296,293,'cms','删除','','module_admin','cms/nav/delete','_self',0,1512457289,1512457289,100,0,1,''),(297,293,'cms','启用','','module_admin','cms/nav/enable','_self',0,1512457289,1512457289,100,0,1,''),(298,293,'cms','禁用','','module_admin','cms/nav/disable','_self',0,1512457289,1512457289,100,0,1,''),(299,293,'cms','快速编辑','','module_admin','cms/nav/quickedit','_self',0,1512457289,1512457289,100,0,1,''),(300,293,'cms','菜单管理','','module_admin','cms/menu/index','_self',0,1512457289,1512457289,100,0,1,''),(301,300,'cms','新增','','module_admin','cms/menu/add','_self',0,1512457289,1512457289,100,0,1,''),(302,300,'cms','编辑','','module_admin','cms/menu/edit','_self',0,1512457289,1512457289,100,0,1,''),(303,300,'cms','删除','','module_admin','cms/menu/delete','_self',0,1512457289,1512457289,100,0,1,''),(304,300,'cms','启用','','module_admin','cms/menu/enable','_self',0,1512457289,1512457289,100,0,1,''),(305,300,'cms','禁用','','module_admin','cms/menu/disable','_self',0,1512457289,1512457289,100,0,1,''),(306,300,'cms','快速编辑','','module_admin','cms/menu/quickedit','_self',0,1512457289,1512457289,100,0,1,''),(308,234,'cms','新闻资讯','fa fa-fw fa-list','module_admin','cms/content/news','_self',0,1513402988,1513402988,100,0,1,''),(325,0,'stock','配资管理','fa fa-fw fa-pie-chart','module_admin','stock/broker/index','_self',0,1513569848,1528074055,100,0,1,''),(327,325,'stock','证券管理','fa fa-fw fa-area-chart','module_admin','','_self',0,1513570124,1513822821,100,0,1,''),(334,327,'stock','券商类型管理','fa fa-fw fa-university','module_admin','stock/broker/index','_self',0,1513570192,1513572153,100,0,1,''),(335,334,'stock','新增','','module_admin','stock/broker/add','_self',0,1513570192,1513570192,100,0,1,''),(336,334,'stock','编辑','','module_admin','stock/broker/edit','_self',0,1513570192,1513570192,100,0,1,''),(337,334,'stock','删除','','module_admin','stock/broker/delete','_self',0,1513570192,1513570192,100,0,1,''),(338,334,'stock','启用','','module_admin','stock/broker/enable','_self',0,1513570192,1513570192,100,0,1,''),(339,334,'stock','禁用','','module_admin','stock/broker/disable','_self',0,1513570192,1513570192,100,0,1,''),(340,334,'stock','快速编辑','','module_admin','stock/broker/quickedit','_self',0,1513570192,1513570192,100,0,1,''),(341,327,'stock','证券信息管理','fa fa-fw fa-user','module_admin','stock/account/index','_self',0,1513572228,1513761208,100,0,1,''),(342,341,'stock','新增','','module_admin','stock/account/add','_self',0,1513572227,1513761224,100,0,1,''),(343,341,'stock','编辑','','module_admin','stock/account/edit','_self',0,1513572227,1513761238,100,0,1,''),(344,341,'stock','删除','','module_admin','stock/account/delete','_self',0,1513572227,1513761249,100,0,1,''),(345,341,'stock','启用','','module_admin','stock/account/enable','_self',0,1513572227,1513761261,100,0,1,''),(346,341,'stock','禁用','','module_admin','stock/account/disable','_self',0,1513572227,1513994845,100,0,1,''),(347,341,'stock','快速编辑','','module_admin','stock/account/quickedit','_self',0,1513572227,1513994861,100,0,1,''),(348,325,'stock','交易账户管理','fa fa-fw fa-user-circle-o','module_admin','','_self',0,1513829146,1530599988,100,0,1,''),(355,348,'stock','交易账户列表','fa fa-fw fa-user-circle-o','module_admin','stock/subaccount/index','_self',0,1513829454,1530600019,100,0,1,''),(356,355,'stock','新增','','module_admin','stock/subaccount/add','_self',0,1513829454,1513829454,100,0,1,''),(357,355,'stock','编辑','','module_admin','stock/subaccount/edit','_self',0,1513829454,1513829454,100,0,1,''),(358,355,'stock','删除','','module_admin','stock/subaccount/delete','_self',0,1513829454,1513829454,100,0,1,''),(359,355,'stock','启用','','module_admin','stock/subaccount/enable','_self',0,1513829454,1513829454,100,0,1,''),(360,355,'stock','禁用','','module_admin','stock/subaccount/disable','_self',0,1513829454,1513829454,100,0,1,''),(361,355,'stock','快速编辑','','module_admin','stock/subaccount/quickedit','_self',0,1513829454,1513829454,100,0,1,''),(362,0,'member','会员','fa fa-fw fa-users','module_admin','member/index/index','_self',0,1513934342,1513934342,100,0,1,''),(363,362,'member','会员管理','fa fa-fw fa-folder-open-o','module_admin','','_self',0,1513934342,1513934342,100,0,1,''),(364,363,'member','会员列表','fa fa-fw fa-user-secret','module_admin','member/index/index','_self',0,1513934342,1513934342,100,0,1,''),(365,364,'member','编辑','','module_admin','member/index/edit','_self',0,1513934342,1513934342,100,0,1,''),(366,364,'member','删除','','module_admin','member/index/delete','_self',0,1513934342,1513934342,100,0,1,''),(367,364,'member','启用','','module_admin','member/index/enable','_self',0,1513934342,1513934342,100,0,1,''),(368,364,'member','禁用','','module_admin','member/index/disable','_self',0,1513934342,1513934342,100,0,1,''),(369,364,'member','快速编辑','','module_admin','member/index/quickedit','_self',0,1513934342,1513934342,100,0,1,''),(370,362,'member','认证管理','fa fa-fw fa-money','module_admin','','_self',0,1513934342,1513934342,100,0,1,''),(371,370,'member','实名认证','fa fa-fw fa-photo','module_admin','member/identity/index','_self',0,1513934342,1513934342,100,0,1,''),(372,371,'member','编辑','','module_admin','member/identity/edit','_self',0,1513934342,1513934342,100,0,1,''),(373,371,'member','参数设置','','module_admin','member/identity/add','_self',0,1513934342,1513934342,100,0,1,''),(374,355,'stock','自选股查询','','module_admin','stock/subaccount/self','_self',0,1513938991,1514354382,100,0,1,''),(375,341,'stock','明细查询','','module_admin','stock/account/info','_self',0,1513994805,1514368672,100,0,1,''),(376,355,'stock','风控设置','','module_admin','stock/subaccount/risk','_self',0,1514285735,1514285735,100,0,1,''),(377,355,'stock','资金参数设置','','module_admin','stock/subaccount/money','_self',0,1514354444,1514354444,100,0,1,''),(380,325,'stock','配资管理','fa fa-fw fa-thermometer','module_admin','','_self',0,1514371642,1514373808,100,0,1,''),(387,380,'stock','待审核的配资','fa fa-fw fa-hourglass-1','module_admin','stock/borrow/index','_self',0,1514372796,1516347332,96,0,1,''),(390,387,'stock','编辑','','module_admin','stock/borrow/edit','_self',0,1514941861,1514941895,100,0,1,''),(391,0,'money','资金','fa fa-fw fa-money','module_admin','money/index/index','_self',0,1515033594,1515033594,100,0,1,''),(392,391,'money','资金管理','','module_admin','','_self',0,1515033594,1515033594,100,0,1,''),(393,392,'money','资金列表','fa fa-fw fa-list','module_admin','money/index/index','_self',0,1515033594,1515033594,100,0,1,''),(394,392,'money','充值管理','fa fa-fw fa-reply','module_admin','money/recharge/index','_self',0,1515033594,1515033594,100,0,1,''),(395,394,'money','充值审核','','module_admin','money/recharge/edit','_self',0,1515033594,1515033594,100,0,1,''),(396,392,'money','提现管理','fa fa-fw fa-share','module_admin','money/withdraw/index','_self',0,1515033594,1515033594,100,0,1,''),(397,396,'money','提现审核','','module_admin','money/withdraw/edit','_self',0,1515033594,1515033594,100,0,1,''),(399,392,'money','清算明细','fa fa-fw fa-random','module_admin','money/record/index','_self',0,1515033594,1515033594,100,0,1,''),(400,392,'money','转账管理','fa fa-fw fa-sign-in','module_admin','money/transfer/index','_self',0,1515033594,1515033594,100,0,1,''),(401,400,'money','发起转账','','module_admin','money/transfer/add','_self',0,1515033594,1515033594,100,0,1,''),(402,380,'stock','操盘中的配资','fa fa-fw fa-hourglass-1','module_admin','stock/borrow/lists','_self',0,1516263805,1529649887,97,0,1,'status=1'),(403,380,'stock','未通过的配资','fa fa-fw fa-hourglass-1','module_admin','stock/borrow/lists_0','_self',0,1516411043,1523169506,98,0,1,'status=0'),(404,380,'stock','已结束配资','fa fa-fw fa-hourglass-1','module_admin','stock/borrow/lists_2','_self',0,1516411173,1523169531,100,0,1,'status=2'),(428,455,'stock','深圳股票代码更新','fa fa-fw fa-file-text-o','module_admin','stock/index/sz_all','_self',1,1515982979,1518227407,2,0,1,''),(430,455,'stock','上海股票代码更新','fa fa-fw fa-file-text-o','module_admin','stock/index/sh_all','_blank',1,1516852106,1518227222,100,0,1,''),(431,455,'stock','创业板股票代码更新','fa fa-fw fa-file-text-o','module_admin','stock/index/szcy_all','_blank',1,1516852247,1518227256,100,0,1,''),(432,455,'stock','编辑','fa fa-fw fa-pencil','module_admin','stock/index/edit','_blank',1,1516868986,1518227296,100,0,1,''),(433,455,'stock','删除','fa fa-fw fa-remove','module_admin','stock/index/delete','_self',1,1516869081,1518227335,100,0,1,''),(448,341,'stock','持仓','','module_admin','stock/account/position','_self',0,1518139216,1518140892,100,0,1,''),(449,341,'stock','当日成交','','module_admin','stock/account/deal_stock','_self',0,1518148311,1518148311,100,0,1,''),(450,341,'stock','当日委托','','module_admin','stock/account/trust','_self',0,1518154150,1518154150,100,0,1,''),(451,341,'stock','历史成交','','module_admin','stock/account/history_deal','_self',0,1518154826,1518154826,100,0,1,''),(452,341,'stock','历史委托','','module_admin','stock/account/history_trust','_self',0,1518155314,1518155314,100,0,1,''),(453,341,'stock','交割单','','module_admin','stock/account/delivery','_self',0,1518160324,1518160324,100,0,1,''),(455,327,'stock','股票管理','fa fa-fw fa-line-chart','module_admin','stock/index/index','_self',0,1518226987,1518227053,100,0,1,''),(456,325,'stock','操盘管理','fa fa-fw fa-university','module_admin','','_self',0,1518229984,1548405645,100,0,1,''),(457,456,'stock','持仓查询','fa fa-fw fa-th-list','module_admin','stock/operate/index','_self',0,1518230244,1518230324,100,0,1,''),(459,456,'stock','当日委托','fa fa-fw fa-hand-o-right','module_admin','stock/operate/trust','_self',0,1518232439,1518243557,100,0,1,''),(460,456,'stock','当日成交','fa fa-fw fa-handshake-o','module_admin','stock/operate/deal','_self',0,1518232511,1518245885,100,0,1,''),(461,456,'stock','历史委托','fa fa-fw fa-clock-o','module_admin','stock/operate/history_trust','_self',0,1518232637,1518232637,100,0,1,''),(462,456,'stock','历史成交','si si-clock','module_admin','stock/operate/history_deal','_self',0,1518232827,1518232827,100,0,1,''),(463,456,'stock','撤单查询','fa fa-fw fa-undo','module_admin','stock/operate/cancel_order','_self',0,1518232953,1518232953,100,0,1,''),(464,456,'stock','资金明细','fa fa-fw fa-table','module_admin','stock/operate/capital_details','_self',0,1518232995,1518233124,100,0,1,''),(465,456,'stock','交割单','fa fa-fw fa-list-ul','module_admin','stock/operate/delivery','_self',0,1518250792,1518250792,100,0,1,''),(466,0,'statistics','统计管理','fa fa-fw fa-bar-chart','module_admin','statistics/index/index','_self',0,1519276187,1519288800,100,0,1,''),(469,466,'statistics','会员账户','fa fa-fw fa-user','module_admin','statistics/index/member','_self',0,1519288226,1519434108,100,0,1,''),(473,466,'statistics','资金变动记录','fa fa-fw fa-list-alt','module_admin','statistics/index/capital','_self',0,1519434077,1519434077,100,0,1,''),(474,380,'stock','扩大配资申请','glyphicon glyphicon-king','module_admin','stock/borrow/addfinancing','_self',0,1520911486,1521165916,100,0,1,''),(475,380,'stock','扩大配资记录','fa fa-fw fa-list','module_admin','stock/borrow/addf_list','_self',0,1520922370,1521165997,100,0,1,''),(476,380,'stock','追加保证金申请','fa fa-fw fa-bank','module_admin','stock/borrow/addmoney','_self',0,1520923568,1520923568,100,0,1,''),(477,380,'stock','追加保证金记录','fa fa-fw fa-list-ul','module_admin','stock/borrow/addmoney_list','_self',0,1520923649,1520923649,100,0,1,''),(478,380,'stock','续期申请','glyphicon glyphicon-open-file','module_admin','stock/borrow/renewal','_self',0,1520923897,1520923897,100,0,1,''),(479,380,'stock','续期记录','fa fa-fw fa-th-list','module_admin','stock/borrow/renewal_list','_self',0,1520924007,1520924007,100,0,1,''),(480,380,'stock','终止操盘','fa fa-fw fa-fast-forward','module_admin','stock/borrow/stop','_self',0,1520926860,1529476441,100,0,1,''),(481,380,'stock','提前终止列表','fa fa-fw fa-step-forward','module_admin','stock/borrow/stop_list','_self',0,1520926954,1520926954,100,0,1,''),(482,474,'stock','扩大配资审核','','module_admin','stock/borrow/addfinancing_edit','_self',0,1521166178,1521166569,100,0,1,''),(483,476,'stock','追加保证金审核','','module_admin','stock/borrow/addmoney_edit','_self',0,1521270707,1521270707,100,0,1,''),(484,478,'stock','续期审核','','module_admin','stock/borrow/renewal_edit','_self',0,1521514923,1521514923,100,0,1,''),(485,480,'stock','提前终止审核','','module_admin','stock/borrow/stop_edit','_self',0,1521594285,1521594285,100,0,1,''),(486,380,'stock','提取盈利申请','glyphicon glyphicon-floppy-disk','module_admin','stock/borrow/drawprofit','_self',0,1521709221,1521709221,100,0,1,''),(487,380,'stock','提取盈利记录','fa fa-fw fa-list-ul','module_admin','stock/borrow/drawprofit_list','_self',0,1521709308,1521709308,100,0,1,''),(488,486,'stock','提取盈利审核','','module_admin','stock/borrow/drawprofit_edit','_self',0,1521709419,1521709419,100,0,1,''),(489,380,'stock','到期配资','fa fa-fw fa-step-forward','module_admin','stock/borrow/endlist','_self',0,1521871847,1521871847,99,0,1,''),(490,489,'stock','到期配资编辑','','module_admin','stock/borrow/endedit','_self',0,1522030391,1522030391,100,0,1,''),(491,456,'stock','实盘暂未成交委托','fa fa-fw fa-hand-o-right','module_admin','stock/operate/temp','_self',0,1522387412,1522387412,100,0,1,''),(499,325,'stock','配资操盘协议','fa fa-fw fa-pencil','module_admin','stock/contract/index','_self',0,1526627037,1526715534,100,0,1,''),(527,466,'statistics','模拟盘统计','fa fa-fw fa-resistance','module_admin','','_self',0,1527840253,1527840253,100,0,1,''),(528,527,'statistics','已结束模拟盘','fa fa-fw fa-adjust','module_admin','statistics/mock/index','_self',0,1527840944,1527906620,100,0,1,''),(529,527,'statistics','未结束模拟盘','fa fa-fw fa-linkedin-square','module_admin','statistics/mock/mock_in_use','_self',0,1527906885,1527906885,100,0,1,''),(530,455,'stock','设置创业板为禁买','','module_admin','stock/index/cy_alls','_self',0,1528335977,1528335977,100,0,1,''),(531,455,'stock','设全部股票为可买','','module_admin','stock/index/all_low','_self',0,1528336361,1528336361,100,0,1,''),(532,455,'stock','设ST*ST为禁买','','module_admin','stock/index/risk_alls','_self',0,1528336420,1528336420,100,0,1,''),(533,455,'stock','设基金债券为禁买','','module_admin','stock/index/jijin_alls','_self',0,1528336543,1528336543,100,0,1,''),(901,391,'money','充值设置','fa fa-fw fa-cog','module_admin','','_self',0,1528850941,1528851430,100,0,1,''),(902,901,'money','线下充值','fa fa-fw fa-arrow-circle-o-down','module_admin','money/setrecharge/index','_self',0,1528851013,1528851013,100,0,1,''),(903,901,'money','线上充值','fa fa-fw fa-arrow-circle-o-up','module_admin','money/setrecharge/online','_self',0,1528851103,1528851103,100,0,1,''),(904,902,'money','新增','','module_admin','money/setrecharge/add','_self',0,1528858944,1528858944,100,0,1,''),(905,902,'money','编辑','','module_admin','money/setrecharge/edit','_self',0,1528858997,1528858997,100,0,1,''),(906,902,'money','删除','','module_admin','money/setrecharge/delete','_self',0,1528870116,1528870116,100,0,1,''),(908,380,'stock','即将到期配资','fa fa-fw fa-camera','module_admin','stock/borrow/soonexpire','_self',0,1529544976,1529545064,99,0,1,''),(927,0,'agents','用户代理','fa fa-fw fa-sitemap','module_admin','agents/manager/agent_list','_self',0,1530069524,1530069524,100,0,1,''),(928,964,'agents','代理商列表','fa fa-fw fa-sitemap','module_admin','agents/manager/agent_list','_self',0,1530069524,1530702799,1,0,1,''),(929,928,'agents','新增代理商','fa fa-fw fa-tachometer','module_admin','agents/manager/add','_self',1,1530069524,1530702799,1,0,1,''),(930,928,'agents','编辑代理商','fa fa-fw fa-tachometer','module_admin','agents/manager/edit','_self',1,1530069524,1530702799,2,0,1,''),(931,928,'agents','模糊查询手机号','fa fa-fw fa-tachometer','module_admin','agents/manager/getlikemobile','_self',1,1530069524,1530702799,3,0,1,''),(932,964,'agents','邀请记录','fa fa-fw fa-user','module_admin','agents/manager/application_invite','_self',0,1530069524,1530702799,3,0,1,''),(933,964,'agents','提现记录','fa fa-fw fa-lastfm-square','module_admin','agents/manager/application_record','_self',0,1530069524,1530702799,2,0,1,''),(934,964,'agents','佣金分成明细','fa fa-fw fa-calculator','module_admin','agents/manager/agent_share','_self',0,1530069524,1530702799,4,0,1,''),(938,466,'statistics','用户统计','fa fa-fw fa-user','module_admin','','_self',0,1530666331,1530666331,83,0,1,''),(939,938,'statistics','注册人数','fa fa-fw fa-users','module_admin','statistics/index/registercounts','_self',0,1530666420,1530666420,100,0,1,''),(940,938,'statistics','会员分析','fa fa-fw fa-film','module_admin','statistics/index/useranalysis','_self',0,1530666463,1530666463,100,0,1,''),(941,938,'statistics','邀请统计','fa fa-fw fa-male','module_admin','statistics/index/invite','_self',0,1530666548,1530666548,100,0,1,''),(942,466,'statistics','代理商统计','fa fa-fw fa-github-square','module_admin','','_self',0,1530666608,1530666608,85,0,1,''),(943,942,'statistics','代理商分析','fa fa-fw fa-cloud','module_admin','statistics/index/agentanalyse','_self',0,1530666639,1530666639,100,0,1,''),(944,942,'statistics','佣金统计','fa fa-fw fa-map-signs','module_admin','statistics/index/commissionstatistics','_self',0,1530666668,1530666668,100,0,1,''),(945,466,'statistics','实盘统计','fa fa-fw fa-handshake-o','module_admin','','_self',0,1530666699,1530666699,88,0,1,''),(946,945,'statistics','操盘统计','fa fa-fw fa-cubes','module_admin','statistics/index/operatestatistics','_self',0,1530666740,1530666740,100,0,1,''),(947,945,'statistics','股票统计','fa fa-fw fa-signal','module_admin','statistics/index/sharesstatistics','_self',0,1530666777,1530666777,100,0,1,''),(948,466,'statistics','资金统计','fa fa-fw fa-usd','module_admin','statistics/index/amountstatistics','_self',0,1530666812,1530666812,90,0,1,''),(949,466,'statistics','配资统计','fa fa-fw fa-credit-card','module_admin','','_self',0,1530666843,1530666857,95,0,1,''),(950,0,'crontab','定时任务','glyphicon glyphicon-time','module_admin','crontab/index/index','_self',0,1530666868,1530666868,100,0,1,''),(951,950,'crontab','任务列表','fa fa-fw fa-list','module_admin','crontab/index/index','_self',0,1530666868,1530666868,100,0,1,''),(952,951,'crontab','禁用','','module_admin','crontab/index/disable','_self',1,1530666868,1530666868,100,0,1,''),(953,951,'crontab','编辑','','module_admin','crontab/index/edit','_self',1,1530666868,1530666868,100,0,1,''),(954,951,'crontab','删除','','module_admin','crontab/index/delete','_self',1,1530666868,1530666868,100,0,1,''),(955,951,'crontab','添加','','module_admin','crontab/index/add','_self',1,1530666868,1530666868,100,0,1,''),(956,951,'crontab','启用','','module_admin','crontab/index/enable','_self',1,1530666868,1530666868,100,0,1,''),(957,951,'crontab','检查Crontab格式','','module_admin','crontab/index/checkschedule','_self',1,1530666868,1530666868,100,0,1,''),(958,951,'crontab','获取未来N次的时间','','module_admin','crontab/index/getschedulefuture','_self',1,1530666868,1530666868,100,0,1,''),(959,950,'crontab','执行日志','fa fa-fw fa-play','module_admin','crontab/log/index','_self',0,1530666868,1530666868,100,0,1,''),(960,959,'crontab','编辑','','module_admin','crontab/log/edit','_self',1,1530666868,1530666868,100,0,1,''),(961,959,'crontab','清空日志','','module_admin','crontab/log/clear','_self',1,1530666868,1530666868,100,0,1,''),(962,949,'statistics','配资资金','fa fa-fw fa-html5','module_admin','statistics/index/allocationstatistics','_self',0,1530666882,1530666882,100,0,1,''),(963,949,'statistics','申请统计','fa fa-fw fa-comments','module_admin','statistics/index/applynums','_self',0,1530666911,1530666911,100,0,1,''),(964,927,'agents','代理商管理','fa fa-fw fa-sitemap','module_admin','','_self',0,1530702682,1530702799,1,0,1,''),(965,474,'stock','导出excel','','module_admin','stock/borrow/addfinancing_export','_self',0,1530846696,1530846696,100,0,1,''),(966,387,'stock','导出EXCEL','','module_admin','stock/borrow/index_export','_self',0,1530859276,1530859276,100,0,1,''),(967,402,'stock','导出EXCEL','','module_admin','stock/borrow/lists_export','_self',0,1530861133,1530861201,100,0,1,''),(968,403,'stock','导出excel','','module_admin','stock/borrow/lists_0_export','_self',0,1530863228,1530863228,100,0,1,''),(969,404,'stock','导出EXCEL','','module_admin','stock/borrow/lists_2_export','_self',0,1530863671,1530863671,100,0,1,''),(970,489,'stock','导出excel','','module_admin','stock/borrow/endlist_export','_self',0,1530868482,1530868482,100,0,1,''),(971,475,'stock','导出EXCEL表','','module_admin','stock/borrow/addf_list_export','_self',0,1530873614,1530873614,100,0,1,''),(972,476,'stock','导出EXCEL表','','module_admin','stock/borrow/addmoney_export','_self',0,1530873684,1530873684,100,0,1,''),(973,477,'stock','导出EXCEL表','','module_admin','stock/borrow/addmoney_list_export','_self',0,1530874573,1530874573,100,0,1,''),(974,478,'stock','导出EXCEL表','','module_admin','stock/borrow/renewal_export','_self',0,1530875250,1530875250,100,0,1,''),(975,479,'stock','导出EXCEL表','','module_admin','stock/borrow/renewal_list_export','_self',0,1530875717,1530875717,100,0,1,''),(976,480,'stock','导出EXCEL表','','module_admin','stock/borrow/stop_export','_self',0,1530876104,1530876104,100,0,1,''),(977,481,'stock','导出EXCEL表','','module_admin','stock/borrow/stop_list_export','_self',0,1530876422,1530876422,100,0,1,''),(978,486,'stock','导出EXCEL表','','module_admin','stock/borrow/drawprofit_export','_self',0,1530877815,1530877815,100,0,1,''),(979,487,'stock','导出EXCEL表','','module_admin','stock/borrow/drawprofit_list_export','_self',0,1530878603,1530878603,100,0,1,''),(980,457,'stock','导出EXCEL表','','module_admin','stock/operate/index_export','_self',0,1530935723,1530935723,100,0,1,''),(981,459,'stock','导出EXCEL表','','module_admin','stock/operate/trust_export','_self',0,1530943266,1530943287,100,0,1,''),(982,460,'stock','导出EXCEL表','','module_admin','stock/operate/deal_export','_self',0,1530943937,1530943937,100,0,1,''),(983,461,'stock','导出EXCEL表','','module_admin','stock/operate/history_trust_export','_self',0,1530945002,1530945002,100,0,1,''),(984,462,'stock','导出EXCEL表','','module_admin','stock/operate/history_deal_export','_self',0,1530945555,1530945555,100,0,1,''),(985,463,'stock','导出EXCEL表','','module_admin','stock/operate/cancel_order_export','_self',0,1530946027,1530946027,100,0,1,''),(986,464,'stock','导出EXCEL表','','module_admin','stock/operate/capital_details_export','_self',0,1530946810,1530946810,100,0,1,''),(987,465,'stock','导出EXCEL表','','module_admin','stock/operate/delivery_export','_self',0,1530947377,1530947377,100,0,1,''),(988,491,'stock','导出EXCEL表','','module_admin','stock/operate/temp_export','_self',0,1530947766,1530947766,100,0,1,''),(989,364,'member','导出EXCEL表','','module_admin','member/index/index_export','_self',0,1531101432,1531101432,100,0,1,''),(990,371,'member','导出EXCEL表','','module_admin','member/identity/index_export','_self',0,1531103694,1531103694,100,0,1,''),(991,393,'money','导出EXCEL表','','module_admin','money/index/index_export','_self',0,1531105718,1531105757,100,0,1,''),(992,394,'money','导出EXCEL表','','module_admin','money/recharge/index_export','_self',0,1531106527,1531106527,100,0,1,''),(993,396,'money','导出EXCEL表','','module_admin','money/withdraw/index_export','_self',0,1531115135,1531115135,100,0,1,''),(994,399,'money','导出EXCEL表','','module_admin','money/record/index_export','_self',0,1531116789,1531116789,100,0,1,''),(995,400,'money','导出EXCEL表','','module_admin','money/transfer/index_export','_self',0,1531117314,1531117314,100,0,1,''),(996,469,'statistics','导出EXCEL表','','module_admin','statistics/index/member_export','_self',1,1531119472,1531119866,100,0,1,''),(997,473,'statistics','导出EXCEL表','','module_admin','statistics/index/capital_export','_self',1,1531120843,1531120843,100,0,1,''),(998,528,'statistics','导出EXCEL表','','module_admin','statistics/mock/index_export','_self',1,1531121940,1531121999,100,0,1,''),(1000,529,'statistics','导出EXCEL表','','module_admin','statistics/mock/mock_in_use_export','_self',1,1531122481,1531122481,100,0,1,''),(1001,908,'stock','导出EXCEL表','','module_admin','stock/borrow/soonexpire_export','_self',0,1531195050,1531195050,100,0,1,''),(1002,934,'agents','导出EXCEL表','','module_admin','agents/manager/agent_share_export','_self',0,1531724302,1533969284,1,0,1,''),(1003,235,'cms','友情链接','fa fa-fw fa-thumbs-o-up','module_admin','cms/cooperate/index','_self',0,1531985612,1533967034,5,0,0,''),(1004,1003,'cms','新增','','module_admin','cms/cooperate/add','_self',0,1531985812,1533709474,1,0,1,''),(1005,1003,'cms','修改','','module_admin','cms/cooperate/edit','_self',0,1531986668,1533709474,2,0,1,''),(1006,1003,'cms','删除','','module_admin','cms/cooperate/delete','_self',0,1531987058,1533709474,3,0,1,''),(1007,1003,'cms','启用','','module_admin','cms/cooperate/enable','_self',0,1531987265,1533709474,4,0,1,''),(1008,1003,'cms','禁用','','module_admin','cms/cooperate/disable','_self',0,1531987296,1533709474,5,0,1,''),(1009,1003,'cms','快速编辑','','module_admin','cms/cooperate/quickedit','_self',0,1531987342,1533709474,6,0,1,''),(1011,325,'stock','配资设置','fa fa-fw fa-signal','module_admin','stock/system/index','_self',0,1533951481,1536377652,1,0,1,''),(1012,927,'agents','返佣比列设置','fa fa-fw fa-align-center','module_admin','agents/agentset/index','_self',0,1533951553,1533969284,1,0,1,''),(1013,391,'money','提现银行卡设置','fa fa-fw fa-credit-card-alt','module_admin','money/withdrawbankset/index','_self',0,1533951682,1533969714,100,0,1,''),(1014,1013,'money','充值银行卡添加','fa fa-fw fa-vcard-o','module_admin','money/withdrawbankset/add','_self',1,1533951703,1533969494,100,0,1,''),(1015,1013,'money','充值银行卡修改','fa fa-fw fa-address-card','module_admin','money/withdrawbankset/edit','_self',1,1533951728,1533969503,100,0,1,''),(1016,214,'cms','文档管理','fa fa-fw fa-th-list','module_admin','','_self',0,1533953505,1533953521,3,0,1,''),(1017,1016,'cms','发布文档','fa fa-fw fa-suitcase','module_admin','cms/document/add','_self',0,1533953687,1533967909,100,0,1,''),(1018,1016,'cms','文档列表','fa fa-fw fa-bookmark','module_admin','cms/document/index','_self',0,1533953723,1533953723,100,0,1,''),(1019,1018,'cms','编辑','','module_admin','cms/document/edit','_self',0,1533953738,1533953738,100,0,1,''),(1020,1018,'cms','删除','','module_admin','cms/document/delete','_self',0,1533953750,1533967995,100,0,1,''),(1021,1018,'cms','启用','','module_admin','cms/document/enable','_self',0,1533953766,1533953766,100,0,1,''),(1022,1018,'cms','禁用','','module_admin','cms/document/disable','_self',0,1533953781,1533953781,100,0,1,''),(1023,1018,'cms','快速编辑','','module_admin','cms/document/quickedit','_self',0,1533953802,1533967982,100,0,1,''),(1024,1016,'cms','回收站','fa fa-fw fa-user-secret','module_admin','cms/recycle/index','_self',0,1533953818,1533953845,100,0,1,''),(1025,1024,'cms','删除','','module_admin','cms/recycle/delete','_self',0,1533953861,1533953861,100,0,1,''),(1026,1024,'cms','还原','','module_admin','cms/recycle/restore','_self',0,1533953876,1533953876,100,0,1,''),(1027,5,'admin','短信管理','fa fa-fw fa-podcast','module_admin','admin/sms/index','_self',0,1534924037,1534924037,100,0,1,''),(1028,1027,'admin','增加','fa fa-fw fa-plus-circle','module_admin','admin/sms/add','_self',0,1534989301,1534989301,100,0,1,''),(1029,1027,'admin','设置状态','','module_admin','admin/sms/setstatus','_self',0,1534989358,1534989358,100,0,1,''),(1030,1027,'admin','快速编辑','','module_admin','admin/sms/quickedit','_self',0,1534989382,1534989382,100,0,1,''),(1031,1011,'stock','操盘中的配资ajax刷新节点','','module_admin','stock/borrow/stock_operation','_self',1,1535018693,1536377652,1,0,1,''),(1032,942,'statistics','模拟盘用户盈亏统计','fa fa-fw fa-edit','module_admin','statistics/agent/agent_count','_self',0,1535769682,1535770194,4,0,0,''),(1033,942,'statistics','代理商佣金管理','fa fa-fw fa-pencil-square-o','module_admin','statistics/agent/index','_self',0,1535769750,1535770194,3,0,0,''),(1034,942,'statistics','实盘用户盈亏统计','fa fa-fw fa-check-square-o','module_admin','statistics/agent/agent_stock','_self',0,1535769803,1535770194,5,0,0,''),(1035,5,'admin','刷新追加保证金ajax','','module_admin','admin/admin/operation_remind','_self',1,1535787795,1535787803,100,0,1,''),(1036,457,'stock','强制平仓','','module_admin','stock/operate/close','_self',0,1536128942,1536377652,2,0,1,''),(1037,456,'stock','资金流水','fa fa-fw fa-list','module_admin','stock/operate/money_record','_self',0,1536307908,1536377652,10,0,1,''),(1038,1028,'stock','导出EXCEL表','','module_admin','stock/operate/money_record_export','_self',0,1536374232,1536374232,100,0,1,''),(1039,325,'stock','除权除息管理','glyphicon glyphicon-grain','module_admin','stock/bonus/index','_self',0,1543645692,1543645692,100,0,1,''),(1040,1039,'stock','今日公告','fa fa-fw fa-file-text-o','module_admin','stock/bonus/index','_self',0,1543645760,1543645760,100,0,1,''),(1041,1040,'stock','除权除息详情','fa fa-fw fa-list-ol','module_admin','stock/bonus/detail','_self',0,1543645822,1543645822,100,0,1,''),(1042,1039,'stock','近期除权记录','fa fa-fw fa-th','module_admin','stock/bonus/history','_self',0,1543645875,1543645875,100,0,1,''),(1043,1039,'stock','待除权股票','fa fa-fw fa-universal-access','module_admin','stock/bonus/will','_self',0,1543645931,1543645931,100,0,1,''),(1044,1039,'stock','拆零股票管理','fa fa-fw fa-diamond','module_admin','stock/bonus/surplus','_self',0,1543645985,1543645985,100,0,1,''),(1045,391,'money','出入金统计','fa fa-fw fa-rmb','module_admin','','_self',0,1551320085,1551840988,100,0,1,''),(1046,1045,'money','资金统计','','module_admin','money/allcount/index','_self',0,1551841008,1552203932,100,0,1,''),(1048,348,'stock','获得子账号','','module_admin','stock/subaccount/get_lid','_blank',1,1552225012,1552225776,100,0,1,''),(1049,363,'member','添加会员','fa fa-fw fa-plus-square','module_admin','member/index/add_user','_self',0,1552288447,1552288447,100,0,1,''),(1050,387,'stock','子账号风控信息','','module_admin','stock/borrow/risk','_self',1,1552525857,1552525963,100,0,1,''),(1051,4,'admin','Google身份验证','fa fa-fw fa-lock','module_admin','admin/googleauth/index','_self',0,1553499457,1553566010,100,0,0,''),(1052,392,'money','赠送管理费明细','fa fa-fw fa-dollar','module_admin','money/givefee/givelist','_self',0,1553830186,1553830240,100,0,1,''),(1053,392,'money','赠金明细','fa fa-fw fa-plus-square-o','module_admin','money/givefee/givecash','_self',0,1557750671,1561703979,100,0,1,''),(1054,1053,'money','导出数据','','module_admin','money/givefee/givecash_export','_self',1,1557751497,1557751497,100,0,1,''),(1055,469,'statistics','编辑','','module_admin','statistics/index/edit','_self',1,1558059809,1558059809,100,0,1,''),(1056,364,'member','发送邮件','','module_admin','member/index/send_email','_self',1,1558614483,1558614619,100,0,1,''),(1057,1039,'stock','手动除息','','module_admin','stock/bonus/rebonus','_self',0,1560303554,1560303593,100,0,1,''),(1058,1052,'money','添加','','module_admin','money/givefee/add','_self',1,1561702538,1561704131,100,0,1,''),(1059,457,'stock','添加交易单','','module_admin','stock/operate/add_trade','_self',1,1562827443,1562828670,100,0,1,''),(1060,902,'money','快速编辑','','module_admin','money/setrecharge/quickedit','_self',1,1566875867,1566875931,100,0,1,''),(1061,363,'member','会员分组','','module_admin','member/index/group','_self',0,1569208149,1569208149,100,0,1,''),(1062,1061,'member','添加分组','','module_admin','member/index/group_add','_self',0,1569209428,1569209428,100,0,1,''),(1063,1061,'member','删除分组','','module_admin','member/index/group_delete','_self',0,1569216309,1569216309,100,0,1,''),(1064,1061,'member','会员分组设置','','module_admin','member/index/group_set','_self',0,1569217792,1569217792,100,0,1,''),(1065,363,'member','会员组升级','','module_admin','member/index/group_upgrade','_self',1,1569288032,1569303761,100,0,1,''),(1066,455,'stock','深证中小板','','module_admin','stock/index/szzx_all','_self',0,1569292956,1569292997,100,0,1,''),(1067,1051,'admin','重置验证码','','module_admin','admin/googleauth/reset','_self',1,1571302860,1571302860,100,0,1,''),(1068,928,'agents','邀请','','module_admin','agents/manager/invite_add','_self',0,1573522756,1573522823,100,0,1,''),(1069,4,'admin','短信IP屏蔽','','module_admin','admin/index/sms_ip','_self',0,1576413625,1576413625,100,0,0,''),(1070,355,'stock','批量增加子账号','','module_admin','stock/subaccount/addmuti','_self',0,1577068778,1577068778,100,0,1,''),(1071,402,'stock','编辑时间','','module_admin','stock/borrow/settime','_self',1,1579758989,1579759094,100,0,1,''),(1072,928,'agents','代理导出','','module_admin','agents/manager/agent_list_export','_self',1,1581066448,1581067258,100,0,1,''),(1073,380,'stock','全部配资','fa fa-fw fa-life-ring','module_admin','stock/borrow/all','_self',0,1582782888,1582783925,1,0,1,''),(1074,1073,'stock','导出配资数据','','module_admin','stock/borrow/all_export','_self',1,1582785683,1582785683,100,0,1,''),(1075,364,'member','重置支付密码','fa fa-fw fa-repeat','module_admin','member/index/resetpaywd','_self',0,1586227120,1586227120,100,0,1,''),(1076,469,'statistics','导出全部','','module_admin','statistics/index/member_export_all','_self',1,1587697219,1587697258,100,0,1,''),(1077,234,'cms','公告通知','fa fa-fw fa-list','module_admin','cms/content/notice','_self',0,1616556808,1616556808,100,0,1,'');
/*!40000 ALTER TABLE `st_admin_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_admin_menus`
--

DROP TABLE IF EXISTS `st_admin_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_admin_menus` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '父级id',
  `icon` varchar(16) NOT NULL DEFAULT '' COMMENT '图标',
  `menu_name` varchar(32) NOT NULL DEFAULT '' COMMENT '按钮名',
  `module` varchar(32) NOT NULL DEFAULT '' COMMENT '模块名',
  `controller` varchar(64) NOT NULL COMMENT '控制器',
  `action` varchar(32) NOT NULL DEFAULT '' COMMENT '方法名',
  `api_url` varchar(100) NOT NULL DEFAULT '' COMMENT 'api接口地址',
  `methods` varchar(10) NOT NULL DEFAULT '' COMMENT '提交方式POST GET PUT DELETE',
  `params` varchar(128) NOT NULL DEFAULT '[]' COMMENT '参数',
  `sort` tinyint(4) NOT NULL DEFAULT '1' COMMENT '排序',
  `is_show` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '是否为隐藏菜单0=隐藏菜单,1=显示菜单',
  `is_show_path` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否为隐藏菜单供前台使用',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '子管理员是否可用',
  `menu_path` varchar(128) NOT NULL DEFAULT '' COMMENT '路由名称 前端使用',
  `path` varchar(150) NOT NULL DEFAULT '' COMMENT '路径',
  `auth_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否为菜单 1菜单 2功能',
  `header` varchar(50) NOT NULL DEFAULT '' COMMENT '顶部菜单标示',
  `is_header` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否顶部菜单1是0否',
  `unique_auth` varchar(150) NOT NULL DEFAULT '' COMMENT '前台唯一标识',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE,
  KEY `is_show` (`is_show`) USING BTREE,
  KEY `access` (`access`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=891 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='菜单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_admin_menus`
--

LOCK TABLES `st_admin_menus` WRITE;
/*!40000 ALTER TABLE `st_admin_menus` DISABLE KEYS */;
INSERT INTO `st_admin_menus` VALUES (1,0,'md-basket','商品','admin','product','index','','','[]',126,1,0,1,'/admin/product','',1,'0',1,'admin-product',0),(2,1,'','商品管理','admin','product.product','index','','','[]',1,1,0,1,'/admin/product/product_list','1',1,'',0,'admin-store-storeProuduct-index',0),(3,1,'','商品分类','admin','product.storeCategory','index','','','[]',1,1,0,1,'/admin/product/product_classify','',1,'product',0,'admin-store-storeCategory-index',0),(4,0,'md-cart','订单','admin','order','index','','','[]',110,1,0,1,'/admin/order','',1,'home',1,'admin-order',0),(5,4,'','订单管理','admin','order.store_order','index','','','[]',1,1,0,1,'/admin/order/list','',1,'order',0,'admin-order-storeOrder-index',0),(6,1,'','商品评论','admin','store.store_product_reply','index','','','[]',0,1,0,1,'/admin/product/product_reply','',1,'product',0,'product-product-reply',0),(7,0,'md-home','主页','admin','index','','','','[]',127,1,0,1,'/admin/home/','',1,'home',1,'admin-index-index',0),(9,0,'md-person','用户','admin','user.user','','','','[]',100,1,0,1,'/admin/user','',1,'user',1,'admin-user',0),(10,9,'','用户管理','admin','user.user','index','','','[]',10,1,0,1,'/admin/user/list','',1,'user',1,'admin-user-user-index',0),(12,0,'md-settings','设置','admin','setting.system_config','index','','','[]',0,1,0,1,'/admin/setting','',1,'setting',1,'admin-setting',0),(14,12,'','管理权限','admin','setting.system_admin','','','','[]',0,1,0,1,'/admin/setting/auth/list','',1,'setting',1,'setting-system-admin',0),(19,14,'','角色管理','admin','setting.system_role','index','','','[]',1,1,0,1,'/admin/setting/system_role/index','',1,'setting',1,'setting-system-role',0),(20,14,'','管理员列表','admin','setting.system_admin','index','','','[]',1,1,0,1,'/admin/setting/system_admin/index','',1,'setting',0,'setting-system-list',0),(21,14,'','权限规则','admin','setting.system_menus','index','','','[]',1,1,0,1,'/admin/setting/system_menus/index','',1,'setting',0,'setting-system-menus',0),(22,1,'','产品添加','admin','store.store_product','save','','','[]',1,1,1,1,'/admin/product/add_product','',1,'product',1,'product-product-save',0),(23,12,'','系统设置','admin','setting.system_config','index','','','[]',10,1,0,1,'/admin/setting/system_config','',1,'setting',1,'setting-system-config',0),(25,0,'md-hammer','维护','admin','system','','','','[]',-1,1,0,1,'/admin/system','',1,'setting',1,'admin-system',0),(27,0,'ios-paper-plane','营销','admin','marketing','','','','[]',1,1,0,1,'/admin/marketing','',1,'home',1,'admin-marketing',0),(30,27,'','优惠券','admin','marketing.store_coupon','','','','[]',1,1,0,1,'/admin/marketing/store_coupon','',1,'marketing',1,'marketing-store_coupon-index',0),(34,27,'','积分管理','admin','marketing.user_point','','','','[]',1,1,0,1,'/admin/marketing/user_point','',1,'marketing',1,'marketing-user_point-index',0),(35,0,'logo-usd','财务','admin','finance','','','','[]',1,1,0,1,'/admin/finance','',1,'home',0,'admin-finance',0),(36,35,'','财务操作','admin','finance','','','','[]',1,1,0,1,'/admin/finance/user_extract','',1,'finance',0,'finance-user_extract-index',0),(37,35,'','财务记录','admin','finance','','','','[]',1,1,0,1,'/admin/finance/user_recharge','',1,'finance',0,'finance-user-recharge-index',0),(41,37,'','资金记录','admin','finance.finance','','','','[]',1,1,0,1,'/admin/finance/finance/bill','',1,'finance',0,'finance-finance-bill',0),(43,0,'ios-book','内容','admin','cms','','','','[]',1,1,0,1,'/admin/cms','',1,'home',0,'admin-cms',0),(44,43,'','文章管理','admin','cms.article','index','','','[]',1,1,0,1,'/admin/cms/article/index','',1,'cms',0,'cms-article-index',0),(45,43,'','文章分类','admin','cms.article_category','index','','','[]',1,1,0,1,'/admin/cms/article_category/index','',1,'cms',0,'cms-article-category',0),(46,43,'','文章添加','admin','cms.article','add_article','','','[]',0,1,1,1,'/admin/cms/article/add_article','',1,'cms',1,'cms-article-creat',0),(47,65,'','系统日志','admin','system.system_log','index','','','[]',0,1,0,1,'/admin/system/maintain/system_log/index','',1,'system',0,'system-maintain-system-log',0),(56,25,'','开发配置','admin','system','','','','[]',10,1,0,1,'/admin/system/config','',1,'system',1,'system-config-index',0),(57,65,'','刷新缓存','admin','system','clear','','','[]',1,1,0,1,'/admin/system/maintain/clear/index','',1,'system',1,'system-clear',0),(64,65,'','文件校验','admin','system.system_file','index','','','[]',0,1,0,1,'/admin/system/maintain/system_file/index','',1,'system',0,'system-maintain-system-file',0),(65,25,'','安全维护','admin','system','','','','[]',7,1,0,1,'/admin/system/maintain','',1,'system',1,'system-maintain-index',0),(66,65,'','清除数据','admin','system.system_cleardata','index','','','[]',0,1,0,1,'/admin/system/maintain/system_cleardata/index','',1,'system',0,'system-maintain-system-cleardata',0),(67,65,'','数据备份','admin','system.system_databackup','index','','','[]',0,1,0,1,'/admin/system/maintain/system_databackup/index','',1,'system',0,'system-maintain-system-databackup',0),(69,135,'','公众号','admin','wechat','','','','[]',0,1,0,1,'/admin/app/wechat','',1,'app',1,'admin-wechat',0),(70,30,'','优惠券模板','admin','marketing.store_coupon','index','','','[]',0,0,0,1,'/admin/marketing/store_coupon/index','',1,'marketing',1,'marketing-store_coupon',0),(71,30,'','优惠券列表','admin','marketing.store_coupon_issue','index','','','[]',0,1,0,1,'/admin/marketing/store_coupon_issue/index','',1,'marketing',1,'marketing-store_coupon_issue',0),(72,30,'','用户领取记录','admin','marketing.store_coupon_user','index','','','[]',0,1,0,1,'/admin/marketing/store_coupon_user/index','',1,'marketing',1,'marketing-store_coupon_user',0),(79,34,'','积分配置','admin','setting.system_config/index.html','index','','','[]',0,1,0,1,'/admin/marketing/integral/system_config/3/11','',1,'marketing',1,'marketing-integral-system_config',0),(80,34,'','积分日志','admin','marketing.user_point','index','','','[]',0,1,0,1,'/admin/marketing/user_point/index','',1,'marketing',0,'marketing-user_point',0),(92,69,'','微信菜单','admin','application.wechat_menus','index','','','[]',0,1,0,1,'/admin/app/wechat/setting/menus/index','',1,'app',0,'application-wechat-menus',0),(93,69,'','微信模板消息','admin','application.wechat_template','index','','','[]',0,1,0,1,'/admin/app/wechat/setting/template/index','',1,'app',0,'application-wechat-template',0),(94,12,'','一号通','admin','setting.sms_config','','','','[]',8,1,0,1,'/admin/setting/sms/sms_config/index','',1,'setting',1,'setting-sms',0),(95,94,'','账户管理','admin','sms.sms_config','index','','','[]',0,0,0,1,'/admin/setting/sms/sms_config/index','',1,'setting',1,'setting-sms-sms-config',0),(96,94,'','短信模板','admin','sms.sms_template_apply','index','','','[]',0,0,0,1,'/admin/setting/sms/sms_template_apply/index','',1,'setting',0,'setting-sms-config-template',0),(97,94,'','套餐购买','admin','sms.sms_pay','index','','','[]',0,0,0,1,'/admin/setting/sms/sms_pay/index','',1,'setting',1,'setting-sms-sms-template',0),(99,1,'','商品规格','admin','store.store_product','index','','','[]',1,1,0,1,'/admin/product/product_attr','',1,'product',1,'product-product-attr',0),(105,22,'','添加产品保存','admin','store.store_product','save','product/product/<id>','POST','[]',0,0,0,1,'/admin/product/save','',2,'product',0,'product-save',0),(108,2,'','产品列表','admin','product.product','index','product/product','GET','[]',20,0,0,1,'/admin/product/product','',2,'product',1,'product-product-index',0),(109,69,'','图文管理','admin','wechat.wechat_news_category','index','','','[]',0,1,0,1,'/admin/app/wechat/news_category/index','',1,'app',0,'wechat-wechat-news-category-index',0),(110,69,'','图文添加','admin','wechat.wechat_news_category','save','','','[]',0,1,1,1,'/admin/app/wechat/news_category/save','',1,'app',1,'wechat-wechat-news-category-save',0),(111,56,'','配置分类','admin','setting.system_config_tab','index','','','[]',0,1,0,1,'/admin/system/config/system_config_tab/index','',1,'system',0,'system-config-system_config-tab',0),(112,56,'','组合数据','admin','setting.system_group','index','','','[]',0,1,0,1,'/admin/system/config/system_group/index','',1,'system',0,'system-config-system_config-group',0),(113,114,'','微信关注回复','admin','wechat.reply','index','','','[]',0,1,0,1,'/admin/app/wechat/reply/follow/subscribe','',1,'app',0,'wechat-wechat-reply-subscribe',0),(114,69,'','自动回复','admin','wechat.reply','','','','[]',0,1,0,1,'/admin/app/wechat/reply','',1,'app',0,'wechat-wechat-reply-index',0),(115,114,'','关键字回复','admin','wechat.reply','keyword','','','[]',0,1,0,1,'/admin/app/wechat/reply/keyword','',1,'app',0,'wechat-wechat-reply-keyword',0),(116,114,'','无效关键词回复','admin','wechat.reply','index','','','[]',0,1,0,1,'/admin/app/wechat/reply/index/default','',1,'app',0,'wechat-wechat-reply-default',0),(125,56,'','配置列表','admin','system.config','index','','','[]',0,1,1,1,'/admin/system/config/system_config_tab/list','',1,'system',1,'system-config-system_config_tab-list',0),(126,56,'','组合数据列表','admin','system.system_group','list','','','[]',0,1,1,1,'/admin/system/config/system_group/list','',1,'system',1,'system-config-system_config-list',0),(128,656,'','数据配置','admin','setting.system_group_data','index','','','[]',0,1,0,1,'/admin/setting/system_group_data','',1,'system',1,'setting-system-group_data',0),(132,135,'','小程序','admin','routine','index','','','[]',0,1,0,1,'/admin/app/routine','',1,'app',1,'admin-routine',0),(133,132,'','小程序订阅消息','admin','routine.routine_template','index','','','[]',0,1,0,1,'/admin/app/routine/routine_template/index','',1,'app',1,'routine-routine_template',0),(134,114,'','关键字添加','admin','','index','','','[]',0,1,1,1,'/admin/app/wechat/reply/keyword/save','',1,'app',1,'wechat-wechat-reply-save',0),(135,0,'md-cube','应用','admin','app','index','','','[]',0,1,0,1,'/admin/app','',1,'app',1,'admin-app',0),(145,25,'','物流公司','admin','freight.express','index','','','[]',4,1,0,1,'/admin/setting/freight/express/index','',1,'',0,'setting-freight-express',0),(165,0,'md-chatboxes','客服','admin','setting.storeService','index','','','[]',2,1,0,1,'/admin/kefu','',1,'',0,'setting-store-service',0),(166,25,'','日志','admin','','','','','[]',0,1,1,1,'/admin/system/log','',1,'',0,'system-log',0),(169,577,'','商品删除','admin','product','商品删除','product/product/<id>','DELETE','[]',0,0,0,1,'','',2,'0',1,'',0),(170,3,'','分类列表','admin','','','product/category','GET','[]',0,0,0,1,'/adminproduct/category','',2,'',0,'',0),(171,578,'','删除分类','admin','','','product/category/<id>','DELETE','[]',0,0,0,1,'/adminproduct/category/<id>','',2,'',0,'',0),(172,578,'','修改分类','admin','','','product/category/<id>','PUT','[]',0,0,0,1,'/adminproduct/category/<id>','',2,'',0,'',0),(173,578,'','新增分类','admin','','','product/category','POST','[]',0,0,0,1,'/adminproduct/category','',2,'',0,'product-save-cate',0),(174,578,'','分类状态','admin','','','product/category/set_show/<id>/<is_show>','PUT','[]',0,0,0,1,'/adminproduct/category/set_show/<id>/<is_show>','',2,'',0,'',0),(175,578,'','快速编辑','admin','','','product/category/set_category/<id>','PUT','[]',0,0,0,1,'/adminproduct/category/set_category/<id>','',2,'',0,'',0),(176,578,'','分类表单添加','admin','','','product/category/create','GET','[]',0,0,0,1,'/admincategory/create','',2,'',0,'',0),(177,578,'','分类表单编辑','admin','','','product/category/<id>','GET','[]',0,0,0,1,'/admincategory/<id>/edit','',2,'',0,'',0),(178,3,'','分类树形列表','admin','','','product/category/tree/<type>','GET','[]',0,0,0,1,'/admincategory/tree/:type','',2,'',0,'',0),(179,577,'','产品状态','admin','','','product/product/set_show/<id>/<is_show>','PUT','[]',0,0,0,1,'/adminproduct/set_show/<id>/<is_show>','',2,'',0,'',0),(180,577,'','快速编辑','admin','','','product/product/set_product/<id>','PUT','[]',0,0,0,1,'/adminproduct/product/set_product/<id>','',2,'',0,'',0),(181,577,'','批量上架商品','admin','','','product/product/product_show','PUT','[]',0,0,0,1,'/adminproduct/product/product_show','',2,'',0,'product-product-product_show',0),(182,577,'','采集商品','admin','','','product/copy','POST','[]',0,0,0,1,'/adminproduct/crawl','',2,'',0,'product-crawl-save',0),(183,577,'','采集商品保存','admin','','','product/crawl/save','POST','[]',0,0,0,1,'/adminproduct/crawl/save','',2,'',0,'',0),(184,579,'','虚拟评论表单','admin','','','product/reply/fictitious_reply/<product_id>','GET','[]',0,0,0,1,'/adminproduct/reply/fictitious_reply','',2,'',0,'',0),(185,579,'','保存虚拟评论','admin','','','product/reply/save_fictitious_reply','POST','[]',0,0,0,1,'/adminproduct/reply/save_fictitious_reply','',2,'',0,'product-reply-save_fictitious_reply',0),(186,22,'','获取属性模板列表','admin','','','product/product/get_rule','GET','[]',0,0,0,1,'/adminproduct/product/get_rule','',2,'',0,'',0),(187,22,'','运费模板列表','admin','','','product/product/get_template','GET','[]',0,0,0,1,'/adminproduct/product/get_template','',2,'',0,'',0),(188,579,'','删除评论','admin','','','product/reply/<id>','DELETE','[]',0,0,0,1,'/adminproduct/reply/<id>','',2,'',0,'',0),(189,579,'','评论回复','admin','','','product/reply/set_reply/<id>','PUT','[]',0,0,0,1,'/adminreply/set_reply/<id>','',2,'',0,'',0),(190,6,'','评论列表','admin','','','product/reply','GET','[]',0,0,0,1,'/adminproduct/reply','',2,'',0,'',0),(191,22,'','生成属性','admin','','','product/generate_attr/<id>/<type>','POST','[]',0,0,0,1,'/adminproduct/generate_attr/<id>','',2,'',0,'',0),(192,2,'','商品列表头部','admin','','','product/product/type_header','GET','[]',10,0,0,1,'/adminproduct/product/type_header','',2,'',0,'',0),(193,577,'','商品列表插件','admin','','','product/product/list','GET','[]',0,0,0,1,'/adminproduct/product/list','',2,'',0,'',0),(194,99,'','属性规则列表','admin','','','product/product/rule','GET','[]',0,0,0,1,'/adminproduct/product/rule','',2,'',0,'',0),(195,580,'','保存修改规则','admin','','','product/product/rule/<id>','POST','[]',0,0,0,1,'/adminproduct/rule/<id>','',2,'',0,'product-rule-save',0),(196,580,'','规则详情','admin','','','product/product/rule/<id>','GET','[]',0,0,0,1,'/adminproduct/product/rule/<id>','',2,'',0,'',0),(197,580,'','删除规则','admin','','','product/product/rule/delete','DELETE','[]',0,0,0,1,'/adminproduct/product/rule/delete','',2,'',0,'product-product-rule-delete',0),(198,5,'','订单列表','admin','','','order/list','GET','[]',0,0,0,1,'/adminorder/list','',2,'',0,'',0),(199,5,'','订单数据','admin','','','order/chart','GET','[]',0,0,0,1,'/adminorder/chart','',2,'',0,'',0),(200,581,'','订单核销','admin','','','order/write','POST','[]',0,0,0,1,'/adminorder/write','',2,'',0,'order-write',0),(201,215,'','订单修改表格','admin','','','order/edit/<id>','GET','[]',0,0,0,1,'/adminorder/edit/<id>','',2,'',0,'',0),(202,215,'','订单修改','admin','','','order/update/<id>','PUT','[]',0,0,0,1,'/adminorder/update/<id>','',2,'',0,'',0),(203,581,'','订单收货','admin','','','order/take/<id>','PUT','[]',0,0,0,1,'/adminorder/take/<id>','',2,'',0,'',0),(204,209,'','订单发货','admin','','','order/delivery/<id>','PUT','[]',0,0,0,1,'/adminorder/delivery/<id>','',2,'',0,'',0),(205,214,'','订单退款表格','admin','','','order/refund/<id>','GET','[]',0,0,0,1,'/adminorder/refund/<id>','',2,'',0,'',0),(206,214,'','订单退款','admin','','','order/refund/<id>','PUT','[]',0,0,0,1,'/adminorder/refund/<id>','',2,'',0,'',0),(207,581,'','订单物流信息','admin','','','order/express/<id>','GET','[]',0,0,0,1,'/adminorder/express/<id>','',2,'',0,'',0),(208,209,'','物流公司列表','admin','','','order/express_list','GET','[]',0,0,0,1,'/adminorder/express_list','',2,'',0,'',0),(209,581,'','发货','admin','','','','','[]',0,0,0,1,'/adminorder/delivery','',1,'',0,'',0),(210,767,'','附加权限','admin','','','','GET','[]',99,1,0,1,'/adminorder/info/<id>','',2,'',0,'',0),(211,213,'','订单配送表格','admin','','','order/distribution/<id>','GET','[]',0,0,0,1,'/adminorder/distribution/<id>','',2,'',0,'',0),(212,213,'','修改配送信息','admin','','','order/distribution/<id>','PUT','[]',0,0,0,1,'/adminorder/distribution/<id>','',2,'',0,'',0),(213,581,'','订单配送','admin','','','','','[]',0,0,0,1,'/adminorder/distribution','',1,'',0,'',0),(214,581,'','退款','admin','','','','','[]',0,0,0,1,'/adminorder/refund','',1,'',0,'',0),(215,581,'','修改','admin','','','','','[]',0,0,0,1,'/adminorder/update','',1,'',0,'',0),(216,581,'','不退款','admin','','','','','[]',0,0,0,1,'/adminorder/no_refund','',1,'',0,'',0),(217,216,'','不退款表格','admin','','','order/no_refund/<id>','GET','[]',0,0,0,1,'/adminorder/no_refund/<id>','',2,'',0,'',0),(218,216,'','不退款理由修改','admin','','','order/no_refund/<id>','PUT','[]',0,0,0,1,'/adminorder/no_refund/<id>','',2,'',0,'',0),(219,581,'','线下支付','admin','','','order/pay_offline/<id>','POST','[]',98,0,0,1,'','',2,'',0,'',0),(220,581,'','退积分','admin','','','','','[]',0,0,0,1,'/adminorder/refund_integral','',1,'',0,'',0),(221,220,'','退积分表单','admin','','','order/refund_integral/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(222,220,'','修改退积分','admin','','','order/refund_integral/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(223,581,'','订单备注','admin','','','order/remark/<id>','PUT','[]',97,0,0,1,'','',2,'',0,'',0),(225,581,'','订单删除','admin','','','order/del/<id>','DELETE','[]',95,0,0,1,'','',2,'',0,'',0),(226,581,'','批量删除订单','admin','','','order/dels','POST','[]',100,0,0,1,'','',2,'',0,'',0),(227,9,'','用户分组','admin','user.user_group','index','','','[]',9,1,0,1,'/admin/user/group','',1,'user',1,'user-user-group',0),(229,25,'','城市数据','admin','setting.system_city','','','','[]',1,1,0,1,'/admin/setting/freight/city/list','',1,'setting',1,'setting-system-city',0),(230,303,'','运费模板','admin','setting.shipping_templates','','','','[]',0,1,0,1,'/admin/setting/freight/shipping_templates/list','',1,'setting',1,'setting-shipping-templates',0),(231,767,'','发票列表','admin','','','order/invoice/list','GET','[]',0,1,0,1,'','',2,'',0,'admin-order-invoice-index',0),(232,585,'','用户详情','admin','','','user/one_info/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(233,585,'','创建用户表单','admin','','','user/user/create','GET','[]',0,0,0,1,'','',2,'',0,'',0),(234,585,'','修改用户信息表单','admin','','','user/user/<id>/edit','GET','[]',0,0,0,1,'','',2,'',0,'',0),(235,585,'','获取用户信息','admin','','','user/user/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(236,585,'','修改用户信息','admin','','','user/user/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(238,585,'','发送优惠卷','admin','','','','','[]',0,0,0,1,'/admin/user/coupon','',1,'',0,'admin-user-coupon',0),(239,238,'','优惠卷列表','admin','','','marketing/coupon/grant','GET','[]',0,0,0,1,'','',2,'',0,'',0),(240,238,'','发送优惠卷','admin','','','marketing/coupon/user/grant','POST','[]',0,0,0,1,'','',2,'',0,'',0),(241,585,'','发送图文','admin','','','','','[]',0,0,0,1,'/admin/wechat/news/','',1,'',0,'admin-wechat-news',0),(242,241,'','图文列表','admin','','','app/wechat/news','GET','[]',0,0,0,1,'','',2,'',0,'',0),(243,241,'','发送图文','admin','','','app/wechat/push','POST','[]',0,0,0,1,'','',2,'',0,'',0),(244,585,'','批量用户分组','admin','','','','','[]',0,0,0,1,'/admin/user/group_set/','',1,'',0,'admin-user-group_set',0),(245,244,'','用户分组表单','admin','','','user/set_group/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(246,244,'','保存分组','admin','','','user/set_group','POST','[]',0,0,0,1,'','',2,'',0,'',0),(261,227,'','用户分组列表','admin','','','user/user_group/list','GET','[]',0,0,0,1,'','',2,'',0,'',0),(262,227,'','删除用户分组','admin','','','user/user_group/del/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(263,227,'','添加修改用户分组','admin','','','','','[]',0,0,0,1,'/admin/user/group','',1,'',0,'admin-user-group',0),(264,263,'','添加修改用户分组表单','admin','','','user/user_group/add/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(265,263,'','保存修改用户分组','admin','','','user/user_group/save','POST','[]',0,0,0,1,'','',2,'',0,'',0),(274,583,'','添加优惠卷','admin','','','','','[]',0,0,0,1,'/admin/marketing/store_coupon/add','',1,'',0,'admin-marketing-store_coupon-add',0),(275,274,'','添加优惠卷表单','admin','','','marketing/coupon/create/<type>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(276,274,'','保存优惠卷','admin','','','marketing/coupon/save_coupon','POST','[]',0,0,0,1,'','',2,'',0,'',0),(277,583,'','发布优惠卷','admin','','','','','[]',0,0,0,1,'/admin/marketing/store_coupon/push','',1,'',0,'admin-marketing-store_coupon-push',0),(278,277,'','发布优惠卷表单','admin','','','marketing/coupon/issue/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(279,277,'','发布优惠卷','admin','','','marketing/coupon/issue/<id>','POST','[]',0,0,0,1,'','',2,'',0,'',0),(280,583,'','立即失效','admin','','','marketing/coupon/status/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(281,583,'','删除优惠卷','admin','','','marketing/coupon/del/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(282,71,'','优惠卷已发布列表','admin','','','marketing/coupon/released','GET','[]',0,0,0,1,'','',2,'',0,'',0),(283,71,'','领取记录','admin','','','marketing/coupon/released/issue_log/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(284,71,'','删除优惠卷','admin','','','marketing/coupon/released/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(285,71,'','修改状态','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(286,285,'','修改状态表单','admin','','','marketing/coupon/released/<id>/status','GET','[]',0,0,0,1,'','',2,'',0,'',0),(287,285,'','保存修改状态','admin','','','marketing/coupon/released/status/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(288,80,'','积分日志列表','admin','','','marketing/integral','GET','[]',0,0,0,1,'','',2,'',0,'',0),(289,80,'','积分日志数据','admin','','','marketing/integral/statistics','GET','[]',0,0,0,1,'','',2,'',0,'',0),(303,12,'','发货设置','admin','setting','index','','','[]',0,1,0,1,'/admin/setting/freight','',1,'',0,'',0),(304,303,'','物流配置','admin','setting.systemConfig','index','','','[]',0,0,0,1,'/admin/setting/system_config_logistics/3/10','',1,'',0,'setting-system-config-logistics',0),(305,44,'','文章列表','admin','','','cms/cms','GET','[]',0,0,0,1,'','',2,'',0,'',0),(306,409,'','文章分类','admin','','','cms/category','GET','[]',0,0,0,1,'','',2,'',0,'',0),(311,41,'','资金类型','admin','','','finance/finance/bill_type','GET','[]',0,0,0,1,'','',2,'',0,'',0),(312,41,'','资金列表','admin','','','finance/finance/list','GET','[]',0,0,0,1,'','',2,'',0,'',0),(313,23,'','获取头部导航','admin','','','setting/config/header_basics','GET','[]',0,0,0,1,'','',2,'',0,'',0),(314,23,'','获取配置列表','admin','','','setting/config/edit_basics','GET','[]',0,0,0,1,'','',2,'',0,'',0),(315,23,'','修改配置','admin','','','setting/config/save_basics','POST','[]',0,0,0,1,'','',2,'',0,'',0),(316,423,'','添加客服','admin','','','','','[]',0,0,0,1,'/admin/setting/store_service/add','',1,'',0,'setting-store_service-add',0),(317,316,'','客服用户列表','admin','','','app/wechat/kefu/add','GET','[]',0,0,0,1,'','',2,'',0,'',0),(318,316,'','保存客服','admin','','','app/wechat/kefu','POST','[]',0,0,0,1,'','',2,'',0,'',0),(319,423,'','聊天记录','admin','','','app/wechat/kefu/record/','GET','[]',0,0,0,1,'','',2,'',0,'',0),(320,423,'','编辑客服','admin','','','','','[]',80,0,0,1,'/admin/setting/store_service/edit','',1,'',0,'setting-store_service-edit',0),(321,423,'','删除客服','admin','','','app/wechat/kefu/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(322,423,'','客服是否开启','admin','','','app/wechat/kefu/set_status/<id>/<status>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(323,320,'','编辑客服表单','admin','','','app/wechat/kefu/<id>/edit','GET','[]',0,0,0,1,'','',2,'',0,'',0),(324,320,'','修改客服','admin','','','app/wechat/kefu/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(325,19,'','添加身份','admin','','','','','[]',0,0,0,1,'/admin/setting/system_role/add','',1,'',0,'setting-system_role-add',0),(326,325,'','添加身份表单','admin','','','setting/role/create','GET','[]',0,0,0,1,'','',2,'',0,'',0),(327,325,'','添加修改身份','admin','','','setting/role/<id>','POST','[]',0,0,0,1,'','',2,'',0,'',0),(328,325,'','修改身份表单','admin','','','setting/role/<id>/edit','GET','[]',0,0,0,1,'','',2,'',0,'',0),(329,19,'','修改身份状态','admin','','','setting/role/set_status/<id>/<status>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(330,19,'','删除身份','admin','','','setting/role/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(331,20,'','添加管理员','admin','','','','','[]',0,0,0,1,'/admin/setting/system_admin/add','',1,'',0,'setting-system_admin-add',0),(332,331,'','添加管理员表单','admin','','','setting/admin/create','GET','[]',0,0,0,1,'','',2,'',0,'',0),(333,331,'','添加管理员','admin','','','setting/admin','POST','[]',0,0,0,1,'','',2,'',0,'',0),(334,20,'','编辑管理员','admin','','','','','[]',0,0,0,1,'/admin /setting/system_admin/edit','',1,'',0,' setting-system_admin-edit',0),(335,334,'','编辑管理员表单','admin','','','setting/admin/<id>/edit','GET','[]',0,0,0,1,'','',2,'',0,'',0),(336,334,'','修改管理员','admin','','','setting/admin/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(337,20,'','删除管理员','admin','','','setting/admin/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(338,21,'','添加规则','admin','','','','','[]',0,0,0,1,'/admin/setting/system_menus/add','',1,'',0,'setting-system_menus-add',0),(339,338,'','添加权限表单','admin','','','setting/menus/create','GET','[]',0,0,0,1,'','',2,'',0,'',0),(340,338,'','添加权限','admin','','','setting/menus','POST','[]',0,0,0,1,'','',2,'',0,'',0),(341,21,'','修改权限','admin','setting.system_menus','edit','','','[]',0,0,0,1,'/admin/setting/system_menus/edit','',1,'',0,'/setting-system_menus-edit',0),(342,341,'','编辑权限表单','admin','','','setting/menus/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(343,341,'','修改权限','admin','','','setting/menus/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(344,21,'','修改权限状态','admin','','','setting/menus/show/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(345,21,'','删除权限菜单','admin','','','setting/menus/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(346,338,'','添加子菜单','admin','setting.system_menus','add','','','[]',0,0,0,1,'/admin/setting/system_menus/add_sub','',1,'',0,'setting-system_menus-add_sub',0),(347,361,'','是否登陆短信平台','admin','','','notify/sms/is_login','GET','[]',0,0,0,1,'','',2,'',0,'',0),(348,361,'','短信剩余条数','admin','','','notify/sms/number','GET','[]',0,0,0,1,'','',2,'',0,'',0),(349,95,'','获取短信验证码','admin','','','serve/captcha','POST','[]',0,0,0,1,'','',2,'',0,'',0),(350,95,'','修改注册账号','admin','','','serve/register','POST','[]',0,0,0,1,'','',2,'',0,'',0),(351,95,'','登陆短信平台','admin','','','serve/login','POST','[]',0,0,0,1,'','',2,'',0,'',0),(353,95,'','退出短信登陆','admin','','','notify/sms/logout','GET','[]',0,0,0,1,'','',2,'',0,'',0),(355,96,'','短信模板列表','admin','','','serve/sms/temps','GET','[]',0,0,0,1,'','',2,'',0,'',0),(356,96,'','申请模板','admin','','','','','[]',0,0,0,1,'/admin/setting/sms/sms_template_apply/add','',1,'',0,'setting-sms-sms_template_apply-add',0),(357,356,'','申请短信模板表单','admin','','','notify/sms/temp/create','GET','[]',0,0,0,1,'','',2,'',0,'',0),(358,356,'','保存申请短信模板','admin','','','notify/sms/temp','POST','[]',0,0,0,1,'','',2,'',0,'',0),(359,97,'','短信套餐','admin','','','serve/meal_list','GET','[]',0,0,0,1,'','',2,'',0,'',0),(360,97,'','短信购买支付码','admin','','','serve/pay_meal','POST','[]',0,0,0,1,'','',2,'',0,'',0),(361,94,'','短信设置附加权限','admin','','','','','[]',0,0,0,1,'/admin/setting/sms/attach','',1,'',0,'',0),(366,7,'','首页统计数据','admin','','','home/header','GET','[]',0,0,0,1,'','',2,'',0,'',0),(367,7,'','首页订单图表','admin','','','home/order','GET','[]',0,0,0,1,'','',2,'',0,'',0),(368,7,'','首页用户图表','admin','','','home/user','GET','[]',0,0,0,1,'','',2,'',0,'',0),(369,7,'','首页交易额排行','admin','','','home/rank','GET','[]',0,0,0,1,'','',2,'',0,'',0),(370,72,'','优惠卷领取列表','admin','','','marketing/coupon/user','GET','[]',0,0,0,1,'','',2,'',0,'',0),(406,44,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(407,406,'','保存修改文章','admin','','','cms/cms','POST','[]',0,0,0,1,'','',2,'',0,'',0),(408,406,'','获取文章详情','admin','','','cms/cms/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(409,44,'','公共权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(410,406,'','关联商品列表','admin','','','product/product/list','GET','[]',0,0,0,1,'','',2,'',0,'',0),(411,406,'','分类树型列表','admin','','','product/category/tree/<type>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(412,406,'','关联商品','admin','','','cms/cms/relation/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(413,406,'','取消关联','admin','','','cms/cms/unrelation/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(414,406,'','删除文章','admin','','','cms/cms/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(415,45,'','文章列表','admin','','','cms/category','GET','[]',0,0,0,1,'','',2,'',0,'',0),(416,45,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(417,416,'','文章分类添加表单','admin','','','cms/category/create','GET','[]',0,0,0,1,'','',2,'',0,'cms-category-create',0),(418,416,'','保存文章分类','admin','','','cms/category','POST','[]',0,0,0,1,'','',2,'',0,'',0),(419,416,'','编辑文章分类','admin','','','cms/category/<id>/edit','GET','[]',0,0,0,1,'','',2,'',0,'',0),(420,416,'','修改文章分类','admin','','','cms/category/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(421,416,'','删除文章分类','admin','','','cms/category/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(422,678,'','客服列表','admin','','','app/wechat/kefu','GET','[]',0,0,0,1,'','',2,'',0,'',0),(442,229,'','城市数据列表','admin','','','setting/city/list/<parent_id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(443,229,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(444,443,'','获取添加城市表单','admin','','','setting/city/add/<parent_id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(445,443,'','保存修改城市数据','admin','','','setting/city/save','POST','[]',0,0,0,1,'','',2,'',0,'',0),(446,443,'','获取修改城市表单','admin','','','setting/city/<id>/edit','GET','[]',0,0,0,1,'','',2,'',0,'',0),(447,443,'','删除城市数据','admin','','','setting/city/del/<city_id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(448,145,'','物流公司列表','admin','','','freight/express','GET','[]',0,0,0,1,'','',2,'',0,'',0),(449,145,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(450,449,'','修改物流公司状态','admin','','','freight/express/set_status/<id>/<status>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(451,449,'','获取添加物流公司表单','admin','','','freight/express/create','GET','[]',0,0,0,1,'','',2,'',0,'',0),(452,449,'','保存物流公司','admin','','','freight/express','POST','[]',0,0,0,1,'','',2,'',0,'',0),(453,449,'','获取编辑物流公司表单','admin','','','freight/express/<id>/edit','GET','[]',0,0,0,1,'','',2,'',0,'',0),(454,449,'','修改物流公司','admin','','','freight/express/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(455,449,'','删除物流公司','admin','','','freight/express/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(456,230,'','运费模板列表','admin','','','setting/shipping_templates/list','GET','[]',0,0,0,1,'','',2,'',0,'',0),(457,230,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(458,457,'','运费模板城市数据','admin','','','setting/shipping_templates/city_list','GET','[]',0,0,0,1,'','',2,'',0,'',0),(459,457,'','保存或者修改运费模板','admin','','','setting/shipping_templates/save/<id>','POST','[]',0,0,0,1,'','',2,'',0,'',0),(460,457,'','删除运费模板','admin','','','setting/shipping_templates/del/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(461,111,'','配置分类列表','admin','','','setting/config_class','GET','[]',0,0,0,1,'','',2,'',0,'',0),(462,111,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(463,462,'','配置分类添加表单','admin','','','setting/config_class/create','GET','[]',0,0,0,1,'','',2,'',0,'',0),(464,462,'','保存配置分类','admin','','','setting/config_class','POST','[]',0,0,0,1,'','',2,'',0,'',0),(465,641,'','编辑配置分类','admin','','','setting/config_class/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(466,462,'','删除配置分类','admin','','','setting/config_class/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(467,125,'','配置列表展示','admin','','','setting/config','GET','[]',0,0,0,1,'','',2,'',0,'',0),(468,125,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(469,468,'','添加配置字段表单','admin','','','setting/config/create','GET','[]',0,0,0,1,'','',2,'',0,'',0),(470,468,'','保存配置字段','admin','','','setting/config','POST','[]',0,0,0,1,'','',2,'',0,'',0),(471,468,'','编辑配置字段表单','admin','','','setting/config/<id>/edit','','[]',0,0,0,1,'','',2,'',0,'',0),(472,468,'','编辑配置分类','admin','','','setting/config/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(473,468,'','删除配置','admin','','','setting/config/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(474,468,'','修改配置状态','admin','','','setting/config/set_status/<id>/<status>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(475,112,'','组合数据列表','admin','','','setting/group','GET','[]',0,1,0,1,'','',2,'',0,'',0),(476,112,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(477,476,'','新增组合数据','admin','','','setting/group','POST','[]',0,0,0,1,'','',2,'',0,'',0),(478,476,'','获取组合数据','admin','','','setting/group/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(479,476,'','修改组合数据','admin','','','setting/group/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(480,476,'','删除组合数据','admin','','','setting/group/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(481,126,'','组合数据列表表头','admin','','','setting/group_data/header','GET','[]',0,0,0,1,'','',2,'',0,'',0),(482,126,'','组合数据列表','admin','','','setting/group_data','GET','[]',0,0,0,1,'','',2,'',0,'',0),(483,126,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(484,483,'','获取组合数据添加表单','admin','','','setting/group_data/create','GET','[]',0,0,0,1,'','',2,'',0,'',0),(485,483,'','保存组合数据','admin','','','setting/group_data','POST','[]',0,0,0,1,'','',2,'',0,'',0),(486,483,'','获取组合数据信息','admin','','','setting/group_data/<id>/edit','GET','[]',0,0,0,1,'','',2,'',0,'',0),(487,483,'','修改组合数据信息','admin','','','setting/group_data/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(488,483,'','删除组合数据','admin','','','setting/group_data/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(489,483,'','修改组合数据状态','admin','','','setting/group_data/set_status/<id>/<status>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(490,57,'','清除缓存','admin','','','system/refresh_cache/cache','GET','[]',0,0,0,1,'','',2,'',0,'',0),(491,57,'','清除日志','admin','','','system/refresh_cache/log','GET','[]',0,0,0,1,'','',2,'',0,'',0),(492,47,'','管理员搜索列表','admin','','','system/log/search_admin','GET','[]',0,0,0,1,'','',2,'',0,'',0),(493,47,'','系统日志列表','admin','','','system/log','GET','[]',0,0,0,1,'','',2,'',0,'',0),(494,64,'','文件校验列表','admin','','','system/file','GET','[]',0,0,0,1,'','',2,'',0,'',0),(495,66,'','清除数据接口','admin','','','system/clear/<type>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(496,67,'','数据库列表','admin','','','system/backup','GET','[]',0,0,0,1,'','',2,'',0,'',0),(497,67,'','数据库备份列表','admin','','','system/backup/file_list','GET','[]',0,0,0,1,'','',2,'',0,'',0),(498,67,'','数据表详情','admin','','','system/backup/read','GET','[]',0,0,0,1,'','',2,'',0,'',0),(499,67,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(500,499,'','备份表','admin','','','system/backup/backup','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(501,499,'','优化表','admin','','','system/backup/optimize','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(502,499,'','修复表','admin','','','system/backup/repair','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(503,499,'','导入sql','admin','','','system/backup/import','POST','[]',0,0,1,1,'','',2,'',0,'',0),(504,499,'','删除数据库备份','admin','','','system/backup/del_file','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(505,499,'','备份下载','admin','','','backup/download','GET','[]',0,0,0,1,'','',2,'',0,'',0),(507,92,'','微信菜单列表','admin','','','app/wechat/menu','GET','[]',0,0,0,1,'','',2,'',0,'',0),(508,92,'','保存微信菜单','admin','','','app/wechat/menu','POST','[]',0,0,0,1,'','',2,'',0,'',0),(509,93,'','微信模板消息列表','admin','','','app/wechat/template','GET','[]',0,0,0,1,'','',2,'',0,'',0),(510,93,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(511,510,'','添加模板消息表单','admin','','','app/wechat/template/create','GET','[]',0,0,0,1,'','',2,'',0,'app-wechat-template-create',0),(512,510,'','保存模板消息','admin','','','app/wechat/template','POST','[]',0,0,0,1,'','',2,'',0,'',0),(513,510,'','编辑模板消息表单','admin','','','app/wechat/template/<id>/edit','GET','[]',0,0,0,1,'','',2,'',0,'',0),(514,510,'','修改模板消息','admin','','','app/wechat/template/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(515,510,'','修改模板消息状态','admin','','','app/wechat/template/set_status/<id>/<status>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(516,510,'','删除模板消息','admin','','','app/wechat/template/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(520,133,'','订阅消息列表','admin','','','app/routine','GET','[]',0,0,0,1,'','',2,'',0,'',0),(521,133,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(522,521,'','添加模板消息表单','admin','','','app/routine/create','GET','[]',0,0,0,1,'','',2,'',0,'app-routine-create',0),(523,521,'','保存模板消息','admin','','','app/routine','POST','[]',0,0,0,1,'','',2,'',0,'',0),(524,521,'','修改订阅消息状态','admin','','','app/routine/set_status/<id>/<status>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(525,521,'','编辑模板消息表单','admin','','','app/routine/<id>/edit','GET','[]',0,0,0,1,'','',2,'',0,'',0),(526,521,'','编辑订阅消息','admin','','','app/routine/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(527,521,'','删除订阅消息','admin','','','app/routine/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(553,109,'','图文列表','admin','','','app/wechat/news','GET','[]',0,0,0,1,'','',2,'',0,'',0),(554,109,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(555,554,'','保存图文','admin','','','app/wechat/news','POST','[]',0,0,0,1,'','',2,'',0,'',0),(556,554,'','图文详情','admin','','','app/wechat/news/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(557,554,'','删除图文','admin','','','app/wechat/news/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(558,114,'','公共权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(559,558,'','回复关键词','admin','','','app/wechat/reply','GET','[]',0,0,0,1,'','',2,'',0,'',0),(560,115,'','关键词回复列表','admin','','','app/wechat/keyword','GET','[]',0,0,0,1,'','',2,'',0,'',0),(561,115,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(562,558,'','保存修改关键字','admin','','','app/wechat/keyword/<id>','POST','[]',0,0,0,1,'','',2,'',0,'',0),(563,561,'','获取关键字信息','admin','','','app/wechat/keyword/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(564,561,'','修改关键字状态','admin','','','app/wechat/keyword/set_status/<id>/<status>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(565,561,'','删除关键字','admin','','','app/wechat/keyword/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(566,25,'','附件管理权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(567,566,'','附件列表','admin','','','file/file','GET','[]',0,0,0,1,'','',2,'',0,'',0),(568,566,'','附件分类','admin','','','file/category','GET','[]',0,0,0,1,'','',2,'',0,'',0),(569,566,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(570,569,'','附件分类表单','admin','','','file/category/create','GET','[]',0,0,0,1,'','',2,'',0,'',0),(571,569,'','附件分类保存','admin','','','file/category','POST','[]',0,0,0,1,'','',2,'',0,'',0),(572,569,'','删除附件','admin','','','file/file/delete','POST','[]',0,0,0,1,'','',2,'',0,'',0),(573,569,'','移动附件分类','admin','','','file/file/do_move','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(574,566,'','上传附件','admin','','','file/upload/<upload_type?>','POST','[]',10,0,0,1,'','',2,'',0,'',0),(575,569,'','附件分类编辑表单','admin','','','file/category/<id>/edit','GET','[]',0,0,0,1,'','',2,'',0,'',0),(576,569,'','附件分类修改','admin','','','file/category/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(577,2,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(578,3,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(579,6,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(580,99,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(581,5,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(582,70,'','优惠卷模板列表','admin','','','marketing/coupon/list','GET','[]',0,0,0,1,'','',2,'',0,'',0),(583,70,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(585,10,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(587,25,'','个人中心','admin','','','','','[]',0,1,1,1,'/admin/system/user','',1,'',0,'system-user',0),(589,9,'','用户标签','admin','user.user_label','index','','','[]',8,1,0,1,'/admin/user/label','',1,'user',1,'user-user-label',0),(590,589,'','用户标签接口','admin','','','user/user_label','GET','[]',0,0,0,1,'','',2,'',0,'',0),(591,589,'','删除用户标签','admin','','','user/user_label/del/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(592,589,'','添加修改用户标签','admin','','','','','[]',0,0,0,1,'/admin/user/label_add','',1,'',0,'admin-user-label_add',0),(593,592,'','添加修改用户标签表单','admin','','','user/user_label/add/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(594,592,'','保存修改用户标签','admin','','','user/user_label/save','POST','[]',0,0,0,1,'','',2,'',0,'',0),(596,2,'','商品导出','admin','','','export/storeProduct','GET','[]',10,0,0,1,'','',2,'',0,'export-storeProduct',0),(597,5,'','订单导出','admin','','','export/storeorder','GET','[]',0,0,0,1,'','',2,'',0,'export-storeOrder',0),(607,587,'','修改密码','admin','','','setting/update_admin','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(610,20,'','管理员列表','admin','','','setting/admin','GET','[]',0,0,0,1,'','',2,'',0,'',0),(611,19,'','身份列表','admin','','','setting/role','GET','[]',0,0,0,1,'','',2,'',0,'',0),(612,2,'','批量上下架','admin','','','product/product/product_show','PUT','[]',5,0,0,1,'','',2,'',0,'product-product-product_show',0),(613,585,'','批量设置标签','admin','','','','','[]',0,0,0,1,'/admin/user/set_label','',1,'',0,'admin-user-set_label',0),(614,613,'','获取标签表单','admin','','','user/set_label','POST','[]',0,0,0,1,'','',2,'',0,'',0),(615,613,'','保存标签','admin','','','user/save_set_label','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(616,80,'','积分导出','admin','','','export/userPoint','GET','[]',0,0,0,1,'','',2,'',0,'export-userPoint',0),(617,41,'','资金记录导出','admin','','','export/userFinance','GET','[]',0,0,0,1,'','',2,'',0,'export-userFinance',0),(619,21,'','权限列表','admin','','','setting/menus','GET','[]',0,0,0,1,'','',2,'',0,'',0),(620,22,'','商品详情','admin','','','product/product/<id>','GET','[]',0,1,1,1,'','',2,'',0,'',0),(621,585,'','保存用户信息','admin','','','user/user','POST','[]',10,0,0,1,'','',2,'',0,'',0),(622,585,'','积分余额','admin','','','','','[]',0,0,0,1,'/admin/user/edit_other','',1,'',0,'',0),(623,622,'','获取修改用户详情表单','admin','','','user/edit_other/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(624,622,'','修改用户余额','admin','','','user/update_other/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(625,585,'','赠送用户','admin','','','','','[]',0,0,0,1,'/admin/user/user_level','',1,'',0,'',0),(626,625,'','获取表单','admin','','','user/give_level/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(627,625,'','赠送会员等级','admin','','','user/save_give_level/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(628,585,'','单个用户分组设置','admin','','','user/save_set_group','PUT','[]',10,0,0,1,'','',2,'',0,'',0),(635,20,'','修改管理员状态','admin','','','setting/set_status/<id>/<status>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(636,25,'','其他权限','admin','','','','','[]',0,0,0,1,'/admin/system/other','',1,'',0,'',0),(637,636,'','消息提醒','admin','','','jnotice','GET','[]',0,0,0,1,'','',2,'',0,'',0),(638,457,'','获取运费模板详情','admin','','','setting/shipping_templates/<id>/edit','GET','[]',0,0,0,1,'','',2,'',0,'',0),(639,457,'','删除运费模板','admin','','','setting/shipping_templates/del/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(640,462,'','修改配置分类状态','admin','','','setting/config_class/set_status/<id>/<status>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(641,462,'','编辑配置分类','admin','','','','','[]',0,0,0,1,'system/config/system_config_tab/edit','',1,'',0,'',0),(642,641,'','获取编辑配置分类表单','admin','','','setting/config_class/<id>/edit','GET','[]',0,0,0,1,'','',2,'',0,'',0),(655,65,'','在线升级','admin','','','','','[]',0,0,1,1,'/admin/system/system_upgradeclient/index','',1,'',0,'system-system-upgradeclient',0),(656,12,'','页面管理','admin','','','','','[]',1,1,0,1,'/admin/setting/pages','',1,'',0,'admin-setting-pages',0),(657,656,'','页面设计','admin','','','','','[]',1,1,0,1,'/admin/setting/pages/devise','',1,'',0,'admin-setting-pages-devise',0),(658,656,'','页面编辑','admin','','','','','[]',1,1,1,1,'/admin/setting/pages/diy','',1,'',0,'admin-setting-pages-diy',0),(660,656,'','页面链接','admin','','','','','[]',1,0,0,1,'/admin/setting/pages/links','',1,'',0,'admin-setting-pages-links',0),(661,657,'','DIY列表','admin','','','diy/get_list','GET','[]',0,0,0,1,'','',2,'',0,'',0),(662,657,'','组件文章分类','admin','','','cms/category_list','GET','[]',0,0,0,1,'','',2,'',0,'',0),(663,657,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin/setting/diy','',1,'',0,'admin-setting-diy-additional',0),(664,663,'','获取页面设计','admin','','','diy/get_info/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(665,663,'','保存和修改页面','admin','','','diy/save/<id?>','POST','[]',0,0,0,1,'','',2,'',0,'admin-setting-pages-diy-save',0),(666,660,'','路径列表','admin','','','diy/get_url','GET','[]',0,0,0,1,'','',2,'',0,'',0),(667,663,'','删除页面','admin','','','diy/del/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(668,663,'','修改页面状态','admin','','','diy/set_status/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(669,2,'','批量下架','admin','','','product/product/product_unshow','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(670,581,'','订单打印','admin','','','order/print/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(671,585,'','清除会员等级','admin','','','user/del_level/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(673,416,'','修改文章分类状态','admin','','','cms/category/set_status/<id>/<status>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(674,229,'','清除城市缓存','admin','','','setting/city/clean_cache','GET','[]',0,0,0,1,'','',2,'',0,'',0),(675,657,'','组件商品分类','admin','','','diy/get_category','GET','[]',0,0,0,1,'','',2,'',0,'',0),(676,657,'','组件商品列表','admin','','','diy/get_product','GET','[]',0,0,0,1,'','',2,'',0,'',0),(677,581,'','订单号核销','admin','','','order/write_update/<order_id>','PUT','[]',0,0,0,1,'order/dels','',2,'',0,'admin-order-write_update',0),(678,165,'','客服列表','admin','','','','','[]',0,1,0,1,'/admin/setting/store_service/index','',1,'',0,'admin-setting-store_service-index',0),(679,165,'','客服话术','admin','','','','','[]',0,1,0,1,'/admin/setting/store_service/speechcraft','',1,'',0,'admin-setting-store_service-speechcraft',0),(685,22,'','上传商品视频','admin','','','product/product/get_temp_keys','GET','[]',0,0,0,1,'','',2,'',0,'',0),(715,133,'','一键同步订阅消息','admin','','','app/routine/syncSubscribe','GET','[]',0,0,0,1,'','',2,'',0,'app-wechat-template-sync',0),(719,71,'','添加优惠卷','admin','','','','','[]',0,0,0,1,'/admin/marketing/store_coupon_issue/create','',1,'',0,'admin-marketing-store_coupon_issue-create',0),(720,303,'','配送员管理','admin','','','','','[]',0,1,0,1,'/admin/setting/delivery_service/index','',1,'',0,'setting-delivery-service',0),(721,729,'','编辑配送员','admin','','','','','[]',0,0,0,1,'/admin/setting/delivery_service/edit','',1,'',0,'setting-delivery_service-edit',0),(722,720,'','配送员列表','admin','','','app/order/delivery','GET','[]',0,0,0,1,'','',2,'',0,'',0),(723,721,'','修改配送员','admin','','','app/order/delivery/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(724,729,'','添加配送员','admin','','','','','[]',0,0,0,1,'/admin/setting/delivery_service/add','',1,'',0,'setting-delivery_service-add',0),(725,724,'','配送员用户列表','admin','','','app/order/delivery/add','GET','[]',0,0,0,1,'','',2,'',0,'',0),(726,724,'','保存配送员','admin','','','app/order/delivery','POST','[]',0,0,0,1,'','',2,'',0,'',0),(727,729,'','删除配送员','admin','','','app/order/delivery/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(728,729,'','配送员是否开启','admin','','','app/order/delivery/set_status/<id>/<status>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(729,720,'','附加权限','admin','','','','','[]',0,0,0,1,'/admin*','',1,'',0,'',0),(738,165,'','用户留言','admin','','','','','[]',0,1,0,1,'/admin/setting/store_service/feedback','',1,'',0,'admin-setting-store_service-feedback',0),(739,738,'','列表展示','admin','','','app/feedback','GET','[]',0,0,0,1,'','',2,'',0,'',0),(740,738,'','附件权限','admin','','','','','[]',0,0,0,1,'*','',1,'',0,'',0),(741,740,'','删除反馈','admin','','','app/feedback/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(742,679,'','列表展示','admin','','','app/wechat/speechcraft','GET','[]',0,0,0,1,'','',2,'',0,'',0),(743,679,'','附件权限','admin','','','','','[]',0,0,0,1,'*','',1,'',0,'',0),(744,743,'','添加话术','admin','','','','','[]',0,0,0,1,'/admin/setting/store_service/speechcraft/add','',1,'',0,'admin-setting-store_service-speechcraft-add',0),(745,743,'','编辑话术','admin','','','','','[]',0,0,0,1,'/admin/setting/store_service/speechcraft/edit','',1,'',0,'admin-setting-store_service-speechcraft-edit',0),(746,744,'','获取添加话术表单','admin','','','app/wechat/speechcraft/create','GET','[]',0,0,0,1,'','',2,'',0,'',0),(747,744,'','保存话术','admin','','','app/wechat/speechcraft','POST','[]',0,0,0,1,'','',2,'',0,'',0),(748,745,'','获取编辑话术表单','admin','','','app/wechat/speechcraft/<id>/edit','GET','[]',0,0,0,1,'','',2,'',0,'',0),(749,745,'','确认修改','admin','','','app/wechat/speechcraft/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(750,743,'','删除话术','admin','','','app/wechat/speechcraft/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(756,585,'','添加用户','admin','','','','','[]',0,0,0,1,'/admin/user/save','',1,'',0,'admin-user-save',0),(757,756,'','获取添加用户表单','admin','','','user/user/create','GET','[]',0,0,0,1,'','',2,'',0,'',0),(758,756,'','保存用户','admin','','','user/user','POST','[]',0,0,0,1,'','',2,'',0,'',0),(759,585,'','同步公众号用户','admin','','','user/user/syncUsers','GET','[]',0,0,0,1,'','',2,'',0,'admin-user-synchro',0),(767,36,'','发票管理','admin','','','','','[]',0,1,0,1,'/admin/order/invoice/list','',1,'',0,'admin-order-startOrderInvoice-index',0),(768,210,'','编辑','admin','','','','','[]',0,1,0,1,'','',2,'',0,'admin-order-invoice-edit',0),(769,210,'','订单信息','admin','','','order/invoice_order_info/<id>','GET','[]',0,1,0,1,'','',2,'',0,'admin-order-invoice-orderInfo',0),(770,210,'','编辑提交','admin','','','order/invoice/set/<id>','POST','[]',0,1,0,1,'','',2,'',0,'admin-order-invoice-update',0),(774,589,'','用户标签列表','admin','','','user/user_label_cate/all','GET','[]',0,0,0,1,'','',2,'',0,'admin-user-user_lable_cate-all',0),(780,589,'','标签分类','admin','','','','','[]',0,0,0,1,'/admin/user/label_cate','',1,'',0,'',0),(781,780,'','获取标签分类列表','admin','','','user/user_label_cate/all','GET','[]',0,0,0,1,'','',2,'',0,'',0),(782,780,'','添加标签分类','admin','','','','','[]',0,0,0,1,'/admin/user/label_cate/add','',1,'',0,'',0),(783,782,'','获取标签分类表单','admin','','','user/user_label_cate/create','GET','[]',0,0,0,1,'','',2,'',0,'',0),(784,782,'','保存标签分类','admin','','','user/user_label_cate','POST','[]',0,0,0,1,'','',2,'',0,'',0),(785,780,'','修改标签分类','admin','','','','','[]',0,0,0,1,'/admin/user/label_cate/edit','',1,'',0,'',0),(786,785,'','获取修改标签分类表单','admin','','','user/user_label_cate/<id>/edit','GET','[]',0,0,0,1,'user/user_label_cate/<id>/edit','',2,'',0,'',0),(787,785,'','保存用户标签分类','admin','','','user/user_label_cate/<id>','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(788,780,'','删除用户标签分类','admin','','','user/user_label_cate/<id>','DELETE','[]',0,0,0,1,'','',2,'',0,'',0),(798,209,'','获取送货人列表','admin','','','order/delivery/list','GET','[]',0,0,0,1,'','',2,'',0,'',0),(799,209,'','获取电子面单打印默认配置','admin','','','order/sheet_info','GET','[]',0,0,0,1,'','',2,'',0,'',0),(800,581,'','电子面单打印','admin','','','order/order_dump/<id>','GET','[]',0,0,0,1,'','',2,'',0,'',0),(802,767,'','获取订单发票数据','admin','','','order/invoice/chart','GET','[]',0,0,0,1,'','',2,'',0,'',0),(806,71,'','复制优惠券','admin','','','marketing/coupon/copy/<id>','GET','[]',0,0,0,1,'marketing/coupon/copy/369','',2,'',0,'',0),(809,95,'','获取平台用户信息','admin','','','serve/info','GET','[]',0,0,0,1,'','',2,'',0,'',0),(810,95,'','获取平台消费列表','admin','','','serve/record','GET','[]',0,0,0,1,'','',2,'',0,'',0),(811,95,'','修改手机号','admin','','','serve/update_phone','POST','[]',0,0,0,1,'','',2,'',0,'',0),(812,95,'','修改签名','admin','','','serve/sms/sign','PUT','[]',0,0,0,1,'','',2,'',0,'',0),(813,95,'','修改账号密码','admin','','','serve/modify','POST','[]',0,0,0,1,'','',2,'',0,'',0),(828,10,'','用户列表','admin','','','user/user','GET','[]',0,0,0,1,'','',2,'',0,'',0),(832,71,'','保存优惠券','admin','','','marketing/coupon/save_coupon','POST','[]',0,0,0,1,'','',2,'',0,'',0),(834,95,'','短信记录列表','admin','','','notify/sms/record','GET','[]',0,0,0,1,'notify/sms/record','',2,'',0,'',0),(837,79,'','积分配置表单','admin','','','marketing/integral_config/edit_basics','GET','[]',0,1,0,1,'','',2,'',0,'',0),(838,79,'','积分配置表单提交','admin','','','marketing/integral_config/save_basics','POST','[]',0,1,0,1,'','',2,'',0,'',0),(884,128,'','获取数据分类','admin','','','setting/group_all','GET','[]',0,0,0,1,'','',2,'',0,'',0),(885,721,'','获取编辑配送员表单','admin','','','order/delivery/<id>/edit','GET','[]',0,1,0,1,'','12/303/720/729/721',2,'',0,'',0),(886,0,'md-analytics','股票','admin','','','','','[]',1,1,0,1,'/admin/risk','',1,'',0,'admin-risk',0),(887,886,'','个股列表','admin','','','','','[]',1,1,0,1,'/admin/risk/stock_list','886',1,'',0,'admin-risk-stocklist',0),(888,886,'','禁买股票','admin','','','','','[]',0,1,0,1,'/admin/risk/black_list','886',1,'',0,'admin-risk-blacklist',0),(889,886,'','除权除息','admin','','','','','[]',0,1,0,1,'/admin/risk/xrxd','886',1,'',0,'admin-risk-xrxd',0),(890,886,'','停牌复牌','admin','','','','','[]',0,1,0,1,'/admin/risk/suspension','886',1,'',0,'admin-risk-suspension',0);
/*!40000 ALTER TABLE `st_admin_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_admin_module`
--

DROP TABLE IF EXISTS `st_admin_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_admin_module` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '模块名称（标识）',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '模块标题',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '图标',
  `description` text NOT NULL COMMENT '描述',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `author_url` varchar(255) NOT NULL DEFAULT '' COMMENT '作者主页',
  `config` text COMMENT '配置信息',
  `access` text COMMENT '授权配置',
  `version` varchar(16) NOT NULL DEFAULT '' COMMENT '版本号',
  `identifier` varchar(64) NOT NULL DEFAULT '' COMMENT '模块唯一标识符',
  `system_module` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统模块',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='模块表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_admin_module`
--

LOCK TABLES `st_admin_module` WRITE;
/*!40000 ALTER TABLE `st_admin_module` DISABLE KEYS */;
INSERT INTO `st_admin_module` VALUES (1,'admin','系统模块','fa fa-fw fa-gear','系统模块','我的配资','http://www.ufpz.cn','','','1.0.0','admin.lvmaque.module',1,1468204902,1468204902,100,1),(2,'user','管理员模块','fa fa-fw fa-user','管理员模块','我的配资','http://www.ufpz.cn','','','1.0.0','user.lvmaque.module',1,1468204902,1468204902,100,1),(3,'cms','门户模块','fa fa-fw fa-newspaper-o','门户模块','我的配资','http://www.ufpz.cn','{\"summary\":\"0\",\"contact\":\"\",\"meta_head\":\"\",\"meta_foot\":\"\",\"support_status\":\"0\",\"support_color\":\"rgba(0,158,232,1)\",\"support_wx\":\"33\",\"support_extra\":\"\"}','{\"group\":{\"tab_title\":\"\\u680f\\u76ee\\u6388\\u6743\",\"table_name\":\"cms_column\",\"primary_key\":\"id\",\"parent_id\":\"pid\",\"node_name\":\"name\"}}','1.0.0','cms.lvmaque.module',0,1512457289,1526971966,100,1),(5,'stock','配资模块','fa fa-fw fa-pie-chart','配资模块','我的配资','http://www.ufpz.cn','','','1.0.0','stock.lei.module',0,1513566609,1525481877,100,1),(6,'member','会员模块','fa fa-fw fa-users','会员模块','ZhangJiLi','http://www.ufpz.cn','{\"member_is_login\":\"1\",\"member_is_register\":\"1\"}','','1.0.0','member.jili.module',0,1513934342,1515121910,100,1),(7,'money','资金模块','fa fa-fw fa-money','资金模块','ZhangJiLi','http://www.ufpz.cn','','','1.0.0','money.jili.module',0,1515033594,1515121901,100,1),(10,'statistics','统计管理模块','fa fa-fw fa-bar-chart','统计管理模块','MengHui','http://www.ufpz.cn',NULL,NULL,'1.0.0','statistics.meng.module',0,1524795782,1524795782,100,1),(11,'market','股票交易中心','fa fa-fw fa-line-chart','股票交易模块','MengHui','http://www.ufpz.cn',NULL,NULL,'1.0.0','market.meng.module',1,1524796898,1524796898,100,1),(22,'agents','用户代理模块','fa fa-fw fa-sitemap','用户代理模块','我的配资','http://www.ufpz.cn','','','1.0.0','agents.lvmaque.module',0,1529732615,1530669190,100,1),(24,'statistics','统计管理模块','','统计管理模块','MengHui','http://www.ufpz.cn',NULL,NULL,'1.0.0','statistics.meng.module',0,1530181377,1530181377,100,1),(25,'crontab','定时任务','glyphicon glyphicon-time','模块依赖 composer 组件 <code>mtdowling/cron-expression</code> 和 <code>guzzlehttp/guzzle</code>','流风回雪','http://www.ufpz.cn',NULL,NULL,'1.0.0','crontab.meishixiu.module',0,1530666868,1530666868,100,1),(26,'app','APP','fa fa-fw fa-newspaper-o','app配置','我的配资','http://www.ufpz.cn','{\"app_open\":1,\"app_name\":\"\\u5b9e\\u76d8\\u914d\\u8d44\",\"down_android\":\"\",\"is_power_android\":0,\"version_androd_name\":\"\",\"version_androd_code\":\"\",\"\\tdescription_android\":\"\",\"\\tdown_iso\":\"\",\"power_ios\":0,\"\\tversion_ios\":\"\",\"\\tdescription_ios\":\"\"}','{\"group\":{\"tab_title\":\"\\u680f\\u76ee\\u6388\\u6743\",\"table_name\":\"app_column\",\"primary_key\":\"id\",\"parent_id\":\"pid\",\"node_name\":\"name\"}}','1.0.0','app.lvmaque.module',0,1530667078,1530669163,100,1),(27,'wap','wap','','wap模块','bing','http://www.ufpz.cn',NULL,NULL,'1.0.0','wap.bing.module',0,1531288587,1531288587,100,1);
/*!40000 ALTER TABLE `st_admin_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_admin_packet`
--

DROP TABLE IF EXISTS `st_admin_packet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_admin_packet` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '数据包名',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '数据包标题',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `author_url` varchar(255) NOT NULL DEFAULT '' COMMENT '作者url',
  `version` varchar(16) NOT NULL,
  `tables` text NOT NULL COMMENT '数据表名',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='数据包表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_admin_packet`
--

LOCK TABLES `st_admin_packet` WRITE;
/*!40000 ALTER TABLE `st_admin_packet` DISABLE KEYS */;
INSERT INTO `st_admin_packet` VALUES (1,'wechat_area','微信地区数据包','CaiWeiMing','','1.0.0','[\"packet_wechat_area\"]',1512456171,1512456171,1),(2,'broker','券商类型数据包','明道配资','www.mingdaopeizi.com','1.0.0','[\"stock_broker\"]',1513569400,1513569400,1);
/*!40000 ALTER TABLE `st_admin_packet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_admin_plugin`
--

DROP TABLE IF EXISTS `st_admin_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_admin_plugin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '插件名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '插件标题',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '图标',
  `description` text NOT NULL COMMENT '插件描述',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `author_url` varchar(255) NOT NULL DEFAULT '' COMMENT '作者主页',
  `config` text NOT NULL COMMENT '配置信息',
  `version` varchar(16) NOT NULL DEFAULT '' COMMENT '版本号',
  `identifier` varchar(64) NOT NULL DEFAULT '' COMMENT '插件唯一标识符',
  `admin` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台管理',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='插件表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_admin_plugin`
--

LOCK TABLES `st_admin_plugin` WRITE;
/*!40000 ALTER TABLE `st_admin_plugin` DISABLE KEYS */;
INSERT INTO `st_admin_plugin` VALUES (1,'SystemInfo','系统环境信息','fa fa-fw fa-info-circle','在后台首页显示服务器信息','明道配资','http://www.caiweiming.com','{\"display\":\"1\",\"width\":\"6\"}','1.0.0','system_info.ming.plugin',0,1477757503,1477757503,100,1),(2,'DevTeam','开发团队成员信息','fa fa-fw fa-users','开发团队成员信息','明道配资','http://www.caiweiming.com','{\"display\":\"1\",\"width\":\"6\"}','1.0.0','dev_team.ming.plugin',0,1477755780,1477755780,100,1),(4,'Qrcode','二维码生成插件','fa fa-fw fa-qrcode','二维码生成插件','蔡伟明','http://www.dolphinphp.com','{\"outfile\":\"1\",\"level\":\"H\",\"size\":\"3\",\"margin\":\"4\",\"saveandprint\":\"1\",\"back_color\":\"rgb(255,255,255)\",\"fore_color\":\"rgb(0,0,0)\",\"logo\":\"\"}','1.0.0','qrcode.ming.plugin',0,1512457258,1512457258,100,1),(6,'Excel','Excel 插件','fa fa-fw fa-file-excel-o','导入或导出excel','蔡伟明','http://www.caiweiming.com','','1.0.0','excel.ming.plugin',0,1514261204,1514261204,100,1),(9,'GreenSparrow','GreenSparrow','fa fa-fw fa-globe','这是明道配资实盘交易插件，为您提供实盘交易和行情查询方法。','明道配资','http://www.mingdaopeizi.com','{\"status\":\"3\"}','1.0.1','greensparrow.meng.plugin',0,1514971688,1514971688,100,1),(11,'Statistics','后台配资统计','fa fa-fw fa-pie-chart','在后台首页显示配资统计','明道配资','http://www.mingdaopeizi.com','{\"display\":\"1\",\"width\":\"12\"}','1.0.0','Statistics.ming.plugin',0,1526870611,1526870611,100,1),(12,'waitingProcess','后台首页代办事项','fa fa-fw fa-stack-overflow','在后台首页显示代办事项','明道配资','http://www.mingdaopeizi.com','{\"display\":1,\"width\":6}','1.0.0','waitingProcess.ming.plugin',0,1526955706,1526955706,100,1),(14,'UcpaasSms','创蓝短信','fa fa-fw fa-envelope','创蓝253短信接口。','张继立','http://www.mingdaopeizi.com','{\"username\":\"N1011364\",\"password\":\"ILzmKHNMpe8258\",\"tip\":\"[\\u7eff\\u9ebb\\u96c0]\"}','1.0.0','ucpaassms.zhangjili.plugin',0,1531359120,1531359120,100,1);
/*!40000 ALTER TABLE `st_admin_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_admin_role`
--

DROP TABLE IF EXISTS `st_admin_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_admin_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '角色id',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级角色',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '角色名称',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '角色描述',
  `menu_auth` text NOT NULL COMMENT '菜单权限',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否可登录后台',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='角色表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_admin_role`
--

LOCK TABLES `st_admin_role` WRITE;
/*!40000 ALTER TABLE `st_admin_role` DISABLE KEYS */;
INSERT INTO `st_admin_role` VALUES (1,0,'超级管理员','系统默认创建的角色，拥有最高权限','',0,1476270000,1468117612,1,1);
/*!40000 ALTER TABLE `st_admin_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_admin_user`
--

DROP TABLE IF EXISTS `st_admin_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_admin_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '所属上级的代理ID',
  `username` varchar(32) NOT NULL DEFAULT '' COMMENT '用户名',
  `nickname` varchar(32) NOT NULL DEFAULT '' COMMENT '昵称',
  `password` varchar(96) NOT NULL DEFAULT '' COMMENT '密码',
  `mobile` varchar(11) NOT NULL DEFAULT '' COMMENT '手机号码',
  `mobile_bind` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否绑定手机号码',
  `commission_scale` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '佣金比例（单位：%）',
  `profit_share_scale` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '盈利分成比例（单位：%）',
  `rate_scale` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '管理费分成比例（单位：%）',
  `avatar` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '头像',
  `money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '余额',
  `score` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '积分',
  `role` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '角色ID',
  `group` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '部门id',
  `signup_ip` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '注册ip',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `last_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后一次登录时间',
  `last_login_ip` varchar(50) DEFAULT '0' COMMENT '登录ip',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态：0禁用，1启用',
  `email` varchar(64) NOT NULL DEFAULT '' COMMENT '邮箱地址',
  `email_bind` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否绑定邮箱地址',
  `auth_code` varchar(20) DEFAULT NULL,
  `if_auth` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `google_code` (`auth_code`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_admin_user`
--

LOCK TABLES `st_admin_user` WRITE;
/*!40000 ALTER TABLE `st_admin_user` DISABLE KEYS */;
INSERT INTO `st_admin_user` VALUES (1,NULL,'admin','超级管理员','$2y$10$2ZGP.JiMczYgKrXFX7J1OeiclGiiYzaY5mnGC.EnzjkQoei9DrzUW','18888888888',0,0.00,0.00,0.00,0,0.00,0,1,0,0,1764154528,1764154528,1764154528,'47.242.100.58',100,1,'',0,'3PV6UHG424BXXR6Y',1);
/*!40000 ALTER TABLE `st_admin_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_agents_back_money`
--

DROP TABLE IF EXISTS `st_agents_back_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_agents_back_money` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mid` int(10) unsigned NOT NULL COMMENT '奖励用户',
  `affect_mid` int(11) DEFAULT NULL COMMENT '奖励来源用户id',
  `affect` float(11,2) NOT NULL DEFAULT '0.00' COMMENT '影响金额',
  `info` varchar(255) NOT NULL COMMENT '详情',
  `create_time` int(11) NOT NULL COMMENT '交易时间',
  `create_ip` varchar(50) NOT NULL COMMENT '交易IP',
  `affect_mobile` varchar(20) DEFAULT NULL,
  `rate` float(10,2) DEFAULT NULL,
  `money_a` float(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `moneylog_uid` (`mid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='代理商资金操作记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_agents_back_money`
--

LOCK TABLES `st_agents_back_money` WRITE;
/*!40000 ALTER TABLE `st_agents_back_money` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_agents_back_money` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_area`
--

DROP TABLE IF EXISTS `st_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_area` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `reid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(120) NOT NULL DEFAULT '',
  `sort_order` smallint(5) unsigned NOT NULL DEFAULT '0',
  `is_open` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `domain` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`reid`,`sort_order`),
  KEY `is_open` (`is_open`,`domain`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=3414 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_area`
--

LOCK TABLES `st_area` WRITE;
/*!40000 ALTER TABLE `st_area` DISABLE KEYS */;
INSERT INTO `st_area` VALUES (1,0,'中国',0,0,''),(2,1,'北京市',1,1,'bj'),(3,1,'安徽',1,0,'ah'),(4,1,'福建',1,0,''),(5,1,'甘肃',1,0,''),(6,1,'广东',1,0,''),(7,1,'广西',1,0,''),(8,1,'贵州',1,0,''),(9,1,'海南',1,0,''),(10,1,'河北',1,0,''),(11,1,'河南',1,0,''),(12,1,'黑龙江',1,0,''),(13,1,'湖北',1,0,''),(14,1,'湖南',1,0,''),(15,1,'吉林',1,0,''),(16,1,'江苏',1,0,''),(17,1,'江西',1,0,''),(18,1,'辽宁',1,0,''),(19,1,'内蒙古',1,0,''),(20,1,'宁夏',1,0,''),(21,1,'青海',1,0,''),(22,1,'山东',1,0,''),(23,1,'山西',1,0,''),(24,1,'陕西',1,0,''),(25,1,'上海',1,1,'sh'),(26,1,'四川',1,0,''),(27,1,'天津',1,0,''),(28,1,'西藏',1,0,''),(29,1,'新疆',1,0,''),(30,1,'云南',1,0,''),(31,1,'浙江',1,0,''),(32,1,'重庆',1,0,''),(33,1,'香港',1,0,''),(34,1,'澳门',1,0,''),(35,1,'台湾',1,0,''),(36,3,'安庆',2,1,'aq'),(37,3,'蚌埠',2,0,''),(38,3,'巢湖',2,0,''),(39,3,'池州',2,0,''),(40,3,'滁州',2,0,''),(41,3,'阜阳',2,0,''),(42,3,'淮北',2,0,''),(43,3,'淮南',2,0,''),(44,3,'黄山',2,0,''),(45,3,'六安',2,0,''),(46,3,'马鞍山',2,0,''),(47,3,'宿州',2,0,''),(48,3,'铜陵',2,0,''),(49,3,'芜湖',2,0,''),(50,3,'宣城',2,0,''),(51,3,'亳州',2,0,''),(52,2,'北京',2,1,''),(53,4,'福州',2,0,''),(54,4,'龙岩',2,0,''),(55,4,'南平',2,0,''),(56,4,'宁德',2,0,''),(57,4,'莆田',2,0,''),(58,4,'泉州',2,0,''),(59,4,'三明',2,0,''),(60,4,'厦门',2,0,''),(61,4,'漳州',2,0,''),(62,5,'兰州',2,0,''),(63,5,'白银',2,0,''),(64,5,'定西',2,0,''),(65,5,'甘南',2,0,''),(66,5,'嘉峪关',2,0,''),(67,5,'金昌',2,0,''),(68,5,'酒泉',2,0,''),(69,5,'临夏',2,0,''),(70,5,'陇南',2,0,''),(71,5,'平凉',2,0,''),(72,5,'庆阳',2,0,''),(73,5,'天水',2,0,''),(74,5,'武威',2,0,''),(75,5,'张掖',2,0,''),(76,6,'广州',2,0,''),(77,6,'深圳',2,0,''),(78,6,'潮州',2,0,''),(79,6,'东莞',2,0,''),(80,6,'佛山',2,0,''),(81,6,'河源',2,0,''),(82,6,'惠州',2,0,''),(83,6,'江门',2,0,''),(84,6,'揭阳',2,0,''),(85,6,'茂名',2,0,''),(86,6,'梅州',2,0,''),(87,6,'清远',2,0,''),(88,6,'汕头',2,0,''),(89,6,'汕尾',2,0,''),(90,6,'韶关',2,0,''),(91,6,'阳江',2,0,''),(92,6,'云浮',2,0,''),(93,6,'湛江',2,0,''),(94,6,'肇庆',2,0,''),(95,6,'中山',2,0,''),(96,6,'珠海',2,0,''),(97,7,'南宁',2,0,''),(98,7,'桂林',2,0,''),(99,7,'百色',2,0,''),(100,7,'北海',2,0,''),(101,7,'崇左',2,0,''),(102,7,'防城港',2,0,''),(103,7,'贵港',2,0,''),(104,7,'河池',2,0,''),(105,7,'贺州',2,0,''),(106,7,'来宾',2,0,''),(107,7,'柳州',2,0,''),(108,7,'钦州',2,0,''),(109,7,'梧州',2,0,''),(110,7,'玉林',2,0,''),(111,8,'贵阳',2,0,''),(112,8,'安顺',2,0,''),(113,8,'毕节',2,0,''),(114,8,'六盘水',2,0,''),(115,8,'黔东南',2,0,''),(116,8,'黔南',2,0,''),(117,8,'黔西南',2,0,''),(118,8,'铜仁',2,0,''),(119,8,'遵义',2,0,''),(120,9,'海口',2,0,''),(121,9,'三亚',2,0,''),(122,9,'白沙',2,0,''),(123,9,'保亭',2,0,''),(124,9,'昌江',2,0,''),(125,9,'澄迈县',2,0,''),(126,9,'定安县',2,0,''),(127,9,'东方',2,0,''),(128,9,'乐东',2,0,''),(129,9,'临高县',2,0,''),(130,9,'陵水',2,0,''),(131,9,'琼海',2,0,''),(132,9,'琼中',2,0,''),(133,9,'屯昌县',2,0,''),(134,9,'万宁',2,0,''),(135,9,'文昌',2,0,''),(136,9,'五指山',2,0,''),(137,9,'儋州',2,0,''),(138,10,'石家庄',2,0,''),(139,10,'保定',2,0,''),(140,10,'沧州',2,0,''),(141,10,'承德',2,0,''),(142,10,'邯郸',2,0,''),(143,10,'衡水',2,0,''),(144,10,'廊坊',2,0,''),(145,10,'秦皇岛',2,0,''),(146,10,'唐山',2,0,''),(147,10,'邢台',2,0,''),(148,10,'张家口',2,0,''),(149,11,'郑州',2,0,''),(150,11,'洛阳',2,0,''),(151,11,'开封',2,0,''),(152,11,'安阳',2,0,''),(153,11,'鹤壁',2,0,''),(154,11,'济源',2,0,''),(155,11,'焦作',2,0,''),(156,11,'南阳',2,0,''),(157,11,'平顶山',2,0,''),(158,11,'三门峡',2,0,''),(159,11,'商丘',2,0,''),(160,11,'新乡',2,0,''),(161,11,'信阳',2,0,''),(162,11,'许昌',2,0,''),(163,11,'周口',2,0,''),(164,11,'驻马店',2,0,''),(165,11,'漯河',2,0,''),(166,11,'濮阳',2,0,''),(167,12,'哈尔滨',2,0,''),(168,12,'大庆',2,0,''),(169,12,'大兴安岭',2,0,''),(170,12,'鹤岗',2,0,''),(171,12,'黑河',2,0,''),(172,12,'鸡西',2,0,''),(173,12,'佳木斯',2,0,''),(174,12,'牡丹江',2,0,''),(175,12,'七台河',2,0,''),(176,12,'齐齐哈尔',2,0,''),(177,12,'双鸭山',2,0,''),(178,12,'绥化',2,0,''),(179,12,'伊春',2,0,''),(180,13,'武汉',100,0,'wh'),(181,13,'仙桃',2,0,''),(182,13,'鄂州',2,0,''),(183,13,'黄冈',2,0,''),(184,13,'黄石',2,0,''),(185,13,'荆门',2,0,''),(186,13,'荆州',2,0,''),(187,13,'潜江',2,0,''),(188,13,'神农架林区',2,0,''),(189,13,'十堰',2,0,''),(190,13,'随州',2,0,''),(191,13,'天门',2,0,''),(192,13,'咸宁',2,0,''),(193,13,'襄樊',2,0,''),(194,13,'孝感',2,0,''),(195,13,'宜昌',2,0,''),(196,13,'恩施',2,0,''),(197,14,'长沙',2,0,'cs'),(198,14,'张家界',2,0,''),(199,14,'常德',2,0,''),(200,14,'郴州',2,0,''),(201,14,'衡阳',2,0,''),(202,14,'怀化',2,0,''),(203,14,'娄底',2,0,''),(204,14,'邵阳',2,0,''),(205,14,'湘潭',2,0,''),(206,14,'湘西',2,0,''),(207,14,'益阳',2,0,''),(208,14,'永州',2,0,''),(209,14,'岳阳',2,0,''),(210,14,'株洲',2,0,''),(211,15,'长春',2,0,''),(212,15,'吉林',2,0,''),(213,15,'白城',2,0,''),(214,15,'白山',2,0,''),(215,15,'辽源',2,0,''),(216,15,'四平',2,0,''),(217,15,'松原',2,0,''),(218,15,'通化',2,0,''),(219,15,'延边',2,0,''),(220,16,'南京',2,0,''),(221,16,'苏州',2,0,''),(222,16,'无锡',2,0,''),(223,16,'常州',2,0,''),(224,16,'淮安',2,0,''),(225,16,'连云港',2,0,''),(226,16,'南通',2,0,''),(227,16,'宿迁',2,0,''),(228,16,'泰州',2,0,''),(229,16,'徐州',2,0,''),(230,16,'盐城',2,0,''),(231,16,'扬州',2,0,''),(232,16,'镇江',2,0,''),(233,17,'南昌',2,0,''),(234,17,'抚州',2,0,''),(235,17,'赣州',2,0,''),(236,17,'吉安',2,0,''),(237,17,'景德镇',2,0,''),(238,17,'九江',2,0,''),(239,17,'萍乡',2,0,''),(240,17,'上饶',2,0,''),(241,17,'新余',2,0,''),(242,17,'宜春',2,0,''),(243,17,'鹰潭',2,0,''),(244,18,'沈阳',2,0,''),(245,18,'大连',2,0,''),(246,18,'鞍山',2,0,''),(247,18,'本溪',2,0,''),(248,18,'朝阳',2,0,''),(249,18,'丹东',2,0,''),(250,18,'抚顺',2,0,''),(251,18,'阜新',2,0,''),(252,18,'葫芦岛',2,0,''),(253,18,'锦州',2,0,''),(254,18,'辽阳',2,0,''),(255,18,'盘锦',2,0,''),(256,18,'铁岭',2,0,''),(257,18,'营口',2,0,''),(258,19,'呼和浩特',2,0,''),(259,19,'阿拉善盟',2,0,''),(260,19,'巴彦淖尔盟',2,0,''),(261,19,'包头',2,0,''),(262,19,'赤峰',2,0,''),(263,19,'鄂尔多斯',2,0,''),(264,19,'呼伦贝尔',2,0,''),(265,19,'通辽',2,0,''),(266,19,'乌海',2,0,''),(267,19,'乌兰察布市',2,0,''),(268,19,'锡林郭勒盟',2,0,''),(269,19,'兴安盟',2,0,''),(270,20,'银川',2,0,''),(271,20,'固原',2,0,''),(272,20,'石嘴山',2,0,''),(273,20,'吴忠',2,0,''),(274,20,'中卫',2,0,''),(275,21,'西宁',2,0,''),(276,21,'果洛',2,0,''),(277,21,'海北',2,0,''),(278,21,'海东',2,0,''),(279,21,'海南',2,0,''),(280,21,'海西',2,0,''),(281,21,'黄南',2,0,''),(282,21,'玉树',2,0,''),(283,22,'济南',2,0,''),(284,22,'青岛',2,0,''),(285,22,'滨州',2,0,'binzhou'),(286,22,'德州',2,0,''),(287,22,'东营',2,0,''),(288,22,'菏泽',2,0,'heze'),(289,22,'济宁',2,0,''),(290,22,'莱芜',2,0,''),(291,22,'聊城',2,0,''),(292,22,'临沂',2,0,''),(293,22,'日照',2,0,''),(294,22,'泰安',2,0,''),(295,22,'威海',2,0,''),(296,22,'潍坊',2,0,''),(297,22,'烟台',2,0,''),(298,22,'枣庄',2,0,''),(299,22,'淄博',2,0,''),(300,23,'太原',2,0,''),(301,23,'长治',2,0,''),(302,23,'大同',2,0,''),(303,23,'晋城',2,0,''),(304,23,'晋中',2,0,''),(305,23,'临汾',2,0,''),(306,23,'吕梁',2,0,''),(307,23,'朔州',2,0,''),(308,23,'忻州',2,0,''),(309,23,'阳泉',2,0,''),(310,23,'运城',2,0,''),(311,24,'西安',2,0,''),(312,24,'安康',2,0,''),(313,24,'宝鸡',2,0,''),(314,24,'汉中',2,0,''),(315,24,'商洛',2,0,''),(316,24,'铜川',2,0,''),(317,24,'渭南',2,0,''),(318,24,'咸阳',2,0,''),(319,24,'延安',2,0,''),(320,24,'榆林',2,0,''),(321,25,'上海',2,0,''),(322,26,'成都',2,0,''),(323,26,'绵阳',2,0,''),(324,26,'阿坝',2,0,''),(325,26,'巴中',2,0,''),(326,26,'达州',2,0,''),(327,26,'德阳',2,0,''),(328,26,'甘孜',2,0,''),(329,26,'广安',2,0,''),(330,26,'广元',2,0,''),(331,26,'乐山',2,0,''),(332,26,'凉山',2,0,''),(333,26,'眉山',2,0,''),(334,26,'南充',2,0,''),(335,26,'内江',2,0,''),(336,26,'攀枝花',2,0,''),(337,26,'遂宁',2,0,''),(338,26,'雅安',2,0,''),(339,26,'宜宾',2,0,''),(340,26,'资阳',2,0,''),(341,26,'自贡',2,0,''),(342,26,'泸州',2,0,''),(343,27,'天津',2,0,''),(344,28,'拉萨',2,0,''),(345,28,'阿里',2,0,''),(346,28,'昌都',2,0,''),(347,28,'林芝',2,0,''),(348,28,'那曲',2,0,''),(349,28,'日喀则',2,0,''),(350,28,'山南',2,0,''),(351,29,'乌鲁木齐',2,0,''),(352,29,'阿克苏',2,0,''),(353,29,'阿拉尔',2,0,''),(354,29,'巴音郭楞',2,0,''),(355,29,'博尔塔拉',2,0,''),(356,29,'昌吉',2,0,''),(357,29,'哈密',2,0,''),(358,29,'和田',2,0,''),(359,29,'喀什',2,0,''),(360,29,'克拉玛依',2,0,''),(361,29,'克孜勒苏',2,0,''),(362,29,'石河子',2,0,''),(363,29,'图木舒克',2,0,''),(364,29,'吐鲁番',2,0,''),(365,29,'五家渠',2,0,''),(366,29,'伊犁',2,0,''),(367,30,'昆明',2,0,''),(368,30,'怒江',2,0,''),(369,30,'普洱',2,0,''),(370,30,'丽江',2,0,''),(371,30,'保山',2,0,''),(372,30,'楚雄',2,0,''),(373,30,'大理',2,0,''),(374,30,'德宏',2,0,''),(375,30,'迪庆',2,0,''),(376,30,'红河',2,0,''),(377,30,'临沧',2,0,''),(378,30,'曲靖',2,0,''),(379,30,'文山',2,0,''),(380,30,'西双版纳',2,0,''),(381,30,'玉溪',2,0,''),(382,30,'昭通',2,0,''),(383,31,'杭州',2,0,''),(384,31,'湖州',2,0,''),(385,31,'嘉兴',2,0,''),(386,31,'金华',2,0,''),(387,31,'丽水',2,0,''),(388,31,'宁波',2,0,''),(389,31,'绍兴',2,0,''),(390,31,'台州',2,0,''),(391,31,'温州',2,0,''),(392,31,'舟山',2,0,''),(393,31,'衢州',2,0,''),(394,32,'重庆',2,0,''),(395,33,'香港',2,0,''),(396,34,'澳门',2,0,''),(397,35,'台湾',2,0,''),(398,36,'迎江区',3,0,''),(399,36,'大观区',3,0,''),(400,36,'宜秀区',3,0,''),(401,36,'桐城市',3,0,''),(402,36,'怀宁县',3,0,''),(403,36,'枞阳县',3,0,''),(404,36,'潜山县',3,0,''),(405,36,'太湖县',3,0,''),(406,36,'宿松县',3,0,''),(407,36,'望江县',3,0,''),(408,36,'岳西县',3,0,''),(409,37,'中市区',3,0,''),(410,37,'东市区',3,0,''),(411,37,'西市区',3,0,''),(412,37,'郊区',3,0,''),(413,37,'怀远县',3,0,''),(414,37,'五河县',3,0,''),(415,37,'固镇县',3,0,''),(416,38,'居巢区',3,0,''),(417,38,'庐江县',3,0,''),(418,38,'无为县',3,0,''),(419,38,'含山县',3,0,''),(420,38,'和县',3,0,''),(421,39,'贵池区',3,0,''),(422,39,'东至县',3,0,''),(423,39,'石台县',3,0,''),(424,39,'青阳县',3,0,''),(425,40,'琅琊区',3,0,''),(426,40,'南谯区',3,0,''),(427,40,'天长市',3,0,''),(428,40,'明光市',3,0,''),(429,40,'来安县',3,0,''),(430,40,'全椒县',3,0,''),(431,40,'定远县',3,0,''),(432,40,'凤阳县',3,0,''),(433,41,'蚌山区',3,0,''),(434,41,'龙子湖区',3,0,''),(435,41,'禹会区',3,0,''),(436,41,'淮上区',3,0,''),(437,41,'颍州区',3,0,''),(438,41,'颍东区',3,0,''),(439,41,'颍泉区',3,0,''),(440,41,'界首市',3,0,''),(441,41,'临泉县',3,0,''),(442,41,'太和县',3,0,''),(443,41,'阜南县',3,0,''),(444,41,'颖上县',3,0,''),(445,42,'相山区',3,0,''),(446,42,'杜集区',3,0,''),(447,42,'烈山区',3,0,''),(448,42,'濉溪县',3,0,''),(449,43,'田家庵区',3,0,''),(450,43,'大通区',3,0,''),(451,43,'谢家集区',3,0,''),(452,43,'八公山区',3,0,''),(453,43,'潘集区',3,0,''),(454,43,'凤台县',3,0,''),(455,44,'屯溪区',3,0,''),(456,44,'黄山区',3,0,''),(457,44,'徽州区',3,0,''),(458,44,'歙县',3,0,''),(459,44,'休宁县',3,0,''),(460,44,'黟县',3,0,''),(461,44,'祁门县',3,0,''),(462,45,'金安区',3,0,''),(463,45,'裕安区',3,0,''),(464,45,'寿县',3,0,''),(465,45,'霍邱县',3,0,''),(466,45,'舒城县',3,0,''),(467,45,'金寨县',3,0,''),(468,45,'霍山县',3,0,''),(469,46,'雨山区',3,0,''),(470,46,'花山区',3,0,''),(471,46,'金家庄区',3,0,''),(472,46,'当涂县',3,0,''),(473,47,'埇桥区',3,0,''),(474,47,'砀山县',3,0,''),(475,47,'萧县',3,0,''),(476,47,'灵璧县',3,0,''),(477,47,'泗县',3,0,''),(478,48,'铜官山区',3,0,''),(479,48,'狮子山区',3,0,''),(480,48,'郊区',3,0,''),(481,48,'铜陵县',3,0,''),(482,49,'镜湖区',3,0,''),(483,49,'弋江区',3,0,''),(484,49,'鸠江区',3,0,''),(485,49,'三山区',3,0,''),(486,49,'芜湖县',3,0,''),(487,49,'繁昌县',3,0,''),(488,49,'南陵县',3,0,''),(489,50,'宣州区',3,0,''),(490,50,'宁国市',3,0,''),(491,50,'郎溪县',3,0,''),(492,50,'广德县',3,0,''),(493,50,'泾县',3,0,''),(494,50,'绩溪县',3,0,''),(495,50,'旌德县',3,0,''),(496,51,'涡阳县',3,0,''),(497,51,'蒙城县',3,0,''),(498,51,'利辛县',3,0,''),(499,51,'谯城区',3,0,''),(500,52,'东城区',3,1,'bj'),(501,52,'西城区',3,0,''),(502,52,'海淀区',3,0,''),(503,52,'朝阳区',3,0,''),(504,52,'崇文区',3,0,''),(505,52,'宣武区',3,0,''),(506,52,'丰台区',3,0,''),(507,52,'石景山区',3,0,''),(508,52,'房山区',3,0,''),(509,52,'门头沟区',3,0,''),(510,52,'通州区',3,0,''),(511,52,'顺义区',3,0,''),(512,52,'昌平区',3,0,''),(513,52,'怀柔区',3,0,''),(514,52,'平谷区',3,0,''),(515,52,'大兴区',3,0,''),(516,52,'密云县',3,0,''),(517,52,'延庆县',3,0,''),(518,53,'鼓楼区',3,0,''),(519,53,'台江区',3,0,''),(520,53,'仓山区',3,0,''),(521,53,'马尾区',3,0,''),(522,53,'晋安区',3,0,''),(523,53,'福清市',3,0,''),(524,53,'长乐市',3,0,''),(525,53,'闽侯县',3,0,''),(526,53,'连江县',3,0,''),(527,53,'罗源县',3,0,''),(528,53,'闽清县',3,0,''),(529,53,'永泰县',3,0,''),(530,53,'平潭县',3,0,''),(531,54,'新罗区',3,0,''),(532,54,'漳平市',3,0,''),(533,54,'长汀县',3,0,''),(534,54,'永定县',3,0,''),(535,54,'上杭县',3,0,''),(536,54,'武平县',3,0,''),(537,54,'连城县',3,0,''),(538,55,'延平区',3,0,''),(539,55,'邵武市',3,0,''),(540,55,'武夷山市',3,0,''),(541,55,'建瓯市',3,0,''),(542,55,'建阳市',3,0,''),(543,55,'顺昌县',3,0,''),(544,55,'浦城县',3,0,''),(545,55,'光泽县',3,0,''),(546,55,'松溪县',3,0,''),(547,55,'政和县',3,0,''),(548,56,'蕉城区',3,0,''),(549,56,'福安市',3,0,''),(550,56,'福鼎市',3,0,''),(551,56,'霞浦县',3,0,''),(552,56,'古田县',3,0,''),(553,56,'屏南县',3,0,''),(554,56,'寿宁县',3,0,''),(555,56,'周宁县',3,0,''),(556,56,'柘荣县',3,0,''),(557,57,'城厢区',3,0,''),(558,57,'涵江区',3,0,''),(559,57,'荔城区',3,0,''),(560,57,'秀屿区',3,0,''),(561,57,'仙游县',3,0,''),(562,58,'鲤城区',3,0,''),(563,58,'丰泽区',3,0,''),(564,58,'洛江区',3,0,''),(565,58,'清濛开发区',3,0,''),(566,58,'泉港区',3,0,''),(567,58,'石狮市',3,0,''),(568,58,'晋江市',3,0,''),(569,58,'南安市',3,0,''),(570,58,'惠安县',3,0,''),(571,58,'安溪县',3,0,''),(572,58,'永春县',3,0,''),(573,58,'德化县',3,0,''),(574,58,'金门县',3,0,''),(575,59,'梅列区',3,0,''),(576,59,'三元区',3,0,''),(577,59,'永安市',3,0,''),(578,59,'明溪县',3,0,''),(579,59,'清流县',3,0,''),(580,59,'宁化县',3,0,''),(581,59,'大田县',3,0,''),(582,59,'尤溪县',3,0,''),(583,59,'沙县',3,0,''),(584,59,'将乐县',3,0,''),(585,59,'泰宁县',3,0,''),(586,59,'建宁县',3,0,''),(587,60,'思明区',3,0,''),(588,60,'海沧区',3,0,''),(589,60,'湖里区',3,0,''),(590,60,'集美区',3,0,''),(591,60,'同安区',3,0,''),(592,60,'翔安区',3,0,''),(593,61,'芗城区',3,0,''),(594,61,'龙文区',3,0,''),(595,61,'龙海市',3,0,''),(596,61,'云霄县',3,0,''),(597,61,'漳浦县',3,0,''),(598,61,'诏安县',3,0,''),(599,61,'长泰县',3,0,''),(600,61,'东山县',3,0,''),(601,61,'南靖县',3,0,''),(602,61,'平和县',3,0,''),(603,61,'华安县',3,0,''),(604,62,'皋兰县',3,0,''),(605,62,'城关区',3,0,''),(606,62,'七里河区',3,0,''),(607,62,'西固区',3,0,''),(608,62,'安宁区',3,0,''),(609,62,'红古区',3,0,''),(610,62,'永登县',3,0,''),(611,62,'榆中县',3,0,''),(612,63,'白银区',3,0,''),(613,63,'平川区',3,0,''),(614,63,'会宁县',3,0,''),(615,63,'景泰县',3,0,''),(616,63,'靖远县',3,0,''),(617,64,'临洮县',3,0,''),(618,64,'陇西县',3,0,''),(619,64,'通渭县',3,0,''),(620,64,'渭源县',3,0,''),(621,64,'漳县',3,0,''),(622,64,'岷县',3,0,''),(623,64,'安定区',3,0,''),(624,64,'安定区',3,0,''),(625,65,'合作市',3,0,''),(626,65,'临潭县',3,0,''),(627,65,'卓尼县',3,0,''),(628,65,'舟曲县',3,0,''),(629,65,'迭部县',3,0,''),(630,65,'玛曲县',3,0,''),(631,65,'碌曲县',3,0,''),(632,65,'夏河县',3,0,''),(633,66,'嘉峪关市',3,0,''),(634,67,'金川区',3,0,''),(635,67,'永昌县',3,0,''),(636,68,'肃州区',3,0,''),(637,68,'玉门市',3,0,''),(638,68,'敦煌市',3,0,''),(639,68,'金塔县',3,0,''),(640,68,'瓜州县',3,0,''),(641,68,'肃北',3,0,''),(642,68,'阿克塞',3,0,''),(643,69,'临夏市',3,0,''),(644,69,'临夏县',3,0,''),(645,69,'康乐县',3,0,''),(646,69,'永靖县',3,0,''),(647,69,'广河县',3,0,''),(648,69,'和政县',3,0,''),(649,69,'东乡族自治县',3,0,''),(650,69,'积石山',3,0,''),(651,70,'成县',3,0,''),(652,70,'徽县',3,0,''),(653,70,'康县',3,0,''),(654,70,'礼县',3,0,''),(655,70,'两当县',3,0,''),(656,70,'文县',3,0,''),(657,70,'西和县',3,0,''),(658,70,'宕昌县',3,0,''),(659,70,'武都区',3,0,''),(660,71,'崇信县',3,0,''),(661,71,'华亭县',3,0,''),(662,71,'静宁县',3,0,''),(663,71,'灵台县',3,0,''),(664,71,'崆峒区',3,0,''),(665,71,'庄浪县',3,0,''),(666,71,'泾川县',3,0,''),(667,72,'合水县',3,0,''),(668,72,'华池县',3,0,''),(669,72,'环县',3,0,''),(670,72,'宁县',3,0,''),(671,72,'庆城县',3,0,''),(672,72,'西峰区',3,0,''),(673,72,'镇原县',3,0,''),(674,72,'正宁县',3,0,''),(675,73,'甘谷县',3,0,''),(676,73,'秦安县',3,0,''),(677,73,'清水县',3,0,''),(678,73,'秦州区',3,0,''),(679,73,'麦积区',3,0,''),(680,73,'武山县',3,0,''),(681,73,'张家川',3,0,''),(682,74,'古浪县',3,0,''),(683,74,'民勤县',3,0,''),(684,74,'天祝',3,0,''),(685,74,'凉州区',3,0,''),(686,75,'高台县',3,0,''),(687,75,'临泽县',3,0,''),(688,75,'民乐县',3,0,''),(689,75,'山丹县',3,0,''),(690,75,'肃南',3,0,''),(691,75,'甘州区',3,0,''),(692,76,'从化市',3,0,''),(693,76,'天河区',3,0,''),(694,76,'东山区',3,0,''),(695,76,'白云区',3,0,''),(696,76,'海珠区',3,0,''),(697,76,'荔湾区',3,0,''),(698,76,'越秀区',3,0,''),(699,76,'黄埔区',3,0,''),(700,76,'番禺区',3,0,''),(701,76,'花都区',3,0,''),(702,76,'增城区',3,0,''),(703,76,'从化区',3,0,''),(704,76,'市郊',3,0,''),(705,77,'福田区',3,0,''),(706,77,'罗湖区',3,0,''),(707,77,'南山区',3,0,''),(708,77,'宝安区',3,0,''),(709,77,'龙岗区',3,0,''),(710,77,'盐田区',3,0,''),(711,78,'湘桥区',3,0,''),(712,78,'潮安县',3,0,''),(713,78,'饶平县',3,0,''),(714,79,'南城区',3,0,''),(715,79,'东城区',3,0,''),(716,79,'万江区',3,0,''),(717,79,'莞城区',3,0,''),(718,79,'石龙镇',3,0,''),(719,79,'虎门镇',3,0,''),(720,79,'麻涌镇',3,0,''),(721,79,'道滘镇',3,0,''),(722,79,'石碣镇',3,0,''),(723,79,'沙田镇',3,0,''),(724,79,'望牛墩镇',3,0,''),(725,79,'洪梅镇',3,0,''),(726,79,'茶山镇',3,0,''),(727,79,'寮步镇',3,0,''),(728,79,'大岭山镇',3,0,''),(729,79,'大朗镇',3,0,''),(730,79,'黄江镇',3,0,''),(731,79,'樟木头',3,0,''),(732,79,'凤岗镇',3,0,''),(733,79,'塘厦镇',3,0,''),(734,79,'谢岗镇',3,0,''),(735,79,'厚街镇',3,0,''),(736,79,'清溪镇',3,0,''),(737,79,'常平镇',3,0,''),(738,79,'桥头镇',3,0,''),(739,79,'横沥镇',3,0,''),(740,79,'东坑镇',3,0,''),(741,79,'企石镇',3,0,''),(742,79,'石排镇',3,0,''),(743,79,'长安镇',3,0,''),(744,79,'中堂镇',3,0,''),(745,79,'高埗镇',3,0,''),(746,80,'禅城区',3,0,''),(747,80,'南海区',3,0,''),(748,80,'顺德区',3,0,''),(749,80,'三水区',3,0,''),(750,80,'高明区',3,0,''),(751,81,'东源县',3,0,''),(752,81,'和平县',3,0,''),(753,81,'源城区',3,0,''),(754,81,'连平县',3,0,''),(755,81,'龙川县',3,0,''),(756,81,'紫金县',3,0,''),(757,82,'惠阳区',3,0,''),(758,82,'惠城区',3,0,''),(759,82,'大亚湾',3,0,''),(760,82,'博罗县',3,0,''),(761,82,'惠东县',3,0,''),(762,82,'龙门县',3,0,''),(763,83,'江海区',3,0,''),(764,83,'蓬江区',3,0,''),(765,83,'新会区',3,0,''),(766,83,'台山市',3,0,''),(767,83,'开平市',3,0,''),(768,83,'鹤山市',3,0,''),(769,83,'恩平市',3,0,''),(770,84,'榕城区',3,0,''),(771,84,'普宁市',3,0,''),(772,84,'揭东县',3,0,''),(773,84,'揭西县',3,0,''),(774,84,'惠来县',3,0,''),(775,85,'茂南区',3,0,''),(776,85,'茂港区',3,0,''),(777,85,'高州市',3,0,''),(778,85,'化州市',3,0,''),(779,85,'信宜市',3,0,''),(780,85,'电白县',3,0,''),(781,86,'梅县',3,0,''),(782,86,'梅江区',3,0,''),(783,86,'兴宁市',3,0,''),(784,86,'大埔县',3,0,''),(785,86,'丰顺县',3,0,''),(786,86,'五华县',3,0,''),(787,86,'平远县',3,0,''),(788,86,'蕉岭县',3,0,''),(789,87,'清城区',3,0,''),(790,87,'英德市',3,0,''),(791,87,'连州市',3,0,''),(792,87,'佛冈县',3,0,''),(793,87,'阳山县',3,0,''),(794,87,'清新县',3,0,''),(795,87,'连山',3,0,''),(796,87,'连南',3,0,''),(797,88,'南澳县',3,0,''),(798,88,'潮阳区',3,0,''),(799,88,'澄海区',3,0,''),(800,88,'龙湖区',3,0,''),(801,88,'金平区',3,0,''),(802,88,'濠江区',3,0,''),(803,88,'潮南区',3,0,''),(804,89,'城区',3,0,''),(805,89,'陆丰市',3,0,''),(806,89,'海丰县',3,0,''),(807,89,'陆河县',3,0,''),(808,90,'曲江县',3,0,''),(809,90,'浈江区',3,0,''),(810,90,'武江区',3,0,''),(811,90,'曲江区',3,0,''),(812,90,'乐昌市',3,0,''),(813,90,'南雄市',3,0,''),(814,90,'始兴县',3,0,''),(815,90,'仁化县',3,0,''),(816,90,'翁源县',3,0,''),(817,90,'新丰县',3,0,''),(818,90,'乳源',3,0,''),(819,91,'江城区',3,0,''),(820,91,'阳春市',3,0,''),(821,91,'阳西县',3,0,''),(822,91,'阳东县',3,0,''),(823,92,'云城区',3,0,''),(824,92,'罗定市',3,0,''),(825,92,'新兴县',3,0,''),(826,92,'郁南县',3,0,''),(827,92,'云安县',3,0,''),(828,93,'赤坎区',3,0,''),(829,93,'霞山区',3,0,''),(830,93,'坡头区',3,0,''),(831,93,'麻章区',3,0,''),(832,93,'廉江市',3,0,''),(833,93,'雷州市',3,0,''),(834,93,'吴川市',3,0,''),(835,93,'遂溪县',3,0,''),(836,93,'徐闻县',3,0,''),(837,94,'肇庆市',3,0,''),(838,94,'高要市',3,0,''),(839,94,'四会市',3,0,''),(840,94,'广宁县',3,0,''),(841,94,'怀集县',3,0,''),(842,94,'封开县',3,0,''),(843,94,'德庆县',3,0,''),(844,95,'石岐街道',3,0,''),(845,95,'东区街道',3,0,''),(846,95,'西区街道',3,0,''),(847,95,'环城街道',3,0,''),(848,95,'中山港街道',3,0,''),(849,95,'五桂山街道',3,0,''),(850,96,'香洲区',3,0,''),(851,96,'斗门区',3,0,''),(852,96,'金湾区',3,0,''),(853,97,'邕宁区',3,0,''),(854,97,'青秀区',3,0,''),(855,97,'兴宁区',3,0,''),(856,97,'良庆区',3,0,''),(857,97,'西乡塘区',3,0,''),(858,97,'江南区',3,0,''),(859,97,'武鸣县',3,0,''),(860,97,'隆安县',3,0,''),(861,97,'马山县',3,0,''),(862,97,'上林县',3,0,''),(863,97,'宾阳县',3,0,''),(864,97,'横县',3,0,''),(865,98,'秀峰区',3,0,''),(866,98,'叠彩区',3,0,''),(867,98,'象山区',3,0,''),(868,98,'七星区',3,0,''),(869,98,'雁山区',3,0,''),(870,98,'阳朔县',3,0,''),(871,98,'临桂县',3,0,''),(872,98,'灵川县',3,0,''),(873,98,'全州县',3,0,''),(874,98,'平乐县',3,0,''),(875,98,'兴安县',3,0,''),(876,98,'灌阳县',3,0,''),(877,98,'荔浦县',3,0,''),(878,98,'资源县',3,0,''),(879,98,'永福县',3,0,''),(880,98,'龙胜',3,0,''),(881,98,'恭城',3,0,''),(882,99,'右江区',3,0,''),(883,99,'凌云县',3,0,''),(884,99,'平果县',3,0,''),(885,99,'西林县',3,0,''),(886,99,'乐业县',3,0,''),(887,99,'德保县',3,0,''),(888,99,'田林县',3,0,''),(889,99,'田阳县',3,0,''),(890,99,'靖西县',3,0,''),(891,99,'田东县',3,0,''),(892,99,'那坡县',3,0,''),(893,99,'隆林',3,0,''),(894,100,'海城区',3,0,''),(895,100,'银海区',3,0,''),(896,100,'铁山港区',3,0,''),(897,100,'合浦县',3,0,''),(898,101,'江州区',3,0,''),(899,101,'凭祥市',3,0,''),(900,101,'宁明县',3,0,''),(901,101,'扶绥县',3,0,''),(902,101,'龙州县',3,0,''),(903,101,'大新县',3,0,''),(904,101,'天等县',3,0,''),(905,102,'港口区',3,0,''),(906,102,'防城区',3,0,''),(907,102,'东兴市',3,0,''),(908,102,'上思县',3,0,''),(909,103,'港北区',3,0,''),(910,103,'港南区',3,0,''),(911,103,'覃塘区',3,0,''),(912,103,'桂平市',3,0,''),(913,103,'平南县',3,0,''),(914,104,'金城江区',3,0,''),(915,104,'宜州市',3,0,''),(916,104,'天峨县',3,0,''),(917,104,'凤山县',3,0,''),(918,104,'南丹县',3,0,''),(919,104,'东兰县',3,0,''),(920,104,'都安',3,0,''),(921,104,'罗城',3,0,''),(922,104,'巴马',3,0,''),(923,104,'环江',3,0,''),(924,104,'大化',3,0,''),(925,105,'八步区',3,0,''),(926,105,'钟山县',3,0,''),(927,105,'昭平县',3,0,''),(928,105,'富川',3,0,''),(929,106,'兴宾区',3,0,''),(930,106,'合山市',3,0,''),(931,106,'象州县',3,0,''),(932,106,'武宣县',3,0,''),(933,106,'忻城县',3,0,''),(934,106,'金秀',3,0,''),(935,107,'城中区',3,0,''),(936,107,'鱼峰区',3,0,''),(937,107,'柳北区',3,0,''),(938,107,'柳南区',3,0,''),(939,107,'柳江县',3,0,''),(940,107,'柳城县',3,0,''),(941,107,'鹿寨县',3,0,''),(942,107,'融安县',3,0,''),(943,107,'融水',3,0,''),(944,107,'三江',3,0,''),(945,108,'钦南区',3,0,''),(946,108,'钦北区',3,0,''),(947,108,'灵山县',3,0,''),(948,108,'浦北县',3,0,''),(949,109,'万秀区',3,0,''),(950,109,'蝶山区',3,0,''),(951,109,'长洲区',3,0,''),(952,109,'岑溪市',3,0,''),(953,109,'苍梧县',3,0,''),(954,109,'藤县',3,0,''),(955,109,'蒙山县',3,0,''),(956,110,'玉州区',3,0,''),(957,110,'北流市',3,0,''),(958,110,'容县',3,0,''),(959,110,'陆川县',3,0,''),(960,110,'博白县',3,0,''),(961,110,'兴业县',3,0,''),(962,111,'南明区',3,0,''),(963,111,'云岩区',3,0,''),(964,111,'花溪区',3,0,''),(965,111,'乌当区',3,0,''),(966,111,'白云区',3,0,''),(967,111,'小河区',3,0,''),(968,111,'金阳新区',3,0,''),(969,111,'新天园区',3,0,''),(970,111,'清镇市',3,0,''),(971,111,'开阳县',3,0,''),(972,111,'修文县',3,0,''),(973,111,'息烽县',3,0,''),(974,112,'西秀区',3,0,''),(975,112,'关岭',3,0,''),(976,112,'镇宁',3,0,''),(977,112,'紫云',3,0,''),(978,112,'平坝县',3,0,''),(979,112,'普定县',3,0,''),(980,113,'毕节市',3,0,''),(981,113,'大方县',3,0,''),(982,113,'黔西县',3,0,''),(983,113,'金沙县',3,0,''),(984,113,'织金县',3,0,''),(985,113,'纳雍县',3,0,''),(986,113,'赫章县',3,0,''),(987,113,'威宁',3,0,''),(988,114,'钟山区',3,0,''),(989,114,'六枝特区',3,0,''),(990,114,'水城县',3,0,''),(991,114,'盘县',3,0,''),(992,115,'凯里市',3,0,''),(993,115,'黄平县',3,0,''),(994,115,'施秉县',3,0,''),(995,115,'三穗县',3,0,''),(996,115,'镇远县',3,0,''),(997,115,'岑巩县',3,0,''),(998,115,'天柱县',3,0,''),(999,115,'锦屏县',3,0,''),(1000,115,'剑河县',3,0,''),(1001,115,'台江县',3,0,''),(1002,115,'黎平县',3,0,''),(1003,115,'榕江县',3,0,''),(1004,115,'从江县',3,0,''),(1005,115,'雷山县',3,0,''),(1006,115,'麻江县',3,0,''),(1007,115,'丹寨县',3,0,''),(1008,116,'都匀市',3,0,''),(1009,116,'福泉市',3,0,''),(1010,116,'荔波县',3,0,''),(1011,116,'贵定县',3,0,''),(1012,116,'瓮安县',3,0,''),(1013,116,'独山县',3,0,''),(1014,116,'平塘县',3,0,''),(1015,116,'罗甸县',3,0,''),(1016,116,'长顺县',3,0,''),(1017,116,'龙里县',3,0,''),(1018,116,'惠水县',3,0,''),(1019,116,'三都',3,0,''),(1020,117,'兴义市',3,0,''),(1021,117,'兴仁县',3,0,''),(1022,117,'普安县',3,0,''),(1023,117,'晴隆县',3,0,''),(1024,117,'贞丰县',3,0,''),(1025,117,'望谟县',3,0,''),(1026,117,'册亨县',3,0,''),(1027,117,'安龙县',3,0,''),(1028,118,'铜仁市',3,0,''),(1029,118,'江口县',3,0,''),(1030,118,'石阡县',3,0,''),(1031,118,'思南县',3,0,''),(1032,118,'德江县',3,0,''),(1033,118,'玉屏',3,0,''),(1034,118,'印江',3,0,''),(1035,118,'沿河',3,0,''),(1036,118,'松桃',3,0,''),(1037,118,'万山特区',3,0,''),(1038,119,'红花岗区',3,0,''),(1039,119,'务川县',3,0,''),(1040,119,'道真县',3,0,''),(1041,119,'汇川区',3,0,''),(1042,119,'赤水市',3,0,''),(1043,119,'仁怀市',3,0,''),(1044,119,'遵义县',3,0,''),(1045,119,'桐梓县',3,0,''),(1046,119,'绥阳县',3,0,''),(1047,119,'正安县',3,0,''),(1048,119,'凤冈县',3,0,''),(1049,119,'湄潭县',3,0,''),(1050,119,'余庆县',3,0,''),(1051,119,'习水县',3,0,''),(1052,119,'道真',3,0,''),(1053,119,'务川',3,0,''),(1054,120,'秀英区',3,0,''),(1055,120,'龙华区',3,0,''),(1056,120,'琼山区',3,0,''),(1057,120,'美兰区',3,0,''),(1058,137,'市区',3,0,''),(1059,137,'洋浦开发区',3,0,''),(1060,137,'那大镇',3,0,''),(1061,137,'王五镇',3,0,''),(1062,137,'雅星镇',3,0,''),(1063,137,'大成镇',3,0,''),(1064,137,'中和镇',3,0,''),(1065,137,'峨蔓镇',3,0,''),(1066,137,'南丰镇',3,0,''),(1067,137,'白马井镇',3,0,''),(1068,137,'兰洋镇',3,0,''),(1069,137,'和庆镇',3,0,''),(1070,137,'海头镇',3,0,''),(1071,137,'排浦镇',3,0,''),(1072,137,'东成镇',3,0,''),(1073,137,'光村镇',3,0,''),(1074,137,'木棠镇',3,0,''),(1075,137,'新州镇',3,0,''),(1076,137,'三都镇',3,0,''),(1077,137,'其他',3,0,''),(1078,138,'长安区',3,0,''),(1079,138,'桥东区',3,0,''),(1080,138,'桥西区',3,0,''),(1081,138,'新华区',3,0,''),(1082,138,'裕华区',3,0,''),(1083,138,'井陉矿区',3,0,''),(1084,138,'高新区',3,0,''),(1085,138,'辛集市',3,0,''),(1086,138,'藁城市',3,0,''),(1087,138,'晋州市',3,0,''),(1088,138,'新乐市',3,0,''),(1089,138,'鹿泉市',3,0,''),(1090,138,'井陉县',3,0,''),(1091,138,'正定县',3,0,''),(1092,138,'栾城县',3,0,''),(1093,138,'行唐县',3,0,''),(1094,138,'灵寿县',3,0,''),(1095,138,'高邑县',3,0,''),(1096,138,'深泽县',3,0,''),(1097,138,'赞皇县',3,0,''),(1098,138,'无极县',3,0,''),(1099,138,'平山县',3,0,''),(1100,138,'元氏县',3,0,''),(1101,138,'赵县',3,0,''),(1102,139,'新市区',3,0,''),(1103,139,'南市区',3,0,''),(1104,139,'北市区',3,0,''),(1105,139,'涿州市',3,0,''),(1106,139,'定州市',3,0,''),(1107,139,'安国市',3,0,''),(1108,139,'高碑店市',3,0,''),(1109,139,'满城县',3,0,''),(1110,139,'清苑县',3,0,''),(1111,139,'涞水县',3,0,''),(1112,139,'阜平县',3,0,''),(1113,139,'徐水县',3,0,''),(1114,139,'定兴县',3,0,''),(1115,139,'唐县',3,0,''),(1116,139,'高阳县',3,0,''),(1117,139,'容城县',3,0,''),(1118,139,'涞源县',3,0,''),(1119,139,'望都县',3,0,''),(1120,139,'安新县',3,0,''),(1121,139,'易县',3,0,''),(1122,139,'曲阳县',3,0,''),(1123,139,'蠡县',3,0,''),(1124,139,'顺平县',3,0,''),(1125,139,'博野县',3,0,''),(1126,139,'雄县',3,0,''),(1127,140,'运河区',3,0,''),(1128,140,'新华区',3,0,''),(1129,140,'泊头市',3,0,''),(1130,140,'任丘市',3,0,''),(1131,140,'黄骅市',3,0,''),(1132,140,'河间市',3,0,''),(1133,140,'沧县',3,0,''),(1134,140,'青县',3,0,''),(1135,140,'东光县',3,0,''),(1136,140,'海兴县',3,0,''),(1137,140,'盐山县',3,0,''),(1138,140,'肃宁县',3,0,''),(1139,140,'南皮县',3,0,''),(1140,140,'吴桥县',3,0,''),(1141,140,'献县',3,0,''),(1142,140,'孟村',3,0,''),(1143,141,'双桥区',3,0,''),(1144,141,'双滦区',3,0,''),(1145,141,'鹰手营子矿区',3,0,''),(1146,141,'承德县',3,0,''),(1147,141,'兴隆县',3,0,''),(1148,141,'平泉县',3,0,''),(1149,141,'滦平县',3,0,''),(1150,141,'隆化县',3,0,''),(1151,141,'丰宁',3,0,''),(1152,141,'宽城',3,0,''),(1153,141,'围场',3,0,''),(1154,142,'从台区',3,0,''),(1155,142,'复兴区',3,0,''),(1156,142,'邯山区',3,0,''),(1157,142,'峰峰矿区',3,0,''),(1158,142,'武安市',3,0,''),(1159,142,'邯郸县',3,0,''),(1160,142,'临漳县',3,0,''),(1161,142,'成安县',3,0,''),(1162,142,'大名县',3,0,''),(1163,142,'涉县',3,0,''),(1164,142,'磁县',3,0,''),(1165,142,'肥乡县',3,0,''),(1166,142,'永年县',3,0,''),(1167,142,'邱县',3,0,''),(1168,142,'鸡泽县',3,0,''),(1169,142,'广平县',3,0,''),(1170,142,'馆陶县',3,0,''),(1171,142,'魏县',3,0,''),(1172,142,'曲周县',3,0,''),(1173,143,'桃城区',3,0,''),(1174,143,'冀州市',3,0,''),(1175,143,'深州市',3,0,''),(1176,143,'枣强县',3,0,''),(1177,143,'武邑县',3,0,''),(1178,143,'武强县',3,0,''),(1179,143,'饶阳县',3,0,''),(1180,143,'安平县',3,0,''),(1181,143,'故城县',3,0,''),(1182,143,'景县',3,0,''),(1183,143,'阜城县',3,0,''),(1184,144,'安次区',3,0,''),(1185,144,'广阳区',3,0,''),(1186,144,'霸州市',3,0,''),(1187,144,'三河市',3,0,''),(1188,144,'固安县',3,0,''),(1189,144,'永清县',3,0,''),(1190,144,'香河县',3,0,''),(1191,144,'大城县',3,0,''),(1192,144,'文安县',3,0,''),(1193,144,'大厂',3,0,''),(1194,145,'海港区',3,0,''),(1195,145,'山海关区',3,0,''),(1196,145,'北戴河区',3,0,''),(1197,145,'昌黎县',3,0,''),(1198,145,'抚宁县',3,0,''),(1199,145,'卢龙县',3,0,''),(1200,145,'青龙',3,0,''),(1201,146,'路北区',3,0,''),(1202,146,'路南区',3,0,''),(1203,146,'古冶区',3,0,''),(1204,146,'开平区',3,0,''),(1205,146,'丰南区',3,0,''),(1206,146,'丰润区',3,0,''),(1207,146,'遵化市',3,0,''),(1208,146,'迁安市',3,0,''),(1209,146,'滦县',3,0,''),(1210,146,'滦南县',3,0,''),(1211,146,'乐亭县',3,0,''),(1212,146,'迁西县',3,0,''),(1213,146,'玉田县',3,0,''),(1214,146,'唐海县',3,0,''),(1215,147,'桥东区',3,0,''),(1216,147,'桥西区',3,0,''),(1217,147,'南宫市',3,0,''),(1218,147,'沙河市',3,0,''),(1219,147,'邢台县',3,0,''),(1220,147,'临城县',3,0,''),(1221,147,'内丘县',3,0,''),(1222,147,'柏乡县',3,0,''),(1223,147,'隆尧县',3,0,''),(1224,147,'任县',3,0,''),(1225,147,'南和县',3,0,''),(1226,147,'宁晋县',3,0,''),(1227,147,'巨鹿县',3,0,''),(1228,147,'新河县',3,0,''),(1229,147,'广宗县',3,0,''),(1230,147,'平乡县',3,0,''),(1231,147,'威县',3,0,''),(1232,147,'清河县',3,0,''),(1233,147,'临西县',3,0,''),(1234,148,'桥西区',3,0,''),(1235,148,'桥东区',3,0,''),(1236,148,'宣化区',3,0,''),(1237,148,'下花园区',3,0,''),(1238,148,'宣化县',3,0,''),(1239,148,'张北县',3,0,''),(1240,148,'康保县',3,0,''),(1241,148,'沽源县',3,0,''),(1242,148,'尚义县',3,0,''),(1243,148,'蔚县',3,0,''),(1244,148,'阳原县',3,0,''),(1245,148,'怀安县',3,0,''),(1246,148,'万全县',3,0,''),(1247,148,'怀来县',3,0,''),(1248,148,'涿鹿县',3,0,''),(1249,148,'赤城县',3,0,''),(1250,148,'崇礼县',3,0,''),(1251,149,'金水区',3,0,''),(1252,149,'邙山区',3,0,''),(1253,149,'二七区',3,0,''),(1254,149,'管城区',3,0,''),(1255,149,'中原区',3,0,''),(1256,149,'上街区',3,0,''),(1257,149,'惠济区',3,0,''),(1258,149,'郑东新区',3,0,''),(1259,149,'经济技术开发区',3,0,''),(1260,149,'高新开发区',3,0,''),(1261,149,'出口加工区',3,0,''),(1262,149,'巩义市',3,0,''),(1263,149,'荥阳市',3,0,''),(1264,149,'新密市',3,0,''),(1265,149,'新郑市',3,0,''),(1266,149,'登封市',3,0,''),(1267,149,'中牟县',3,0,''),(1268,150,'西工区',3,0,''),(1269,150,'老城区',3,0,''),(1270,150,'涧西区',3,0,''),(1271,150,'瀍河回族区',3,0,''),(1272,150,'洛龙区',3,0,''),(1273,150,'吉利区',3,0,''),(1274,150,'偃师市',3,0,''),(1275,150,'孟津县',3,0,''),(1276,150,'新安县',3,0,''),(1277,150,'栾川县',3,0,''),(1278,150,'嵩县',3,0,''),(1279,150,'汝阳县',3,0,''),(1280,150,'宜阳县',3,0,''),(1281,150,'洛宁县',3,0,''),(1282,150,'伊川县',3,0,''),(1283,151,'鼓楼区',3,0,''),(1284,151,'龙亭区',3,0,''),(1285,151,'顺河回族区',3,0,''),(1286,151,'金明区',3,0,''),(1287,151,'禹王台区',3,0,''),(1288,151,'杞县',3,0,''),(1289,151,'通许县',3,0,''),(1290,151,'尉氏县',3,0,''),(1291,151,'开封县',3,0,''),(1292,151,'兰考县',3,0,''),(1293,152,'北关区',3,0,''),(1294,152,'文峰区',3,0,''),(1295,152,'殷都区',3,0,''),(1296,152,'龙安区',3,0,''),(1297,152,'林州市',3,0,''),(1298,152,'安阳县',3,0,''),(1299,152,'汤阴县',3,0,''),(1300,152,'滑县',3,0,''),(1301,152,'内黄县',3,0,''),(1302,153,'淇滨区',3,0,''),(1303,153,'山城区',3,0,''),(1304,153,'鹤山区',3,0,''),(1305,153,'浚县',3,0,''),(1306,153,'淇县',3,0,''),(1307,154,'济源市',3,0,''),(1308,155,'解放区',3,0,''),(1309,155,'中站区',3,0,''),(1310,155,'马村区',3,0,''),(1311,155,'山阳区',3,0,''),(1312,155,'沁阳市',3,0,''),(1313,155,'孟州市',3,0,''),(1314,155,'修武县',3,0,''),(1315,155,'博爱县',3,0,''),(1316,155,'武陟县',3,0,''),(1317,155,'温县',3,0,''),(1318,156,'卧龙区',3,0,''),(1319,156,'宛城区',3,0,''),(1320,156,'邓州市',3,0,''),(1321,156,'南召县',3,0,''),(1322,156,'方城县',3,0,''),(1323,156,'西峡县',3,0,''),(1324,156,'镇平县',3,0,''),(1325,156,'内乡县',3,0,''),(1326,156,'淅川县',3,0,''),(1327,156,'社旗县',3,0,''),(1328,156,'唐河县',3,0,''),(1329,156,'新野县',3,0,''),(1330,156,'桐柏县',3,0,''),(1331,157,'新华区',3,0,''),(1332,157,'卫东区',3,0,''),(1333,157,'湛河区',3,0,''),(1334,157,'石龙区',3,0,''),(1335,157,'舞钢市',3,0,''),(1336,157,'汝州市',3,0,''),(1337,157,'宝丰县',3,0,''),(1338,157,'叶县',3,0,''),(1339,157,'鲁山县',3,0,''),(1340,157,'郏县',3,0,''),(1341,158,'湖滨区',3,0,''),(1342,158,'义马市',3,0,''),(1343,158,'灵宝市',3,0,''),(1344,158,'渑池县',3,0,''),(1345,158,'陕县',3,0,''),(1346,158,'卢氏县',3,0,''),(1347,159,'梁园区',3,0,''),(1348,159,'睢阳区',3,0,''),(1349,159,'永城市',3,0,''),(1350,159,'民权县',3,0,''),(1351,159,'睢县',3,0,''),(1352,159,'宁陵县',3,0,''),(1353,159,'虞城县',3,0,''),(1354,159,'柘城县',3,0,''),(1355,159,'夏邑县',3,0,''),(1356,160,'卫滨区',3,0,''),(1357,160,'红旗区',3,0,''),(1358,160,'凤泉区',3,0,''),(1359,160,'牧野区',3,0,''),(1360,160,'卫辉市',3,0,''),(1361,160,'辉县市',3,0,''),(1362,160,'新乡县',3,0,''),(1363,160,'获嘉县',3,0,''),(1364,160,'原阳县',3,0,''),(1365,160,'延津县',3,0,''),(1366,160,'封丘县',3,0,''),(1367,160,'长垣县',3,0,''),(1368,161,'浉河区',3,0,''),(1369,161,'平桥区',3,0,''),(1370,161,'罗山县',3,0,''),(1371,161,'光山县',3,0,''),(1372,161,'新县',3,0,''),(1373,161,'商城县',3,0,''),(1374,161,'固始县',3,0,''),(1375,161,'潢川县',3,0,''),(1376,161,'淮滨县',3,0,''),(1377,161,'息县',3,0,''),(1378,162,'魏都区',3,0,''),(1379,162,'禹州市',3,0,''),(1380,162,'长葛市',3,0,''),(1381,162,'许昌县',3,0,''),(1382,162,'鄢陵县',3,0,''),(1383,162,'襄城县',3,0,''),(1384,163,'川汇区',3,0,''),(1385,163,'项城市',3,0,''),(1386,163,'扶沟县',3,0,''),(1387,163,'西华县',3,0,''),(1388,163,'商水县',3,0,''),(1389,163,'沈丘县',3,0,''),(1390,163,'郸城县',3,0,''),(1391,163,'淮阳县',3,0,''),(1392,163,'太康县',3,0,''),(1393,163,'鹿邑县',3,0,''),(1394,164,'驿城区',3,0,''),(1395,164,'西平县',3,0,''),(1396,164,'上蔡县',3,0,''),(1397,164,'平舆县',3,0,''),(1398,164,'正阳县',3,0,''),(1399,164,'确山县',3,0,''),(1400,164,'泌阳县',3,0,''),(1401,164,'汝南县',3,0,''),(1402,164,'遂平县',3,0,''),(1403,164,'新蔡县',3,0,''),(1404,165,'郾城区',3,0,''),(1405,165,'源汇区',3,0,''),(1406,165,'召陵区',3,0,''),(1407,165,'舞阳县',3,0,''),(1408,165,'临颍县',3,0,''),(1409,166,'华龙区',3,0,''),(1410,166,'清丰县',3,0,''),(1411,166,'南乐县',3,0,''),(1412,166,'范县',3,0,''),(1413,166,'台前县',3,0,''),(1414,166,'濮阳县',3,0,''),(1415,167,'道里区',3,0,''),(1416,167,'南岗区',3,0,''),(1417,167,'动力区',3,0,''),(1418,167,'平房区',3,0,''),(1419,167,'香坊区',3,0,''),(1420,167,'太平区',3,0,''),(1421,167,'道外区',3,0,''),(1422,167,'阿城区',3,0,''),(1423,167,'呼兰区',3,0,''),(1424,167,'松北区',3,0,''),(1425,167,'尚志市',3,0,''),(1426,167,'双城市',3,0,''),(1427,167,'五常市',3,0,''),(1428,167,'方正县',3,0,''),(1429,167,'宾县',3,0,''),(1430,167,'依兰县',3,0,''),(1431,167,'巴彦县',3,0,''),(1432,167,'通河县',3,0,''),(1433,167,'木兰县',3,0,''),(1434,167,'延寿县',3,0,''),(1435,168,'萨尔图区',3,0,''),(1436,168,'红岗区',3,0,''),(1437,168,'龙凤区',3,0,''),(1438,168,'让胡路区',3,0,''),(1439,168,'大同区',3,0,''),(1440,168,'肇州县',3,0,''),(1441,168,'肇源县',3,0,''),(1442,168,'林甸县',3,0,''),(1443,168,'杜尔伯特',3,0,''),(1444,169,'呼玛县',3,0,''),(1445,169,'漠河县',3,0,''),(1446,169,'塔河县',3,0,''),(1447,170,'兴山区',3,0,''),(1448,170,'工农区',3,0,''),(1449,170,'南山区',3,0,''),(1450,170,'兴安区',3,0,''),(1451,170,'向阳区',3,0,''),(1452,170,'东山区',3,0,''),(1453,170,'萝北县',3,0,''),(1454,170,'绥滨县',3,0,''),(1455,171,'爱辉区',3,0,''),(1456,171,'五大连池市',3,0,''),(1457,171,'北安市',3,0,''),(1458,171,'嫩江县',3,0,''),(1459,171,'逊克县',3,0,''),(1460,171,'孙吴县',3,0,''),(1461,172,'鸡冠区',3,0,''),(1462,172,'恒山区',3,0,''),(1463,172,'城子河区',3,0,''),(1464,172,'滴道区',3,0,''),(1465,172,'梨树区',3,0,''),(1466,172,'虎林市',3,0,''),(1467,172,'密山市',3,0,''),(1468,172,'鸡东县',3,0,''),(1469,173,'前进区',3,0,''),(1470,173,'郊区',3,0,''),(1471,173,'向阳区',3,0,''),(1472,173,'东风区',3,0,''),(1473,173,'同江市',3,0,''),(1474,173,'富锦市',3,0,''),(1475,173,'桦南县',3,0,''),(1476,173,'桦川县',3,0,''),(1477,173,'汤原县',3,0,''),(1478,173,'抚远县',3,0,''),(1479,174,'爱民区',3,0,''),(1480,174,'东安区',3,0,''),(1481,174,'阳明区',3,0,''),(1482,174,'西安区',3,0,''),(1483,174,'绥芬河市',3,0,''),(1484,174,'海林市',3,0,''),(1485,174,'宁安市',3,0,''),(1486,174,'穆棱市',3,0,''),(1487,174,'东宁县',3,0,''),(1488,174,'林口县',3,0,''),(1489,175,'桃山区',3,0,''),(1490,175,'新兴区',3,0,''),(1491,175,'茄子河区',3,0,''),(1492,175,'勃利县',3,0,''),(1493,176,'龙沙区',3,0,''),(1494,176,'昂昂溪区',3,0,''),(1495,176,'铁峰区',3,0,''),(1496,176,'建华区',3,0,''),(1497,176,'富拉尔基区',3,0,''),(1498,176,'碾子山区',3,0,''),(1499,176,'梅里斯达斡尔区',3,0,''),(1500,176,'讷河市',3,0,''),(1501,176,'龙江县',3,0,''),(1502,176,'依安县',3,0,''),(1503,176,'泰来县',3,0,''),(1504,176,'甘南县',3,0,''),(1505,176,'富裕县',3,0,''),(1506,176,'克山县',3,0,''),(1507,176,'克东县',3,0,''),(1508,176,'拜泉县',3,0,''),(1509,177,'尖山区',3,0,''),(1510,177,'岭东区',3,0,''),(1511,177,'四方台区',3,0,''),(1512,177,'宝山区',3,0,''),(1513,177,'集贤县',3,0,''),(1514,177,'友谊县',3,0,''),(1515,177,'宝清县',3,0,''),(1516,177,'饶河县',3,0,''),(1517,178,'北林区',3,0,''),(1518,178,'安达市',3,0,''),(1519,178,'肇东市',3,0,''),(1520,178,'海伦市',3,0,''),(1521,178,'望奎县',3,0,''),(1522,178,'兰西县',3,0,''),(1523,178,'青冈县',3,0,''),(1524,178,'庆安县',3,0,''),(1525,178,'明水县',3,0,''),(1526,178,'绥棱县',3,0,''),(1527,179,'伊春区',3,0,''),(1528,179,'带岭区',3,0,''),(1529,179,'南岔区',3,0,''),(1530,179,'金山屯区',3,0,''),(1531,179,'西林区',3,0,''),(1532,179,'美溪区',3,0,''),(1533,179,'乌马河区',3,0,''),(1534,179,'翠峦区',3,0,''),(1535,179,'友好区',3,0,''),(1536,179,'上甘岭区',3,0,''),(1537,179,'五营区',3,0,''),(1538,179,'红星区',3,0,''),(1539,179,'新青区',3,0,''),(1540,179,'汤旺河区',3,0,''),(1541,179,'乌伊岭区',3,0,''),(1542,179,'铁力市',3,0,''),(1543,179,'嘉荫县',3,0,''),(1544,180,'江岸区',3,0,''),(1545,180,'武昌区',3,0,''),(1546,180,'江汉区',3,0,''),(1547,180,'硚口区',3,0,''),(1548,180,'汉阳区',3,0,''),(1549,180,'青山区',3,0,''),(1550,180,'洪山区',3,0,''),(1551,180,'东西湖区',3,0,''),(1552,180,'汉南区',3,0,''),(1553,180,'蔡甸区',3,0,''),(1554,180,'江夏区',3,0,''),(1555,180,'黄陂区',3,0,''),(1556,180,'新洲区',3,0,''),(1557,180,'经济开发区',3,0,''),(1558,181,'仙桃市',3,0,''),(1559,182,'鄂城区',3,0,''),(1560,182,'华容区',3,0,''),(1561,182,'梁子湖区',3,0,''),(1562,183,'黄州区',3,0,''),(1563,183,'麻城市',3,0,''),(1564,183,'武穴市',3,0,''),(1565,183,'团风县',3,0,''),(1566,183,'红安县',3,0,''),(1567,183,'罗田县',3,0,''),(1568,183,'英山县',3,0,''),(1569,183,'浠水县',3,0,''),(1570,183,'蕲春县',3,0,''),(1571,183,'黄梅县',3,0,''),(1572,184,'黄石港区',3,0,''),(1573,184,'西塞山区',3,0,''),(1574,184,'下陆区',3,0,''),(1575,184,'铁山区',3,0,''),(1576,184,'大冶市',3,0,''),(1577,184,'阳新县',3,0,''),(1578,185,'东宝区',3,0,''),(1579,185,'掇刀区',3,0,''),(1580,185,'钟祥市',3,0,''),(1581,185,'京山县',3,0,''),(1582,185,'沙洋县',3,0,''),(1583,186,'沙市区',3,0,''),(1584,186,'荆州区',3,0,''),(1585,186,'石首市',3,0,''),(1586,186,'洪湖市',3,0,''),(1587,186,'松滋市',3,0,''),(1588,186,'公安县',3,0,''),(1589,186,'监利县',3,0,''),(1590,186,'江陵县',3,0,''),(1591,187,'潜江市',3,0,''),(1592,188,'神农架林区',3,0,''),(1593,189,'张湾区',3,0,''),(1594,189,'茅箭区',3,0,''),(1595,189,'丹江口市',3,0,''),(1596,189,'郧县',3,0,''),(1597,189,'郧西县',3,0,''),(1598,189,'竹山县',3,0,''),(1599,189,'竹溪县',3,0,''),(1600,189,'房县',3,0,''),(1601,190,'曾都区',3,0,''),(1602,190,'广水市',3,0,''),(1603,191,'天门市',3,0,''),(1604,192,'咸安区',3,0,''),(1605,192,'赤壁市',3,0,''),(1606,192,'嘉鱼县',3,0,''),(1607,192,'通城县',3,0,''),(1608,192,'崇阳县',3,0,''),(1609,192,'通山县',3,0,''),(1610,193,'襄城区',3,0,''),(1611,193,'樊城区',3,0,''),(1612,193,'襄阳区',3,0,''),(1613,193,'老河口市',3,0,''),(1614,193,'枣阳市',3,0,''),(1615,193,'宜城市',3,0,''),(1616,193,'南漳县',3,0,''),(1617,193,'谷城县',3,0,''),(1618,193,'保康县',3,0,''),(1619,194,'孝南区',3,0,''),(1620,194,'应城市',3,0,''),(1621,194,'安陆市',3,0,''),(1622,194,'汉川市',3,0,''),(1623,194,'孝昌县',3,0,''),(1624,194,'大悟县',3,0,''),(1625,194,'云梦县',3,0,''),(1626,195,'长阳',3,0,''),(1627,195,'五峰',3,0,''),(1628,195,'西陵区',3,0,''),(1629,195,'伍家岗区',3,0,''),(1630,195,'点军区',3,0,''),(1631,195,'猇亭区',3,0,''),(1632,195,'夷陵区',3,0,''),(1633,195,'宜都市',3,0,''),(1634,195,'当阳市',3,0,''),(1635,195,'枝江市',3,0,''),(1636,195,'远安县',3,0,''),(1637,195,'兴山县',3,0,''),(1638,195,'秭归县',3,0,''),(1639,196,'恩施市',3,0,''),(1640,196,'利川市',3,0,''),(1641,196,'建始县',3,0,''),(1642,196,'巴东县',3,0,''),(1643,196,'宣恩县',3,0,''),(1644,196,'咸丰县',3,0,''),(1645,196,'来凤县',3,0,''),(1646,196,'鹤峰县',3,0,''),(1647,197,'岳麓区',3,0,''),(1648,197,'芙蓉区',3,0,''),(1649,197,'天心区',3,0,''),(1650,197,'开福区',3,0,''),(1651,197,'雨花区',3,0,''),(1652,197,'开发区',3,0,''),(1653,197,'浏阳市',3,0,''),(1654,197,'长沙县',3,0,''),(1655,197,'望城县',3,0,''),(1656,197,'宁乡县',3,0,''),(1657,198,'永定区',3,0,''),(1658,198,'武陵源区',3,0,''),(1659,198,'慈利县',3,0,''),(1660,198,'桑植县',3,0,''),(1661,199,'武陵区',3,0,''),(1662,199,'鼎城区',3,0,''),(1663,199,'津市市',3,0,''),(1664,199,'安乡县',3,0,''),(1665,199,'汉寿县',3,0,''),(1666,199,'澧县',3,0,''),(1667,199,'临澧县',3,0,''),(1668,199,'桃源县',3,0,''),(1669,199,'石门县',3,0,''),(1670,200,'北湖区',3,0,''),(1671,200,'苏仙区',3,0,''),(1672,200,'资兴市',3,0,''),(1673,200,'桂阳县',3,0,''),(1674,200,'宜章县',3,0,''),(1675,200,'永兴县',3,0,''),(1676,200,'嘉禾县',3,0,''),(1677,200,'临武县',3,0,''),(1678,200,'汝城县',3,0,''),(1679,200,'桂东县',3,0,''),(1680,200,'安仁县',3,0,''),(1681,201,'雁峰区',3,0,''),(1682,201,'珠晖区',3,0,''),(1683,201,'石鼓区',3,0,''),(1684,201,'蒸湘区',3,0,''),(1685,201,'南岳区',3,0,''),(1686,201,'耒阳市',3,0,''),(1687,201,'常宁市',3,0,''),(1688,201,'衡阳县',3,0,''),(1689,201,'衡南县',3,0,''),(1690,201,'衡山县',3,0,''),(1691,201,'衡东县',3,0,''),(1692,201,'祁东县',3,0,''),(1693,202,'鹤城区',3,0,''),(1694,202,'靖州',3,0,''),(1695,202,'麻阳',3,0,''),(1696,202,'通道',3,0,''),(1697,202,'新晃',3,0,''),(1698,202,'芷江',3,0,''),(1699,202,'沅陵县',3,0,''),(1700,202,'辰溪县',3,0,''),(1701,202,'溆浦县',3,0,''),(1702,202,'中方县',3,0,''),(1703,202,'会同县',3,0,''),(1704,202,'洪江市',3,0,''),(1705,203,'娄星区',3,0,''),(1706,203,'冷水江市',3,0,''),(1707,203,'涟源市',3,0,''),(1708,203,'双峰县',3,0,''),(1709,203,'新化县',3,0,''),(1710,204,'城步',3,0,''),(1711,204,'双清区',3,0,''),(1712,204,'大祥区',3,0,''),(1713,204,'北塔区',3,0,''),(1714,204,'武冈市',3,0,''),(1715,204,'邵东县',3,0,''),(1716,204,'新邵县',3,0,''),(1717,204,'邵阳县',3,0,''),(1718,204,'隆回县',3,0,''),(1719,204,'洞口县',3,0,''),(1720,204,'绥宁县',3,0,''),(1721,204,'新宁县',3,0,''),(1722,205,'岳塘区',3,0,''),(1723,205,'雨湖区',3,0,''),(1724,205,'湘乡市',3,0,''),(1725,205,'韶山市',3,0,''),(1726,205,'湘潭县',3,0,''),(1727,206,'吉首市',3,0,''),(1728,206,'泸溪县',3,0,''),(1729,206,'凤凰县',3,0,''),(1730,206,'花垣县',3,0,''),(1731,206,'保靖县',3,0,''),(1732,206,'古丈县',3,0,''),(1733,206,'永顺县',3,0,''),(1734,206,'龙山县',3,0,''),(1735,207,'赫山区',3,0,''),(1736,207,'资阳区',3,0,''),(1737,207,'沅江市',3,0,''),(1738,207,'南县',3,0,''),(1739,207,'桃江县',3,0,''),(1740,207,'安化县',3,0,''),(1741,208,'江华',3,0,''),(1742,208,'冷水滩区',3,0,''),(1743,208,'零陵区',3,0,''),(1744,208,'祁阳县',3,0,''),(1745,208,'东安县',3,0,''),(1746,208,'双牌县',3,0,''),(1747,208,'道县',3,0,''),(1748,208,'江永县',3,0,''),(1749,208,'宁远县',3,0,''),(1750,208,'蓝山县',3,0,''),(1751,208,'新田县',3,0,''),(1752,209,'岳阳楼区',3,0,''),(1753,209,'君山区',3,0,''),(1754,209,'云溪区',3,0,''),(1755,209,'汨罗市',3,0,''),(1756,209,'临湘市',3,0,''),(1757,209,'岳阳县',3,0,''),(1758,209,'华容县',3,0,''),(1759,209,'湘阴县',3,0,''),(1760,209,'平江县',3,0,''),(1761,210,'天元区',3,0,''),(1762,210,'荷塘区',3,0,''),(1763,210,'芦淞区',3,0,''),(1764,210,'石峰区',3,0,''),(1765,210,'醴陵市',3,0,''),(1766,210,'株洲县',3,0,''),(1767,210,'攸县',3,0,''),(1768,210,'茶陵县',3,0,''),(1769,210,'炎陵县',3,0,''),(1770,211,'朝阳区',3,0,''),(1771,211,'宽城区',3,0,''),(1772,211,'二道区',3,0,''),(1773,211,'南关区',3,0,''),(1774,211,'绿园区',3,0,''),(1775,211,'双阳区',3,0,''),(1776,211,'净月潭开发区',3,0,''),(1777,211,'高新技术开发区',3,0,''),(1778,211,'经济技术开发区',3,0,''),(1779,211,'汽车产业开发区',3,0,''),(1780,211,'德惠市',3,0,''),(1781,211,'九台市',3,0,''),(1782,211,'榆树市',3,0,''),(1783,211,'农安县',3,0,''),(1784,212,'船营区',3,0,''),(1785,212,'昌邑区',3,0,''),(1786,212,'龙潭区',3,0,''),(1787,212,'丰满区',3,0,''),(1788,212,'蛟河市',3,0,''),(1789,212,'桦甸市',3,0,''),(1790,212,'舒兰市',3,0,''),(1791,212,'磐石市',3,0,''),(1792,212,'永吉县',3,0,''),(1793,213,'洮北区',3,0,''),(1794,213,'洮南市',3,0,''),(1795,213,'大安市',3,0,''),(1796,213,'镇赉县',3,0,''),(1797,213,'通榆县',3,0,''),(1798,214,'江源区',3,0,''),(1799,214,'八道江区',3,0,''),(1800,214,'长白',3,0,''),(1801,214,'临江市',3,0,''),(1802,214,'抚松县',3,0,''),(1803,214,'靖宇县',3,0,''),(1804,215,'龙山区',3,0,''),(1805,215,'西安区',3,0,''),(1806,215,'东丰县',3,0,''),(1807,215,'东辽县',3,0,''),(1808,216,'铁西区',3,0,''),(1809,216,'铁东区',3,0,''),(1810,216,'伊通',3,0,''),(1811,216,'公主岭市',3,0,''),(1812,216,'双辽市',3,0,''),(1813,216,'梨树县',3,0,''),(1814,217,'前郭尔罗斯',3,0,''),(1815,217,'宁江区',3,0,''),(1816,217,'长岭县',3,0,''),(1817,217,'乾安县',3,0,''),(1818,217,'扶余县',3,0,''),(1819,218,'东昌区',3,0,''),(1820,218,'二道江区',3,0,''),(1821,218,'梅河口市',3,0,''),(1822,218,'集安市',3,0,''),(1823,218,'通化县',3,0,''),(1824,218,'辉南县',3,0,''),(1825,218,'柳河县',3,0,''),(1826,219,'延吉市',3,0,''),(1827,219,'图们市',3,0,''),(1828,219,'敦化市',3,0,''),(1829,219,'珲春市',3,0,''),(1830,219,'龙井市',3,0,''),(1831,219,'和龙市',3,0,''),(1832,219,'安图县',3,0,''),(1833,219,'汪清县',3,0,''),(1834,220,'玄武区',3,0,''),(1835,220,'鼓楼区',3,0,''),(1836,220,'白下区',3,0,''),(1837,220,'建邺区',3,0,''),(1838,220,'秦淮区',3,0,''),(1839,220,'雨花台区',3,0,''),(1840,220,'下关区',3,0,''),(1841,220,'栖霞区',3,0,''),(1842,220,'浦口区',3,0,''),(1843,220,'江宁区',3,0,''),(1844,220,'六合区',3,0,''),(1845,220,'溧水县',3,0,''),(1846,220,'高淳县',3,0,''),(1847,221,'沧浪区',3,0,''),(1848,221,'金阊区',3,0,''),(1849,221,'平江区',3,0,''),(1850,221,'虎丘区',3,0,''),(1851,221,'吴中区',3,0,''),(1852,221,'相城区',3,0,''),(1853,221,'园区',3,0,''),(1854,221,'新区',3,0,''),(1855,221,'常熟市',3,0,''),(1856,221,'张家港市',3,0,''),(1857,221,'玉山镇',3,0,''),(1858,221,'巴城镇',3,0,''),(1859,221,'周市镇',3,0,''),(1860,221,'陆家镇',3,0,''),(1861,221,'花桥镇',3,0,''),(1862,221,'淀山湖镇',3,0,''),(1863,221,'张浦镇',3,0,''),(1864,221,'周庄镇',3,0,''),(1865,221,'千灯镇',3,0,''),(1866,221,'锦溪镇',3,0,''),(1867,221,'开发区',3,0,''),(1868,221,'吴江市',3,0,''),(1869,221,'太仓市',3,0,''),(1870,222,'崇安区',3,0,''),(1871,222,'北塘区',3,0,''),(1872,222,'南长区',3,0,''),(1873,222,'锡山区',3,0,''),(1874,222,'惠山区',3,0,''),(1875,222,'滨湖区',3,0,''),(1876,222,'新区',3,0,''),(1877,222,'江阴市',3,0,''),(1878,222,'宜兴市',3,0,''),(1879,223,'天宁区',3,0,''),(1880,223,'钟楼区',3,0,''),(1881,223,'戚墅堰区',3,0,''),(1882,223,'郊区',3,0,''),(1883,223,'新北区',3,0,''),(1884,223,'武进区',3,0,''),(1885,223,'溧阳市',3,0,''),(1886,223,'金坛市',3,0,''),(1887,224,'清河区',3,0,''),(1888,224,'清浦区',3,0,''),(1889,224,'楚州区',3,0,''),(1890,224,'淮阴区',3,0,''),(1891,224,'涟水县',3,0,''),(1892,224,'洪泽县',3,0,''),(1893,224,'盱眙县',3,0,''),(1894,224,'金湖县',3,0,''),(1895,225,'新浦区',3,0,''),(1896,225,'连云区',3,0,''),(1897,225,'海州区',3,0,''),(1898,225,'赣榆县',3,0,''),(1899,225,'东海县',3,0,''),(1900,225,'灌云县',3,0,''),(1901,225,'灌南县',3,0,''),(1902,226,'崇川区',3,0,''),(1903,226,'港闸区',3,0,''),(1904,226,'经济开发区',3,0,''),(1905,226,'启东市',3,0,''),(1906,226,'如皋市',3,0,''),(1907,226,'通州市',3,0,''),(1908,226,'海门市',3,0,''),(1909,226,'海安县',3,0,''),(1910,226,'如东县',3,0,''),(1911,227,'宿城区',3,0,''),(1912,227,'宿豫区',3,0,''),(1913,227,'宿豫县',3,0,''),(1914,227,'沭阳县',3,0,''),(1915,227,'泗阳县',3,0,''),(1916,227,'泗洪县',3,0,''),(1917,228,'海陵区',3,0,''),(1918,228,'高港区',3,0,''),(1919,228,'兴化市',3,0,''),(1920,228,'靖江市',3,0,''),(1921,228,'泰兴市',3,0,''),(1922,228,'姜堰市',3,0,''),(1923,229,'云龙区',3,0,''),(1924,229,'鼓楼区',3,0,''),(1925,229,'九里区',3,0,''),(1926,229,'贾汪区',3,0,''),(1927,229,'泉山区',3,0,''),(1928,229,'新沂市',3,0,''),(1929,229,'邳州市',3,0,''),(1930,229,'丰县',3,0,''),(1931,229,'沛县',3,0,''),(1932,229,'铜山县',3,0,''),(1933,229,'睢宁县',3,0,''),(1934,230,'城区',3,0,''),(1935,230,'亭湖区',3,0,''),(1936,230,'盐都区',3,0,''),(1937,230,'盐都县',3,0,''),(1938,230,'东台市',3,0,''),(1939,230,'大丰市',3,0,''),(1940,230,'响水县',3,0,''),(1941,230,'滨海县',3,0,''),(1942,230,'阜宁县',3,0,''),(1943,230,'射阳县',3,0,''),(1944,230,'建湖县',3,0,''),(1945,231,'广陵区',3,0,''),(1946,231,'维扬区',3,0,''),(1947,231,'邗江区',3,0,''),(1948,231,'仪征市',3,0,''),(1949,231,'高邮市',3,0,''),(1950,231,'江都市',3,0,''),(1951,231,'宝应县',3,0,''),(1952,232,'京口区',3,0,''),(1953,232,'润州区',3,0,''),(1954,232,'丹徒区',3,0,''),(1955,232,'丹阳市',3,0,''),(1956,232,'扬中市',3,0,''),(1957,232,'句容市',3,0,''),(1958,233,'东湖区',3,0,''),(1959,233,'西湖区',3,0,''),(1960,233,'青云谱区',3,0,''),(1961,233,'湾里区',3,0,''),(1962,233,'青山湖区',3,0,''),(1963,233,'红谷滩新区',3,0,''),(1964,233,'昌北区',3,0,''),(1965,233,'高新区',3,0,''),(1966,233,'南昌县',3,0,''),(1967,233,'新建县',3,0,''),(1968,233,'安义县',3,0,''),(1969,233,'进贤县',3,0,''),(1970,234,'临川区',3,0,''),(1971,234,'南城县',3,0,''),(1972,234,'黎川县',3,0,''),(1973,234,'南丰县',3,0,''),(1974,234,'崇仁县',3,0,''),(1975,234,'乐安县',3,0,''),(1976,234,'宜黄县',3,0,''),(1977,234,'金溪县',3,0,''),(1978,234,'资溪县',3,0,''),(1979,234,'东乡县',3,0,''),(1980,234,'广昌县',3,0,''),(1981,235,'章贡区',3,0,''),(1982,235,'于都县',3,0,''),(1983,235,'瑞金市',3,0,''),(1984,235,'南康市',3,0,''),(1985,235,'赣县',3,0,''),(1986,235,'信丰县',3,0,''),(1987,235,'大余县',3,0,''),(1988,235,'上犹县',3,0,''),(1989,235,'崇义县',3,0,''),(1990,235,'安远县',3,0,''),(1991,235,'龙南县',3,0,''),(1992,235,'定南县',3,0,''),(1993,235,'全南县',3,0,''),(1994,235,'宁都县',3,0,''),(1995,235,'兴国县',3,0,''),(1996,235,'会昌县',3,0,''),(1997,235,'寻乌县',3,0,''),(1998,235,'石城县',3,0,''),(1999,236,'安福县',3,0,''),(2000,236,'吉州区',3,0,''),(2001,236,'青原区',3,0,''),(2002,236,'井冈山市',3,0,''),(2003,236,'吉安县',3,0,''),(2004,236,'吉水县',3,0,''),(2005,236,'峡江县',3,0,''),(2006,236,'新干县',3,0,''),(2007,236,'永丰县',3,0,''),(2008,236,'泰和县',3,0,''),(2009,236,'遂川县',3,0,''),(2010,236,'万安县',3,0,''),(2011,236,'永新县',3,0,''),(2012,237,'珠山区',3,0,''),(2013,237,'昌江区',3,0,''),(2014,237,'乐平市',3,0,''),(2015,237,'浮梁县',3,0,''),(2016,238,'浔阳区',3,0,''),(2017,238,'庐山区',3,0,''),(2018,238,'瑞昌市',3,0,''),(2019,238,'九江县',3,0,''),(2020,238,'武宁县',3,0,''),(2021,238,'修水县',3,0,''),(2022,238,'永修县',3,0,''),(2023,238,'德安县',3,0,''),(2024,238,'星子县',3,0,''),(2025,238,'都昌县',3,0,''),(2026,238,'湖口县',3,0,''),(2027,238,'彭泽县',3,0,''),(2028,239,'安源区',3,0,''),(2029,239,'湘东区',3,0,''),(2030,239,'莲花县',3,0,''),(2031,239,'芦溪县',3,0,''),(2032,239,'上栗县',3,0,''),(2033,240,'信州区',3,0,''),(2034,240,'德兴市',3,0,''),(2035,240,'上饶县',3,0,''),(2036,240,'广丰县',3,0,''),(2037,240,'玉山县',3,0,''),(2038,240,'铅山县',3,0,''),(2039,240,'横峰县',3,0,''),(2040,240,'弋阳县',3,0,''),(2041,240,'余干县',3,0,''),(2042,240,'波阳县',3,0,''),(2043,240,'万年县',3,0,''),(2044,240,'婺源县',3,0,''),(2045,241,'渝水区',3,0,''),(2046,241,'分宜县',3,0,''),(2047,242,'袁州区',3,0,''),(2048,242,'丰城市',3,0,''),(2049,242,'樟树市',3,0,''),(2050,242,'高安市',3,0,''),(2051,242,'奉新县',3,0,''),(2052,242,'万载县',3,0,''),(2053,242,'上高县',3,0,''),(2054,242,'宜丰县',3,0,''),(2055,242,'靖安县',3,0,''),(2056,242,'铜鼓县',3,0,''),(2057,243,'月湖区',3,0,''),(2058,243,'贵溪市',3,0,''),(2059,243,'余江县',3,0,''),(2060,244,'沈河区',3,0,''),(2061,244,'皇姑区',3,0,''),(2062,244,'和平区',3,0,''),(2063,244,'大东区',3,0,''),(2064,244,'铁西区',3,0,''),(2065,244,'苏家屯区',3,0,''),(2066,244,'东陵区',3,0,''),(2067,244,'沈北新区',3,0,''),(2068,244,'于洪区',3,0,''),(2069,244,'浑南新区',3,0,''),(2070,244,'新民市',3,0,''),(2071,244,'辽中县',3,0,''),(2072,244,'康平县',3,0,''),(2073,244,'法库县',3,0,''),(2074,245,'西岗区',3,0,''),(2075,245,'中山区',3,0,''),(2076,245,'沙河口区',3,0,''),(2077,245,'甘井子区',3,0,''),(2078,245,'旅顺口区',3,0,''),(2079,245,'金州区',3,0,''),(2080,245,'开发区',3,0,''),(2081,245,'瓦房店市',3,0,''),(2082,245,'普兰店市',3,0,''),(2083,245,'庄河市',3,0,''),(2084,245,'长海县',3,0,''),(2085,246,'铁东区',3,0,''),(2086,246,'铁西区',3,0,''),(2087,246,'立山区',3,0,''),(2088,246,'千山区',3,0,''),(2089,246,'岫岩',3,0,''),(2090,246,'海城市',3,0,''),(2091,246,'台安县',3,0,''),(2092,247,'本溪',3,0,''),(2093,247,'平山区',3,0,''),(2094,247,'明山区',3,0,''),(2095,247,'溪湖区',3,0,''),(2096,247,'南芬区',3,0,''),(2097,247,'桓仁',3,0,''),(2098,248,'双塔区',3,0,''),(2099,248,'龙城区',3,0,''),(2100,248,'喀喇沁左翼蒙古族自治县',3,0,''),(2101,248,'北票市',3,0,''),(2102,248,'凌源市',3,0,''),(2103,248,'朝阳县',3,0,''),(2104,248,'建平县',3,0,''),(2105,249,'振兴区',3,0,''),(2106,249,'元宝区',3,0,''),(2107,249,'振安区',3,0,''),(2108,249,'宽甸',3,0,''),(2109,249,'东港市',3,0,''),(2110,249,'凤城市',3,0,''),(2111,250,'顺城区',3,0,''),(2112,250,'新抚区',3,0,''),(2113,250,'东洲区',3,0,''),(2114,250,'望花区',3,0,''),(2115,250,'清原',3,0,''),(2116,250,'新宾',3,0,''),(2117,250,'抚顺县',3,0,''),(2118,251,'阜新',3,0,''),(2119,251,'海州区',3,0,''),(2120,251,'新邱区',3,0,''),(2121,251,'太平区',3,0,''),(2122,251,'清河门区',3,0,''),(2123,251,'细河区',3,0,''),(2124,251,'彰武县',3,0,''),(2125,252,'龙港区',3,0,''),(2126,252,'南票区',3,0,''),(2127,252,'连山区',3,0,''),(2128,252,'兴城市',3,0,''),(2129,252,'绥中县',3,0,''),(2130,252,'建昌县',3,0,''),(2131,253,'太和区',3,0,''),(2132,253,'古塔区',3,0,''),(2133,253,'凌河区',3,0,''),(2134,253,'凌海市',3,0,''),(2135,253,'北镇市',3,0,''),(2136,253,'黑山县',3,0,''),(2137,253,'义县',3,0,''),(2138,254,'白塔区',3,0,''),(2139,254,'文圣区',3,0,''),(2140,254,'宏伟区',3,0,''),(2141,254,'太子河区',3,0,''),(2142,254,'弓长岭区',3,0,''),(2143,254,'灯塔市',3,0,''),(2144,254,'辽阳县',3,0,''),(2145,255,'双台子区',3,0,''),(2146,255,'兴隆台区',3,0,''),(2147,255,'大洼县',3,0,''),(2148,255,'盘山县',3,0,''),(2149,256,'银州区',3,0,''),(2150,256,'清河区',3,0,''),(2151,256,'调兵山市',3,0,''),(2152,256,'开原市',3,0,''),(2153,256,'铁岭县',3,0,''),(2154,256,'西丰县',3,0,''),(2155,256,'昌图县',3,0,''),(2156,257,'站前区',3,0,''),(2157,257,'西市区',3,0,''),(2158,257,'鲅鱼圈区',3,0,''),(2159,257,'老边区',3,0,''),(2160,257,'盖州市',3,0,''),(2161,257,'大石桥市',3,0,''),(2162,258,'回民区',3,0,''),(2163,258,'玉泉区',3,0,''),(2164,258,'新城区',3,0,''),(2165,258,'赛罕区',3,0,''),(2166,258,'清水河县',3,0,''),(2167,258,'土默特左旗',3,0,''),(2168,258,'托克托县',3,0,''),(2169,258,'和林格尔县',3,0,''),(2170,258,'武川县',3,0,''),(2171,259,'阿拉善左旗',3,0,''),(2172,259,'阿拉善右旗',3,0,''),(2173,259,'额济纳旗',3,0,''),(2174,260,'临河区',3,0,''),(2175,260,'五原县',3,0,''),(2176,260,'磴口县',3,0,''),(2177,260,'乌拉特前旗',3,0,''),(2178,260,'乌拉特中旗',3,0,''),(2179,260,'乌拉特后旗',3,0,''),(2180,260,'杭锦后旗',3,0,''),(2181,261,'昆都仑区',3,0,''),(2182,261,'青山区',3,0,''),(2183,261,'东河区',3,0,''),(2184,261,'九原区',3,0,''),(2185,261,'石拐区',3,0,''),(2186,261,'白云矿区',3,0,''),(2187,261,'土默特右旗',3,0,''),(2188,261,'固阳县',3,0,''),(2189,261,'达尔罕茂明安联合旗',3,0,''),(2190,262,'红山区',3,0,''),(2191,262,'元宝山区',3,0,''),(2192,262,'松山区',3,0,''),(2193,262,'阿鲁科尔沁旗',3,0,''),(2194,262,'巴林左旗',3,0,''),(2195,262,'巴林右旗',3,0,''),(2196,262,'林西县',3,0,''),(2197,262,'克什克腾旗',3,0,''),(2198,262,'翁牛特旗',3,0,''),(2199,262,'喀喇沁旗',3,0,''),(2200,262,'宁城县',3,0,''),(2201,262,'敖汉旗',3,0,''),(2202,263,'东胜区',3,0,''),(2203,263,'达拉特旗',3,0,''),(2204,263,'准格尔旗',3,0,''),(2205,263,'鄂托克前旗',3,0,''),(2206,263,'鄂托克旗',3,0,''),(2207,263,'杭锦旗',3,0,''),(2208,263,'乌审旗',3,0,''),(2209,263,'伊金霍洛旗',3,0,''),(2210,264,'海拉尔区',3,0,''),(2211,264,'莫力达瓦',3,0,''),(2212,264,'满洲里市',3,0,''),(2213,264,'牙克石市',3,0,''),(2214,264,'扎兰屯市',3,0,''),(2215,264,'额尔古纳市',3,0,''),(2216,264,'根河市',3,0,''),(2217,264,'阿荣旗',3,0,''),(2218,264,'鄂伦春自治旗',3,0,''),(2219,264,'鄂温克族自治旗',3,0,''),(2220,264,'陈巴尔虎旗',3,0,''),(2221,264,'新巴尔虎左旗',3,0,''),(2222,264,'新巴尔虎右旗',3,0,''),(2223,265,'科尔沁区',3,0,''),(2224,265,'霍林郭勒市',3,0,''),(2225,265,'科尔沁左翼中旗',3,0,''),(2226,265,'科尔沁左翼后旗',3,0,''),(2227,265,'开鲁县',3,0,''),(2228,265,'库伦旗',3,0,''),(2229,265,'奈曼旗',3,0,''),(2230,265,'扎鲁特旗',3,0,''),(2231,266,'海勃湾区',3,0,''),(2232,266,'乌达区',3,0,''),(2233,266,'海南区',3,0,''),(2234,267,'化德县',3,0,''),(2235,267,'集宁区',3,0,''),(2236,267,'丰镇市',3,0,''),(2237,267,'卓资县',3,0,''),(2238,267,'商都县',3,0,''),(2239,267,'兴和县',3,0,''),(2240,267,'凉城县',3,0,''),(2241,267,'察哈尔右翼前旗',3,0,''),(2242,267,'察哈尔右翼中旗',3,0,''),(2243,267,'察哈尔右翼后旗',3,0,''),(2244,267,'四子王旗',3,0,''),(2245,268,'二连浩特市',3,0,''),(2246,268,'锡林浩特市',3,0,''),(2247,268,'阿巴嘎旗',3,0,''),(2248,268,'苏尼特左旗',3,0,''),(2249,268,'苏尼特右旗',3,0,''),(2250,268,'东乌珠穆沁旗',3,0,''),(2251,268,'西乌珠穆沁旗',3,0,''),(2252,268,'太仆寺旗',3,0,''),(2253,268,'镶黄旗',3,0,''),(2254,268,'正镶白旗',3,0,''),(2255,268,'正蓝旗',3,0,''),(2256,268,'多伦县',3,0,''),(2257,269,'乌兰浩特市',3,0,''),(2258,269,'阿尔山市',3,0,''),(2259,269,'科尔沁右翼前旗',3,0,''),(2260,269,'科尔沁右翼中旗',3,0,''),(2261,269,'扎赉特旗',3,0,''),(2262,269,'突泉县',3,0,''),(2263,270,'西夏区',3,0,''),(2264,270,'金凤区',3,0,''),(2265,270,'兴庆区',3,0,''),(2266,270,'灵武市',3,0,''),(2267,270,'永宁县',3,0,''),(2268,270,'贺兰县',3,0,''),(2269,271,'原州区',3,0,''),(2270,271,'海原县',3,0,''),(2271,271,'西吉县',3,0,''),(2272,271,'隆德县',3,0,''),(2273,271,'泾源县',3,0,''),(2274,271,'彭阳县',3,0,''),(2275,272,'惠农县',3,0,''),(2276,272,'大武口区',3,0,''),(2277,272,'惠农区',3,0,''),(2278,272,'陶乐县',3,0,''),(2279,272,'平罗县',3,0,''),(2280,273,'利通区',3,0,''),(2281,273,'中卫县',3,0,''),(2282,273,'青铜峡市',3,0,''),(2283,273,'中宁县',3,0,''),(2284,273,'盐池县',3,0,''),(2285,273,'同心县',3,0,''),(2286,274,'沙坡头区',3,0,''),(2287,274,'海原县',3,0,''),(2288,274,'中宁县',3,0,''),(2289,275,'城中区',3,0,''),(2290,275,'城东区',3,0,''),(2291,275,'城西区',3,0,''),(2292,275,'城北区',3,0,''),(2293,275,'湟中县',3,0,''),(2294,275,'湟源县',3,0,''),(2295,275,'大通',3,0,''),(2296,276,'玛沁县',3,0,''),(2297,276,'班玛县',3,0,''),(2298,276,'甘德县',3,0,''),(2299,276,'达日县',3,0,''),(2300,276,'久治县',3,0,''),(2301,276,'玛多县',3,0,''),(2302,277,'海晏县',3,0,''),(2303,277,'祁连县',3,0,''),(2304,277,'刚察县',3,0,''),(2305,277,'门源',3,0,''),(2306,278,'平安县',3,0,''),(2307,278,'乐都县',3,0,''),(2308,278,'民和',3,0,''),(2309,278,'互助',3,0,''),(2310,278,'化隆',3,0,''),(2311,278,'循化',3,0,''),(2312,279,'共和县',3,0,''),(2313,279,'同德县',3,0,''),(2314,279,'贵德县',3,0,''),(2315,279,'兴海县',3,0,''),(2316,279,'贵南县',3,0,''),(2317,280,'德令哈市',3,0,''),(2318,280,'格尔木市',3,0,''),(2319,280,'乌兰县',3,0,''),(2320,280,'都兰县',3,0,''),(2321,280,'天峻县',3,0,''),(2322,281,'同仁县',3,0,''),(2323,281,'尖扎县',3,0,''),(2324,281,'泽库县',3,0,''),(2325,281,'河南蒙古族自治县',3,0,''),(2326,282,'玉树县',3,0,''),(2327,282,'杂多县',3,0,''),(2328,282,'称多县',3,0,''),(2329,282,'治多县',3,0,''),(2330,282,'囊谦县',3,0,''),(2331,282,'曲麻莱县',3,0,''),(2332,283,'市中区',3,0,''),(2333,283,'历下区',3,0,''),(2334,283,'天桥区',3,0,''),(2335,283,'槐荫区',3,0,''),(2336,283,'历城区',3,0,''),(2337,283,'长清区',3,0,''),(2338,283,'章丘市',3,0,''),(2339,283,'平阴县',3,0,''),(2340,283,'济阳县',3,0,''),(2341,283,'商河县',3,0,''),(2342,284,'市南区',3,0,''),(2343,284,'市北区',3,0,''),(2344,284,'城阳区',3,0,''),(2345,284,'四方区',3,0,''),(2346,284,'李沧区',3,0,''),(2347,284,'黄岛区',3,0,''),(2348,284,'崂山区',3,0,''),(2349,284,'胶州市',3,0,''),(2350,284,'即墨市',3,0,''),(2351,284,'平度市',3,0,'pingdu'),(2352,284,'胶南市',3,0,''),(2353,284,'莱西市',3,0,''),(2354,285,'滨城区',3,0,''),(2355,285,'惠民县',3,0,''),(2356,285,'阳信县',3,0,''),(2357,285,'无棣县',3,0,''),(2358,285,'沾化县',3,0,''),(2359,285,'博兴县',3,0,''),(2360,285,'邹平县',3,0,''),(2361,286,'德城区',3,0,''),(2362,286,'陵县',3,0,''),(2363,286,'乐陵市',3,0,''),(2364,286,'禹城市',3,0,''),(2365,286,'宁津县',3,0,''),(2366,286,'庆云县',3,0,''),(2367,286,'临邑县',3,0,''),(2368,286,'齐河县',3,0,''),(2369,286,'平原县',3,0,''),(2370,286,'夏津县',3,0,''),(2371,286,'武城县',3,0,''),(2372,287,'东营区',3,0,''),(2373,287,'河口区',3,0,''),(2374,287,'垦利县',3,0,''),(2375,287,'利津县',3,0,''),(2376,287,'广饶县',3,0,''),(2377,288,'牡丹区',3,0,''),(2378,288,'曹县',3,0,''),(2379,288,'单县',3,0,''),(2380,288,'成武县',3,0,''),(2381,288,'巨野县',3,0,''),(2382,288,'郓城县',3,0,''),(2383,288,'鄄城县',3,0,''),(2384,288,'定陶县',3,0,''),(2385,288,'东明县',3,0,''),(2386,289,'市中区',3,0,''),(2387,289,'任城区',3,0,''),(2388,289,'曲阜市',3,0,''),(2389,289,'兖州市',3,0,''),(2390,289,'邹城市',3,0,''),(2391,289,'微山县',3,0,''),(2392,289,'鱼台县',3,0,''),(2393,289,'金乡县',3,0,''),(2394,289,'嘉祥县',3,0,''),(2395,289,'汶上县',3,0,''),(2396,289,'泗水县',3,0,''),(2397,289,'梁山县',3,0,''),(2398,290,'莱城区',3,0,''),(2399,290,'钢城区',3,0,''),(2400,291,'东昌府区',3,0,''),(2401,291,'临清市',3,0,''),(2402,291,'阳谷县',3,0,''),(2403,291,'莘县',3,0,''),(2404,291,'茌平县',3,0,''),(2405,291,'东阿县',3,0,''),(2406,291,'冠县',3,0,''),(2407,291,'高唐县',3,0,''),(2408,292,'兰山区',3,0,''),(2409,292,'罗庄区',3,0,''),(2410,292,'河东区',3,0,''),(2411,292,'沂南县',3,0,''),(2412,292,'郯城县',3,0,''),(2413,292,'沂水县',3,0,''),(2414,292,'苍山县',3,0,''),(2415,292,'费县',3,0,''),(2416,292,'平邑县',3,0,''),(2417,292,'莒南县',3,0,''),(2418,292,'蒙阴县',3,0,''),(2419,292,'临沭县',3,0,''),(2420,293,'东港区',3,0,''),(2421,293,'岚山区',3,0,''),(2422,293,'五莲县',3,0,''),(2423,293,'莒县',3,0,''),(2424,294,'泰山区',3,0,''),(2425,294,'岱岳区',3,0,''),(2426,294,'新泰市',3,0,''),(2427,294,'肥城市',3,0,''),(2428,294,'宁阳县',3,0,''),(2429,294,'东平县',3,0,''),(2430,295,'荣成市',3,0,''),(2431,295,'乳山市',3,0,''),(2432,295,'环翠区',3,0,''),(2433,295,'文登市',3,0,''),(2434,296,'潍城区',3,0,''),(2435,296,'寒亭区',3,0,''),(2436,296,'坊子区',3,0,''),(2437,296,'奎文区',3,0,''),(2438,296,'青州市',3,0,''),(2439,296,'诸城市',3,0,''),(2440,296,'寿光市',3,0,''),(2441,296,'安丘市',3,0,''),(2442,296,'高密市',3,0,''),(2443,296,'昌邑市',3,0,''),(2444,296,'临朐县',3,0,''),(2445,296,'昌乐县',3,0,''),(2446,297,'芝罘区',3,0,''),(2447,297,'福山区',3,0,''),(2448,297,'牟平区',3,0,''),(2449,297,'莱山区',3,0,''),(2450,297,'开发区',3,0,''),(2451,297,'龙口市',3,0,''),(2452,297,'莱阳市',3,0,''),(2453,297,'莱州市',3,0,''),(2454,297,'蓬莱市',3,0,''),(2455,297,'招远市',3,0,''),(2456,297,'栖霞市',3,0,''),(2457,297,'海阳市',3,0,''),(2458,297,'长岛县',3,0,''),(2459,298,'市中区',3,0,''),(2460,298,'山亭区',3,0,''),(2461,298,'峄城区',3,0,''),(2462,298,'台儿庄区',3,0,''),(2463,298,'薛城区',3,0,''),(2464,298,'滕州市',3,0,''),(2465,299,'张店区',3,0,''),(2466,299,'临淄区',3,0,''),(2467,299,'淄川区',3,0,''),(2468,299,'博山区',3,0,''),(2469,299,'周村区',3,0,''),(2470,299,'桓台县',3,0,''),(2471,299,'高青县',3,0,''),(2472,299,'沂源县',3,0,''),(2473,300,'杏花岭区',3,0,''),(2474,300,'小店区',3,0,''),(2475,300,'迎泽区',3,0,''),(2476,300,'尖草坪区',3,0,''),(2477,300,'万柏林区',3,0,''),(2478,300,'晋源区',3,0,''),(2479,300,'高新开发区',3,0,''),(2480,300,'民营经济开发区',3,0,''),(2481,300,'经济技术开发区',3,0,''),(2482,300,'清徐县',3,0,''),(2483,300,'阳曲县',3,0,''),(2484,300,'娄烦县',3,0,''),(2485,300,'古交市',3,0,''),(2486,301,'城区',3,0,''),(2487,301,'郊区',3,0,''),(2488,301,'沁县',3,0,''),(2489,301,'潞城市',3,0,''),(2490,301,'长治县',3,0,''),(2491,301,'襄垣县',3,0,''),(2492,301,'屯留县',3,0,''),(2493,301,'平顺县',3,0,''),(2494,301,'黎城县',3,0,''),(2495,301,'壶关县',3,0,''),(2496,301,'长子县',3,0,''),(2497,301,'武乡县',3,0,''),(2498,301,'沁源县',3,0,''),(2499,302,'城区',3,0,''),(2500,302,'矿区',3,0,''),(2501,302,'南郊区',3,0,''),(2502,302,'新荣区',3,0,''),(2503,302,'阳高县',3,0,''),(2504,302,'天镇县',3,0,''),(2505,302,'广灵县',3,0,''),(2506,302,'灵丘县',3,0,''),(2507,302,'浑源县',3,0,''),(2508,302,'左云县',3,0,''),(2509,302,'大同县',3,0,''),(2510,303,'城区',3,0,''),(2511,303,'高平市',3,0,''),(2512,303,'沁水县',3,0,''),(2513,303,'阳城县',3,0,''),(2514,303,'陵川县',3,0,''),(2515,303,'泽州县',3,0,''),(2516,304,'榆次区',3,0,''),(2517,304,'介休市',3,0,''),(2518,304,'榆社县',3,0,''),(2519,304,'左权县',3,0,''),(2520,304,'和顺县',3,0,''),(2521,304,'昔阳县',3,0,''),(2522,304,'寿阳县',3,0,''),(2523,304,'太谷县',3,0,''),(2524,304,'祁县',3,0,''),(2525,304,'平遥县',3,0,''),(2526,304,'灵石县',3,0,''),(2527,305,'尧都区',3,0,''),(2528,305,'侯马市',3,0,''),(2529,305,'霍州市',3,0,''),(2530,305,'曲沃县',3,0,''),(2531,305,'翼城县',3,0,''),(2532,305,'襄汾县',3,0,''),(2533,305,'洪洞县',3,0,''),(2534,305,'吉县',3,0,''),(2535,305,'安泽县',3,0,''),(2536,305,'浮山县',3,0,''),(2537,305,'古县',3,0,''),(2538,305,'乡宁县',3,0,''),(2539,305,'大宁县',3,0,''),(2540,305,'隰县',3,0,''),(2541,305,'永和县',3,0,''),(2542,305,'蒲县',3,0,''),(2543,305,'汾西县',3,0,''),(2544,306,'离石市',3,0,''),(2545,306,'离石区',3,0,''),(2546,306,'孝义市',3,0,''),(2547,306,'汾阳市',3,0,''),(2548,306,'文水县',3,0,''),(2549,306,'交城县',3,0,''),(2550,306,'兴县',3,0,''),(2551,306,'临县',3,0,''),(2552,306,'柳林县',3,0,''),(2553,306,'石楼县',3,0,''),(2554,306,'岚县',3,0,''),(2555,306,'方山县',3,0,''),(2556,306,'中阳县',3,0,''),(2557,306,'交口县',3,0,''),(2558,307,'朔城区',3,0,''),(2559,307,'平鲁区',3,0,''),(2560,307,'山阴县',3,0,''),(2561,307,'应县',3,0,''),(2562,307,'右玉县',3,0,''),(2563,307,'怀仁县',3,0,''),(2564,308,'忻府区',3,0,''),(2565,308,'原平市',3,0,''),(2566,308,'定襄县',3,0,''),(2567,308,'五台县',3,0,''),(2568,308,'代县',3,0,''),(2569,308,'繁峙县',3,0,''),(2570,308,'宁武县',3,0,''),(2571,308,'静乐县',3,0,''),(2572,308,'神池县',3,0,''),(2573,308,'五寨县',3,0,''),(2574,308,'岢岚县',3,0,''),(2575,308,'河曲县',3,0,''),(2576,308,'保德县',3,0,''),(2577,308,'偏关县',3,0,''),(2578,309,'城区',3,0,''),(2579,309,'矿区',3,0,''),(2580,309,'郊区',3,0,''),(2581,309,'平定县',3,0,''),(2582,309,'盂县',3,0,''),(2583,310,'盐湖区',3,0,''),(2584,310,'永济市',3,0,''),(2585,310,'河津市',3,0,''),(2586,310,'临猗县',3,0,''),(2587,310,'万荣县',3,0,''),(2588,310,'闻喜县',3,0,''),(2589,310,'稷山县',3,0,''),(2590,310,'新绛县',3,0,''),(2591,310,'绛县',3,0,''),(2592,310,'垣曲县',3,0,''),(2593,310,'夏县',3,0,''),(2594,310,'平陆县',3,0,''),(2595,310,'芮城县',3,0,''),(2596,311,'莲湖区',3,0,''),(2597,311,'新城区',3,0,''),(2598,311,'碑林区',3,0,''),(2599,311,'雁塔区',3,0,''),(2600,311,'灞桥区',3,0,''),(2601,311,'未央区',3,0,''),(2602,311,'阎良区',3,0,''),(2603,311,'临潼区',3,0,''),(2604,311,'长安区',3,0,''),(2605,311,'蓝田县',3,0,''),(2606,311,'周至县',3,0,''),(2607,311,'户县',3,0,''),(2608,311,'高陵县',3,0,''),(2609,312,'汉滨区',3,0,''),(2610,312,'汉阴县',3,0,''),(2611,312,'石泉县',3,0,''),(2612,312,'宁陕县',3,0,''),(2613,312,'紫阳县',3,0,''),(2614,312,'岚皋县',3,0,''),(2615,312,'平利县',3,0,''),(2616,312,'镇坪县',3,0,''),(2617,312,'旬阳县',3,0,''),(2618,312,'白河县',3,0,''),(2619,313,'陈仓区',3,0,''),(2620,313,'渭滨区',3,0,''),(2621,313,'金台区',3,0,''),(2622,313,'凤翔县',3,0,''),(2623,313,'岐山县',3,0,''),(2624,313,'扶风县',3,0,''),(2625,313,'眉县',3,0,''),(2626,313,'陇县',3,0,''),(2627,313,'千阳县',3,0,''),(2628,313,'麟游县',3,0,''),(2629,313,'凤县',3,0,''),(2630,313,'太白县',3,0,''),(2631,314,'汉台区',3,0,''),(2632,314,'南郑县',3,0,''),(2633,314,'城固县',3,0,''),(2634,314,'洋县',3,0,''),(2635,314,'西乡县',3,0,''),(2636,314,'勉县',3,0,''),(2637,314,'宁强县',3,0,''),(2638,314,'略阳县',3,0,''),(2639,314,'镇巴县',3,0,''),(2640,314,'留坝县',3,0,''),(2641,314,'佛坪县',3,0,''),(2642,315,'商州区',3,0,''),(2643,315,'洛南县',3,0,''),(2644,315,'丹凤县',3,0,''),(2645,315,'商南县',3,0,''),(2646,315,'山阳县',3,0,''),(2647,315,'镇安县',3,0,''),(2648,315,'柞水县',3,0,''),(2649,316,'耀州区',3,0,''),(2650,316,'王益区',3,0,''),(2651,316,'印台区',3,0,''),(2652,316,'宜君县',3,0,''),(2653,317,'临渭区',3,0,''),(2654,317,'韩城市',3,0,''),(2655,317,'华阴市',3,0,''),(2656,317,'华县',3,0,''),(2657,317,'潼关县',3,0,''),(2658,317,'大荔县',3,0,''),(2659,317,'合阳县',3,0,''),(2660,317,'澄城县',3,0,''),(2661,317,'蒲城县',3,0,''),(2662,317,'白水县',3,0,''),(2663,317,'富平县',3,0,''),(2664,318,'秦都区',3,0,''),(2665,318,'渭城区',3,0,''),(2666,318,'杨陵区',3,0,''),(2667,318,'兴平市',3,0,''),(2668,318,'三原县',3,0,''),(2669,318,'泾阳县',3,0,''),(2670,318,'乾县',3,0,''),(2671,318,'礼泉县',3,0,''),(2672,318,'永寿县',3,0,''),(2673,318,'彬县',3,0,''),(2674,318,'长武县',3,0,''),(2675,318,'旬邑县',3,0,''),(2676,318,'淳化县',3,0,''),(2677,318,'武功县',3,0,''),(2678,319,'吴起县',3,0,''),(2679,319,'宝塔区',3,0,''),(2680,319,'延长县',3,0,''),(2681,319,'延川县',3,0,''),(2682,319,'子长县',3,0,''),(2683,319,'安塞县',3,0,''),(2684,319,'志丹县',3,0,''),(2685,319,'甘泉县',3,0,''),(2686,319,'富县',3,0,''),(2687,319,'洛川县',3,0,''),(2688,319,'宜川县',3,0,''),(2689,319,'黄龙县',3,0,''),(2690,319,'黄陵县',3,0,''),(2691,320,'榆阳区',3,0,''),(2692,320,'神木县',3,0,''),(2693,320,'府谷县',3,0,''),(2694,320,'横山县',3,0,''),(2695,320,'靖边县',3,0,''),(2696,320,'定边县',3,0,''),(2697,320,'绥德县',3,0,''),(2698,320,'米脂县',3,0,''),(2699,320,'佳县',3,0,''),(2700,320,'吴堡县',3,0,''),(2701,320,'清涧县',3,0,''),(2702,320,'子洲县',3,0,''),(2703,321,'长宁区',3,0,''),(2704,321,'闸北区',3,0,''),(2705,321,'闵行区',3,0,''),(2706,321,'徐汇区',3,0,''),(2707,321,'浦东新区',3,0,''),(2708,321,'杨浦区',3,0,''),(2709,321,'普陀区',3,0,''),(2710,321,'静安区',3,0,''),(2711,321,'卢湾区',3,0,''),(2712,321,'虹口区',3,0,''),(2713,321,'黄浦区',3,0,''),(2714,321,'南汇区',3,0,''),(2715,321,'松江区',3,0,''),(2716,321,'嘉定区',3,0,''),(2717,321,'宝山区',3,0,''),(2718,321,'青浦区',3,0,''),(2719,321,'金山区',3,0,''),(2720,321,'奉贤区',3,0,''),(2721,321,'崇明县',3,0,''),(2722,322,'青羊区',3,0,''),(2723,322,'锦江区',3,0,''),(2724,322,'金牛区',3,0,''),(2725,322,'武侯区',3,0,''),(2726,322,'成华区',3,0,''),(2727,322,'龙泉驿区',3,0,''),(2728,322,'青白江区',3,0,''),(2729,322,'新都区',3,0,''),(2730,322,'温江区',3,0,''),(2731,322,'高新区',3,0,''),(2732,322,'高新西区',3,0,''),(2733,322,'都江堰市',3,0,''),(2734,322,'彭州市',3,0,''),(2735,322,'邛崃市',3,0,''),(2736,322,'崇州市',3,0,''),(2737,322,'金堂县',3,0,''),(2738,322,'双流县',3,0,''),(2739,322,'郫县',3,0,''),(2740,322,'大邑县',3,0,''),(2741,322,'蒲江县',3,0,''),(2742,322,'新津县',3,0,''),(2743,322,'都江堰市',3,0,''),(2744,322,'彭州市',3,0,''),(2745,322,'邛崃市',3,0,''),(2746,322,'崇州市',3,0,''),(2747,322,'金堂县',3,0,''),(2748,322,'双流县',3,0,''),(2749,322,'郫县',3,0,''),(2750,322,'大邑县',3,0,''),(2751,322,'蒲江县',3,0,''),(2752,322,'新津县',3,0,''),(2753,323,'涪城区',3,0,''),(2754,323,'游仙区',3,0,''),(2755,323,'江油市',3,0,''),(2756,323,'盐亭县',3,0,''),(2757,323,'三台县',3,0,''),(2758,323,'平武县',3,0,''),(2759,323,'安县',3,0,''),(2760,323,'梓潼县',3,0,''),(2761,323,'北川县',3,0,''),(2762,324,'马尔康县',3,0,''),(2763,324,'汶川县',3,0,''),(2764,324,'理县',3,0,''),(2765,324,'茂县',3,0,''),(2766,324,'松潘县',3,0,''),(2767,324,'九寨沟县',3,0,''),(2768,324,'金川县',3,0,''),(2769,324,'小金县',3,0,''),(2770,324,'黑水县',3,0,''),(2771,324,'壤塘县',3,0,''),(2772,324,'阿坝县',3,0,''),(2773,324,'若尔盖县',3,0,''),(2774,324,'红原县',3,0,''),(2775,325,'巴州区',3,0,''),(2776,325,'通江县',3,0,''),(2777,325,'南江县',3,0,''),(2778,325,'平昌县',3,0,''),(2779,326,'通川区',3,0,''),(2780,326,'万源市',3,0,''),(2781,326,'达县',3,0,''),(2782,326,'宣汉县',3,0,''),(2783,326,'开江县',3,0,''),(2784,326,'大竹县',3,0,''),(2785,326,'渠县',3,0,''),(2786,327,'旌阳区',3,0,''),(2787,327,'广汉市',3,0,''),(2788,327,'什邡市',3,0,''),(2789,327,'绵竹市',3,0,''),(2790,327,'罗江县',3,0,''),(2791,327,'中江县',3,0,''),(2792,328,'康定县',3,0,''),(2793,328,'丹巴县',3,0,''),(2794,328,'泸定县',3,0,''),(2795,328,'炉霍县',3,0,''),(2796,328,'九龙县',3,0,''),(2797,328,'甘孜县',3,0,''),(2798,328,'雅江县',3,0,''),(2799,328,'新龙县',3,0,''),(2800,328,'道孚县',3,0,''),(2801,328,'白玉县',3,0,''),(2802,328,'理塘县',3,0,''),(2803,328,'德格县',3,0,''),(2804,328,'乡城县',3,0,''),(2805,328,'石渠县',3,0,''),(2806,328,'稻城县',3,0,''),(2807,328,'色达县',3,0,''),(2808,328,'巴塘县',3,0,''),(2809,328,'得荣县',3,0,''),(2810,329,'广安区',3,0,''),(2811,329,'华蓥市',3,0,''),(2812,329,'岳池县',3,0,''),(2813,329,'武胜县',3,0,''),(2814,329,'邻水县',3,0,''),(2815,330,'利州区',3,0,''),(2816,330,'元坝区',3,0,''),(2817,330,'朝天区',3,0,''),(2818,330,'旺苍县',3,0,''),(2819,330,'青川县',3,0,''),(2820,330,'剑阁县',3,0,''),(2821,330,'苍溪县',3,0,''),(2822,331,'峨眉山市',3,0,''),(2823,331,'乐山市',3,0,''),(2824,331,'犍为县',3,0,''),(2825,331,'井研县',3,0,''),(2826,331,'夹江县',3,0,''),(2827,331,'沐川县',3,0,''),(2828,331,'峨边',3,0,''),(2829,331,'马边',3,0,''),(2830,332,'西昌市',3,0,''),(2831,332,'盐源县',3,0,''),(2832,332,'德昌县',3,0,''),(2833,332,'会理县',3,0,''),(2834,332,'会东县',3,0,''),(2835,332,'宁南县',3,0,''),(2836,332,'普格县',3,0,''),(2837,332,'布拖县',3,0,''),(2838,332,'金阳县',3,0,''),(2839,332,'昭觉县',3,0,''),(2840,332,'喜德县',3,0,''),(2841,332,'冕宁县',3,0,''),(2842,332,'越西县',3,0,''),(2843,332,'甘洛县',3,0,''),(2844,332,'美姑县',3,0,''),(2845,332,'雷波县',3,0,''),(2846,332,'木里',3,0,''),(2847,333,'东坡区',3,0,''),(2848,333,'仁寿县',3,0,''),(2849,333,'彭山县',3,0,''),(2850,333,'洪雅县',3,0,''),(2851,333,'丹棱县',3,0,''),(2852,333,'青神县',3,0,''),(2853,334,'阆中市',3,0,''),(2854,334,'南部县',3,0,''),(2855,334,'营山县',3,0,''),(2856,334,'蓬安县',3,0,''),(2857,334,'仪陇县',3,0,''),(2858,334,'顺庆区',3,0,''),(2859,334,'高坪区',3,0,''),(2860,334,'嘉陵区',3,0,''),(2861,334,'西充县',3,0,''),(2862,335,'市中区',3,0,''),(2863,335,'东兴区',3,0,''),(2864,335,'威远县',3,0,''),(2865,335,'资中县',3,0,''),(2866,335,'隆昌县',3,0,''),(2867,336,'东  区',3,0,''),(2868,336,'西  区',3,0,''),(2869,336,'仁和区',3,0,''),(2870,336,'米易县',3,0,''),(2871,336,'盐边县',3,0,''),(2872,337,'船山区',3,0,''),(2873,337,'安居区',3,0,''),(2874,337,'蓬溪县',3,0,''),(2875,337,'射洪县',3,0,''),(2876,337,'大英县',3,0,''),(2877,338,'雨城区',3,0,''),(2878,338,'名山县',3,0,''),(2879,338,'荥经县',3,0,''),(2880,338,'汉源县',3,0,''),(2881,338,'石棉县',3,0,''),(2882,338,'天全县',3,0,''),(2883,338,'芦山县',3,0,''),(2884,338,'宝兴县',3,0,''),(2885,339,'翠屏区',3,0,''),(2886,339,'宜宾县',3,0,''),(2887,339,'南溪县',3,0,''),(2888,339,'江安县',3,0,''),(2889,339,'长宁县',3,0,''),(2890,339,'高县',3,0,''),(2891,339,'珙县',3,0,''),(2892,339,'筠连县',3,0,''),(2893,339,'兴文县',3,0,''),(2894,339,'屏山县',3,0,''),(2895,340,'雁江区',3,0,''),(2896,340,'简阳市',3,0,''),(2897,340,'安岳县',3,0,''),(2898,340,'乐至县',3,0,''),(2899,341,'大安区',3,0,''),(2900,341,'自流井区',3,0,''),(2901,341,'贡井区',3,0,''),(2902,341,'沿滩区',3,0,''),(2903,341,'荣县',3,0,''),(2904,341,'富顺县',3,0,''),(2905,342,'江阳区',3,0,''),(2906,342,'纳溪区',3,0,''),(2907,342,'龙马潭区',3,0,''),(2908,342,'泸县',3,0,''),(2909,342,'合江县',3,0,''),(2910,342,'叙永县',3,0,''),(2911,342,'古蔺县',3,0,''),(2912,343,'和平区',3,0,''),(2913,343,'河西区',3,0,''),(2914,343,'南开区',3,0,''),(2915,343,'河北区',3,0,''),(2916,343,'河东区',3,0,''),(2917,343,'红桥区',3,0,''),(2918,343,'东丽区',3,0,''),(2919,343,'津南区',3,0,''),(2920,343,'西青区',3,0,''),(2921,343,'北辰区',3,0,''),(2922,343,'塘沽区',3,0,''),(2923,343,'汉沽区',3,0,''),(2924,343,'大港区',3,0,''),(2925,343,'武清区',3,0,''),(2926,343,'宝坻区',3,0,''),(2927,343,'经济开发区',3,0,''),(2928,343,'宁河县',3,0,''),(2929,343,'静海县',3,0,''),(2930,343,'蓟县',3,0,''),(2931,344,'城关区',3,0,''),(2932,344,'林周县',3,0,''),(2933,344,'当雄县',3,0,''),(2934,344,'尼木县',3,0,''),(2935,344,'曲水县',3,0,''),(2936,344,'堆龙德庆县',3,0,''),(2937,344,'达孜县',3,0,''),(2938,344,'墨竹工卡县',3,0,''),(2939,345,'噶尔县',3,0,''),(2940,345,'普兰县',3,0,''),(2941,345,'札达县',3,0,''),(2942,345,'日土县',3,0,''),(2943,345,'革吉县',3,0,''),(2944,345,'改则县',3,0,''),(2945,345,'措勤县',3,0,''),(2946,346,'昌都县',3,0,''),(2947,346,'江达县',3,0,''),(2948,346,'贡觉县',3,0,''),(2949,346,'类乌齐县',3,0,''),(2950,346,'丁青县',3,0,''),(2951,346,'察雅县',3,0,''),(2952,346,'八宿县',3,0,''),(2953,346,'左贡县',3,0,''),(2954,346,'芒康县',3,0,''),(2955,346,'洛隆县',3,0,''),(2956,346,'边坝县',3,0,''),(2957,347,'林芝县',3,0,''),(2958,347,'工布江达县',3,0,''),(2959,347,'米林县',3,0,''),(2960,347,'墨脱县',3,0,''),(2961,347,'波密县',3,0,''),(2962,347,'察隅县',3,0,''),(2963,347,'朗县',3,0,''),(2964,348,'那曲县',3,0,''),(2965,348,'嘉黎县',3,0,''),(2966,348,'比如县',3,0,''),(2967,348,'聂荣县',3,0,''),(2968,348,'安多县',3,0,''),(2969,348,'申扎县',3,0,''),(2970,348,'索县',3,0,''),(2971,348,'班戈县',3,0,''),(2972,348,'巴青县',3,0,''),(2973,348,'尼玛县',3,0,''),(2974,349,'日喀则市',3,0,''),(2975,349,'南木林县',3,0,''),(2976,349,'江孜县',3,0,''),(2977,349,'定日县',3,0,''),(2978,349,'萨迦县',3,0,''),(2979,349,'拉孜县',3,0,''),(2980,349,'昂仁县',3,0,''),(2981,349,'谢通门县',3,0,''),(2982,349,'白朗县',3,0,''),(2983,349,'仁布县',3,0,''),(2984,349,'康马县',3,0,''),(2985,349,'定结县',3,0,''),(2986,349,'仲巴县',3,0,''),(2987,349,'亚东县',3,0,''),(2988,349,'吉隆县',3,0,''),(2989,349,'聂拉木县',3,0,''),(2990,349,'萨嘎县',3,0,''),(2991,349,'岗巴县',3,0,''),(2992,350,'乃东县',3,0,''),(2993,350,'扎囊县',3,0,''),(2994,350,'贡嘎县',3,0,''),(2995,350,'桑日县',3,0,''),(2996,350,'琼结县',3,0,''),(2997,350,'曲松县',3,0,''),(2998,350,'措美县',3,0,''),(2999,350,'洛扎县',3,0,''),(3000,350,'加查县',3,0,''),(3001,350,'隆子县',3,0,''),(3002,350,'错那县',3,0,''),(3003,350,'浪卡子县',3,0,''),(3004,351,'天山区',3,0,''),(3005,351,'沙依巴克区',3,0,''),(3006,351,'新市区',3,0,''),(3007,351,'水磨沟区',3,0,''),(3008,351,'头屯河区',3,0,''),(3009,351,'达坂城区',3,0,''),(3010,351,'米东区',3,0,''),(3011,351,'乌鲁木齐县',3,0,''),(3012,352,'阿克苏市',3,0,''),(3013,352,'温宿县',3,0,''),(3014,352,'库车县',3,0,''),(3015,352,'沙雅县',3,0,''),(3016,352,'新和县',3,0,''),(3017,352,'拜城县',3,0,''),(3018,352,'乌什县',3,0,''),(3019,352,'阿瓦提县',3,0,''),(3020,352,'柯坪县',3,0,''),(3021,353,'阿拉尔市',3,0,''),(3022,354,'库尔勒市',3,0,''),(3023,354,'轮台县',3,0,''),(3024,354,'尉犁县',3,0,''),(3025,354,'若羌县',3,0,''),(3026,354,'且末县',3,0,''),(3027,354,'焉耆',3,0,''),(3028,354,'和静县',3,0,''),(3029,354,'和硕县',3,0,''),(3030,354,'博湖县',3,0,''),(3031,355,'博乐市',3,0,''),(3032,355,'精河县',3,0,''),(3033,355,'温泉县',3,0,''),(3034,356,'呼图壁县',3,0,''),(3035,356,'米泉市',3,0,''),(3036,356,'昌吉市',3,0,''),(3037,356,'阜康市',3,0,''),(3038,356,'玛纳斯县',3,0,''),(3039,356,'奇台县',3,0,''),(3040,356,'吉木萨尔县',3,0,''),(3041,356,'木垒',3,0,''),(3042,357,'哈密市',3,0,''),(3043,357,'伊吾县',3,0,''),(3044,357,'巴里坤',3,0,''),(3045,358,'和田市',3,0,''),(3046,358,'和田县',3,0,''),(3047,358,'墨玉县',3,0,''),(3048,358,'皮山县',3,0,''),(3049,358,'洛浦县',3,0,''),(3050,358,'策勒县',3,0,''),(3051,358,'于田县',3,0,''),(3052,358,'民丰县',3,0,''),(3053,359,'喀什市',3,0,''),(3054,359,'疏附县',3,0,''),(3055,359,'疏勒县',3,0,''),(3056,359,'英吉沙县',3,0,''),(3057,359,'泽普县',3,0,''),(3058,359,'莎车县',3,0,''),(3059,359,'叶城县',3,0,''),(3060,359,'麦盖提县',3,0,''),(3061,359,'岳普湖县',3,0,''),(3062,359,'伽师县',3,0,''),(3063,359,'巴楚县',3,0,''),(3064,359,'塔什库尔干',3,0,''),(3065,360,'克拉玛依市',3,0,''),(3066,361,'阿图什市',3,0,''),(3067,361,'阿克陶县',3,0,''),(3068,361,'阿合奇县',3,0,''),(3069,361,'乌恰县',3,0,''),(3070,362,'石河子市',3,0,''),(3071,363,'图木舒克市',3,0,''),(3072,364,'吐鲁番市',3,0,''),(3073,364,'鄯善县',3,0,''),(3074,364,'托克逊县',3,0,''),(3075,365,'五家渠市',3,0,''),(3076,366,'阿勒泰市',3,0,''),(3077,366,'布克赛尔',3,0,''),(3078,366,'伊宁市',3,0,''),(3079,366,'布尔津县',3,0,''),(3080,366,'奎屯市',3,0,''),(3081,366,'乌苏市',3,0,''),(3082,366,'额敏县',3,0,''),(3083,366,'富蕴县',3,0,''),(3084,366,'伊宁县',3,0,''),(3085,366,'福海县',3,0,''),(3086,366,'霍城县',3,0,''),(3087,366,'沙湾县',3,0,''),(3088,366,'巩留县',3,0,''),(3089,366,'哈巴河县',3,0,''),(3090,366,'托里县',3,0,''),(3091,366,'青河县',3,0,''),(3092,366,'新源县',3,0,''),(3093,366,'裕民县',3,0,''),(3094,366,'和布克赛尔',3,0,''),(3095,366,'吉木乃县',3,0,''),(3096,366,'昭苏县',3,0,''),(3097,366,'特克斯县',3,0,''),(3098,366,'尼勒克县',3,0,''),(3099,366,'察布查尔',3,0,''),(3100,367,'盘龙区',3,0,''),(3101,367,'五华区',3,0,''),(3102,367,'官渡区',3,0,''),(3103,367,'西山区',3,0,''),(3104,367,'东川区',3,0,''),(3105,367,'安宁市',3,0,''),(3106,367,'呈贡县',3,0,''),(3107,367,'晋宁县',3,0,''),(3108,367,'富民县',3,0,''),(3109,367,'宜良县',3,0,''),(3110,367,'嵩明县',3,0,''),(3111,367,'石林县',3,0,''),(3112,367,'禄劝',3,0,''),(3113,367,'寻甸',3,0,''),(3114,368,'兰坪',3,0,''),(3115,368,'泸水县',3,0,''),(3116,368,'福贡县',3,0,''),(3117,368,'贡山',3,0,''),(3118,369,'宁洱',3,0,''),(3119,369,'思茅区',3,0,''),(3120,369,'墨江',3,0,''),(3121,369,'景东',3,0,''),(3122,369,'景谷',3,0,''),(3123,369,'镇沅',3,0,''),(3124,369,'江城',3,0,''),(3125,369,'孟连',3,0,''),(3126,369,'澜沧',3,0,''),(3127,369,'西盟',3,0,''),(3128,370,'古城区',3,0,''),(3129,370,'宁蒗',3,0,''),(3130,370,'玉龙',3,0,''),(3131,370,'永胜县',3,0,''),(3132,370,'华坪县',3,0,''),(3133,371,'隆阳区',3,0,''),(3134,371,'施甸县',3,0,''),(3135,371,'腾冲县',3,0,''),(3136,371,'龙陵县',3,0,''),(3137,371,'昌宁县',3,0,''),(3138,372,'楚雄市',3,0,''),(3139,372,'双柏县',3,0,''),(3140,372,'牟定县',3,0,''),(3141,372,'南华县',3,0,''),(3142,372,'姚安县',3,0,''),(3143,372,'大姚县',3,0,''),(3144,372,'永仁县',3,0,''),(3145,372,'元谋县',3,0,''),(3146,372,'武定县',3,0,''),(3147,372,'禄丰县',3,0,''),(3148,373,'大理市',3,0,''),(3149,373,'祥云县',3,0,''),(3150,373,'宾川县',3,0,''),(3151,373,'弥渡县',3,0,''),(3152,373,'永平县',3,0,''),(3153,373,'云龙县',3,0,''),(3154,373,'洱源县',3,0,''),(3155,373,'剑川县',3,0,''),(3156,373,'鹤庆县',3,0,''),(3157,373,'漾濞',3,0,''),(3158,373,'南涧',3,0,''),(3159,373,'巍山',3,0,''),(3160,374,'潞西市',3,0,''),(3161,374,'瑞丽市',3,0,''),(3162,374,'梁河县',3,0,''),(3163,374,'盈江县',3,0,''),(3164,374,'陇川县',3,0,''),(3165,375,'香格里拉县',3,0,''),(3166,375,'德钦县',3,0,''),(3167,375,'维西',3,0,''),(3168,376,'泸西县',3,0,''),(3169,376,'蒙自县',3,0,''),(3170,376,'个旧市',3,0,''),(3171,376,'开远市',3,0,''),(3172,376,'绿春县',3,0,''),(3173,376,'建水县',3,0,''),(3174,376,'石屏县',3,0,''),(3175,376,'弥勒县',3,0,''),(3176,376,'元阳县',3,0,''),(3177,376,'红河县',3,0,''),(3178,376,'金平',3,0,''),(3179,376,'河口',3,0,''),(3180,376,'屏边',3,0,''),(3181,377,'临翔区',3,0,''),(3182,377,'凤庆县',3,0,''),(3183,377,'云县',3,0,''),(3184,377,'永德县',3,0,''),(3185,377,'镇康县',3,0,''),(3186,377,'双江',3,0,''),(3187,377,'耿马',3,0,''),(3188,377,'沧源',3,0,''),(3189,378,'麒麟区',3,0,''),(3190,378,'宣威市',3,0,''),(3191,378,'马龙县',3,0,''),(3192,378,'陆良县',3,0,''),(3193,378,'师宗县',3,0,''),(3194,378,'罗平县',3,0,''),(3195,378,'富源县',3,0,''),(3196,378,'会泽县',3,0,''),(3197,378,'沾益县',3,0,''),(3198,379,'文山县',3,0,''),(3199,379,'砚山县',3,0,''),(3200,379,'西畴县',3,0,''),(3201,379,'麻栗坡县',3,0,''),(3202,379,'马关县',3,0,''),(3203,379,'丘北县',3,0,''),(3204,379,'广南县',3,0,''),(3205,379,'富宁县',3,0,''),(3206,380,'景洪市',3,0,''),(3207,380,'勐海县',3,0,''),(3208,380,'勐腊县',3,0,''),(3209,381,'红塔区',3,0,''),(3210,381,'江川县',3,0,''),(3211,381,'澄江县',3,0,''),(3212,381,'通海县',3,0,''),(3213,381,'华宁县',3,0,''),(3214,381,'易门县',3,0,''),(3215,381,'峨山',3,0,''),(3216,381,'新平',3,0,''),(3217,381,'元江',3,0,''),(3218,382,'昭阳区',3,0,''),(3219,382,'鲁甸县',3,0,''),(3220,382,'巧家县',3,0,''),(3221,382,'盐津县',3,0,''),(3222,382,'大关县',3,0,''),(3223,382,'永善县',3,0,''),(3224,382,'绥江县',3,0,''),(3225,382,'镇雄县',3,0,''),(3226,382,'彝良县',3,0,''),(3227,382,'威信县',3,0,''),(3228,382,'水富县',3,0,''),(3229,383,'西湖区',3,0,''),(3230,383,'上城区',3,0,''),(3231,383,'下城区',3,0,''),(3232,383,'拱墅区',3,0,''),(3233,383,'滨江区',3,0,''),(3234,383,'江干区',3,0,''),(3235,383,'萧山区',3,0,''),(3236,383,'余杭区',3,0,''),(3237,383,'市郊',3,0,''),(3238,383,'建德市',3,0,''),(3239,383,'富阳市',3,0,''),(3240,383,'临安市',3,0,''),(3241,383,'桐庐县',3,0,''),(3242,383,'淳安县',3,0,''),(3243,384,'吴兴区',3,0,''),(3244,384,'南浔区',3,0,''),(3245,384,'德清县',3,0,''),(3246,384,'长兴县',3,0,''),(3247,384,'安吉县',3,0,''),(3248,385,'南湖区',3,0,''),(3249,385,'秀洲区',3,0,''),(3250,385,'海宁市',3,0,''),(3251,385,'嘉善县',3,0,''),(3252,385,'平湖市',3,0,''),(3253,385,'桐乡市',3,0,''),(3254,385,'海盐县',3,0,''),(3255,386,'婺城区',3,0,''),(3256,386,'金东区',3,0,''),(3257,386,'兰溪市',3,0,''),(3258,386,'市区',3,0,''),(3259,386,'佛堂镇',3,0,''),(3260,386,'上溪镇',3,0,''),(3261,386,'义亭镇',3,0,''),(3262,386,'大陈镇',3,0,''),(3263,386,'苏溪镇',3,0,''),(3264,386,'赤岸镇',3,0,''),(3265,386,'东阳市',3,0,''),(3266,386,'永康市',3,0,''),(3267,386,'武义县',3,0,''),(3268,386,'浦江县',3,0,''),(3269,386,'磐安县',3,0,''),(3270,387,'莲都区',3,0,''),(3271,387,'龙泉市',3,0,''),(3272,387,'青田县',3,0,''),(3273,387,'缙云县',3,0,''),(3274,387,'遂昌县',3,0,''),(3275,387,'松阳县',3,0,''),(3276,387,'云和县',3,0,''),(3277,387,'庆元县',3,0,''),(3278,387,'景宁',3,0,''),(3279,388,'海曙区',3,0,''),(3280,388,'江东区',3,0,''),(3281,388,'江北区',3,0,''),(3282,388,'镇海区',3,0,''),(3283,388,'北仑区',3,0,''),(3284,388,'鄞州区',3,0,''),(3285,388,'余姚市',3,0,''),(3286,388,'慈溪市',3,0,''),(3287,388,'奉化市',3,0,''),(3288,388,'象山县',3,0,''),(3289,388,'宁海县',3,0,''),(3290,389,'越城区',3,0,''),(3291,389,'上虞市',3,0,''),(3292,389,'嵊州市',3,0,''),(3293,389,'绍兴县',3,0,''),(3294,389,'新昌县',3,0,''),(3295,389,'诸暨市',3,0,''),(3296,390,'椒江区',3,0,''),(3297,390,'黄岩区',3,0,''),(3298,390,'路桥区',3,0,''),(3299,390,'温岭市',3,0,''),(3300,390,'临海市',3,0,''),(3301,390,'玉环县',3,0,''),(3302,390,'三门县',3,0,''),(3303,390,'天台县',3,0,''),(3304,390,'仙居县',3,0,''),(3305,391,'鹿城区',3,0,''),(3306,391,'龙湾区',3,0,''),(3307,391,'瓯海区',3,0,''),(3308,391,'瑞安市',3,0,''),(3309,391,'乐清市',3,0,''),(3310,391,'洞头县',3,0,''),(3311,391,'永嘉县',3,0,''),(3312,391,'平阳县',3,0,''),(3313,391,'苍南县',3,0,''),(3314,391,'文成县',3,0,''),(3315,391,'泰顺县',3,0,''),(3316,392,'定海区',3,0,''),(3317,392,'普陀区',3,0,''),(3318,392,'岱山县',3,0,''),(3319,392,'嵊泗县',3,0,''),(3320,393,'衢州市',3,0,''),(3321,393,'江山市',3,0,''),(3322,393,'常山县',3,0,''),(3323,393,'开化县',3,0,''),(3324,393,'龙游县',3,0,''),(3325,394,'合川区',3,0,''),(3326,394,'江津区',3,0,''),(3327,394,'南川区',3,0,''),(3328,394,'永川区',3,0,''),(3329,394,'南岸区',3,0,''),(3330,394,'渝北区',3,0,''),(3331,394,'万盛区',3,0,''),(3332,394,'大渡口区',3,0,''),(3333,394,'万州区',3,0,''),(3334,394,'北碚区',3,0,''),(3335,394,'沙坪坝区',3,0,''),(3336,394,'巴南区',3,0,''),(3337,394,'涪陵区',3,0,''),(3338,394,'江北区',3,0,''),(3339,394,'九龙坡区',3,0,''),(3340,394,'渝中区',3,0,''),(3341,394,'黔江开发区',3,0,''),(3342,394,'长寿区',3,0,''),(3343,394,'双桥区',3,0,''),(3344,394,'綦江县',3,0,''),(3345,394,'潼南县',3,0,''),(3346,394,'铜梁县',3,0,''),(3347,394,'大足县',3,0,''),(3348,394,'荣昌县',3,0,''),(3349,394,'璧山县',3,0,''),(3350,394,'垫江县',3,0,''),(3351,394,'武隆县',3,0,''),(3352,394,'丰都县',3,0,''),(3353,394,'城口县',3,0,''),(3354,394,'梁平县',3,0,''),(3355,394,'开县',3,0,''),(3356,394,'巫溪县',3,0,''),(3357,394,'巫山县',3,0,''),(3358,394,'奉节县',3,0,''),(3359,394,'云阳县',3,0,''),(3360,394,'忠县',3,0,''),(3361,394,'石柱',3,0,''),(3362,394,'彭水',3,0,''),(3363,394,'酉阳',3,0,''),(3364,394,'秀山',3,0,''),(3365,395,'沙田区',3,0,''),(3366,395,'东区',3,0,''),(3367,395,'观塘区',3,0,''),(3368,395,'黄大仙区',3,0,''),(3369,395,'九龙城区',3,0,''),(3370,395,'屯门区',3,0,''),(3371,395,'葵青区',3,0,''),(3372,395,'元朗区',3,0,''),(3373,395,'深水埗区',3,0,''),(3374,395,'西贡区',3,0,''),(3375,395,'大埔区',3,0,''),(3376,395,'湾仔区',3,0,''),(3377,395,'油尖旺区',3,0,''),(3378,395,'北区',3,0,''),(3379,395,'南区',3,0,''),(3380,395,'荃湾区',3,0,''),(3381,395,'中西区',3,0,''),(3382,395,'离岛区',3,0,''),(3383,396,'澳门',3,0,''),(3384,397,'台北',3,0,''),(3385,397,'高雄',3,0,''),(3386,397,'基隆',3,0,''),(3387,397,'台中',3,0,''),(3388,397,'台南',3,0,''),(3389,397,'新竹',3,0,''),(3390,397,'嘉义',3,0,''),(3391,397,'宜兰县',3,0,''),(3392,397,'桃园县',3,0,''),(3393,397,'苗栗县',3,0,''),(3394,397,'彰化县',3,0,''),(3395,397,'南投县',3,0,''),(3396,397,'云林县',3,0,''),(3397,397,'屏东县',3,0,''),(3398,397,'台东县',3,0,''),(3399,397,'花莲县',3,0,''),(3400,397,'澎湖县',3,0,''),(3401,3,'合肥',2,0,''),(3402,3401,'庐阳区',3,0,''),(3403,3401,'瑶海区',3,0,''),(3404,3401,'蜀山区',3,0,''),(3405,3401,'包河区',3,0,''),(3406,3401,'长丰县',3,0,''),(3407,3401,'肥东县',3,0,''),(3408,3401,'肥西县',3,0,''),(3410,292,'经济开发区',3,0,''),(3411,284,'西海区',3,0,''),(3412,292,'高新技术开发区',3,0,''),(3413,292,'北城新区',3,0,'');
/*!40000 ALTER TABLE `st_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_cms_advert`
--

DROP TABLE IF EXISTS `st_cms_advert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_cms_advert` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类id',
  `tagname` varchar(30) NOT NULL DEFAULT '' COMMENT '广告位标识',
  `ad_type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '广告类型',
  `timeset` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '时间限制:0-永不过期,1-在设内时间内有效',
  `start_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '开始时间',
  `end_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '结束时间',
  `name` varchar(60) NOT NULL DEFAULT '' COMMENT '广告位名称',
  `content` text NOT NULL COMMENT '广告内容',
  `expcontent` text COMMENT '过期显示内容',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='广告表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_cms_advert`
--

LOCK TABLES `st_cms_advert` WRITE;
/*!40000 ALTER TABLE `st_cms_advert` DISABLE KEYS */;
INSERT INTO `st_cms_advert` VALUES (3,0,'index_tl',2,0,0,0,'首页中部通栏','<p><a href=\"http://www.18155.com/stock/trial\" target=\"_self\"><img src=\"/uploads/images/20190111/08b51b68f62d04645ad5083efccb5b7c.png\" title=\"1229_95090_副本.png\" alt=\"\"/></a></p>','',1529649223,1547183076,0),(5,0,'head_logo',2,0,0,0,'logo图片','<p><img src=\"/uploads/images/20200505/0714a8e1005ecbe18b1b86f09cdeafd4.png\" title=\"logo.png\" alt=\"\"/></p>',NULL,1531355949,1588754668,0),(6,0,'trial_banner',2,0,0,0,'免费体验配资banner图片（1920*240）像素','<p><img src=\"/uploads/images/20181121/897e0ebfc8507cfe64df422ee4a9fe48.jpg\" title=\"3c7f83220f59ef7e3a9af027e8adfa1b_副本.jpg\" alt=\"\"/></p>',NULL,1531356168,1542767495,0),(7,0,'free_banner',2,0,0,0,'免息配资banner图片（1920*240）像素','<p><img src=\"/uploads/images/20200506/91a0b196e3f883bc37820bf498006bf5.png\" title=\"5.png\" alt=\"\"/></p>',NULL,1531356378,1588754646,0),(8,0,'day_banner',2,0,0,0,'按天配资banner图片（1920*240）像素','<p><img src=\"/uploads/images/20200506/6d833b0c1c9784e7e999fa2e5f1a7be5.png\" title=\"4.png\" alt=\"\"/></p>',NULL,1531356503,1588754633,0),(9,0,'week_banner',2,0,0,0,'按周配资banner图片（1920*240）像素','<p><img src=\"/uploads/images/20200506/7db5879ddcef321fe269c5a5367b7e50.png\" title=\"3.png\" alt=\"\"/></p>',NULL,1531356555,1588754620,0),(10,0,'month_banner',2,0,0,0,'按月配资banner图片（1920*240）像素','<p><img src=\"/uploads/images/20200506/d2f028559741a9aeb891158be7b85364.png\" title=\"2.png\" alt=\"\"/></p>',NULL,1531356604,1588754603,0),(11,0,'float_app',2,0,0,0,'扫描下载手机APP','<p><img src=\"/uploads/images/20200505/49199fbd040b8a7c2f34bb6eb53a12ba.jpg\" title=\"20190711162946_49337.jpg\" alt=\"\"/></p>',NULL,1531356727,1588749113,1),(12,0,'weixin_img',2,0,0,0,'微信','<p><img src=\"/uploads/images/20200505/367d20458cc08a2df888261b705c26bc.jpg\" title=\"20190711162921_29353.jpg\" alt=\"\"/></p>',NULL,1531356888,1588749156,1),(13,0,'ssjhy',2,0,0,0,'扫扫加微信好友','<p><img src=\"/uploads/images/20200505/367d20458cc08a2df888261b705c26bc.jpg\" title=\"20190711162921_29353.jpg\" alt=\"\"/></p>',NULL,1541120306,1588749039,1),(14,0,'gzgzzh',2,0,0,0,'关注公众账号','<p><img src=\"/uploads/images/20200505/49199fbd040b8a7c2f34bb6eb53a12ba.jpg\" title=\"20190711162946_49337.jpg\" alt=\"\" width=\"166\" height=\"126\"/></p>',NULL,1541120417,1588749013,1),(17,0,'index_ad',2,1,1545148800,1546617600,'首页广告位500*500','<p><img src=\"/uploads/images/20200505/72ce93103bbc2e2c501ec0100a0d9786.png\" title=\"l1.png\" alt=\"\"/></p>',NULL,1542011405,1588653968,1),(18,0,'stock_borrow',0,0,0,0,'配资说明','<ul class=\" list-paddingleft-2\"><li><p>1.保证金：您用于投资股票的资金,起点相当低。</p></li><li><p>2.配资期限：按30个自然日计算，请避开法定节假日，合理使用资金。</p></li><li><p>3.按月支付账户管理费（不包含交易印花税、过户费和佣金），无其他任何费用。</p></li><li><p>4.如1月8日配资，1月8日支付第一个月管理费2月7号到期，如果续约必须在2月6号之前支付。</p></li><li><p>5.交易日当天14:57之前的申请于当日生效（当天开始收取账户管理费），交易日当天14：57后的申请于下个交易日生效。</p></li><li><p>6.请各位会员如果不想再次使用该账户配资需在到期日14：57之前终止配资，以免延期扣除相对应利息，利息扣除概不退还！</p></li></ul>',NULL,1558515643,1588749212,1),(19,0,'money_add_notice',0,0,0,0,'入金页面友情提示','友情提示',NULL,1560066003,1560066003,1),(20,0,'share_banner',2,0,0,0,'推广banner','<a href=\"http://127.0.0.1\" target=\"_blank\"><img src=\"/uploads/images/20210326/e84ea974f13202479abf0155e9c8b8dc.png\" style=\"width:750px;height:544px;\" /></a>',NULL,1616765677,1616765677,1);
/*!40000 ALTER TABLE `st_cms_advert` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_cms_advert_type`
--

DROP TABLE IF EXISTS `st_cms_advert_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_cms_advert_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '分类名称',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='广告分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_cms_advert_type`
--

LOCK TABLES `st_cms_advert_type` WRITE;
/*!40000 ALTER TABLE `st_cms_advert_type` DISABLE KEYS */;
INSERT INTO `st_cms_advert_type` VALUES (1,'横幅广告',0,0,0),(2,'轮播广告',0,0,1);
/*!40000 ALTER TABLE `st_cms_advert_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_cms_column`
--

DROP TABLE IF EXISTS `st_cms_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_cms_column` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父级id',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '栏目名称',
  `model` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档模型id',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '链接',
  `target` varchar(16) NOT NULL DEFAULT '_self' COMMENT '链接打开方式',
  `content` text NOT NULL COMMENT '内容',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '字体图标',
  `index_template` varchar(32) NOT NULL DEFAULT '' COMMENT '封面模板',
  `list_template` varchar(32) NOT NULL DEFAULT '' COMMENT '列表页模板',
  `detail_template` varchar(32) NOT NULL DEFAULT '' COMMENT '详情页模板',
  `post_auth` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '投稿权限',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `hide` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `rank_auth` int(11) NOT NULL DEFAULT '0' COMMENT '浏览权限，-1待审核，0为开放浏览，大于0则为对应的用户角色id',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '栏目属性：0-最终列表栏目，1-外部链接，2-频道封面',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `sort` (`sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='栏目表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_cms_column`
--

LOCK TABLES `st_cms_column` WRITE;
/*!40000 ALTER TABLE `st_cms_column` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_cms_column` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_cms_cooperate`
--

DROP TABLE IF EXISTS `st_cms_cooperate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_cms_cooperate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '类型：1-文字链接，2-图片链接',
  `title` varchar(128) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '链接标题',
  `url` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '链接地址',
  `logo` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '链接LOGO',
  `contact` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '联系方式',
  `sort` int(11) NOT NULL DEFAULT '100',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='有钱链接表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_cms_cooperate`
--

LOCK TABLES `st_cms_cooperate` WRITE;
/*!40000 ALTER TABLE `st_cms_cooperate` DISABLE KEYS */;
INSERT INTO `st_cms_cooperate` VALUES (2,2,'配资','',13,'',100,1,1531987121,1531987121);
/*!40000 ALTER TABLE `st_cms_cooperate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_cms_document`
--

DROP TABLE IF EXISTS `st_cms_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_cms_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '栏目id',
  `model` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档模型ID',
  `title` varchar(256) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '标题',
  `shorttitle` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '简略标题',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `flag` set('j','p','b','s','a','f','c','h') CHARACTER SET utf8 DEFAULT NULL COMMENT '自定义属性',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '阅读量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `good` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '点赞数',
  `bad` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '踩数',
  `mark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数量',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `trash` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '回收站',
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  KEY `model` (`model`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='文档基础表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_cms_document`
--

LOCK TABLES `st_cms_document` WRITE;
/*!40000 ALTER TABLE `st_cms_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_cms_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_cms_document_content`
--

DROP TABLE IF EXISTS `st_cms_document_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_cms_document_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(10) NOT NULL DEFAULT '1' COMMENT '文档id',
  `content` text CHARACTER SET utf8 NOT NULL COMMENT '内容',
  PRIMARY KEY (`id`),
  UNIQUE KEY `aid` (`aid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='在线客服模型扩展表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_cms_document_content`
--

LOCK TABLES `st_cms_document_content` WRITE;
/*!40000 ALTER TABLE `st_cms_document_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_cms_document_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_cms_field`
--

DROP TABLE IF EXISTS `st_cms_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_cms_field` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '字段名称',
  `name` varchar(32) CHARACTER SET utf8 NOT NULL,
  `title` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '字段标题',
  `type` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '字段类型',
  `define` varchar(128) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '字段定义',
  `value` text CHARACTER SET utf8 COMMENT '默认值',
  `options` text CHARACTER SET utf8 COMMENT '额外选项',
  `tips` varchar(256) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '提示说明',
  `fixed` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否为固定字段',
  `show` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否显示',
  `model` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属文档模型id',
  `ajax_url` varchar(256) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '联动下拉框ajax地址',
  `next_items` varchar(256) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '联动下拉框的下级下拉框名，多个以逗号隔开',
  `param` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '联动下拉框请求参数名',
  `format` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '格式，用于格式文本',
  `table` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '表名，只用于快速联动类型',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '联动级别，只用于快速联动类型',
  `key` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '键字段，只用于快速联动类型',
  `option` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '值字段，只用于快速联动类型',
  `pid` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '父级id字段，只用于快速联动类型',
  `ak` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '百度地图appkey',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='文档字段表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_cms_field`
--

LOCK TABLES `st_cms_field` WRITE;
/*!40000 ALTER TABLE `st_cms_field` DISABLE KEYS */;
INSERT INTO `st_cms_field` VALUES (1,'id','ID','text','int(11) UNSIGNED NOT NULL','0','','ID',0,0,0,'','','','','',0,'','','','',1480562978,1480562978,100,1),(2,'cid','栏目','select','int(11) UNSIGNED NOT NULL','0','','请选择所属栏目',0,0,0,'','','','','',0,'','','','',1480562978,1480562978,100,1),(3,'uid','用户ID','text','int(11) UNSIGNED NOT NULL','0','','',0,0,0,'','','','','',0,'','','','',1480563110,1480563110,100,1),(4,'model','模型ID','text','int(11) UNSIGNED NOT NULL','0','','',0,0,0,'','','','','',0,'','','','',1480563110,1480563110,100,1),(5,'title','标题','text','varchar(128) NOT NULL','','','文档标题',0,1,0,'','','','','',0,'','','','',1480575844,1480576134,1,1),(6,'shorttitle','简略标题','text','varchar(32) NOT NULL','','','简略标题',0,1,0,'','','','','',0,'','','','',1480575844,1480576134,1,1),(7,'flag','自定义属性','checkbox','set(\'j\',\'p\',\'b\',\'s\',\'a\',\'f\',\'h\',\'c\') NULL DEFAULT NULL','','j:跳转\np:图片\nb:加粗\ns:滚动\na:特荐\nf:幻灯\nh:头条\nc:推荐','自定义属性',0,1,0,'','','','','',0,'','','','',1480671258,1480671258,100,1),(8,'view','阅读量','text','int(11) UNSIGNED NOT NULL','0','','',0,1,0,'','','','','',0,'','','','',1480563149,1480563149,100,1),(9,'comment','评论数','text','int(11) UNSIGNED NOT NULL','0','','',0,0,0,'','','','','',0,'','','','',1480563189,1480563189,100,1),(10,'good','点赞数','text','int(11) UNSIGNED NOT NULL','0','','',0,0,0,'','','','','',0,'','','','',1480563279,1480563279,100,1),(11,'bad','踩数','text','int(11) UNSIGNED NOT NULL','0','','',0,0,0,'','','','','',0,'','','','',1480563330,1480563330,100,1),(12,'mark','收藏数量','text','int(11) UNSIGNED NOT NULL','0','','',0,0,0,'','','','','',0,'','','','',1480563372,1480563372,100,1),(13,'create_time','创建时间','datetime','int(11) UNSIGNED NOT NULL','0','','',0,0,0,'','','','','',0,'','','','',1480563406,1480563406,100,1),(14,'update_time','更新时间','datetime','int(11) UNSIGNED NOT NULL','0','','',0,0,0,'','','','','',0,'','','','',1480563432,1480563432,100,1),(15,'sort','排序','text','int(11) NOT NULL','100','','',0,1,0,'','','','','',0,'','','','',1480563510,1480563510,100,1),(16,'status','状态','radio','tinyint(2) UNSIGNED NOT NULL','1','0:禁用\n1:启用','',0,1,0,'','','','','',0,'','','','',1480563576,1480563576,100,1),(17,'trash','回收站','text','tinyint(2) UNSIGNED NOT NULL','0','','',0,0,0,'','','','','',0,'','','','',1480563576,1480563576,100,1),(18,'content','内容','ueditor','text NOT NULL','','','',1,1,2,'','','','','',0,'','','','',1515566500,1515566500,99,1),(19,'summary','摘要','textarea','varchar(256) NOT NULL','','','',1,1,2,'','','','','',0,'','','','',1515823323,1515823323,88,1),(20,'content','内容','ueditor','text NOT NULL','','','文本内容',1,1,3,'','','','','',0,'','','','',1525484096,1525484096,99,1),(21,'content','内容','ueditor','text NOT NULL','','','文本内容',1,1,4,'','','','','',0,'','','','',1525484156,1525484156,99,1),(23,'content','内容','ueditor','text NOT NULL','','','公告内容',1,1,5,'','','','','',0,'','','','',1616559621,1616559621,100,1);
/*!40000 ALTER TABLE `st_cms_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_cms_link`
--

DROP TABLE IF EXISTS `st_cms_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_cms_link` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '类型：1-文字链接，2-图片链接',
  `title` varchar(128) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '链接标题',
  `url` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '链接地址',
  `logo` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '链接LOGO',
  `contact` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '联系方式',
  `sort` int(11) NOT NULL DEFAULT '100',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='友情链接表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_cms_link`
--

LOCK TABLES `st_cms_link` WRITE;
/*!40000 ALTER TABLE `st_cms_link` DISABLE KEYS */;
INSERT INTO `st_cms_link` VALUES (5,2,'大智慧','http://www.gw.com.cn/',439,'',100,1,1529371109,1619449623),(6,2,'同花顺','http://www.10jqka.com.cn/',438,'',100,1,1619449316,1619449610),(7,2,'东方财富','https://jywg.18.cn/',440,'',100,1,1619450181,1619450181),(8,2,'新浪财经','https://finance.sina.com.cn/',441,'',100,1,1619450218,1619450218),(9,2,'平安证券','https://stock.pingan.com/static/info/news/stock.html',442,'',100,1,1619450433,1619450433);
/*!40000 ALTER TABLE `st_cms_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_cms_menu`
--

DROP TABLE IF EXISTS `st_cms_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_cms_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航id',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父级id',
  `column` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '栏目id',
  `page` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '单页id',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '类型：0-栏目链接，1-单页链接，2-自定义链接',
  `title` varchar(128) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '菜单标题',
  `url` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '链接',
  `css` varchar(64) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT 'css类',
  `rel` varchar(64) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '链接关系网',
  `target` varchar(16) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '打开方式',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='菜单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_cms_menu`
--

LOCK TABLES `st_cms_menu` WRITE;
/*!40000 ALTER TABLE `st_cms_menu` DISABLE KEYS */;
INSERT INTO `st_cms_menu` VALUES (1,1,0,0,0,2,'网站首页','/','active','','_self',1492345605,1515634150,100,1),(5,1,0,0,0,2,'免费体验','/stock/trial','','','_self',1492347372,1515632770,100,0),(8,1,0,0,0,2,'股票配资','/stock/day','','','_self',1513403275,1530493492,100,1),(9,1,0,0,0,2,'股票实盘','/market/index/index/','','','_self',1515632831,1524376330,100,0),(10,1,0,7,0,0,'','','','','_self',1515632939,1525769632,100,1),(11,1,0,6,0,0,'','','','','_self',1515632951,1525769616,100,0),(12,4,0,2,0,0,'','','','','_self',1520649134,1520649134,100,1),(13,4,0,4,0,0,'','','','','_self',1520649144,1520649144,100,1),(14,4,0,7,0,0,'','','','','_self',1520649154,1525769948,100,1),(15,4,0,6,0,0,'','','','','_self',1520649162,1525769976,100,1),(16,1,0,0,0,2,'模拟操盘','stock/mock/index','','','_self',1527745828,1527745828,100,0),(17,4,0,0,3,1,'','','','','_self',1529913270,1529913270,100,1),(18,1,0,0,3,1,'','','','','_self',1529978663,1529978663,100,1),(19,1,0,14,0,0,'','','','','_self',1536592408,1536592408,100,1),(24,1,0,18,0,0,'','','','','_self',1540701353,1540701822,100,0);
/*!40000 ALTER TABLE `st_cms_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_cms_model`
--

DROP TABLE IF EXISTS `st_cms_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_cms_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '模型名称',
  `title` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '模型标题',
  `table` varchar(64) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '附加表名称',
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '模型类别：0-系统模型，1-普通模型，2-独立模型',
  `icon` varchar(64) CHARACTER SET utf8 NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `system` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否系统模型',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='内容模型表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_cms_model`
--

LOCK TABLES `st_cms_model` WRITE;
/*!40000 ALTER TABLE `st_cms_model` DISABLE KEYS */;
INSERT INTO `st_cms_model` VALUES (2,'news','新闻资讯','cms_document_news',0,'si si-film',100,0,1513402988,1513402988,1),(3,'questions','常见问题','cms_document_questions',1,'fa fa-fw fa-user-md',100,0,1525418303,1525418303,1),(4,'novice','新手指引','cms_document_novice',1,'fa fa-fw fa-blind',100,0,1525418367,1525418367,1),(5,'notice','公告通知','cms_document_notice',1,'fa fa-fw fa-envelope-o',100,0,1616556808,1616556808,1);
/*!40000 ALTER TABLE `st_cms_model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_cms_nav`
--

DROP TABLE IF EXISTS `st_cms_nav`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_cms_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tag` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '导航标识',
  `title` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '菜单标题',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='导航表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_cms_nav`
--

LOCK TABLES `st_cms_nav` WRITE;
/*!40000 ALTER TABLE `st_cms_nav` DISABLE KEYS */;
INSERT INTO `st_cms_nav` VALUES (1,'main_nav','顶部导航',1492345083,1492345083,1),(4,'cms_nav','文章咨询',1524376683,1524376683,1),(5,'about_nav','底部关于',1525770853,1525770853,1);
/*!40000 ALTER TABLE `st_cms_nav` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_cms_page`
--

DROP TABLE IF EXISTS `st_cms_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_cms_page` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '单页标题',
  `content` mediumtext CHARACTER SET utf8 NOT NULL COMMENT '单页内容',
  `keywords` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '关键词',
  `description` varchar(250) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '页面描述',
  `template` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '模板文件',
  `cover` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '单页封面',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '阅读量',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='单页表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_cms_page`
--

LOCK TABLES `st_cms_page` WRITE;
/*!40000 ALTER TABLE `st_cms_page` DISABLE KEYS */;
INSERT INTO `st_cms_page` VALUES (1,'网站公告这里？','<p>网站公告这里？网站公告这里？</p>\n','公告,网站公告这里？','网站公告这里？','',0,261,1529023729,1529023853,1),(2,'公告单页页面','<p>公告单页页面公告单页页面</p>\n','','公告单页页面','',0,13,1529024836,1529024836,1),(3,'软件下载','','配资软件下载','','download/index',364,82203,1529913084,1554197567,1),(4,'IOS苹果APP下载','','','苹果页面下载','download/ios',0,38,1564103151,1564103381,1);
/*!40000 ALTER TABLE `st_cms_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_cms_slider`
--

DROP TABLE IF EXISTS `st_cms_slider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_cms_slider` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '标题',
  `cover` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面id',
  `url` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '链接地址',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned DEFAULT '0' COMMENT '更新时间',
  `sort` int(10) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `ifwap` tinyint(4) DEFAULT '0' COMMENT '是否手机幻灯片 ',
  `ifapp` tinyint(4) DEFAULT '0',
  `jumpid` tinyint(4) DEFAULT '6',
  `colomid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='滚动图片表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_cms_slider`
--

LOCK TABLES `st_cms_slider` WRITE;
/*!40000 ALTER TABLE `st_cms_slider` DISABLE KEYS */;
INSERT INTO `st_cms_slider` VALUES (15,'2233',984,'127.0.0.1',1761731046,0,100,0,0,0,6,0),(16,'1',986,'127.0.0.1',1761730986,1761730986,100,1,0,0,6,0),(17,'2',987,'127.0.0.1',1761730994,1761730994,100,1,0,0,6,0),(18,'3',988,'127.0.0.1',1761731022,1761731022,100,1,0,0,6,0),(19,'4',989,'127.0.0.1',1761731028,1761731028,100,1,0,0,6,0),(20,'5',990,'127.0.0.1',1761731037,1761731037,100,1,0,0,6,0);
/*!40000 ALTER TABLE `st_cms_slider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_cms_support`
--

DROP TABLE IF EXISTS `st_cms_support`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_cms_support` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '客服名称',
  `qq` varchar(16) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT 'QQ',
  `msn` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT 'msn',
  `taobao` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT 'taobao',
  `alibaba` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT 'alibaba',
  `skype` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT 'skype',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `sort` int(10) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='客服表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_cms_support`
--

LOCK TABLES `st_cms_support` WRITE;
/*!40000 ALTER TABLE `st_cms_support` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_cms_support` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_invest_item`
--

DROP TABLE IF EXISTS `st_invest_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_invest_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `single_class` int(11) DEFAULT '1' COMMENT '项目类型 1新手跟投  2一键跟投',
  `title` varchar(255) DEFAULT NULL COMMENT '项目名称',
  `day` varchar(50) DEFAULT NULL COMMENT '项目周期（天）',
  `scale` decimal(10,2) DEFAULT '0.00' COMMENT '项目分成比例',
  `num` int(11) DEFAULT '0' COMMENT '项目人数 0 不限制',
  `is_money` bigint(20) DEFAULT '0' COMMENT '投资金额  0 不限制  1限制',
  `min_money` varchar(100) DEFAULT NULL COMMENT '最低投资金额',
  `max_money` varchar(100) DEFAULT NULL COMMENT '最大投资金额',
  `profit` decimal(15,2) DEFAULT '0.00' COMMENT '项目盈利',
  `status` tinyint(3) DEFAULT '1' COMMENT '1正常 0禁用',
  `user_level` varchar(100) DEFAULT NULL COMMENT '项目限制等级和金额',
  `time_type` tinyint(4) DEFAULT '1' COMMENT '时间类型  1固定时间   2范围时间',
  `start_time` varchar(255) DEFAULT NULL COMMENT '范围时间   开始时间',
  `end_time` varchar(255) DEFAULT NULL COMMENT '范围时间   结束时间',
  `content` text COMMENT '说明',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='带单项目';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_invest_item`
--

LOCK TABLES `st_invest_item` WRITE;
/*!40000 ALTER TABLE `st_invest_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_invest_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_invest_item_day`
--

DROP TABLE IF EXISTS `st_invest_item_day`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_invest_item_day` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) DEFAULT NULL,
  `rate` decimal(20,2) DEFAULT '0.00' COMMENT '分傭',
  `day` int(11) DEFAULT '0' COMMENT '天數',
  `end_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '到期時間',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_invest_item_day`
--

LOCK TABLES `st_invest_item_day` WRITE;
/*!40000 ALTER TABLE `st_invest_item_day` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_invest_item_day` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_invest_item_income`
--

DROP TABLE IF EXISTS `st_invest_item_income`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_invest_item_income` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) DEFAULT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rate` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_invest_item_income`
--

LOCK TABLES `st_invest_item_income` WRITE;
/*!40000 ALTER TABLE `st_invest_item_income` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_invest_item_income` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_invest_order`
--

DROP TABLE IF EXISTS `st_invest_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_invest_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `invest_id` int(11) DEFAULT '0' COMMENT '項目ID',
  `mobile` varchar(50) DEFAULT NULL,
  `order_sn` varchar(255) DEFAULT NULL COMMENT '订单号',
  `invest_title` varchar(255) DEFAULT NULL COMMENT '项目名称',
  `invest_day_id` int(11) NOT NULL DEFAULT '0',
  `invest_day` int(11) DEFAULT '0' COMMENT '项目周期（天）',
  `scale` decimal(10,2) DEFAULT '0.00' COMMENT '分成比例',
  `direction` tinyint(3) DEFAULT '1' COMMENT '方向 1买涨  2买跌',
  `status` tinyint(3) DEFAULT '1' COMMENT '订单状态  1收益中2收益完成',
  `money` decimal(20,0) DEFAULT NULL COMMENT '金额',
  `ying_money` decimal(20,0) DEFAULT NULL COMMENT '盈利金额',
  `withdraw_money` decimal(20,0) DEFAULT NULL COMMENT '提盈金额',
  `trust_time` int(11) DEFAULT '0' COMMENT '委托时间',
  `deal_time` int(11) DEFAULT '0' COMMENT '成交时间',
  `is_show` tinyint(3) DEFAULT '0' COMMENT '是否显示前端  0不显示  1显示',
  `stamp_duty` decimal(10,2) DEFAULT '0.00' COMMENT '印花税',
  `transfer_fee` decimal(15,2) DEFAULT '0.00' COMMENT '过户费',
  `commission` decimal(15,2) DEFAULT '0.00' COMMENT '净佣金',
  `transaction_fee` decimal(15,2) DEFAULT '0.00' COMMENT '交易费',
  `deal_status` tinyint(3) DEFAULT '1' COMMENT '订单收益状态  1 收益中  2已交割分佣   弃用',
  `out_time` int(11) DEFAULT '0' COMMENT '项目到期时间',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `auth_time` int(11) DEFAULT '0' COMMENT '审核时间',
  `end_time` int(11) DEFAULT '0' COMMENT '该项目订单结束时间',
  `total_income` decimal(20,2) DEFAULT '0.00' COMMENT '纍計收益',
  `balance` decimal(20,2) DEFAULT '0.00' COMMENT '賬戶餘額',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `order_sn` (`order_sn`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='跟投订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_invest_order`
--

LOCK TABLES `st_invest_order` WRITE;
/*!40000 ALTER TABLE `st_invest_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_invest_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_invest_order_log`
--

DROP TABLE IF EXISTS `st_invest_order_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_invest_order_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `invest_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `invest_day_id` int(11) DEFAULT NULL,
  `period` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '周期',
  `starting_amount` decimal(20,2) DEFAULT '0.00' COMMENT '起始金額',
  `ending_amount` decimal(20,2) DEFAULT '0.00' COMMENT '賬戶餘額（期末資金）',
  `total_income` decimal(20,2) DEFAULT '0.00' COMMENT '纍計收益',
  `rate` decimal(20,2) DEFAULT '0.00' COMMENT '收益率',
  `day_income` decimal(20,2) DEFAULT '0.00' COMMENT '當日收益',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_invest_order_log`
--

LOCK TABLES `st_invest_order_log` WRITE;
/*!40000 ALTER TABLE `st_invest_order_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_invest_order_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_member`
--

DROP TABLE IF EXISTS `st_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `uid` varchar(100) DEFAULT NULL COMMENT '用户uid 用于查询展示使用',
  `user_type` tinyint(4) DEFAULT '1' COMMENT '用户类型   1正常用户 2带单老师',
  `type` tinyint(3) DEFAULT '1' COMMENT '1正式用户 2营销用户 3体验用户',
  `mobile` varchar(50) DEFAULT NULL COMMENT '手机号用于登陆',
  `passwd` varchar(96) CHARACTER SET utf8 NOT NULL COMMENT '登陆密码',
  `paywd` varchar(96) CHARACTER SET utf8 NOT NULL COMMENT '支付密码',
  `level` int(11) DEFAULT '1' COMMENT '用户等级',
  `id_card` varchar(18) CHARACTER SET utf8 DEFAULT NULL COMMENT '身份证号码',
  `name` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '姓名',
  `nick_name` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '昵称',
  `id_auth` tinyint(1) NOT NULL DEFAULT '0' COMMENT '身份证是否通过校验 0 处理中  1通过 2 错误',
  `create_ip` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '注册IP',
  `create_time` varchar(50) DEFAULT NULL COMMENT '注册时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0： 禁止登录  1 ：正常使用  ',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除 1 已删除或注销',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后一次登录时间',
  `last_login_ip` varchar(50) NOT NULL DEFAULT '0' COMMENT '最近登录ip',
  `urgent_name` varchar(24) CHARACTER SET utf8 DEFAULT NULL COMMENT '紧急联系人姓名',
  `urgent_mobile` bigint(20) DEFAULT NULL COMMENT '紧急联系人手机号',
  `pid` int(11) DEFAULT '0' COMMENT '所属上级的代理ID',
  `card_pic` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '身份证图片',
  `agent_far` int(10) unsigned DEFAULT '0' COMMENT '上级代理id 0：没有上级id',
  `agent_pro` tinyint(4) DEFAULT '0' COMMENT '代理状态 0：禁用 1：正常使用',
  `agent_id` int(11) DEFAULT '0' COMMENT '代理商id 0：非代理',
  `agent_rate` int(11) DEFAULT '0' COMMENT '代理商返佣比例',
  `agent_time` int(11) DEFAULT '0' COMMENT '返佣期限',
  `auth_time` int(11) DEFAULT NULL COMMENT '实名认证申请时间',
  `pei_time` int(11) DEFAULT '0' COMMENT '配额到期时间',
  `is_pei` tinyint(3) DEFAULT '0' COMMENT '0 未使用  1已使用',
  `head_img` text CHARACTER SET utf8 COMMENT '用户头像',
  `card_pic_back` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `card_pic_hand` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `domain` varchar(35) CHARACTER SET utf8 DEFAULT '',
  `remark` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `group_id` int(10) unsigned DEFAULT '0',
  `group_set` tinyint(4) DEFAULT '0' COMMENT '1为管理员分配用户组，系统不自动更新',
  `recharge` bigint(20) DEFAULT '0' COMMENT '单位分',
  `recomed` varchar(50) DEFAULT NULL COMMENT '邀请码',
  `macid` varchar(100) CHARACTER SET utf8 DEFAULT '' COMMENT '设备唯一识别码',
  `label` varchar(100) DEFAULT NULL COMMENT '带单老师标签',
  `label2` varchar(255) DEFAULT NULL COMMENT '带单老师标签2',
  `single_name` varchar(255) DEFAULT NULL COMMENT '老师姓名',
  `company` varchar(500) DEFAULT NULL COMMENT '所属公司',
  `time` varchar(100) DEFAULT NULL COMMENT '从业市场',
  `content` varchar(500) DEFAULT NULL COMMENT '老师介绍',
  `single_type` tinyint(3) DEFAULT '1' COMMENT '1稳健收益  2激进收益',
  `is_true` tinyint(3) unsigned DEFAULT '1' COMMENT '是否分红  1分红 0不分红',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobile` (`mobile`),
  KEY `name` (`name`),
  KEY `agent_far` (`agent_far`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='会员信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_member`
--

LOCK TABLES `st_member` WRITE;
/*!40000 ALTER TABLE `st_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_member_bank`
--

DROP TABLE IF EXISTS `st_member_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_member_bank` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mid` int(10) unsigned NOT NULL COMMENT '会员id',
  `card` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '银行卡号',
  `bank` varchar(25) CHARACTER SET utf8 DEFAULT NULL COMMENT '所属银行',
  `bank_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '银行名称',
  `branch` varchar(60) CHARACTER SET utf8 DEFAULT NULL COMMENT '分行',
  `province` varchar(6) CHARACTER SET utf8 DEFAULT NULL COMMENT '省',
  `city` varchar(6) CHARACTER SET utf8 DEFAULT NULL COMMENT '市',
  `create_ip` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `mobile` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '预留手机',
  `real_name` char(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '真实姓名',
  `card_pic_head` varchar(500) DEFAULT NULL COMMENT '身份证 正面',
  `card_pic_back` varchar(500) DEFAULT NULL COMMENT '身份证 反面',
  `status` tinyint(3) DEFAULT '0' COMMENT '0 待审核 1通过 2驳回',
  `remark` varchar(255) DEFAULT NULL COMMENT '驳回备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员银行卡';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_member_bank`
--

LOCK TABLES `st_member_bank` WRITE;
/*!40000 ALTER TABLE `st_member_bank` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_member_bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_member_card`
--

DROP TABLE IF EXISTS `st_member_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_member_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `card_num` varchar(200) DEFAULT NULL COMMENT '身份证号',
  `real_name` varchar(200) DEFAULT NULL COMMENT '真实姓名',
  `card_pic_head` text COMMENT '身份证正面',
  `card_pic_back` text COMMENT '身份证反面',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0待审核。1通过。2驳回',
  `create_time` int(11) DEFAULT NULL COMMENT '提交时间',
  `auth_time` int(11) DEFAULT NULL COMMENT '审核时间',
  `remark` varchar(200) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL COMMENT '活体认证token',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户身份证信息实名表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_member_card`
--

LOCK TABLES `st_member_card` WRITE;
/*!40000 ALTER TABLE `st_member_card` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_member_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_member_commission`
--

DROP TABLE IF EXISTS `st_member_commission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_member_commission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `send_uid` int(11) DEFAULT NULL COMMENT '触发返佣用户id',
  `type` tinyint(3) DEFAULT '1' COMMENT '1.2收益分佣 3团队分红',
  `money` decimal(15,2) DEFAULT '0.00' COMMENT '金额',
  `is_return` tinyint(3) DEFAULT '0' COMMENT '0未返佣  1已返佣',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注描述',
  `create_time` int(11) DEFAULT NULL,
  `auth_time` int(11) DEFAULT NULL COMMENT '结算时间 （结算返佣时间）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户分佣记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_member_commission`
--

LOCK TABLES `st_member_commission` WRITE;
/*!40000 ALTER TABLE `st_member_commission` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_member_commission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_member_group`
--

DROP TABLE IF EXISTS `st_member_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_member_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) CHARACTER SET utf8 NOT NULL,
  `descript` varchar(250) CHARACTER SET utf8 NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `recharge` varchar(200) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_member_group`
--

LOCK TABLES `st_member_group` WRITE;
/*!40000 ALTER TABLE `st_member_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_member_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_member_invitation_record`
--

DROP TABLE IF EXISTS `st_member_invitation_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_member_invitation_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mid` int(11) NOT NULL DEFAULT '0' COMMENT '邀请人member_id',
  `money` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '奖励金额(分)',
  `remark` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '备注',
  `create_time` int(11) NOT NULL COMMENT '奖励时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='邀请奖励记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_member_invitation_record`
--

LOCK TABLES `st_member_invitation_record` WRITE;
/*!40000 ALTER TABLE `st_member_invitation_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_member_invitation_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_member_invitation_relation`
--

DROP TABLE IF EXISTS `st_member_invitation_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_member_invitation_relation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invitation_mid` int(11) NOT NULL COMMENT '被邀请人id',
  `mid` int(11) NOT NULL COMMENT '邀请人id',
  `agent_id` tinyint(4) NOT NULL DEFAULT '0' COMMENT '代理级别',
  `create_time` int(11) NOT NULL COMMENT '邀请时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='邀请人与会员关系表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_member_invitation_relation`
--

LOCK TABLES `st_member_invitation_relation` WRITE;
/*!40000 ALTER TABLE `st_member_invitation_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_member_invitation_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_member_level`
--

DROP TABLE IF EXISTS `st_member_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_member_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL COMMENT '等级名称',
  `money` decimal(15,2) DEFAULT '0.00' COMMENT '下级交易额  资金流水',
  `recharge_num` int(11) DEFAULT '1' COMMENT '有效下级充值人数',
  `active` int(11) DEFAULT '1' COMMENT '有效活跃人数',
  `lv` decimal(10,4) DEFAULT '0.0000' COMMENT '团队收益分红 比例',
  `status` tinyint(3) DEFAULT '1' COMMENT '0 禁用 1 启用',
  `invite_num` int(11) DEFAULT '0' COMMENT '直属邀请人数',
  `min_team_num` int(11) DEFAULT '0' COMMENT '团队总人数',
  `max_team_num` int(11) NOT NULL,
  `toatl_money` decimal(15,2) DEFAULT '0.00' COMMENT '团队总资产',
  `is_true` tinyint(3) unsigned DEFAULT '1' COMMENT '1 开启分红  0禁止分红',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户等级分佣表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_member_level`
--

LOCK TABLES `st_member_level` WRITE;
/*!40000 ALTER TABLE `st_member_level` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_member_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_member_message`
--

DROP TABLE IF EXISTS `st_member_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_member_message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mid` int(11) NOT NULL COMMENT '用户MID',
  `title` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '标题',
  `info` text CHARACTER SET utf8 NOT NULL COMMENT '消息内容',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '查看状态 （1 已查看）',
  `type` tinyint(4) NOT NULL COMMENT '状态（备用）',
  `create_time` int(11) NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='会员消息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_member_message`
--

LOCK TABLES `st_member_message` WRITE;
/*!40000 ALTER TABLE `st_member_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_member_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_money`
--

DROP TABLE IF EXISTS `st_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_money` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `account` decimal(30,0) unsigned DEFAULT NULL COMMENT '账户金额(单位 分)',
  `freeze` decimal(20,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '冻结金额(单位 分)',
  `operate_account` float unsigned NOT NULL DEFAULT '0' COMMENT '操盘总资金总额(单位 分)',
  `bond_account` float unsigned NOT NULL DEFAULT '0' COMMENT '保证金总额(单位 分)',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否冻结 1 正常 0冻结账户',
  `give_fee` float unsigned DEFAULT '0',
  `freeze_give_fee` float unsigned NOT NULL DEFAULT '0',
  `single_money` decimal(15,2) unsigned DEFAULT '0.00' COMMENT '用户跟投账户资金',
  `pei_money` decimal(30,0) DEFAULT NULL COMMENT '配额金额',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员资金表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_money`
--

LOCK TABLES `st_money` WRITE;
/*!40000 ALTER TABLE `st_money` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_money` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_money_givefee`
--

DROP TABLE IF EXISTS `st_money_givefee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_money_givefee` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mid` int(10) unsigned NOT NULL COMMENT '交易用户id',
  `affect` bigint(20) NOT NULL DEFAULT '0' COMMENT '影响金额',
  `remain` bigint(20) NOT NULL DEFAULT '0' COMMENT '剩余管理费',
  `type` varchar(20) CHARACTER SET utf8 NOT NULL COMMENT '资金类型',
  `info` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '详情',
  `create_time` int(11) NOT NULL COMMENT '交易时间',
  `create_ip` varchar(50) DEFAULT NULL COMMENT '交易IP',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='资金操作记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_money_givefee`
--

LOCK TABLES `st_money_givefee` WRITE;
/*!40000 ALTER TABLE `st_money_givefee` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_money_givefee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_money_recharge`
--

DROP TABLE IF EXISTS `st_money_recharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_money_recharge` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_no` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '订单号',
  `mid` int(11) NOT NULL COMMENT '用户id',
  `money` decimal(20,0) DEFAULT NULL COMMENT '充值金额(单位 分)',
  `type` char(15) CHARACTER SET utf8 NOT NULL COMMENT '充值方式',
  `fee` int(11) NOT NULL DEFAULT '0' COMMENT '充值手续费（预留 单位 分）',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '提交时间',
  `create_ip` varchar(50) NOT NULL COMMENT 'ip',
  `line_bank` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '0' COMMENT '线下支付银行信息',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0待处理 1 成功 2 失败',
  `receipt_img` text CHARACTER SET utf8 COMMENT '充值凭证图片地址',
  `charge_type_id` int(11) DEFAULT NULL COMMENT '平台对公账号id',
  `form_name` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '转账人',
  `create_day` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `pay_name` varchar(255) DEFAULT NULL,
  `channel_id` varchar(255) DEFAULT NULL COMMENT '三方支付订单号',
  `is_admin` tinyint(3) DEFAULT '0' COMMENT '0自主充值 1后台上分',
  PRIMARY KEY (`id`),
  KEY `mid` (`mid`),
  KEY `type` (`type`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员资金充值记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_money_recharge`
--

LOCK TABLES `st_money_recharge` WRITE;
/*!40000 ALTER TABLE `st_money_recharge` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_money_recharge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_money_record`
--

DROP TABLE IF EXISTS `st_money_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_money_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mid` int(10) unsigned NOT NULL COMMENT '交易用户id',
  `affect` decimal(20,0) DEFAULT NULL COMMENT '影响金额',
  `account` decimal(30,0) DEFAULT NULL COMMENT '账户余额',
  `fee_affect` bigint(20) NOT NULL DEFAULT '0' COMMENT '影响管理费',
  `fee_remain` bigint(20) NOT NULL DEFAULT '0' COMMENT '管理费余额',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '资金类型',
  `info` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '详情',
  `remark` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `create_time` int(11) NOT NULL COMMENT '交易时间',
  `create_ip` varchar(50) DEFAULT NULL COMMENT '交易IP',
  `order_sn` varchar(100) DEFAULT NULL COMMENT '跟投订单号',
  PRIMARY KEY (`id`),
  KEY `mid` (`mid`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='资金操作记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_money_record`
--

LOCK TABLES `st_money_record` WRITE;
/*!40000 ALTER TABLE `st_money_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_money_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_money_transfer`
--

DROP TABLE IF EXISTS `st_money_transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_money_transfer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_no` varchar(32) CHARACTER SET utf8 NOT NULL COMMENT '订单号',
  `mid` int(11) NOT NULL COMMENT '会员id',
  `money` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '转账金额',
  `user_id` int(10) unsigned NOT NULL COMMENT '管理员id',
  `create_time` int(11) NOT NULL COMMENT '添加时间',
  `create_ip` varchar(50) DEFAULT NULL COMMENT '添加ip',
  `info` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '信息说明',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_money_transfer`
--

LOCK TABLES `st_money_transfer` WRITE;
/*!40000 ALTER TABLE `st_money_transfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_money_transfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_money_withdraw`
--

DROP TABLE IF EXISTS `st_money_withdraw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_money_withdraw` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mid` int(11) NOT NULL COMMENT '用户id',
  `order_no` varchar(32) CHARACTER SET utf8 NOT NULL COMMENT '订单号',
  `money` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '提现资金(单位 分)',
  `fee` int(11) NOT NULL DEFAULT '0' COMMENT '手续费(单位 分)',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '提现状态0处理中 1 提现成功 2 提现失败 3提现退回 4代付中',
  `bank` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '提现银行卡信息',
  `bank_code` varchar(255) DEFAULT NULL COMMENT '银行编码',
  `real_name` varchar(255) DEFAULT NULL COMMENT '持卡人姓名',
  `card` varchar(255) DEFAULT NULL COMMENT '卡号',
  `branch` varchar(255) DEFAULT NULL COMMENT '支行',
  `pay_id` int(11) DEFAULT '0' COMMENT '通道id',
  `create_time` int(11) NOT NULL COMMENT '提现时间',
  `create_ip` varchar(50) DEFAULT NULL COMMENT '申请IP',
  `create_day` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `pay_name` varchar(255) DEFAULT NULL COMMENT '支付名称',
  `channel_id` varchar(255) DEFAULT NULL COMMENT '支付通道订单号',
  `pay_msg` varchar(500) DEFAULT NULL COMMENT '通道同步返回错误信息',
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mid` (`mid`),
  KEY `order_no` (`order_no`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='资金提现记录标';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_money_withdraw`
--

LOCK TABLES `st_money_withdraw` WRITE;
/*!40000 ALTER TABLE `st_money_withdraw` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_money_withdraw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_opinion`
--

DROP TABLE IF EXISTS `st_opinion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_opinion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '用户id',
  `mobile` varchar(100) DEFAULT NULL COMMENT '用户',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `content` text COMMENT '描述',
  `image` text,
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='意见反馈表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_opinion`
--

LOCK TABLES `st_opinion` WRITE;
/*!40000 ALTER TABLE `st_opinion` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_opinion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_packet_wechat_area`
--

DROP TABLE IF EXISTS `st_packet_wechat_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_packet_wechat_area` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `country` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '国家名称',
  `province` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '省份名称',
  `city` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '城市名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=482 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='地区信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_packet_wechat_area`
--

LOCK TABLES `st_packet_wechat_area` WRITE;
/*!40000 ALTER TABLE `st_packet_wechat_area` DISABLE KEYS */;
INSERT INTO `st_packet_wechat_area` VALUES (1,'中国','四川','凉山'),(2,'中国','四川','资阳'),(3,'中国','四川','成都'),(4,'中国','四川','自贡'),(5,'中国','四川','泸州'),(6,'中国','四川','攀枝花'),(7,'中国','四川','绵阳'),(8,'中国','四川','德阳'),(9,'中国','四川','遂宁'),(10,'中国','四川','广元'),(11,'中国','四川','乐山'),(12,'中国','四川','内江'),(13,'中国','四川','南充'),(14,'中国','四川','宜宾'),(15,'中国','四川','眉山'),(16,'中国','四川','达州'),(17,'中国','四川','广安'),(18,'中国','四川','巴中'),(19,'中国','四川','雅安'),(20,'中国','四川','甘孜'),(21,'中国','四川','阿坝'),(22,'中国','重庆','酉阳'),(23,'中国','重庆','彭水'),(24,'中国','重庆','合川'),(25,'中国','重庆','永川'),(26,'中国','重庆','江津'),(27,'中国','重庆','南川'),(28,'中国','重庆','铜梁'),(29,'中国','重庆','大足'),(30,'中国','重庆','荣昌'),(31,'中国','重庆','璧山'),(32,'中国','重庆','长寿'),(33,'中国','重庆','綦江'),(34,'中国','重庆','潼南'),(35,'中国','重庆','梁平'),(36,'中国','重庆','城口'),(37,'中国','重庆','石柱'),(38,'中国','重庆','秀山'),(39,'中国','重庆','万州'),(40,'中国','重庆','渝中'),(41,'中国','重庆','涪陵'),(42,'中国','重庆','江北'),(43,'中国','重庆','大渡口'),(44,'中国','重庆','九龙坡'),(45,'中国','重庆','沙坪坝'),(46,'中国','重庆','北碚'),(47,'中国','重庆','南岸'),(48,'中国','重庆','黔江'),(49,'中国','重庆','巫溪'),(50,'中国','重庆','双桥'),(51,'中国','重庆','万盛'),(52,'中国','重庆','巴南'),(53,'中国','重庆','渝北'),(54,'中国','重庆','忠县'),(55,'中国','重庆','武隆'),(56,'中国','重庆','垫江'),(57,'中国','重庆','丰都'),(58,'中国','重庆','巫山'),(59,'中国','重庆','奉节'),(60,'中国','重庆','云阳'),(61,'中国','重庆','开县'),(62,'中国','陕西','商洛'),(63,'中国','陕西','西安'),(64,'中国','陕西','宝鸡'),(65,'中国','陕西','铜川'),(66,'中国','陕西','渭南'),(67,'中国','陕西','咸阳'),(68,'中国','陕西','汉中'),(69,'中国','陕西','延安'),(70,'中国','陕西','安康'),(71,'中国','陕西','榆林'),(72,'中国','甘肃','定西'),(73,'中国','甘肃','庆阳'),(74,'中国','甘肃','陇南'),(75,'中国','甘肃','甘南'),(76,'中国','甘肃','临夏'),(77,'中国','甘肃','兰州'),(78,'中国','甘肃','金昌'),(79,'中国','甘肃','嘉峪关'),(80,'中国','甘肃','天水'),(81,'中国','甘肃','白银'),(82,'中国','甘肃','张掖'),(83,'中国','甘肃','武威'),(84,'中国','甘肃','酒泉'),(85,'中国','甘肃','平凉'),(86,'中国','青海','海南'),(87,'中国','青海','果洛'),(88,'中国','青海','玉树'),(89,'中国','青海','海东'),(90,'中国','青海','海北'),(91,'中国','青海','黄南'),(92,'中国','青海','海西'),(93,'中国','青海','西宁'),(94,'中国','宁夏','银川'),(95,'中国','宁夏','吴忠'),(96,'中国','宁夏','石嘴山'),(97,'中国','宁夏','中卫'),(98,'中国','宁夏','固原'),(99,'中国','云南','红河'),(100,'中国','云南','文山'),(101,'中国','云南','楚雄'),(102,'中国','云南','怒江'),(103,'中国','云南','德宏'),(104,'中国','云南','西双版纳'),(105,'中国','云南','大理'),(106,'中国','云南','迪庆'),(107,'中国','云南','昆明'),(108,'中国','云南','曲靖'),(109,'中国','云南','保山'),(110,'中国','云南','玉溪'),(111,'中国','云南','丽江'),(112,'中国','云南','昭通'),(113,'中国','云南','临沧'),(114,'中国','云南','普洱'),(115,'中国','澳门',''),(116,'中国','香港',''),(117,'中国','贵州','毕节'),(118,'中国','贵州','黔东南'),(119,'中国','贵州','黔南'),(120,'中国','贵州','铜仁'),(121,'中国','贵州','黔西南'),(122,'中国','贵州','贵阳'),(123,'中国','贵州','遵义'),(124,'中国','贵州','六盘水'),(125,'中国','贵州','安顺'),(126,'中国','辽宁','盘锦'),(127,'中国','辽宁','辽阳'),(128,'中国','辽宁','朝阳'),(129,'中国','辽宁','铁岭'),(130,'中国','辽宁','葫芦岛'),(131,'中国','辽宁','沈阳'),(132,'中国','辽宁','鞍山'),(133,'中国','辽宁','大连'),(134,'中国','辽宁','本溪'),(135,'中国','辽宁','抚顺'),(136,'中国','辽宁','锦州'),(137,'中国','辽宁','丹东'),(138,'中国','辽宁','阜新'),(139,'中国','辽宁','营口'),(140,'中国','吉林','延边'),(141,'中国','吉林','长春'),(142,'中国','吉林','四平'),(143,'中国','吉林','吉林'),(144,'中国','吉林','通化'),(145,'中国','吉林','辽源'),(146,'中国','吉林','松原'),(147,'中国','吉林','白山'),(148,'中国','吉林','白城'),(149,'中国','黑龙江','黑河'),(150,'中国','黑龙江','牡丹江'),(151,'中国','黑龙江',' 绥化'),(152,'中国','黑龙江','哈尔滨'),(153,'中国','黑龙江','大兴安岭'),(154,'中国','黑龙江','鸡西'),(155,'中国','黑龙江','齐齐哈尔'),(156,'中国','黑龙江','双鸭山'),(157,'中国','黑龙江','鹤岗'),(158,'中国','黑龙江','伊春'),(159,'中国','黑龙江','大庆'),(160,'中国','黑龙江','七台河'),(161,'中国','黑龙江','佳木斯'),(162,'中国','海南','乐东'),(163,'中国','海南','昌江'),(164,'中国','海南','白沙'),(165,'中国','海南','西沙'),(166,'中国','海南','琼中'),(167,'中国','海南','保亭'),(168,'中国','海南','陵水'),(169,'中国','海南','中沙'),(170,'中国','海南','南沙'),(171,'中国','海南','海口'),(172,'中国','海南','三亚'),(173,'中国','海南','五指山'),(174,'中国','海南','儋州'),(175,'中国','海南','琼海'),(176,'中国','海南','文昌'),(177,'中国','海南','东方'),(178,'中国','海南','万宁'),(179,'中国','海南','定安'),(180,'中国','海南','屯昌'),(181,'中国','海南','澄迈'),(182,'中国','海南','临高'),(183,'中国','广东','揭阳'),(184,'中国','广东','中山'),(185,'中国','广东','广州'),(186,'中国','广东','深圳'),(187,'中国','广东','韶关'),(188,'中国','广东','汕头'),(189,'中国','广东','珠海'),(190,'中国','广东','江门'),(191,'中国','广东','佛山'),(192,'中国','广东','茂名'),(193,'中国','广东','湛江'),(194,'中国','广东','惠州'),(195,'中国','广东','肇庆'),(196,'中国','广东','汕尾'),(197,'中国','广东','梅州'),(198,'中国','广东','阳江'),(199,'中国','广东','河源'),(200,'中国','广东','东莞'),(201,'中国','广东','清远'),(202,'中国','广东','潮州'),(203,'中国','广东','云浮'),(204,'中国','广西','贺州'),(205,'中国','广西','百色'),(206,'中国','广西','来宾'),(207,'中国','广西','河池'),(208,'中国','广西','崇左'),(209,'中国','广西','南宁'),(210,'中国','广西','桂林'),(211,'中国','广西','柳州'),(212,'中国','广西','北海'),(213,'中国','广西','梧州'),(214,'中国','广西','钦州'),(215,'中国','广西','防城港'),(216,'中国','广西','玉林'),(217,'中国','广西','贵港'),(218,'中国','湖北','黄冈'),(219,'中国','湖北','荆州'),(220,'中国','湖北','随州'),(221,'中国','湖北','咸宁'),(222,'中国','湖北','神农架'),(223,'中国','湖北','恩施'),(224,'中国','湖北','武汉'),(225,'中国','湖北','十堰'),(226,'中国','湖北','黄石'),(227,'中国','湖北','宜昌'),(228,'中国','湖北','鄂州'),(229,'中国','湖北','襄樊'),(230,'中国','湖北','孝感'),(231,'中国','湖北','荆门'),(232,'中国','湖北','潜江'),(233,'中国','湖北','仙桃'),(234,'中国','湖北','天门'),(235,'中国','湖南','永州'),(236,'中国','湖南','郴州'),(237,'中国','湖南','娄底'),(238,'中国','湖南','怀化'),(239,'中国','湖南','湘西'),(240,'中国','湖南','长沙'),(241,'中国','湖南','湘潭'),(242,'中国','湖南','株洲'),(243,'中国','湖南','邵阳'),(244,'中国','湖南','衡阳'),(245,'中国','湖南','常德'),(246,'中国','湖南','岳阳'),(247,'中国','湖南','益阳'),(248,'中国','湖南','张家界'),(249,'中国','河南','漯河'),(250,'中国','河南','许昌'),(251,'中国','河南','南阳'),(252,'中国','河南','三门峡'),(253,'中国','河南','信阳'),(254,'中国','河南','商丘'),(255,'中国','河南','驻马店'),(256,'中国','河南','周口'),(257,'中国','河南','济源'),(258,'中国','河南','郑州'),(259,'中国','河南','洛阳'),(260,'中国','河南','开封'),(261,'中国','河南','安阳'),(262,'中国','河南','平顶山'),(263,'中国','河南','新乡'),(264,'中国','河南','鹤壁'),(265,'中国','河南','濮阳'),(266,'中国','河南','焦作'),(267,'中国','台湾','屏东县'),(268,'中国','台湾','澎湖县'),(269,'中国','台湾','台东县'),(270,'中国','台湾','花莲县'),(271,'中国','台湾','台北市'),(272,'中国','台湾','基隆市'),(273,'中国','台湾','高雄市'),(274,'中国','台湾','台南市'),(275,'中国','台湾','台中市'),(276,'中国','台湾','嘉义市'),(277,'中国','台湾','新竹市'),(278,'中国','台湾','宜兰县'),(279,'中国','台湾','台北县'),(280,'中国','台湾','新竹县'),(281,'中国','台湾','桃园县'),(282,'中国','台湾','台中县'),(283,'中国','台湾','苗栗县'),(284,'中国','台湾','南投县'),(285,'中国','台湾','彰化县'),(286,'中国','台湾','嘉义县'),(287,'中国','台湾','云林县'),(288,'中国','台湾','高雄县'),(289,'中国','台湾','台南县'),(290,'中国','北京','房山'),(291,'中国','北京','大兴'),(292,'中国','北京','顺义'),(293,'中国','北京','通州'),(294,'中国','北京','昌平'),(295,'中国','北京','密云'),(296,'中国','北京','平谷'),(297,'中国','北京','延庆'),(298,'中国','北京','东城'),(299,'中国','北京','怀柔'),(300,'中国','北京','崇文'),(301,'中国','北京','西城'),(302,'中国','北京','朝阳'),(303,'中国','北京','宣武'),(304,'中国','北京','石景山'),(305,'中国','北京','丰台'),(306,'中国','北京','门头沟'),(307,'中国','北京','海淀'),(308,'中国','河北','衡水'),(309,'中国','河北','廊坊'),(310,'中国','河北','石家庄'),(311,'中国','河北','秦皇岛'),(312,'中国','河北','唐山'),(313,'中国','河北','邢台'),(314,'中国','河北','邯郸'),(315,'中国','河北','张家口'),(316,'中国','河北','保定'),(317,'中国','河北','沧州'),(318,'中国','河北','承德'),(319,'中国','天津','西青'),(320,'中国','天津','东丽'),(321,'中国','天津','北辰'),(322,'中国','天津','津南'),(323,'中国','天津','宁河'),(324,'中国','天津','武清'),(325,'中国','天津','静海'),(326,'中国','天津','宝坻'),(327,'中国','天津','和平'),(328,'中国','天津','河西'),(329,'中国','天津','河东'),(330,'中国','天津','河北'),(331,'中国','天津','南开'),(332,'中国','天津','塘沽'),(333,'中国','天津','红桥'),(334,'中国','天津','大港'),(335,'中国','天津','汉沽'),(336,'中国','天津','蓟县'),(337,'中国','内蒙古','锡林郭勒'),(338,'中国','内蒙古','兴安'),(339,'中国','内蒙古','阿拉善'),(340,'中国','内蒙古','呼和浩特'),(341,'中国','内蒙古','乌海'),(342,'中国','内蒙古','包头'),(343,'中国','内蒙古','通辽'),(344,'中国','内蒙古','赤峰'),(345,'中国','内蒙古','呼伦贝尔'),(346,'中国','内蒙古','鄂尔多斯'),(347,'中国','内蒙古','乌兰察布'),(348,'中国','内蒙古','巴彦淖尔'),(349,'中国','山西','吕梁'),(350,'中国','山西','临汾'),(351,'中国','山西','太原'),(352,'中国','山西','阳泉'),(353,'中国','山西','大同'),(354,'中国','山西','晋城'),(355,'中国','山西','长治'),(356,'中国','山西','晋中'),(357,'中国','山西','朔州'),(358,'中国','山西','忻州'),(359,'中国','山西','运城'),(360,'中国','浙江','丽水'),(361,'中国','浙江','台州'),(362,'中国','浙江','杭州'),(363,'中国','浙江','温州'),(364,'中国','浙江','宁波'),(365,'中国','浙江','湖州'),(366,'中国','浙江','嘉兴'),(367,'中国','浙江','金华'),(368,'中国','浙江','绍兴'),(369,'中国','浙江','舟山'),(370,'中国','浙江','衢州'),(371,'中国','江苏','镇江'),(372,'中国','江苏','扬州'),(373,'中国','江苏','宿迁'),(374,'中国','江苏','泰州'),(375,'中国','江苏','南京'),(376,'中国','江苏','徐州'),(377,'中国','江苏','无锡'),(378,'中国','江苏','苏州'),(379,'中国','江苏','常州'),(380,'中国','江苏','连云港'),(381,'中国','江苏','南通'),(382,'中国','江苏','盐城'),(383,'中国','江苏','淮安'),(384,'中国','上海','杨浦'),(385,'中国','上海','南汇'),(386,'中国','上海','宝山'),(387,'中国','上海','闵行'),(388,'中国','上海','浦东新'),(389,'中国','上海','嘉定'),(390,'中国','上海','松江'),(391,'中国','上海','金山'),(392,'中国','上海','崇明'),(393,'中国','上海','奉贤'),(394,'中国','上海','青浦'),(395,'中国','上海','黄浦'),(396,'中国','上海','卢湾'),(397,'中国','上海','长宁'),(398,'中国','上海','徐汇'),(399,'中国','上海','普陀'),(400,'中国','上海','静安'),(401,'中国','上海','虹口'),(402,'中国','上海','闸北'),(403,'中国','山东','日照'),(404,'中国','山东','威海'),(405,'中国','山东','临沂'),(406,'中国','山东','莱芜'),(407,'中国','山东','聊城'),(408,'中国','山东','德州'),(409,'中国','山东','菏泽'),(410,'中国','山东','滨州'),(411,'中国','山东','济南'),(412,'中国','山东','淄博'),(413,'中国','山东','青岛'),(414,'中国','山东','东营'),(415,'中国','山东','枣庄'),(416,'中国','山东','潍坊'),(417,'中国','山东','烟台'),(418,'中国','山东','泰安'),(419,'中国','山东','济宁'),(420,'中国','江西','上饶'),(421,'中国','江西','抚州'),(422,'中国','江西','南昌'),(423,'中国','江西','萍乡'),(424,'中国','江西','景德镇'),(425,'中国','江西','新余'),(426,'中国','江西','九江'),(427,'中国','江西','赣州'),(428,'中国','江西','鹰潭'),(429,'中国','江西','宜春'),(430,'中国','江西','吉安'),(431,'中国','福建','福州'),(432,'中国','福建','莆田'),(433,'中国','福建','厦门'),(434,'中国','福建','泉州'),(435,'中国','福建','三明'),(436,'中国','福建','南平'),(437,'中国','福建','漳州'),(438,'中国','福建','宁德'),(439,'中国','福建','龙岩'),(440,'中国','安徽','滁州'),(441,'中国','安徽','黄山'),(442,'中国','安徽','宿州'),(443,'中国','安徽','阜阳'),(444,'中国','安徽','六安'),(445,'中国','安徽','巢湖'),(446,'中国','安徽','池州'),(447,'中国','安徽','亳州'),(448,'中国','安徽','宣城'),(449,'中国','安徽','合肥'),(450,'中国','安徽','蚌埠'),(451,'中国','安徽','芜湖'),(452,'中国','安徽','马鞍山'),(453,'中国','安徽','淮南'),(454,'中国','安徽','铜陵'),(455,'中国','安徽','淮北'),(456,'中国','安徽','安庆'),(457,'中国','西藏','那曲'),(458,'中国','西藏','阿里'),(459,'中国','西藏','林芝'),(460,'中国','西藏','昌都'),(461,'中国','西藏','山南'),(462,'中国','西藏','日喀则'),(463,'中国','西藏','拉萨'),(464,'中国','新疆','博尔塔拉'),(465,'中国','新疆','吐鲁番'),(466,'中国','新疆','哈密'),(467,'中国','新疆','昌吉'),(468,'中国','新疆','和田'),(469,'中国','新疆','喀什'),(470,'中国','新疆','克孜勒苏'),(471,'中国','新疆','巴音郭楞'),(472,'中国','新疆','阿克苏'),(473,'中国','新疆','伊犁'),(474,'中国','新疆','塔城'),(475,'中国','新疆','乌鲁木齐'),(476,'中国','新疆','阿勒泰'),(477,'中国','新疆','克拉玛依'),(478,'中国','新疆','石河子'),(479,'中国','新疆','图木舒克'),(480,'中国','新疆','阿拉尔'),(481,'中国','新疆','五家渠');
/*!40000 ALTER TABLE `st_packet_wechat_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_send_sms`
--

DROP TABLE IF EXISTS `st_send_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_send_sms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mobile` varchar(20) CHARACTER SET utf8 NOT NULL,
  `ip1` varchar(20) CHARACTER SET utf8 DEFAULT '',
  `ip2` varchar(20) CHARACTER SET utf8 DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `addtime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_send_sms`
--

LOCK TABLES `st_send_sms` WRITE;
/*!40000 ALTER TABLE `st_send_sms` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_send_sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_single_addmoney`
--

DROP TABLE IF EXISTS `st_single_addmoney`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_single_addmoney` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `sub_id` int(11) DEFAULT NULL,
  `sub_account` varchar(100) DEFAULT NULL,
  `money` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '追投金额',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0待审核1通过 2驳回',
  `order_sn` varchar(100) DEFAULT NULL COMMENT '跟投订单号',
  `create_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='项目追投金额审核表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_single_addmoney`
--

LOCK TABLES `st_single_addmoney` WRITE;
/*!40000 ALTER TABLE `st_single_addmoney` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_single_addmoney` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_single_item`
--

DROP TABLE IF EXISTS `st_single_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_single_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `single_class` int(11) DEFAULT '1' COMMENT '项目类型 1新手跟投  2一键跟投',
  `title` varchar(255) DEFAULT NULL COMMENT '项目名称',
  `user_id` int(11) DEFAULT NULL COMMENT '带单老师ID',
  `with_name` varchar(255) DEFAULT NULL COMMENT '带单老师',
  `day` varchar(50) DEFAULT NULL COMMENT '项目周期（天）',
  `scale` decimal(10,2) DEFAULT '0.00' COMMENT '项目分成比例',
  `num` int(11) DEFAULT '0' COMMENT '项目人数 0 不限制',
  `is_money` tinyint(3) DEFAULT '0' COMMENT '投资金额  0 不限制  1限制',
  `min_money` varchar(100) DEFAULT NULL COMMENT '最低投资金额',
  `max_money` varchar(100) DEFAULT NULL COMMENT '最大投资金额',
  `type` tinyint(3) DEFAULT '1' COMMENT '项目类型  1现货  2合约',
  `is_up` tinyint(3) DEFAULT '0' COMMENT '追投  0不可追投 1可以追投',
  `is_contract` tinyint(3) DEFAULT '0' COMMENT '双向签约  1打开i  0关闭',
  `profit` decimal(15,2) DEFAULT '0.00' COMMENT '项目盈利',
  `level` int(11) DEFAULT '0' COMMENT '项目跟投会员下级人数限制',
  `status` tinyint(3) DEFAULT '1' COMMENT '1正常 0禁用',
  `user_level` varchar(100) DEFAULT NULL COMMENT '项目限制等级和金额',
  `create_time` int(11) DEFAULT NULL,
  `time_type` tinyint(4) DEFAULT '1' COMMENT '时间类型  1固定时间   2范围时间',
  `start_time` int(11) DEFAULT NULL COMMENT '范围时间   开始时间',
  `end_time` int(11) DEFAULT NULL COMMENT '范围时间   结束时间',
  `content` text COMMENT '跟单说明',
  `single_type` tinyint(3) DEFAULT '1' COMMENT '项目类型 1市价 2限价',
  `min_day` int(11) DEFAULT '0' COMMENT '最小持有天数',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='带单项目';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_single_item`
--

LOCK TABLES `st_single_item` WRITE;
/*!40000 ALTER TABLE `st_single_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_single_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_single_order`
--

DROP TABLE IF EXISTS `st_single_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_single_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `sub_id` int(11) DEFAULT '0' COMMENT '子账户id',
  `mobile` varchar(50) DEFAULT NULL,
  `order_sn` varchar(255) DEFAULT NULL COMMENT '订单号',
  `single_id` int(11) NOT NULL DEFAULT '0' COMMENT '项目id',
  `source_id` int(11) DEFAULT NULL COMMENT '信号源id',
  `single_type` tinyint(3) DEFAULT '1' COMMENT '1合约跟投 2现金跟投',
  `single_title` varchar(255) DEFAULT NULL COMMENT '项目名称',
  `single_day` int(11) DEFAULT '0' COMMENT '项目周期（天）',
  `scale` decimal(10,2) DEFAULT '0.00' COMMENT '分成比例',
  `direction` tinyint(3) DEFAULT '1' COMMENT '方向 1买涨  2买跌',
  `type` tinyint(3) DEFAULT '1' COMMENT '订单类型 1市价 2限价',
  `status` tinyint(3) DEFAULT '1' COMMENT '订单状态  1待审核 2已审核 3转入委托  4 未上车 5已撤销金额返回 6持仓卖出 订单完成',
  `deal_price` decimal(15,2) DEFAULT '0.00' COMMENT '成交价格',
  `volume` int(11) DEFAULT '0' COMMENT '成交数量',
  `money` decimal(20,0) DEFAULT NULL COMMENT '金额',
  `ying_money` decimal(20,0) DEFAULT NULL COMMENT '盈利金额',
  `withdraw_money` decimal(20,0) DEFAULT NULL COMMENT '提盈金额',
  `trust_time` int(11) DEFAULT '0' COMMENT '委托时间',
  `deal_time` int(11) DEFAULT '0' COMMENT '成交时间',
  `is_show` tinyint(3) DEFAULT '0' COMMENT '是否显示前端  0不显示  1显示',
  `sell_price` decimal(15,2) DEFAULT '0.00' COMMENT '卖出价格',
  `sell_time` int(11) DEFAULT '0' COMMENT '卖出时间',
  `stamp_duty` decimal(10,2) DEFAULT '0.00' COMMENT '印花税',
  `transfer_fee` decimal(15,2) DEFAULT '0.00' COMMENT '过户费',
  `commission` decimal(15,2) DEFAULT '0.00' COMMENT '净佣金',
  `transaction_fee` decimal(15,2) DEFAULT '0.00' COMMENT '交易费',
  `deal_status` tinyint(3) DEFAULT '1' COMMENT '订单收益状态  1 收益中  2已交割分佣   弃用',
  `out_time` int(11) DEFAULT '0' COMMENT '项目到期时间',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `auth_time` int(11) DEFAULT '0' COMMENT '审核时间',
  `end_time` int(11) DEFAULT '0' COMMENT '该项目订单结束时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_sn` (`order_sn`),
  KEY `user_id` (`user_id`),
  KEY `source_id` (`source_id`),
  KEY `single_id` (`single_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='跟投订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_single_order`
--

LOCK TABLES `st_single_order` WRITE;
/*!40000 ALTER TABLE `st_single_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_single_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_single_source`
--

DROP TABLE IF EXISTS `st_single_source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_single_source` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `single_id` int(11) DEFAULT NULL COMMENT '项目id',
  `single_class` tinyint(3) DEFAULT '1' COMMENT '信号源类型  1 买入信号  2卖出信号',
  `status` tinyint(3) DEFAULT '1' COMMENT '1 发布买入信号  2卖出信号（信号源完成）',
  `code` varchar(100) DEFAULT NULL COMMENT '股票编码',
  `code_name` varchar(50) DEFAULT NULL COMMENT '股票名称',
  `type` tinyint(3) DEFAULT '1' COMMENT '委托类型  1市价 2限价',
  `buy_price` decimal(10,2) DEFAULT '0.00' COMMENT '买入价格',
  `direction` tinyint(3) DEFAULT '1' COMMENT '委托方向 1 买涨 2买跌',
  `volume` decimal(10,2) DEFAULT '0.00' COMMENT '委托仓位',
  `trust_time` int(11) DEFAULT NULL COMMENT '委托时间',
  `single_type` tinyint(3) DEFAULT '0' COMMENT '信号源类型，1直接卖出，2委托卖出',
  `sell_time` int(11) DEFAULT NULL COMMENT '直接卖出时间（用户显示时间范围）',
  `sell_price` decimal(15,2) DEFAULT '0.00' COMMENT '卖出价格',
  `sell_price_scope` varchar(100) DEFAULT '1' COMMENT '卖出价格范围 前端显示',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `is_show` tinyint(3) DEFAULT '0' COMMENT '是否展示  0不展示 1展示',
  `buy_time` int(11) DEFAULT '0' COMMENT '信号源买入时间，',
  `sell_type` tinyint(4) DEFAULT '1' COMMENT '卖出类型    1市价 2限价',
  `sell_volume` decimal(10,2) DEFAULT '0.00' COMMENT '卖出仓位',
  PRIMARY KEY (`id`),
  KEY `single_id` (`single_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='后台发布信号源表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_single_source`
--

LOCK TABLES `st_single_source` WRITE;
/*!40000 ALTER TABLE `st_single_source` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_single_source` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_single_source_user`
--

DROP TABLE IF EXISTS `st_single_source_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_single_source_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '用户id',
  `single_order_sn` varchar(100) DEFAULT NULL COMMENT '跟投订单号',
  `order_id` int(11) DEFAULT NULL COMMENT '跟投订单id',
  `source_id` int(11) DEFAULT NULL COMMENT '信号源id',
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `single_order_sn` (`single_order_sn`),
  KEY `source_id` (`source_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='跟投订单与信号源中间表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_single_source_user`
--

LOCK TABLES `st_single_source_user` WRITE;
/*!40000 ALTER TABLE `st_single_source_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_single_source_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_single_type`
--

DROP TABLE IF EXISTS `st_single_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_single_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL COMMENT '项目类型名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='跟单项目类型';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_single_type`
--

LOCK TABLES `st_single_type` WRITE;
/*!40000 ALTER TABLE `st_single_type` DISABLE KEYS */;
INSERT INTO `st_single_type` VALUES (1,'新手跟投'),(2,'一键跟投');
/*!40000 ALTER TABLE `st_single_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_account`
--

DROP TABLE IF EXISTS `st_stock_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '证券账户ID',
  `stockjobber` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '证券公司',
  `stock_exchange` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '证券营业部',
  `lid` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '证券账户',
  `user` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '交易通账户',
  `pwd` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '交易密码',
  `communication_pwd` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '通讯密码',
  `commission_scale` decimal(15,2) DEFAULT NULL COMMENT '佣金比例（单位：万分之几） 如：5 代表万分之五',
  `min_commission` decimal(15,2) DEFAULT NULL COMMENT '最低佣金（单位：元）',
  `broker` int(11) NOT NULL DEFAULT '-1' COMMENT 'Broker是券商类型ID 如：32代表中信证券',
  `currency` char(10) NOT NULL DEFAULT 'CN' COMMENT 'CN：人民币；HK：港币',
  `net` int(11) DEFAULT '0' COMMENT '网络类型，0网络不确定、1中国电信、2中国联通、4中国移动、8华数、16其它网络',
  `sever` int(11) DEFAULT '2' COMMENT '指定服务类型，默认2 2:交易服务、 1: 普通行情、4: 扩展行情、8: Level2行情',
  `clienver` varchar(128) CHARACTER SET utf8 DEFAULT NULL COMMENT '券商客户端登录版本',
  `status` int(11) DEFAULT '1' COMMENT '是否可用 0：禁用 1：可用',
  `info` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '备注说明',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `type` int(11) DEFAULT '0' COMMENT '账户类型 默认0  0：模拟账户 1：实盘账户 ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='证券账户信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_account`
--

LOCK TABLES `st_stock_account` WRITE;
/*!40000 ALTER TABLE `st_stock_account` DISABLE KEYS */;
INSERT INTO `st_stock_account` VALUES (2,'模拟账户','模拟证券交易营业部','1111111','moni','123456','',3.00,5.00,-1,'CN',0,2,'1.00',1,NULL,'1970-01-01 08:33:38','2024-10-13 14:43:20',1),(3,'香港交投证券','香港交易所投资有限公司','888888','moni','123456',NULL,5.00,NULL,-1,'CN',0,2,NULL,0,NULL,'2024-05-24 21:50:00','2024-12-26 14:39:56',0);
/*!40000 ALTER TABLE `st_stock_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_account_info`
--

DROP TABLE IF EXISTS `st_stock_account_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_account_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `lid` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '交易账户名',
  `stock_account_id` int(11) NOT NULL COMMENT '外键ID stock_account表的ID',
  `soruce` varchar(100) CHARACTER SET utf8 DEFAULT '' COMMENT '证券来源',
  `user` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '交易通账户',
  `currency` tinyint(4) NOT NULL DEFAULT '0' COMMENT '币种',
  `balance` decimal(15,2) NOT NULL COMMENT '资金余额',
  `account_money` decimal(15,2) DEFAULT NULL COMMENT '可用资金',
  `freeze_money` decimal(15,2) DEFAULT NULL COMMENT '冻结资金',
  `desirable_money` decimal(15,2) DEFAULT NULL COMMENT '可取资金',
  `market_value` decimal(15,2) DEFAULT NULL COMMENT '最新市值',
  `total_money` decimal(15,2) DEFAULT NULL COMMENT '总资产',
  `ck_profit` decimal(15,2) DEFAULT NULL COMMENT '参考浮动盈亏',
  `info` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '保留信息',
  `sh_code` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '沪A股东代码',
  `sz_code` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '深A股东代码',
  `gudong_name` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '股东名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='交易账户信息查询存储表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_account_info`
--

LOCK TABLES `st_stock_account_info` WRITE;
/*!40000 ALTER TABLE `st_stock_account_info` DISABLE KEYS */;
INSERT INTO `st_stock_account_info` VALUES (2,'1111111',2,'模拟账户','moni',0,1000000000000.00,100000.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2223',NULL),(3,'222222',3,'模拟账户','22222',0,1000000.00,1000000.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `st_stock_account_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_addfinancing`
--

DROP TABLE IF EXISTS `st_stock_addfinancing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_addfinancing` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `uid` int(11) NOT NULL COMMENT '会员ID',
  `borrow_id` int(11) NOT NULL COMMENT '配资ID',
  `money` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '扩大配资金额',
  `rate` decimal(15,2) NOT NULL COMMENT '配资费率',
  `borrow_interest` decimal(15,2) NOT NULL COMMENT '配资管理费',
  `last_deposit_money` decimal(15,2) NOT NULL COMMENT '原始保证金总额',
  `last_borrow_money` decimal(15,2) NOT NULL COMMENT '原始配资总金额',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态 0：待审核 1：审核通过 2：审核未通过',
  `add_time` int(11) NOT NULL COMMENT '申请时间',
  `verify_time` int(11) DEFAULT NULL COMMENT '审核时间',
  `target_uid` int(11) DEFAULT NULL COMMENT '操作者ID',
  `target_name` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '操作者姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='扩大配资记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_addfinancing`
--

LOCK TABLES `st_stock_addfinancing` WRITE;
/*!40000 ALTER TABLE `st_stock_addfinancing` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_addfinancing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_addmoney`
--

DROP TABLE IF EXISTS `st_stock_addmoney`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_addmoney` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `borrow_id` int(11) NOT NULL COMMENT '配资ID',
  `uid` int(11) NOT NULL COMMENT '会员ID',
  `money` decimal(15,2) NOT NULL COMMENT '保证金',
  `status` tinyint(4) NOT NULL COMMENT '状态 0：待审核 ，1：审核通过，2：审核失败',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  `verify_time` int(11) NOT NULL COMMENT '审核时间',
  `target_uid` int(11) DEFAULT NULL COMMENT '操作者ID',
  `target_name` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '操作者姓名',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`borrow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='追加保证金记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_addmoney`
--

LOCK TABLES `st_stock_addmoney` WRITE;
/*!40000 ALTER TABLE `st_stock_addmoney` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_addmoney` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_bonus`
--

DROP TABLE IF EXISTS `st_stock_bonus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_bonus` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `code` varchar(10) CHARACTER SET utf8 NOT NULL COMMENT '证券代码',
  `name` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '证券名称',
  `zuan` float(16,3) DEFAULT '0.000' COMMENT '10股转增',
  `song` float(16,3) DEFAULT '0.000' COMMENT '10股送股',
  `bonus` float(16,3) DEFAULT '0.000' COMMENT '10股分红',
  `date` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '委托日期',
  `type` tinyint(4) DEFAULT NULL COMMENT '账号类别',
  `addtime` int(11) DEFAULT NULL COMMENT '操作时间',
  `info` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '保留信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='股票除权除息公告表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_bonus`
--

LOCK TABLES `st_stock_bonus` WRITE;
/*!40000 ALTER TABLE `st_stock_bonus` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_bonus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_bonus_dividend`
--

DROP TABLE IF EXISTS `st_stock_bonus_dividend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_bonus_dividend` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `mobile` varchar(12) CHARACTER SET utf8 DEFAULT NULL COMMENT '手机号',
  `uname` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '用户名',
  `sub_account` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '子账号',
  `code` varchar(10) CHARACTER SET utf8 NOT NULL COMMENT '证券代码',
  `name` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '证券名称',
  `zuan` float(16,3) DEFAULT '0.000' COMMENT '10股转增',
  `song` float(16,3) DEFAULT '0.000' COMMENT '10股送股',
  `bonus` float(16,3) DEFAULT '0.000' COMMENT '10股分红',
  `date` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '委托日期',
  `type` tinyint(4) DEFAULT NULL COMMENT '账号类别',
  `addtime` int(11) DEFAULT NULL COMMENT '添加时间',
  `position_id` int(11) NOT NULL COMMENT '持仓表ID号',
  `sub_id` int(11) NOT NULL COMMENT '子账户ID',
  `stock_count` int(11) DEFAULT NULL COMMENT '权利日实际持仓数量',
  `buy_average_price` decimal(15,3) DEFAULT NULL COMMENT '买入均价',
  `info` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '保留信息',
  `status` tinyint(4) DEFAULT NULL COMMENT '状态：1、未除权，2、已除权',
  `lid` varchar(255) CHARACTER SET utf8 DEFAULT '' COMMENT '交易账户名',
  `soruce` varchar(100) CHARACTER SET utf8 DEFAULT '' COMMENT '证券来源',
  `login_name` varchar(255) CHARACTER SET utf8 DEFAULT '' COMMENT '证券账户',
  `jigou_type` tinyint(4) DEFAULT NULL COMMENT '交易机构类别',
  `jiyisuo` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '交易所',
  `ex_count` int(11) DEFAULT '0' COMMENT '已卖出数量',
  `trade_time` int(11) DEFAULT NULL COMMENT '买入时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='股票已除权除息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_bonus_dividend`
--

LOCK TABLES `st_stock_bonus_dividend` WRITE;
/*!40000 ALTER TABLE `st_stock_bonus_dividend` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_bonus_dividend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_bonus_position`
--

DROP TABLE IF EXISTS `st_stock_bonus_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_bonus_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `code` varchar(10) CHARACTER SET utf8 NOT NULL COMMENT '证券代码',
  `name` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '证券名称',
  `zuan` float(16,6) DEFAULT '0.000000' COMMENT '10股转增',
  `song` float(16,6) DEFAULT '0.000000' COMMENT '10股送股',
  `bonus` float(16,6) DEFAULT '0.000000' COMMENT '10股分红',
  `date` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '委托日期',
  `type` tinyint(4) DEFAULT NULL COMMENT '账号类别',
  `addtime` int(11) DEFAULT NULL COMMENT '操作时间',
  `position_id` int(11) NOT NULL COMMENT '持仓表ID号',
  `sub_id` int(11) NOT NULL COMMENT '子账户ID',
  `stock_count` int(11) DEFAULT NULL COMMENT '权利日实际持仓数量',
  `buy_average_price` decimal(15,3) DEFAULT NULL COMMENT '买入均价',
  `info` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '保留信息',
  `status` tinyint(4) DEFAULT NULL COMMENT '状态：1、未除权，2、已除权',
  `lid` varchar(255) CHARACTER SET utf8 DEFAULT '' COMMENT '交易账户名',
  `soruce` varchar(100) CHARACTER SET utf8 DEFAULT '' COMMENT '证券来源',
  `login_name` varchar(255) CHARACTER SET utf8 DEFAULT '' COMMENT '证券账户',
  `jigou_type` tinyint(4) DEFAULT NULL COMMENT '交易机构类别',
  `jiyisuo` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '交易所',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='股票待除权除息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_bonus_position`
--

LOCK TABLES `st_stock_bonus_position` WRITE;
/*!40000 ALTER TABLE `st_stock_bonus_position` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_bonus_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_bonus_surplus`
--

DROP TABLE IF EXISTS `st_stock_bonus_surplus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_bonus_surplus` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sub_id` int(11) NOT NULL COMMENT '外键 子账户ID',
  `lid` varchar(255) CHARACTER SET utf8 DEFAULT '' COMMENT '交易账户名',
  `soruce` varchar(100) CHARACTER SET utf8 DEFAULT '' COMMENT '证券来源',
  `login_name` varchar(255) CHARACTER SET utf8 DEFAULT '' COMMENT '证券账户',
  `gupiao_code` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '证券代码',
  `gupiao_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '证券名称',
  `count` int(11) DEFAULT NULL COMMENT '证券数量',
  `stock_count` int(11) DEFAULT NULL COMMENT '实际持仓数量',
  `canbuy_count` int(11) DEFAULT NULL COMMENT '可卖数量',
  `ck_price` decimal(15,3) DEFAULT NULL COMMENT '参考成本价',
  `buy_average_price` decimal(15,3) DEFAULT NULL COMMENT '买入均价',
  `ck_profit_price` decimal(15,3) DEFAULT NULL COMMENT '参考盈亏成本价',
  `now_price` decimal(15,2) DEFAULT NULL COMMENT '当前价',
  `market_value` decimal(15,2) DEFAULT NULL COMMENT '最新市值',
  `ck_profit` decimal(15,2) DEFAULT NULL COMMENT '参考浮动盈亏',
  `profit_rate` decimal(15,2) DEFAULT NULL COMMENT '盈亏比例',
  `buying` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '在途买入 0、已经确认的持仓',
  `selling` varchar(50) CHARACTER SET utf8 DEFAULT '0' COMMENT '在途卖出 0、已经确认持仓 1、卖出待确认中',
  `gudong_code` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '股东代码',
  `type` tinyint(4) DEFAULT NULL COMMENT '账号类别',
  `jigou_type` tinyint(4) DEFAULT NULL COMMENT '交易机构类别',
  `jiyisuo` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '交易所',
  `info` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '保留信息',
  `beizhu` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='股票持仓存储表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_bonus_surplus`
--

LOCK TABLES `st_stock_bonus_surplus` WRITE;
/*!40000 ALTER TABLE `st_stock_bonus_surplus` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_bonus_surplus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_borrow`
--

DROP TABLE IF EXISTS `st_stock_borrow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_borrow` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `stock_subaccount_id` int(11) NOT NULL DEFAULT '0' COMMENT '外键 交易子账号的唯一主键ID',
  `sub_account` varchar(255) NOT NULL DEFAULT '' COMMENT '交易子账户',
  `order_id` varchar(15) NOT NULL DEFAULT '' COMMENT '配资单号',
  `member_id` int(11) NOT NULL COMMENT '外键 会员ID',
  `type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '配资类型 5:免费配资 1:按天配资 2:按周配资 3:按月配资 4:试用配资 6 跟投账户',
  `status` tinyint(4) NOT NULL DEFAULT '-1' COMMENT '配资状态 -1：待审核  0：未通过 1：使用中  2：已结束 3：已逾期 ',
  `deposit_money` int(11) NOT NULL DEFAULT '0' COMMENT '保证金',
  `multiple` tinyint(4) NOT NULL DEFAULT '0' COMMENT '配资杠杆倍数',
  `init_money` int(11) NOT NULL COMMENT '股票初始资金',
  `borrow_money` int(11) NOT NULL DEFAULT '0' COMMENT '融资金额',
  `borrow_interest` int(11) NOT NULL DEFAULT '0' COMMENT '配资管理费',
  `offset_fee` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '赠送管理费',
  `repayment_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '还款类型',
  `borrow_duration` int(11) NOT NULL DEFAULT '0' COMMENT '配资时长',
  `loss_warn` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '预警线',
  `loss_close` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '止损线',
  `position` int(11) NOT NULL DEFAULT '0' COMMENT '仓位限制',
  `rate` decimal(5,3) NOT NULL DEFAULT '0.000' COMMENT '配资费率',
  `sort_order` tinyint(4) NOT NULL DEFAULT '0' COMMENT '配资收费批次',
  `total` tinyint(4) NOT NULL COMMENT '配资收费总批次',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '配资申请时间',
  `end_time` int(11) NOT NULL DEFAULT '0' COMMENT '配资结束时间',
  `verify_time` int(11) NOT NULL DEFAULT '0' COMMENT '审核时间',
  `stock_money` int(11) NOT NULL DEFAULT '0' COMMENT '股票卖出总金额',
  `trading_time` tinyint(1) NOT NULL DEFAULT '0' COMMENT '交易时间 0 今日 1 下个交易日',
  `account_id` tinyint(4) DEFAULT '0' COMMENT '券商id号',
  `loss_warn_sms_send` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_id` (`order_id`),
  KEY `sub_account` (`sub_account`),
  KEY `stock_subaccount_id` (`stock_subaccount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='配资信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_borrow`
--

LOCK TABLES `st_stock_borrow` WRITE;
/*!40000 ALTER TABLE `st_stock_borrow` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_borrow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_broker`
--

DROP TABLE IF EXISTS `st_stock_broker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_broker` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `broker_id` int(11) NOT NULL COMMENT '券商ID',
  `broker_value` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '券商名称',
  `clienver` varchar(128) CHARACTER SET utf8 NOT NULL COMMENT '客户端版本号',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态 默认1：启用 2：禁用',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `info` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='券商类型表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_broker`
--

LOCK TABLES `st_stock_broker` WRITE;
/*!40000 ALTER TABLE `st_stock_broker` DISABLE KEYS */;
INSERT INTO `st_stock_broker` VALUES (1,1,'长江证券','11.10',1,1513580665,1513580665,NULL),(2,2,'第一创业','6.95',1,1513580665,1513580665,NULL),(3,3,'东莞证券','	6.64',1,1513580665,1513580665,NULL),(4,4,'国信证券','6.58',1,1513580665,1513580665,NULL),(5,6,'华泰证券','6.41',1,1513580665,1513580665,NULL),(6,7,'平安证券','2.08',1,1513580665,1513580665,NULL),(7,12,'广发证券','8.17',1,1513580665,1513580665,NULL),(8,13,'大通证券','1.03',1,1513580665,1513580665,NULL),(9,14,'华西证券','7.24',1,1513580665,1513580665,NULL),(10,15,'兴业证券','6.65',1,1513580665,1513580665,NULL),(11,16,'招商证券','2.95',1,1513580665,1513580665,NULL),(12,17,'金元证券','6.37',1,1513580665,1513580665,NULL),(13,18,'中信建投','7.09',1,1513580665,1513761920,'测试'),(14,19,'红塔证券','6.26',1,1513580665,1513580665,NULL),(15,20,'长城证券','6.26',1,1513580665,1513580665,NULL),(16,22,'国泰君安','9.40',1,1513580665,1513580665,NULL),(17,23,'世纪证券','6.40',1,1513580665,1513580665,NULL),(18,24,'安信证券','7.07',1,1513580665,1513580665,NULL),(19,25,'财富证券','6.47',1,1513580665,1513580665,NULL),(20,26,'东兴证券','8.15',1,1513580665,1513580665,NULL),(21,27,'银河证券','2.59',1,1513580665,1513580665,NULL),(22,28,'光大证券','6.43',1,1513580665,1513580665,NULL),(23,29,'英大证券','6.43',1,1513580665,1513580665,NULL),(24,30,'德邦证券','6.37',1,1513580665,1513580665,NULL),(25,31,'南京证券','6.68',1,1513580665,1513580665,NULL),(26,32,'中信证券','8.30',1,1513580665,1513580665,NULL),(27,33,'上海证券','10.55',1,1513580665,1513580665,NULL),(28,34,'华宝证券','7.68',1,1513580665,1513580665,NULL),(29,35,'爱建证券','6.50',1,1513580665,1513580665,NULL),(30,36,'中泰证券','1.41',1,1513580665,1513580665,NULL),(31,37,'中银国际','7.21',1,1513580665,1513580665,NULL),(38,38,'民族证券','6.72',1,1513580665,1513580665,''),(40,39,'湘财证券','10.28',1,1513580665,1513762108,''),(41,40,'国金证券','7.31',1,1513762097,1513762189,''),(42,-1,'模拟账户','1.00',1,1513823592,1513823592,'模拟账户'),(43,0,'明道配资证券','6.1',1,1527918221,1527918221,'123456'),(44,181,'孙凯证券','1.01',1,1528943326,1528943326,'啥也没有'),(45,90,'测试上卷','3.0',1,1530666769,1530666769,'测试');
/*!40000 ALTER TABLE `st_stock_broker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_deal_stock`
--

DROP TABLE IF EXISTS `st_stock_deal_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_deal_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sub_id` int(11) NOT NULL COMMENT '外键子账户ID',
  `lid` varchar(255) CHARACTER SET utf8 DEFAULT '' COMMENT '交易账户',
  `soruce` varchar(100) CHARACTER SET utf8 DEFAULT '' COMMENT '证券来源',
  `login_name` varchar(255) CHARACTER SET utf8 DEFAULT '' COMMENT '证券账户',
  `gupiao_code` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '证券代码',
  `market` char(4) DEFAULT NULL COMMENT '股票类别',
  `gupiao_name` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '证券名称',
  `deal_date` date NOT NULL DEFAULT '0000-00-00' COMMENT '成交日期',
  `deal_time` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '成交时间',
  `trust_no` varchar(150) CHARACTER SET utf8 NOT NULL COMMENT '委托编号',
  `trust_price` decimal(15,2) DEFAULT NULL COMMENT '委托价格',
  `trust_count` int(11) DEFAULT NULL COMMENT '委托数量',
  `deal_no` varchar(150) CHARACTER SET utf8 NOT NULL COMMENT '成交编号',
  `deal_price` decimal(15,2) DEFAULT NULL COMMENT '成交价格',
  `volume` int(11) DEFAULT NULL COMMENT '成交数量',
  `amount` decimal(20,2) DEFAULT '0.00' COMMENT '成交金额',
  `flag1` tinyint(4) DEFAULT NULL COMMENT '买卖标志1 0:买入  1：卖出',
  `flag2` varchar(10) CHARACTER SET utf8 DEFAULT NULL COMMENT '买卖标志2',
  `gudong_code` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '股东代码',
  `cancel_order_flag` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '撤单标志',
  `type` tinyint(4) DEFAULT NULL COMMENT '账号类别',
  `status` varchar(8) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态说明',
  `beizhu` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '备注',
  `info` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '保留信息',
  `type_today` tinyint(4) DEFAULT NULL COMMENT '当日成交标识',
  `type_history` tinyint(4) DEFAULT NULL COMMENT '历史成交标识',
  `web_time` int(11) DEFAULT NULL COMMENT '信号源前端展示成交时间',
  `order_sn` varchar(100) DEFAULT NULL COMMENT '跟投订单号',
  PRIMARY KEY (`id`),
  KEY `trust_no` (`trust_no`),
  KEY `order_sn` (`order_sn`),
  KEY `deal_no` (`deal_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='股票成交查询存储表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_deal_stock`
--

LOCK TABLES `st_stock_deal_stock` WRITE;
/*!40000 ALTER TABLE `st_stock_deal_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_deal_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_delivery_order`
--

DROP TABLE IF EXISTS `st_stock_delivery_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_delivery_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `uid` int(11) unsigned DEFAULT NULL,
  `sub_id` int(11) DEFAULT NULL COMMENT '外键子账户ID',
  `lid` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '交易账户',
  `soruce` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '证券来源',
  `login_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '证券账户',
  `gupiao_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '证券代码',
  `market` char(4) DEFAULT NULL COMMENT '股票类别',
  `gupiao_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '证券名称',
  `deal_date` date DEFAULT NULL COMMENT '成交日期',
  `business_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '业务名称',
  `deal_price` decimal(15,2) DEFAULT NULL COMMENT '成交价格',
  `volume` int(11) DEFAULT NULL COMMENT '成交数量',
  `amount` decimal(20,2) DEFAULT NULL COMMENT '剩余数量',
  `residual_quantity` decimal(20,2) DEFAULT '0.00' COMMENT '成交金额',
  `liquidation_amount` decimal(15,2) DEFAULT NULL COMMENT '清算金额',
  `residual_amount` decimal(15,2) DEFAULT NULL COMMENT '剩余金额',
  `stamp_duty` decimal(15,2) DEFAULT NULL COMMENT '印花税',
  `transfer_fee` decimal(15,2) DEFAULT NULL COMMENT '过户费',
  `commission` decimal(15,2) DEFAULT NULL COMMENT '净佣金',
  `transaction_fee` decimal(15,2) DEFAULT NULL COMMENT '交易费',
  `front_desk_fee` decimal(15,2) DEFAULT NULL COMMENT '前台费用',
  `trust_no` varchar(150) CHARACTER SET utf8 DEFAULT NULL COMMENT '委托编号',
  `deal_no` varchar(150) CHARACTER SET utf8 DEFAULT NULL COMMENT '成交编号',
  `gudong_code` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '股东代码',
  `type` int(11) DEFAULT NULL COMMENT '账号类别',
  `status` varchar(10) CHARACTER SET utf8 NOT NULL DEFAULT '1',
  `model` tinyint(1) NOT NULL DEFAULT '0',
  `web_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `trust_no` (`trust_no`),
  KEY `deal_no` (`deal_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='股票交割单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_delivery_order`
--

LOCK TABLES `st_stock_delivery_order` WRITE;
/*!40000 ALTER TABLE `st_stock_delivery_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_delivery_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_detail`
--

DROP TABLE IF EXISTS `st_stock_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `status` tinyint(4) NOT NULL COMMENT '还息状态  0：待还  1：已还',
  `borrow_id` int(11) NOT NULL COMMENT '配资记录ID',
  `mid` int(11) NOT NULL COMMENT '会员ID',
  `interest` decimal(15,2) NOT NULL COMMENT '利息',
  `receive_interest` decimal(15,2) NOT NULL COMMENT '已还利息',
  `sort_order` tinyint(4) NOT NULL COMMENT '当前批次',
  `total` tinyint(4) NOT NULL COMMENT '总批次',
  `deadline` int(11) NOT NULL COMMENT '到期时间',
  `repayment_time` int(11) NOT NULL COMMENT '还款时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='还息明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_detail`
--

LOCK TABLES `st_stock_detail` WRITE;
/*!40000 ALTER TABLE `st_stock_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_drawprofit`
--

DROP TABLE IF EXISTS `st_stock_drawprofit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_drawprofit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `borrow_id` int(11) NOT NULL COMMENT '配资ID',
  `uid` int(11) NOT NULL COMMENT '会员ID',
  `borrow_money` decimal(15,2) NOT NULL COMMENT '配资金额',
  `money` decimal(15,2) NOT NULL COMMENT '提盈金额',
  `status` tinyint(4) NOT NULL COMMENT '状态 0：待审核 1：审核通过 2：审核未通过',
  `add_time` int(11) NOT NULL COMMENT '申请时间',
  `target_uid` int(11) DEFAULT NULL COMMENT '审核人ID',
  `target_name` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '审核人姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='股票提盈表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_drawprofit`
--

LOCK TABLES `st_stock_drawprofit` WRITE;
/*!40000 ALTER TABLE `st_stock_drawprofit` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_drawprofit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_history`
--

DROP TABLE IF EXISTS `st_stock_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `mid` int(11) DEFAULT NULL COMMENT '用户id',
  `market` char(4) CHARACTER SET utf8 DEFAULT NULL COMMENT '交易所代码',
  `code` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '股票代码',
  `code_title` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '股票名称',
  `add_time` int(11) DEFAULT NULL COMMENT '搜索时间',
  `count` int(11) DEFAULT NULL COMMENT '查询数量',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '是否显示1|0 显示|隐藏',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_history`
--

LOCK TABLES `st_stock_history` WRITE;
/*!40000 ALTER TABLE `st_stock_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_industry`
--

DROP TABLE IF EXISTS `st_stock_industry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_industry` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id号',
  `industry_name` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '行业中文名',
  `industry_code` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '行业英文名',
  `num` int(11) NOT NULL DEFAULT '1' COMMENT '行业公司数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_industry`
--

LOCK TABLES `st_stock_industry` WRITE;
/*!40000 ALTER TABLE `st_stock_industry` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_industry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_industry_detail`
--

DROP TABLE IF EXISTS `st_stock_industry_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_industry_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id号',
  `industry_name` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '行业中文名',
  `industry_code` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '行业英文名',
  `num` varchar(10) CHARACTER SET utf8 DEFAULT '1' COMMENT '行业公司数量',
  `name` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT ' 股票名称',
  `code` varchar(10) CHARACTER SET utf8 DEFAULT NULL COMMENT '股票代码',
  `sigin_code` varchar(12) CHARACTER SET utf8 DEFAULT NULL COMMENT '带交易所编号代码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_industry_detail`
--

LOCK TABLES `st_stock_industry_detail` WRITE;
/*!40000 ALTER TABLE `st_stock_industry_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_industry_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_list`
--

DROP TABLE IF EXISTS `st_stock_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `title` varchar(100) NOT NULL COMMENT '股票名称',
  `market` varchar(100) DEFAULT NULL COMMENT '交易所代码',
  `code` varchar(100) NOT NULL COMMENT '股票代码 接口id',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '股票状态  0：黑名单  1：白名单',
  `pinyin` varchar(100) DEFAULT '' COMMENT '股票简拼',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  `edit_time` int(11) DEFAULT '0' COMMENT '修改时间',
  `trade_time` int(11) NOT NULL DEFAULT '0' COMMENT '可交易时间',
  `info` varchar(500) DEFAULT NULL COMMENT '备注信息',
  `target_uid` int(11) NOT NULL COMMENT '操作人ID',
  `target_name` varchar(20) NOT NULL COMMENT '操作人姓名',
  `quota` int(11) NOT NULL DEFAULT '0' COMMENT '单支股票限额，0为不限制 其余数字为限额',
  `country_id` int(11) NOT NULL COMMENT '国家id 48=印尼',
  `symbol` varchar(100) DEFAULT NULL COMMENT '股票代码',
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='股票黑/白名单设置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_list`
--

LOCK TABLES `st_stock_list` WRITE;
/*!40000 ALTER TABLE `st_stock_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_position`
--

DROP TABLE IF EXISTS `st_stock_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `uid` varchar(255) DEFAULT NULL,
  `sub_id` int(11) NOT NULL COMMENT '外键 子账户ID',
  `single_id` int(11) DEFAULT '0' COMMENT '项目id，跟投项目',
  `source_id` int(11) DEFAULT '0' COMMENT '信号源id',
  `lid` varchar(255) CHARACTER SET utf8 DEFAULT '' COMMENT '交易账户名',
  `soruce` varchar(100) CHARACTER SET utf8 DEFAULT '' COMMENT '证券来源',
  `login_name` varchar(255) CHARACTER SET utf8 DEFAULT '' COMMENT '证券账户',
  `gupiao_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '证券代码',
  `market` char(6) DEFAULT NULL COMMENT '市场代码',
  `gupiao_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '证券名称',
  `count` int(11) NOT NULL DEFAULT '0' COMMENT '证券数量',
  `stock_count` int(11) NOT NULL DEFAULT '0' COMMENT '实际持仓数量',
  `canbuy_count` int(11) NOT NULL DEFAULT '0' COMMENT '可卖数量',
  `ck_price` decimal(15,3) DEFAULT NULL COMMENT '参考成本价',
  `buy_average_price` decimal(15,3) DEFAULT NULL COMMENT '买入均价',
  `ck_profit_price` decimal(15,3) DEFAULT NULL COMMENT '参考盈亏成本价',
  `now_price` decimal(15,2) DEFAULT NULL COMMENT '当前价',
  `market_value` decimal(15,2) DEFAULT NULL COMMENT '最新市值',
  `volume` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '成交仓位',
  `ck_profit` decimal(15,2) DEFAULT NULL COMMENT '参考浮动盈亏',
  `profit_rate` decimal(15,2) DEFAULT NULL COMMENT '盈亏比例',
  `buying` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '在途买入',
  `selling` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '在途卖出',
  `gudong_code` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '股东代码',
  `type` tinyint(4) DEFAULT NULL COMMENT '账号类别',
  `jigou_type` tinyint(4) DEFAULT NULL COMMENT '交易机构类别',
  `jiyisuo` varchar(10) CHARACTER SET utf8 DEFAULT NULL COMMENT '交易所',
  `info` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '保留信息',
  `beizhu` varchar(30) CHARACTER SET utf8 DEFAULT NULL COMMENT '备注',
  `single_type` tinyint(3) DEFAULT '1' COMMENT '1自主持仓  2跟单持仓',
  `single_day` int(11) DEFAULT '0' COMMENT '跟单持仓周期',
  `sell_type` tinyint(3) DEFAULT '1' COMMENT '信号源卖出类型 1直接卖出 2委托卖出（后台确认）',
  `sell_time` int(11) DEFAULT NULL COMMENT '前端显示卖出时间',
  `sell_price` decimal(10,2) DEFAULT '0.00' COMMENT '真实卖出价格',
  `sell_count` int(11) DEFAULT NULL COMMENT '卖出数量',
  `sell_price_scope` decimal(15,2) DEFAULT '0.00' COMMENT '前端显示卖出价格',
  `scale` decimal(10,2) DEFAULT '0.00' COMMENT '老师分佣比例 (带单项目)',
  `single_order_sn` varchar(255) DEFAULT NULL COMMENT '用户跟投订单号',
  `create_time` int(11) DEFAULT NULL,
  `buy_time` int(11) DEFAULT '0' COMMENT '转入前端显示时间',
  `is_show` tinyint(3) DEFAULT '0' COMMENT '是否展示 0不展示 1展示',
  `order_sn` varchar(100) DEFAULT NULL COMMENT '跟投订单号',
  PRIMARY KEY (`id`),
  KEY `sub_id` (`sub_id`),
  KEY `single_id` (`single_id`),
  KEY `source_id` (`source_id`),
  KEY `canbuy_count` (`canbuy_count`),
  KEY `single_type` (`single_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='股票持仓存储表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_position`
--

LOCK TABLES `st_stock_position` WRITE;
/*!40000 ALTER TABLE `st_stock_position` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_renewal`
--

DROP TABLE IF EXISTS `st_stock_renewal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_renewal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `uid` int(11) NOT NULL COMMENT '会员ID',
  `borrow_id` int(11) NOT NULL COMMENT '配资ID',
  `borrow_fee` decimal(15,2) NOT NULL COMMENT '续期管理费',
  `borrow_duration` tinyint(4) DEFAULT '0' COMMENT '续期时长',
  `status` tinyint(4) NOT NULL COMMENT '审核状态',
  `add_time` int(11) NOT NULL COMMENT '申请时间',
  `verify_time` int(11) NOT NULL COMMENT '审核时间',
  `type` int(11) DEFAULT NULL COMMENT '业务类型 1：续期申请  2：终止配资',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='配资续期/终止表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_renewal`
--

LOCK TABLES `st_stock_renewal` WRITE;
/*!40000 ALTER TABLE `st_stock_renewal` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_renewal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_subaccount`
--

DROP TABLE IF EXISTS `st_stock_subaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_subaccount` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `uid` int(11) DEFAULT NULL COMMENT '会员ID',
  `sub_account` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '交易子账户',
  `sub_pwd` varchar(255) NOT NULL COMMENT '交易子账户密码',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '使用状态 0：未使用    1：已使用',
  `user_type` int(11) NOT NULL DEFAULT '0' COMMENT '子账号类型，0：为免费体验账户，1：为按天/周/月分配账户  2：免息配资',
  `account_id` int(11) NOT NULL DEFAULT '0' COMMENT '具体证券ID',
  `relation_type` int(11) NOT NULL DEFAULT '0' COMMENT '账户模式，0:模拟账户，1:证券账户',
  `agent_id` int(11) NOT NULL DEFAULT '0' COMMENT '代理商id  默认为0代表总后台,非0代表具体代理商ID',
  `info` varchar(255) DEFAULT NULL COMMENT '备注信息',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `type` tinyint(3) DEFAULT '1' COMMENT '1配资账户   2跟投账户',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sub_account` (`sub_account`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='子账户信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_subaccount`
--

LOCK TABLES `st_stock_subaccount` WRITE;
/*!40000 ALTER TABLE `st_stock_subaccount` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_subaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_subaccount_money`
--

DROP TABLE IF EXISTS `st_stock_subaccount_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_subaccount_money` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `stock_subaccount_id` int(11) NOT NULL COMMENT '外键id 关联lmq_stock_subaccount表里的唯一主键ID',
  `commission_scale` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '佣金比例（单位：万分之几） 如：5 代表万分之五',
  `min_commission` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '最低佣金（单位：元）',
  `rate_scale` decimal(15,2) DEFAULT NULL COMMENT '配资管理费分成比例',
  `profit_share_scale` decimal(15,2) DEFAULT NULL COMMENT '盈利分成比例',
  `avail` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '可用金额',
  `available_amount` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '可提现金额',
  `freeze_amount` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '冻结金额',
  `return_money` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '盈亏金额',
  `return_rate` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '盈亏利率',
  `deposit_money` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '保证金',
  `borrow_money` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '融资金额',
  `stock_addfinancing` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '扩大配资累计金额',
  `stock_addmoney` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '追加保证金累计金额',
  `stock_drawprofit` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '申请提取盈利累计金额',
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='子账户资金信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_subaccount_money`
--

LOCK TABLES `st_stock_subaccount_money` WRITE;
/*!40000 ALTER TABLE `st_stock_subaccount_money` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_subaccount_money` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_subaccount_risk`
--

DROP TABLE IF EXISTS `st_stock_subaccount_risk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_subaccount_risk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `stock_subaccount_id` int(11) NOT NULL DEFAULT '0' COMMENT '外键id 关联stock_subaccount表里的唯一主键ID',
  `loss_warn` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '预警线（单位：%）',
  `loss_close` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '平仓线（单位：%）',
  `position` int(11) NOT NULL DEFAULT '100' COMMENT '个股持仓比例（单位：%），区间0-100，100表示不限仓',
  `prohibit_open` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否禁止开仓，1：允许开仓 0：禁止开仓',
  `prohibit_close` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否禁止平仓，1：允许平仓 0：禁止平仓',
  `prohibit_back` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否禁止撤单，1：允许撤单  0：禁止撤单',
  `renewal` tinyint(4) DEFAULT NULL COMMENT '是否开启自动续期 0：不开启  1：开启',
  `autoclose` tinyint(4) DEFAULT '1' COMMENT '是否开启自动平仓 0：不开启  1：开启',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_subaccount_id` (`stock_subaccount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='子账户风控设置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_subaccount_risk`
--

LOCK TABLES `st_stock_subaccount_risk` WRITE;
/*!40000 ALTER TABLE `st_stock_subaccount_risk` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_subaccount_risk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_subaccount_self`
--

DROP TABLE IF EXISTS `st_stock_subaccount_self`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_subaccount_self` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sub_id` int(11) NOT NULL COMMENT '外键id 关联lmq_stock_subaccount表里的唯一主键ID',
  `uid` int(11) NOT NULL COMMENT '外键id 关联lmq_member表里的唯一主键ID',
  `market` varchar(25) CHARACTER SET utf8 NOT NULL COMMENT '交易所代码',
  `gupiao_name` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '股票名称',
  `gupiao_code` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '股票代码',
  `create_time` int(11) NOT NULL COMMENT '添加时间',
  `add_ip` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '添加IP',
  `sort` int(11) DEFAULT '0' COMMENT '自选股排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='股票自选表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_subaccount_self`
--

LOCK TABLES `st_stock_subaccount_self` WRITE;
/*!40000 ALTER TABLE `st_stock_subaccount_self` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_subaccount_self` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_submoney_record`
--

DROP TABLE IF EXISTS `st_stock_submoney_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_submoney_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sub_id` int(10) unsigned NOT NULL COMMENT '交易用户id',
  `affect` decimal(30,0) DEFAULT NULL COMMENT '影响金额',
  `account` decimal(30,0) unsigned DEFAULT NULL COMMENT '账户余额',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '资金类型',
  `info` varchar(600) CHARACTER SET utf8 NOT NULL COMMENT '详情',
  `create_time` int(11) NOT NULL COMMENT '交易时间',
  `create_ip` varchar(50) DEFAULT NULL COMMENT '交易IP',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='资金操作记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_submoney_record`
--

LOCK TABLES `st_stock_submoney_record` WRITE;
/*!40000 ALTER TABLE `st_stock_submoney_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_submoney_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_trust`
--

DROP TABLE IF EXISTS `st_stock_trust`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_trust` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `uid` int(11) DEFAULT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0' COMMENT '外键子账户ID',
  `single_id` int(11) DEFAULT '0' COMMENT '项目id',
  `source_id` int(11) DEFAULT '0' COMMENT '信号源id',
  `po_id` int(11) DEFAULT NULL COMMENT '持仓id',
  `lid` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '证券交易账号ID 如：29666537',
  `jytName` varchar(255) CHARACTER SET utf8 DEFAULT '' COMMENT '交易账户名',
  `soruce` varchar(100) CHARACTER SET utf8 DEFAULT '' COMMENT '证券来源',
  `login_name` varchar(255) CHARACTER SET utf8 DEFAULT '' COMMENT '证券账户',
  `gupiao_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '证券代码',
  `market` char(4) DEFAULT NULL COMMENT '股票类别',
  `gupiao_name` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '证券名称',
  `trust_date` date DEFAULT NULL COMMENT '委托日期',
  `trust_time` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '委托时间',
  `trust_no` varchar(150) CHARACTER SET utf8 NOT NULL COMMENT '委托编号',
  `trust_price` decimal(15,2) DEFAULT NULL COMMENT '委托价格',
  `trust_count` int(11) DEFAULT NULL COMMENT '委托数量',
  `volume` int(11) DEFAULT NULL COMMENT '成交数量',
  `amount` decimal(20,2) DEFAULT '0.00' COMMENT '成交金额',
  `buy_price` decimal(15,2) DEFAULT '0.00' COMMENT '委托后台输入买入价格',
  `flag1` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '买卖标志1',
  `flag2` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '买卖标志2',
  `gudong_code` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '股东代码',
  `cancel_order_flag` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '撤单标志',
  `cancel_order_count` int(11) DEFAULT NULL COMMENT '撤单数量',
  `type` tinyint(4) DEFAULT NULL COMMENT '账号类别',
  `status` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态说明',
  `add_time` int(11) DEFAULT NULL COMMENT '操作时间',
  `beizhu` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '备注',
  `info` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '保留信息',
  `type_today` tinyint(4) DEFAULT NULL COMMENT '当日委托',
  `type_today_back` tinyint(4) DEFAULT NULL COMMENT '当日可撤销委托',
  `type_history` tinyint(4) DEFAULT NULL COMMENT '历史委托',
  `single_type` tinyint(3) DEFAULT '1' COMMENT '1 正常购买  2跟单股票',
  `single_day` int(11) DEFAULT '0' COMMENT '跟单项目周期',
  `update_time` int(11) DEFAULT '0',
  `scale` decimal(10,2) DEFAULT '0.00' COMMENT '分成比例 (跟单委托才有)',
  `single_order_sn` varchar(100) DEFAULT NULL COMMENT '用户跟投订单号',
  `is_zhuan` tinyint(3) DEFAULT '1' COMMENT ' 1 未转入持仓，2已转入持仓   跟单订单',
  `buy_time` int(11) DEFAULT NULL,
  `order_sn` varchar(255) DEFAULT NULL COMMENT '跟投订单号',
  PRIMARY KEY (`id`),
  KEY `single_id` (`single_id`),
  KEY `order_sn` (`order_sn`),
  KEY `source_id` (`source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='股票委托存储表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_trust`
--

LOCK TABLES `st_stock_trust` WRITE;
/*!40000 ALTER TABLE `st_stock_trust` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_trust` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_stock_trust_ipo`
--

DROP TABLE IF EXISTS `st_stock_trust_ipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_stock_trust_ipo` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sub_id` int(11) NOT NULL COMMENT '外键子账户ID',
  `lid` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '证券交易账号ID 如：29666537',
  `jytName` varchar(255) CHARACTER SET utf8 DEFAULT '' COMMENT '交易账户名',
  `soruce` varchar(100) CHARACTER SET utf8 DEFAULT '' COMMENT '证券来源',
  `market` char(4) DEFAULT NULL COMMENT '股票类别',
  `login_name` varchar(255) CHARACTER SET utf8 DEFAULT '' COMMENT '证券账户',
  `gupiao_code` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '证券代码',
  `gupiao_name` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '证券名称',
  `trust_date` date DEFAULT NULL COMMENT '委托日期',
  `trust_time` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '委托时间',
  `trust_no` varchar(150) CHARACTER SET utf8 NOT NULL COMMENT '委托编号',
  `trust_price` decimal(15,2) DEFAULT NULL COMMENT '委托价格',
  `trust_count` decimal(15,2) DEFAULT NULL COMMENT '委托数量',
  `volume` int(11) DEFAULT NULL COMMENT '成交数量',
  `amount` int(11) DEFAULT NULL COMMENT '成交金额',
  `flag1` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '买卖标志1',
  `flag2` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '买卖标志2',
  `gudong_code` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '股东代码',
  `cancel_order_flag` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '撤单标志',
  `cancel_order_count` int(11) DEFAULT NULL COMMENT '撤单数量',
  `type` tinyint(4) DEFAULT NULL COMMENT '账号类别',
  `status` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '状态说明',
  `add_time` int(11) DEFAULT NULL COMMENT '操作时间',
  `beizhu` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '备注',
  `info` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '保留信息',
  `type_today` tinyint(4) DEFAULT NULL COMMENT '当日委托',
  `type_today_back` tinyint(4) DEFAULT NULL COMMENT '当日可撤销委托',
  `type_history` tinyint(4) DEFAULT NULL COMMENT '历史委托',
  PRIMARY KEY (`id`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='新股申购存储表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_stock_trust_ipo`
--

LOCK TABLES `st_stock_trust_ipo` WRITE;
/*!40000 ALTER TABLE `st_stock_trust_ipo` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_stock_trust_ipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_verify`
--

DROP TABLE IF EXISTS `st_verify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st_verify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(32) CHARACTER SET utf8 NOT NULL,
  `send_time` int(11) NOT NULL,
  `ukey` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL COMMENT '1:邮件激活验证',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_verify`
--

LOCK TABLES `st_verify` WRITE;
/*!40000 ALTER TABLE `st_verify` DISABLE KEYS */;
/*!40000 ALTER TABLE `st_verify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'aaaa'
--

--
-- Dumping routines for database 'aaaa'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-29 19:03:21

<?php
// +----------------------------------------------------------------------
// | 控制台配置
// +----------------------------------------------------------------------
return [
    // 指令定义
    'commands' => [
        // 活跃股票行情
        'alive' => 'app\command\Alive',
        // 自动风控脚本
        'auto'  => 'app\command\Auto',
        // 股票最新列表
//         'list'  => 'app\command\StockList',
        // 交易自动任务
        'trust' => 'app\command\Trust',
        // 自动审核检查
        'check' => 'app\command\Check',
        // 自动结算配资
        'close' => 'app\command\Close',
        // WebSocket服务器
        'WsSer' => 'app\command\WebSocket',
        'back_single_order' => 'app\command\BackSingleOrder',
        'commission' => 'app\command\Commission',
        'team_commission' => 'app\command\TeamCommission',
        'auth_users_level' => 'app\command\AutoUpdateUserLevel',
        'close_pei' => 'app\command\ClosePei',
         'create_worker' => 'app\command\CreateSingleOrder',
         'sell_worker' => 'app\command\SellWorker',
         'invest' => 'app\command\Invest',//每日執行投資收益
         'deduction_amount' => 'app\command\Deductionamount',//沒小時扣除項目額度
    ],
];

<?php

namespace app\command;


use app\apicom\model\Member;
use app\apicom\model\Recharge;
use app\apicom\model\SingleOrder;
use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;

use think\facade\Db;
use function fast\e;

/*
 * 自动更新会员等级
 */
class AutoUpdateUserLevel extends Command
{

    protected function configure()
    {
        // 指令配置
        $this->setName('auth_users_level')->setDescription('批量检测会员等级，自动升级或降级');

    }

    protected function execute(Input $input, Output $output){
        $week = date('w');
        $date = date('H');
        if ($week == 0 && $date >= 00 ) {
            $output->writeln('开始自动检测会员等级...');
            // 1. 查询所有会员
            $users = Db::name('member')->where(['user_type'=>1])->field('id,level')->select();
            // 2. 查询等级配置（根据你的实际情况）
            $levels = Db::name('member_level')
                ->order('id asc') // 最低min在前
                ->field('id,min_team_num,max_team_num')
                ->select()
                ->toArray();
            // 3. 循环处理每个会员
            foreach ($users as $user) {
                $this->handleUserLevel($user, $levels);
            }
            $output->writeln('会员等级处理完成');
        }
        $this->output->writeln('每周日零点检测会员等级');

    }
    /**
     * 处理单个用户的等级变化
     */
    protected function handleUserLevel($user, $levels)
    {
        $userId = $user['id'];

        $userIds = Member::getAllSubordinatesIterative($userId);  //无限极获取所有下级用户
        
        $userIds = array_map(function($item) {
            return $item['id'];
        }, $userIds);

        // $teamCount = Db::name('member')
        //     ->alias('m')
        //     ->whereIn('m.id', $userIds)
        //     ->whereExists(function($query) {
        //         $query->name('money_record')->alias('r')   // 别名 r
        //             ->whereColumn('r.mid', 'm.id')           // 用 r.mid
        //             ->where('r.type', 1);
        //     })
        //     ->whereExists(function($query) {
        //         $query->name('single_order')->alias('o')    // 别名 o
        //             ->whereColumn('o.user_id', 'm.id')      // 用 o.user_id
        //             ->where('o.status', '>', 1);
        //     })
        //     ->count();
        $recharge = Recharge::whereIn('mid',$userIds)->where(['status'=>1])->group('mid')->column('mid'); //团队有效充值人数
        $item_order= Db::name('single_order')->whereIn('user_id',$userIds)->where('status','>',1)->group('user_id')->column('user_id');  //团队有效跟投订单
        $allActiveUsers = array_unique(array_merge($recharge, $item_order));
        $newLevel = null;
        $teamCount =  count($allActiveUsers);
        
        $newLevel = null;

        foreach ($levels as $level) {
            if ($teamCount >= $level['min_team_num'] && $teamCount <= $level['max_team_num']) {
                $newLevel = $level['id'];
                break;
            }
        }

        if ($newLevel !== null && $newLevel != $user['level']) {
            // 更新等级
            Db::name('member')->where('id', $userId)->update(['level' => $newLevel]);
        }
    }

}
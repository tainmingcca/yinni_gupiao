<?php

namespace app\command;

use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\facade\Cache;
use app\service\SellService;
use util\RedisUtil;

class CreateSingleOrder extends Command
{
    protected function configure()
    {
        $this->setName('order:worker')
            ->setDescription('执行买入委托订单队列');
    }
    protected function execute(Input $input, Output $output)
    {
        $service = new SellService();

        // 永久循环
        while (true) {
            try {
                // brPop 返回格式: [queueName, payload]，timeout 秒
                $res = RedisUtil::redis()->brPop("create_single_order_queue",5);

                if (!$res) {
                    // 长时间空闲时可做心跳/内存检查
                    // 也可以 periodic gc
                    if (function_exists('gc_collect_cycles')) {
                        gc_collect_cycles();
                    }
                    continue;
                }

                $payloadJson = $res[1] ?? '';
                $payload = json_decode($payloadJson, true);
                if (!$payload || !isset($payload['single_id'])) {
                    writeLog('worker_invalid_task', "invalid payload: {$payloadJson}");
                    continue;
                }
                $output->writeln("收到任务 single_id={$payload['single_id']} source_id={$payload['source_id']} retry={$payload['retry']}");
                try {
                    $service->createSingleOrder(
                        $payload['single_id'],
                        $payload['volume'],
                        $payload['buy_price'],
                        $payload['direction'],
                        $payload['code'],
                        $payload['source_id'],
                        $payload['buy_time']
                    );
                    $output->writeln("委托订单完成 single_id={$payload['single_id']}");
                } catch (\Throwable $e) {
                    // 处理失败：根据 retry 次数决定是否重试
                    $retry = isset($payload['retry']) ? (int)$payload['retry'] : 0;
                    if ($retry < 3) {
                        $payload['retry'] = $retry + 1;
                        // rPush 回队列末尾，稍后重试
                        RedisUtil::redis()->rPush("create_single_order_queue", json_encode($payload, JSON_UNESCAPED_UNICODE));

                        $output->writeln("[Worker] 任务失败，已重新入队 retry=" . $payload['retry']);
                        // 后退一小段时间避免立即重试打爆
                        sleep(1);
                    } else {
                        // 达到最大重试次数，记录失败，另外可以保存到 failed 表或报警
                        writeLog('create_failed_task', "task failed permanently single_id={$payload['single_id']} err={$e->getMessage()} payload={$payloadJson}");
                        $output->writeln("委托任务失败并达到最大重试次数，记录日志 single_id={$payload['single_id']}");
                    }
                }

            } catch (\Throwable $e) {
                // Worker 主循环异常，避免退出
                writeLog('worker_exception', "worker exception: " . $e->getMessage());
                $output->writeln("委托异常: " . $e->getMessage());
                sleep(2);
            }
        }
    }

}
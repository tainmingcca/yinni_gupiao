<?php

namespace app\command;
use app\service\SellService;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use util\RedisUtil;

class SellWorker extends Command
{
    protected function configure()
    {
        $this->setName('sell:worker')
            ->setDescription('后台消费卖出队列任务');
    }
    protected function execute(Input $input, Output $output)
    {
        $output->writeln("Sell Worker started...");

        $service = new SellService();


        while (true) {
            try {

                $task = RedisUtil::redis()->rpop('sell_position_queue');

                if (!$task) {
                    sleep(1); // 空队列时休眠，避免 CPU 占用
                    continue;
                }


                $data = json_decode($task, true);
                if (!$data) {
                    continue;
                }
                $output->writeln("Processing pos_id={$data['pos_id']} ...");
                $service->processSellPositionItem(
                    $data['pos_id'],
                    $data['sell_price'],
                    $data['sell_time'],
                    $data['sell_price_scope'],
                    $data['single_type'],
                    $data['sell_volume']
                );
                $output->writeln("Done pos_id={$data['pos_id']}");
            } catch (\Throwable $e) {
                writeLog('sell_position_worker_error', $e->getMessage());
                $output->writeln("Error: " . $e->getMessage());
                sleep(1);
            }
        }
    }
}
<?php

namespace app\command;


use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;

use think\facade\Db;

/*
 * 每小時執行扣減項目額度
 */
class Deductionamount extends Command
{

    protected function configure()
    {
        $this->setName('invest')->setDescription('每小時執行扣減項目額度');
    }

    protected function execute(Input $input, Output $output)
    {
        //獲取項目信息
        $where = [];
        $where[] = ['is_money' ,'>', 0];
        $invests = Db::name('invest_item')->where(['status'=>1])->where($where)->select();
        if ($invests->isEmpty()) $this->output->writeln('暫無項目信息');

        foreach ($invests as $invest) {
            $this->deduction($invest);
        }

    }

    /**
     * 处理单个
     */
    protected function deduction($invest){
        // 获取当前时间
        $currentHour = date('H');
        $currentTime = date('Y-m-d H:i:s');

        // 判断时间段并计算扣减比例
        $deductionRate = $this->getDeductionRate($currentHour);

        if ($deductionRate === null) {
            $this->output->writeln("当前时间 {$currentTime} 不在扣减时间段内");
            return;
        }

        // 计算扣减金额
        $deductionAmount = sprintf("%.0f", $invest['is_money'] * $deductionRate /100);

        // 更新总额度
        $after = bcsub(strval($invest['is_money']), strval($deductionAmount), 2);
        if($after<=0){
            $after = 0;
        }
        $invest_title = $invest['title'];
        $ret = Db::name('invest_item')->where(['id' =>$invest['id']])->update(['is_money' => $after]);
        if($ret){
            $this->output->writeln("項目{$invest_title}扣除{$deductionRate}%, {$deductionAmount} ，剩餘{$after}");
        }

    }

    /**
     * 根据时间段获取扣减比例
     */
    private function getDeductionRate($hour)
    {
        $hour = (int)$hour;

        // 22:00 - 7:00 (跨天时间段)
        if ($hour >= 22 || $hour < 7) {
            // 随机扣减 0.2% - 1.5%
           // return mt_rand(2, 15) / 1000; // 0.002 - 0.015
            //2-5%
            return mt_rand(2, 5) / 100;
        }

        // 8:00 - 21:00
        if ($hour >= 8 && $hour < 21) {
            // 随机扣减 3% - 5%
            return mt_rand(5, 8) / 100; // 0.03 - 0.05
        }

        // 7:00-8:00 和 21:00-22:00 不扣减
        return null;
    }

}
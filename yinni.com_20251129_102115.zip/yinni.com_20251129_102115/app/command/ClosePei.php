<?php

namespace app\command;

use app\apicom\model\Money;
use app\apicom\model\Record;
use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;
use think\facade\Db;
use app\apicom\model\Member  as MemberModel;

class ClosePei extends Command
{
    protected function configure()
    {
        // 指令配置
        $this->setName('close_pei')->setDescription('自动清算到期配额资金');
    }
    protected function execute(Input $input, Output $output)
    {
        $this->Close_pei();

    }
    public function Close_pei()
    {
        $money = new Money();
        $pei_time = strtotime(date('Y-m-d 22:59:59',time()));
        $list = MemberModel::view('member m')
            ->view('money um','id as um_id','m.id=um.mid')
            ->where(['m.is_del'=>0,'m.is_pei'=>0])
            ->where('m.pei_time','<=',$pei_time)
            ->column('m.id');
        if (empty($list)) $this->output->writeln('暂无到期配额的用户');
        foreach ($list as $item){
            Db::name('member')->where(['id'=>$item])->update(['pei_time'=>null,'is_pei'=>0]);
            $money_info = $money->where(['mid'=>$item])->field('id,pei_money')->find();
            Record::saveData($item,  $money_info['pei_money'], 0, 51, '配额到期：'.$money_info['pei_money']);
            $money_info->pei_money = 0;
            $money_info->save();
            $this->output->writeln('用户ID：'.$item.'到期配额已清零');
        }
    }

}
<?php

namespace app\command;


use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;

use think\facade\Db;

/*
 * 每日執行投資收益
 */
class Invest extends Command
{


    protected function configure()
    {
        $this->setName('invest')->setDescription('每日執行投資收益');
    }

    protected function execute(Input $input, Output $output)
    {
       //固定獲取當前項目信息
        $invest = Db::name('invest_item')->where(['id'=>1])->find();
//        if($invest['status'] == 0){
//            $this->output->writeln('項目未開啓');
//            return false;
//        }

        //開始收益時間
        $start_time = strtotime($invest['start_time']);
        if(time() < $start_time) {
            $this->output->writeln('開始收益時間'.$invest['end_time']);
            return false;
        }

//        //項目到期時間
//        $end_time = strtotime($invest['end_time'] . ' 23:59:59');
//
        //當前時間
        $current_time = date('Y-m-d',time());
//
//        //是否到期
//        if(time() > $end_time) {
//            $this->output->writeln('今日時間'.$current_time);
//            $this->output->writeln('已經到期');
//            return false;
//        }

        //匹配對應時間的收益率
        $income = Db::name('invest_item_income')->where(['item_id'=>$invest['id'],'date'=>$current_time,'status'=>1])->find();
        if(empty($income)) {
            $this->output->writeln('未匹配今日的收益率');
            return false;
        }

        //循環所有投資記錄
        $orderlists = Db::name('invest_order')->where(['status'=>2,'deal_status'=>2,'invest_id'=>$invest['id']])->select();
        if ($orderlists->isEmpty()) $this->output->writeln('暂无返佣记录');

        foreach ($orderlists as $orderlist) {
            $this->hand_income($orderlist, $income);
        }

    }

    /**
     * 处理单个
     */
    protected function hand_income($orderlist, $income){
        //投資周期(每日收益的日期時間)
        $period = $income['date'];
        //初期資金
        $starting_amount = $orderlist['money'];
        //當日收益
        $day_income = sprintf("%.0f", $orderlist['money']*$income['rate']/100);
        //纍計收益
        $total_income = $day_income;
        //賬戶餘額
        $ending_amount = $orderlist['money'] + $day_income;
        //收益率
        $rate = $income['rate'];

        //判斷是否有記錄
        $log = Db::name('invest_order_log')->where(['user_id'=>$orderlist['user_id'],'invest_id'=>$orderlist['invest_id'],'order_id'=>$orderlist['id'],'invest_day_id'=>$orderlist['invest_day_id']])->order('id', 'desc')->find();
        if($log){
            //初期資金 = 前一天的初期資金
            $starting_amount = $log['ending_amount'];
            //當日收益
            $day_income = sprintf("%.0f", $starting_amount*$income['rate']/100);
            //纍計收益 =  前一天的纍計收益 + 當日收益
            $total_income = $log['total_income'] + $day_income;
            //賬戶餘額 = 前一天的初期資金 + 當日收益
            $ending_amount = $starting_amount + $day_income;
        }

        //st_invest_order_log
        $logdata = [
            'user_id'       => $orderlist['user_id'],
            'invest_id'        => $orderlist['invest_id'],
            'order_id'        => $orderlist['id'],
            'period'      => $period,
            'starting_amount'  => $starting_amount,
            'ending_amount'    => $ending_amount,
            'total_income'         => $total_income,
            'rate'         => $income['rate'],
            'day_income'         => $day_income,
            'invest_day_id'         => $orderlist['invest_day_id'],
        ];
        $res = Db::name('invest_order_log')->insert($logdata);
        if($res){
            //更新訂單記錄(纍計收益，賬戶餘額)
            Db::name('invest_order')->where(['id'=>$orderlist['id']])->update(['total_income'=>$total_income,'balance'=>$ending_amount]);
            //更新收益率標識
            Db::name('invest_item_income')->where(['id'=>$income['id']])->update(['status'=>2]);

            //判斷收益時間是否 到期了  收益結束了
            //當前時間
            $current_time = date('Y-m-d',time());
            $end_time = date('Y-m-d',$orderlist['end_time']);
            if($current_time == $end_time){
                Db::name('invest_order')->where(['id'=>$orderlist['id']])->update(['deal_status'=>3]);
            }
        }
    }



}
<?php

namespace app\command;
use app\apicom\model\Record as RecordModel;
use app\apicom\model\SingleItem;
use app\apicom\model\SingleOrder;
use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;
use think\facade\Db;

class BackSingleOrder extends Command
{
    /*
     * 自动退回新手项目未审核订单金额   当日收盘后
     */
    protected function configure()
    {
        // 指令配置
        $this->setName('back_single_order')->setDescription('自动退回新手项目未审核订单金额');
    }
    protected function execute(Input $input, Output $output)
    {
        $this->backSingle();

    }

    public function backSingle()
    {
        $singleOrder = new SingleOrder();

        $singleOrderList = $singleOrder->alias('o')->join('single_item i','i.id=o.single_id')
            ->where(['o.status'=>1,'i.single_class'=>1])
            ->field('o.id,o.user_id,o.money,i.single_class,o.status')
            ->select();
        if ($singleOrderList->isEmpty()) $this->output->writeln("暂无有效订单");
        foreach($singleOrderList as  $item){
            $item->status = 5;
            $item->save();
            $money_info = Db::name('money')->where('mid', $item['user_id'])->lock(true)->find();
            Db::name('money') -> where('mid', $item['user_id'])->inc('single_money', $item['money']); // 更新余额
            RecordModel::saveData($item['user_id'],  $item['money'], $money_info['single_money'], 40, '跟投退回：'.$item['money']); //写入资金明细
            $this->output->writeln("订单ID:".$item->id."退回成功");
        }
    }


}
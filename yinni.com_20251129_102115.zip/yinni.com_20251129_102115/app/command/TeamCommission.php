<?php

namespace app\command;
use app\apicom\model\Member as MemberModel;
use app\apicom\model\MemberLevel;
use app\apicom\model\Money;
use app\apicom\model\Record as RecordModel;
use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;
use think\facade\Db;
class TeamCommission extends Command
{

    /*
    * 固定时间节点 统一返利上级获得佣金
    */
    protected function configure()
    {
        // 指令配置
        $this->setName('team_commission')->setDescription('团队分红佣金');
    }
    protected function execute(Input $input, Output $output)
    {
        $this->TeamRebates();

    }
    /*
    * 每周六13点分团队分红
    */

    public function TeamRebates()
    {
        $week = date('w');
        $date = date('H');
        if ($week == 6 && $date >= 13 ){
            $list = Db::name('member_commission')->where(['is_return'=>0,'type'=>3])->field('money,uid,is_return,id')->select();
            if ($list->isEmpty()) $this->output->writeln('暂无分红记录');
            foreach ($list as $item){
                Db::name('member_commission')->where(['id'=>$item['id']])->update(['is_return'=>1,'auth_time'=>time()]);
                Db::name('money')->where(['mid'=>$item['uid']])->Inc('account',$item['money'])->update();
                $userMoney = Money::getMoney($item['uid']);  // 获取自己余额
                $avail =bcadd( $userMoney['account'] ,$item['money'],2);
                RecordModel::saveData($item['uid'],  $item['money'], $avail, 47, '团队分红：'.$item['money']);
                $this->output->writeln('分红完成, 用户ID：'.$item['uid']);
            }
        }else{
            $this->output->writeln('非周六13点不分红');
        }
    }

}
<?php
namespace app\admin\validate;

use think\Validate;

class Document extends Validate
{

    // 定义验证规则
    protected $rule = [
        'cid|文档栏目'     => 'require',
        'title|文档标题'   => 'require|length:1,30',
        'content|文档内容' => 'require|length:10,9999',
    ];

    //定义验证场景
    protected $scene = [
        'create'      => ['title', 'content', 'cid'],
    ];
}

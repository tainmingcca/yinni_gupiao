<?php

namespace app\admin\validate;

use think\Validate;

class SithSingle extends Validate
{
    // 定义验证规则
    protected $rule = [
        'name|老师姓名'   => 'require|length:1,30',
        'img_url|图片' => 'require',
        'content|老师介绍' => 'require',
    ];

    //定义验证场景
    protected $scene = [
        'create'      => ['name', 'img_url','content'],
    ];

}
<?php
namespace app\admin\validate;

use think\Validate;

class Slider extends Validate
{

    // 定义验证规则
    protected $rule = [
        'title|标题'   => 'require|length:1,30',
        'img_url|图片' => 'require',
    ];

    //定义验证场景
    protected $scene = [
        'create'      => ['title', 'img_url'],
    ];
}

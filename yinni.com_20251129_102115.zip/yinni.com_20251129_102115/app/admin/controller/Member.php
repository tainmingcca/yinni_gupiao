<?php
declare (strict_types = 1);

namespace app\admin\controller;
use app\apicom\model\Bank;
use app\apicom\model\Member  as MemberModel;
use app\apicom\model\MemberCard;
use app\apicom\model\MemberCommission;
use app\apicom\model\MemberLevel;
use app\apicom\model\Record  as RecordModel;
use app\apicom\model\Recharge;
use app\apicom\model\SingleOrder;
use app\apicom\model\Withdraw;
use think\facade\Db;
use app\apicom\model\SubAccount;

class Member extends AdminBase
{
    public function index()
    {
        return '您好！这是一个[admin]示例应用';
    }
        /*
 * 获取会员留言
 */
    public function goUserMessageList()
    {
        $mobile = input('mobile','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order  = 'id desc';
        $where = [];
        if(!empty($mobile)) $where[] = ['o.mobile','=', $mobile];

        $data_list = Opinion::getAll($where,$order,$offset);
        if(!$data_list) return ajaxmsg('没有数据',0);

        return ajaxmsg('操作成功',200,$data_list);
    }
    
        /*
 * 获取用户下級報表
 */
    public function getSubreportsList()
    {
        $name   = input('name', '');
        $mobile = input('mobile','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $id = input('id','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $type = input('type','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $level = input('level',0, ['trim', FILTER_SANITIZE_NUMBER_INT]);

        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order  = 'id desc';

        $top_id = 0;
        if(!empty($mobile)){
            $member = MemberModel::whereOr('mobile', $mobile)->field('id')->find();
            if($member['id']){
                $top_id = $member['id'];
            }
        }

        if(!empty($id)){
            $top_id = $id;
        }

        if(!empty($type)) {
            $where[] = ['a.type','=', $type];//用戶類型
            $whereSubreport[] = ['type','=', $type];//用戶類型
        }
        if(!empty($level)){
            $where[] = ['a.level','=', $level];//用戶等級
            $whereSubreport[] = ['level','=', $level];//用戶等級
        }
        $data_list = [];

        // 初始化返回结构
        $total_recharge = 0;
        $total_withdraw = 0;
        $total_single_income = 0;
        $total_single_commission = 0;

        if($top_id > 0){

//            $where[]   = ['a.is_del' ,'=', 0];
            $where[]   = ['a.user_type' ,'=', 1];
            $whereSubreport[]   = ['user_type' ,'=', 1];

            $userIds = $this->get_AllSubordinatesIterative($top_id);  //无限极获取所有下级用户
            $userIds = array_map(function($item) {
                return $item['id'];
            }, $userIds);

//            $top_info = Db::name('member_ids')->where('member_id',$top_id)->find();
//            $userIds = $top_info['ids'];

            $collectedIds = [];
            $collectedIds = MemberModel::whereIn('id',$userIds)->where($whereSubreport)->column('id');


//            $data_list = MemberModel::view('member a')
//                ->view('member_level l','title as level_name','a.level=l.id')
//                ->whereIn('a.id',$userIds)
//                ->where($where)
//                ->order($order)
//                ->paginate($offset, false, ['query' => request()->param()])
//                ->each( function($item, $key) {
//                    //use (&$total_recharge, &$total_withdraw, &$total_single_income, &$total_single_commission)
//                    $item['recharge_money'] = Recharge::where(['mid'=>$item['id'],'status'=>1,'is_admin' => 0])->sum('money');//充值
//                    $item['money_withdraw'] = Withdraw::where(['mid'=>$item['id'],'status'=>1])->sum('money');//提現
//                    $item['single_income'] = RecordModel::where(['mid' => $item['id'], 'type' => 39])->sum('affect');;//总投资盈利
//                    $item['single_commission'] = RecordModel::where(['mid' => $item['id'], 'type' => 38])->sum('affect');//总返佣盈利
//
////                    $item['recharge_money'] = 1;//充值
////                    $item['money_withdraw'] =1;//提現
////                    $item['single_income'] = 1;;//总投资盈利
////                    $item['single_commission'] = 1;//总返佣盈利
//
//                    $item['account'] = format_amount($item['account']);
////                    $total_recharge += $item['recharge_money'];
////                    $total_withdraw += $item['money_withdraw'];
////                    $total_single_income += $item['single_income'];
////                    $total_single_commission += $item['single_commission'];
//
//                });


            // 先获取基础数据
            $data_list = MemberModel::view('member a')
                ->view('member_level l', 'title as level_name', 'a.level=l.id')
                ->whereIn('a.id', $userIds)
                ->where($where)
                ->order($order)
                ->paginate($offset, false, ['query' => request()->param()]);

            // 获取会员ID数组 - 使用集合的 column 方法
            $memberIds = $data_list->column('id');

            if (!empty($memberIds)) {
                // 使用闭包函数减少重复代码
                $getStats = function($table, $conditions = [], $sumField = 'money') use($memberIds) {
                    $query = Db::name($table);
                    foreach ($conditions as $field => $value) {
                        $query->where($field, $value);
                    }
                    return $query->whereIn('mid', $memberIds)
                        ->group('mid')
                        ->field("mid, SUM({$sumField}) as total")
                        ->select()
                        ->toArray();
                };

                // 获取各项统计数据
                $rechargeMap = array_column($getStats('money_recharge', ['status' => 1, 'is_admin' => 0]), 'total', 'mid');
                $withdrawMap = array_column($getStats('money_withdraw', ['status' => 1]), 'total', 'mid');
                $incomeMap = array_column($getStats('money_record', ['type' => 39], 'affect'), 'total', 'mid');
                $commissionMap = array_column($getStats('money_record', ['type' => 38], 'affect'), 'total', 'mid');

                // 映射数据到集合
                $data_list->each(function($item) use ($rechargeMap, $withdrawMap, $incomeMap, $commissionMap) {
                    $item['recharge_money'] = $rechargeMap[$item['id']] ?? 0;
                    $item['money_withdraw'] = $withdrawMap[$item['id']] ?? 0;
                    $item['single_income'] = $incomeMap[$item['id']] ?? 0;
                    $item['single_commission'] = $commissionMap[$item['id']] ?? 0;
                    $item['account'] = format_amount($item['account']);
                });
            }


            //團隊數據
            $total_recharge = Recharge::whereIn('mid', $collectedIds)->where(['status'=>1,'is_admin' => 0])->sum('money');//充值
            $total_withdraw = Withdraw::whereIn('mid', $collectedIds)->where(['status'=>1])->sum('money');//提現
            $total_single_income = RecordModel::whereIn('mid', $collectedIds)->where(['type'=>39])->sum('affect');;//总投资盈利
            $total_single_commission = RecordModel::whereIn('mid', $collectedIds)->where(['type'=>38])->sum('affect');//总返佣盈利

        }

        $other['team_total_recharge'] = $total_recharge;
        $other['team_total_withdraw'] = $total_withdraw;
        $other['team_total_single_income'] = $total_single_income;
        $other['team_total_single_commission'] = $total_single_commission;

        return ajaxmsgnew('操作成功',200,$data_list,$other);
    }
    /**
     * 获取所有下级成员（迭代查询）
     * @param int $userId 目标用户ID
     * @return \think\Collection
     */
    public function get_AllSubordinatesIterative($userId)
    {
        $members = [];
        $queue = [ [ 'id' => $userId, 'lv' => 0, 'lv' => 0 ] ]; // 初始化队列，起始层级为 0
        while (!empty($queue)) {
            $current = array_shift($queue);
            $currentId = $current['id'];
            $currentLevel = $current['lv'];
            // 获取当前用户的直属下级
            $children = Db::name('member')
                ->where('agent_far', $currentId)
                ->field('id,agent_far,level,type') // 原本字段 + 你需要展示的字段
                ->select()
                ->toArray();

            foreach ($children as $child) {
                $child['lv'] = $currentLevel + 1; // 动态添加层级字段
                $members[] = $child;
                $queue[] = [ 'id' => $child['id'], 'lv' => $child['lv'] ]; // 继续遍历
            }
        }
        return $members;
    }

    
    
    /*
     * 获取会员列表
     */
    public function getList()
    {
        $name   = input('name', '');
         $ip   = input('ip', '');
        $mobile = input('mobile','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $id = input('id','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $type = input('type','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $agent  = input('agent','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
         $level = input('level',0, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order  = 'id desc';
        if(!empty($agent)){
            $where[] = ['a.agent_far','=', $agent];
        }else{
            if(!empty($name))   $where[] = ['a.name'  ,'=', $name];
            if(!empty($mobile)) $where[] = ['a.mobile','=', $mobile];
            if(!empty($level))  $where[] = ['a.level','=', $level];
            if(!empty($type))  $where[] = ['a.type','=', $type];
            if(!empty($ip))  $where[] = ['a.last_login_ip','=', $ip];
            if(!empty($level))  $where[] = ['a.level','=', $level];
            if(!empty($id))  $where[] = ['a.id','=', $id];
        }
        
        $where[]   = ['a.is_del' ,'=', 0];
        $where[]   = ['a.user_type' ,'=', 1];
        // halt($where);
    	$data_list = MemberModel::view('member a')
        	->view('money b','account,freeze,operate_account,bond_account,single_money,pei_money','a.id=b.mid')
            ->view('member_level l','title as level_name','a.level=l.id')
        	->where($where)
        	->order($order)
        	->paginate($offset, false, ['query' => request()->param()])
            ->each( function($item, $key){
                $item['agent_mobile'] = MemberModel::where('id',$item['agent_far'])->value('mobile');
                 $item['single_money'] = SingleOrder::where(['user_id'=>$item['id'],'status'=>2])->sum('money');
                 $item['freeze'] = 0 ;
                 $item['account'] = format_amount($item['account']);
                  if (!empty($item['pei_time'])) $item['pei_time'] = date('Y-m-d H:i',$item['pei_time']);
                //  $item['create_time'] = $item->getData($item['create_time']);
            });
    	if(!$data_list) return ajaxmsg('没有数据',0);
        
        return ajaxmsg('操作成功',200,$data_list);
    }
    
    public function getUserTermData()
{
    $id = input('id', 0, ['trim', FILTER_SANITIZE_NUMBER_INT]);
    $page = input('page', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);
    $pageSize = input('pageSize', 10, ['trim', FILTER_SANITIZE_NUMBER_INT]);

    if (empty($id)) {
        return ajaxmsg('缺少参数', 0);
    }

    // 初始化返回结构
    $data = [
        'list'       => [],
        'count'      => 0,
        'term_count' => 0,
        'team_true'  => 0,
        'zhi_count'  => 0,
        'zhi_true'   => 0,
        'page'       => $page,
        'pageSize'   => $pageSize,
    ];

    // 获取所有下级（递归）
    $allList = MemberModel::getAllSubordinatesIterative($id);
    $totalCount = count($allList);
    if ($totalCount == 0) {
        return ajaxmsg('操作成功', 200, $data);
    }

    /**
     * --------------------------------------------------
     * 一、分页处理
     * --------------------------------------------------
     */
    $offset = ($page - 1) * $pageSize;
    $list = array_slice($allList, $offset, $pageSize);

    // 所有下级用户ID（用于统计）
    $userIds = array_column($allList, 'id');
    $pageUserIds = array_column($list, 'id'); // 当前页的ID

    /**
     * --------------------------------------------------
     * 二、批量查询信息（仅当前页）
     * --------------------------------------------------
     */
    $memberInfos = MemberModel::whereIn('id', $pageUserIds)
        ->column('mobile,create_time,last_login_time,last_login_ip,level,name', 'id');

    $moneyInfos = \app\apicom\model\Money::whereIn('mid', $pageUserIds)
        ->column('account,pei_money', 'mid');

    $levels = MemberLevel::column('title', 'id');

    foreach ($list as &$item) {
        $uid = $item['id'];

        // 用户基础信息
        $member = $memberInfos[$uid] ?? [];
        $item['name']          = $member['name'] ?? '';
        $item['mobile']          = $member['mobile'] ?? '';
        $item['create_time']     = $member['create_time'] ?? '';
        $item['last_login_time'] = $member['last_login_time'] ?? '';
        $item['last_login_ip']   = $member['last_login_ip'] ?? '';
        $item['level_name']      = $levels[$member['level'] ?? 0] ?? '';

        // 资金信息
        $moneyInfo = $moneyInfos[$uid] ?? ['account' => 0, 'pei_money' => 0];
        $item['money']     = $moneyInfo['account'] ?? 0;
        $item['pei_money'] = $moneyInfo['pei_money'] ?? 0;

        // 订单、充值、提现、收益
        $item['single_money']       = SingleOrder::where(['user_id' => $uid, 'status' => 2])->sum('money');
        $item['recharge']           = Recharge::where(['mid' => $uid, 'status' => 1])->sum('money');
        $item['withdraw']           = Withdraw::where(['mid' => $uid, 'status' => 1])->sum('money');
        $item['single_yingli']      = RecordModel::where(['mid' => $uid, 'type' => 39])->sum('affect');
        $item['single_commission']  = RecordModel::where(['mid' => $uid, 'type' => 38])->sum('affect');
    }

    /**
     * --------------------------------------------------
     * 三、团队统计（不分页）
     * --------------------------------------------------
     */
    $orders = SingleOrder::whereIn('user_id', $userIds)
        ->whereIn('status', [2, 6])
        ->group('user_id')
        ->column('COUNT(*)', 'user_id');

    $recharges = Recharge::whereIn('mid', $userIds)
        ->where(['is_admin' => 0, 'status' => 1])
        ->group('mid')
        ->column('COUNT(*)', 'mid');

    $team_true = 0;
    foreach ($userIds as $uid) {
        if (!empty($orders[$uid]) && !empty($recharges[$uid])) {
            $team_true++;
        }
    }

    /**
     * --------------------------------------------------
     * 四、直属下级统计（不分页）
     * --------------------------------------------------
     */
    $zhi_info = MemberModel::where(['agent_far' => $id])
        ->field('id,type')
        ->select()
        ->toArray();

    $zhi_userIds = array_column($zhi_info, 'id');
    $zhi_true = 0;

    if (!empty($zhi_userIds)) {
        $zhi_orders = SingleOrder::whereIn('user_id', $zhi_userIds)
            ->whereIn('status', [2, 6])
            ->group('user_id')
            ->column('COUNT(*)', 'user_id');

        $zhi_recharges = Recharge::whereIn('mid', $zhi_userIds)
            ->where(['is_admin' => 0, 'status' => 1])
            ->group('mid')
            ->column('COUNT(*)', 'mid');

        foreach ($zhi_userIds as $uid) {
            if (!empty($zhi_orders[$uid]) && !empty($zhi_recharges[$uid])) {
                $zhi_true++;
            }
        }
    }

    /**
     * --------------------------------------------------
     * 五、返回分页数据
     * --------------------------------------------------
     */
    $data = [
        'list'       => $list,
        'count'      => $totalCount,     // 全部下级数量
        'term_count' => $totalCount,
        'team_true'  => $team_true,
        'zhi_count'  => count($zhi_userIds),
        'zhi_true'   => $zhi_true,
        'page'       => $page,
        'pageSize'   => $pageSize,
        'totalPage'  => ceil($totalCount / $pageSize),
    ];

    return ajaxmsg('操作成功', 200, $data);
}


    /*
     * 删除会员
     */
    public function delMember()
    {
        $id     = input('id','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $member = MemberModel::where('id', $id)->field('mobile, agent_id')->find();
        if(empty($member)) return ajaxmsg('查询失败',0);
		
		if ($member['agent_id'] > 0) {
			return ajaxmsg('操作失败,用户['. $member['mobile'].']是代理，请先取消代理资格',0);
		}
		$result = MemberModel::where('id', $id)->save(['is_del'=> 1]);
        if ($result) {
            return ajaxmsg('操作成功',200);
        } else {
            return ajaxmsg('操作失败',0);
        }
    }
    /*
     * 禁用会员
     */
    public function doDisable()
    {
        $id     = input('id','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $status = input('status','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
		if($status == '') return ajaxmsg('缺少参数',0);
		$res = MemberModel::where('id', $id)->save(['status'=> $status]);
        if ($res) {
            return ajaxmsg('操作成功',200);
        } else {
            return ajaxmsg('操作失败',0);
        }
    }
    /*
     * 新增会员
     */
    public function addMember()
    {
        $data = input();
//		$data['agent_far']= isset($data['agent_far'][0]) ? $data['agent_far'][0] : '';
		//print_r($data);exit;
		// 验证数据
		$result = $this->validate($data, 'Member.create');
		if ($result !== true) return ajaxmsg($result,0);
		
		if (empty($data['mobile'])) 
		    return ajaxmsg('请输入您的手机号！',0);
		$userExist = MemberModel::where('mobile|name', '=', $data['mobile'])->column('mobile', 'id');
        if ($userExist) 
            return ajaxmsg('该手机号已经注册',0);
		if (!in_array(strlen($data['mobile']), [8, 9, 10,11,12])) 
		    return ajaxmsg('您输入的手机号码有误!',0);
        $data['user_type'] = 1;
        $data['id_auth']    = 1;
        $data['recomed'] = generate_rand_str(5,5);
        if(!empty($data['pid_mobile'])){
            if(strlen($data['pid_mobile'])>=8) {
                $tid_data = MemberModel::where('mobile', $data['pid_mobile'])->find();
                if(empty($tid_data)) return ajaxmsg('上级不存在',0);
            }elseif(strlen($data['pid_mobile']) < 8){

                $tid_data = MemberModel::where('id', $data['pid_mobile'])->field('mobile,id')->find();
                if(empty($tid_data)) return ajaxmsg('上级不存在',0);
                if($tid_data['mobile']){
                    if($tid_data['mobile'] == $data['mobile']) return ajaxmsg('邀请人不能是自己',0);
                }
            }
            $data['agent_far'] = $tid_data['id'] ?: 0;
        }





		$res = MemberModel::saveData($data);

        MemberModel::applySave($res['data']['id']);
        if ($res) {
            return ajaxmsg('操作成功',200);
        } else {
            return ajaxmsg('操作失败',0);
        }
    }
    /*
     * 编辑用户
     */
    public function editMember()
    {
        $data = input();
        $data['agent_id'] = $data['agent_id'];
        $data['status']   = $data['status'];
        // $data['agent_far']= isset($data['agent_far'][0]) ? $data['agent_far'][0] : '';
        // if(isset($data['agent_far'][0])){
        //     $data['agent_far'] = $data['agent_pro'] = $data['agent_far'][0];
        // }else{
        //     $data['agent_far'] = $data['agent_pro'] = 0;
        // }
        if($data['passwd']) $data['passwd'] = password_hash($data['passwd'], PASSWORD_DEFAULT);
        if($data['paywd'] ) $data['paywd']  = password_hash($data['paywd'] , PASSWORD_DEFAULT);
        if (empty($data['id'])) return ajaxmsg('缺少ID参数！',0);
        if (empty($data['passwd'])) unset($data['passwd']);
        if (empty($data['paywd']))  unset($data['paywd']);
        //print_r($data);exit;
        unset($data['pei_time']);
		$res = MemberModel::strict(false)->where(['id'=>$data['id']])->save($data);
		if ($res) {
            return ajaxmsg('操作成功',200);
        } else {
            return ajaxmsg('操作失败',0);
        }
    }
    
        public function setPeiMoney()
    {
        $pei_money     = input('pei_money', 0);
        $pei_day    = input('pei_day', 0);
        $id    = input('id', '');
        $member = MemberModel::where(['id'=>$id])->field('is_pei,id')->find();
        if ($member['is_pei'] == 1) return ajaxmsg('配额已在使用中',0);
        if (!empty($pei_money) && !empty($pei_day)){
            $pei_day = $pei_day ? $pei_day : 1;
            $pei_time = strtotime(getTradeDateAfter(intval($pei_day)).date('H:i:s',time()));//订单到期时间
            Db::name('money')->where(['mid'=>$id])->update(['pei_money'=>$pei_money]);
           MemberModel::where(['id'=>$id])->update(['pei_time'=>$pei_time]);
           RecordModel::saveData($id, $pei_money, 0, 52, '增加配额：'.$pei_day.'天' . $pei_money);
        }else{
            Db::name('money')->where(['mid'=>$id])->update(['pei_money'=>0]);
            MemberModel::where(['id'=>$id])->update(['pei_time'=>null]);
        }
        return ajaxmsg('操作成功',200);
    }

   public function setRemark()
   {
       $id     = input('id', '');
       $remark    = input('remark', '');
       $res = MemberModel::strict(false)->where(['id'=>$id])->save(['remark'=>$remark]);
       if ($res) {
           return ajaxmsg('操作成功',200);
       } else {
           return ajaxmsg('操作失败',0);
       }
   }


    /*
     * 根据ID获取会员
     */
    public function getInfo()
    {
        $id     = input('id', '');
        $member = MemberModel::where('id', $id)->find()->toArray();
        $agents = MemberModel::where('agent_id', 1)->field('id,name,mobile')->select()->toArray();
        $datas=[];
        foreach ($agents as $k => $val){
            $datas[$k]['value'] = $val['id'];
            $datas[$k]['label'] = $val['name']." ".$val['mobile'];
        }
        $member['agents'] = $datas;
        return ajaxmsg('操作成功',200,$member); 
    }
    /* 
     * 获取代理列表
     */
    public function getAgents()
    {
        $res   = MemberModel::where(['agent_id'=>1,'agent_pro'=>1])->field('id,name,mobile')->select()->toArray();
        $datas = [];
        foreach ($res as $k => $val){
            $datas[$k]['value'] = $val['id'];
            $datas[$k]['label'] = $val['name']." ".$val['mobile'];
        }
        if($res){
            return ajaxmsg('操作成功',200, $datas); 
        }else {
            return ajaxmsg('操作失败',0);
        }
    }
    /*
     * 获取用户实名信息
     */
    public function getMemberCard()
    {
        $real_name   = input('real_name', '');
        $card_num   = input('card_num', '');
        $mobile = input('mobile','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $status = input('status',null);
        $user_type = input('user_type','',['trim', FILTER_SANITIZE_NUMBER_INT]);
        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order  = 'id desc';
        $where = [];

        if(!empty($real_name))   $where[] = ['c.real_name'  ,'=', $real_name];
        if(!empty($mobile)) $where[] = ['c.mobile','=', $mobile];
        if ($status !== null && $status !== '') $where[] = ['c.status', '=', intval($status)];
        if(!empty($card_num)) $where[] = ['c.card_num','=', $card_num];
        if(!empty($user_type)) $where[] = ['m.type','=', $user_type];

        $data_list = MemberCard::view('member_card c',true)
            ->view('member m','type as user_type','c.uid=m.id','left')
            ->where($where)
            ->order($order)
            ->paginate($offset, false, ['query' => request()->param()]);
        if(!$data_list) return ajaxmsg('没有数据',0);
       
        return ajaxmsg('操作成功',200,$data_list);
    }
    
     //获取用户银行卡列表
    public function getMemberBank()
    {
        $real_name   = input('real_name', '');
        $card   = input('card', '');
        $mobile = input('mobile','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order  = 'id desc';
        $where = [];
        if(!empty($real_name))   $where[] = ['b.real_name'  ,'=', $real_name];
        if(!empty($mobile)) $where[] = ['m.mobile','=', $mobile];
        if(!empty($card)) $where[] = ['b.card','=', $card];
        $data_list = Bank::getAllData($where,$order,$offset);
        if(!$data_list) return ajaxmsg('没有数据',0);

        return ajaxmsg('操作成功',200,$data_list);
    }
        //获取银行卡编辑数据
    public function bankInfo(){

        $bank = sysConfig('web_bank');
        if(!$bank) return false;
        $list = explode(PHP_EOL,$bank);
        $rate_val = array();
        foreach ($list as $k => $v){
            $arr = array(
                'id'   => $k,
                'name' => preg_replace('/\|img/', '',explode(':',$v)[1]),
            );
            array_push($rate_val, $arr);
        }
//        $data['real'] = Db::name('member')->field('name,mobile,id_card')->where(['id'=>$this->userId])->find();
        $data['list'] = $rate_val;
        return ajaxmsg('获取成功',200,$data);
    }
    /*
     * 编辑银行卡
     */
    public function bankInfoEdit(){
        $data['id']        = input('post.id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $data['card']      = input('post.card', '');
        $data['branch']      = input('post.branch', '');
        $data['real_name'] = input('post.real_name', '');
        $data['bank_name'] = input('post.bank_name', '');
        $res=(new Bank())->where(['id'=>$data['id']])->update($data);
        if ($res){
            return ajaxmsg('操作成功',200);
        }else{
            return ajaxmsg('操作失败',0);
        }

    }
     /*
     * 删除银行卡
     * id 要删除的银行卡id
     */
    public function delBank()
    {
        $id   = input('id' , '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $res  = Bank::del_bank($id);
        if(!$res) return ajaxmsg('删除失败',0);
        return ajaxmsg('解绑成功',200);
    }
    
    
    
    
    
    
    
    
    
    
    
    public function memberCardStatus()
    {
        $id = input('id','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $status= input('status','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $remark= input('remark','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $cardInfo = (new MemberCard())->where(['id'=>$id])->find();
        if(!$cardInfo) return ajaxmsg('没有数据',0);
        $cardInfo['status'] = $status;
        $cardInfo['remark'] = $remark;
        if ($status==1){
            $userInfo = (new MemberModel())->where(['id'=>$cardInfo['uid']])->field('id,name,id_auth')->find();
            $userInfo->name = $cardInfo['real_name'];
            $userInfo->id_auth = 1;
            $userInfo->id_card = $cardInfo['card_num'];
            $userInfo->save();
        }
        $res = $cardInfo->save();
        if($res){
            return ajaxmsg('操作成功',200);
        }else{
            return ajaxmsg('操作失败',0);
        }
    }
    
    public function addMemberCard()
    {
        $data['card_num']   = input('card_num', '');
        $data['real_name'] = input('real_name', '');
        $data['card_pic_head'] = input('card_pic_head', '');
        $data['card_pic_back'] = input('card_pic_back', '');
        $data['mobile'] = input('mobile', '');
        $data['status']= input('status','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        if (empty($data['card_num']) || empty($data['real_name']) || empty($data['card_pic_head']) || empty($data['card_pic_back']) || empty($data['mobile'])) return ajaxmsg('请填写完整信息',0);
        $member = MemberModel::where(['mobile'=>$data['mobile']])->field('id,id_auth,name')->find();
        if (!$member) return ajaxmsg('用户不存在',0);
        $cardInfo = (new MemberCard())->where(['card_num'=>$data['card_num']])->find();
        if (!empty($cardInfo)) return ajaxmsg('该身份证号码已存在',0);
        $memberCard = (new MemberCard())->where(['uid'=>$member['id']])->find();
        if ($memberCard) return ajaxmsg('该用户已存在认证信息',0);
        $data['uid'] = $member['id'];
        if ($data['status']==1){
            $member['name'] = $data['real_name'];
            $member['id_auth'] = 1;
            $member['id_card'] = $data['card_num'];
            $member->save();
           $res= (new MemberCard())->save($data);
        }else{
            $res=  (new MemberCard())->save($data);
        }
        if($res){
            return ajaxmsg('操作成功',200);
        }else{
            return ajaxmsg('操作失败',0);
        }
    }
    

    /*
        * 后台增加/扣除总资金
        */
    public function memberMoney()
    {
        $id = input('post.id','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $money = input('post.money',0);
        $type = input('post.type',1, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        if (!$money)  return ajaxmsg('请输入正确金额',0);
        $user = MemberModel::where('id', $id)->field('id')->find();
        $account = Db::name('money')->where('mid', $user['id'])->find();
        if (empty($user)) return  ajaxmsg('参数不正确',0);
        if ($type==1){
            $upMoney = bcadd(strval($account['account']), strval($money),2) ;
            if($account){
                $res_m = Db::name('money')->where('mid', $user['id'])->update(['account' => $upMoney]);
            }else{
                $res_m = Db::name('money')->insert(['mid'=>$user['id'],'account'=>$upMoney,'status'=>'1']);
            }
            RecordModel::saveData($user['id'],  $money, $upMoney, 45, '充值金额：'.$money);
            return  ajaxmsg('充值成功',200);
        }elseif ($type==2){
            if ($account['account'] < $money) return  ajaxmsg('可用余额不足',0);
            $upMoney = bcsub(strval($account['account']), strval($money),2) ;
            Db::name('money')->where('mid', $user['id'])->update(['account' => $upMoney]);
            RecordModel::saveData($user['id'],  $money, $upMoney, 46, '扣除金额：'.$money);
            return  ajaxmsg('扣除成功',200);
        }else{
            return  ajaxmsg('非法请求',0);
        }

    }
    /*
 * 获取会员等级列表
 */
    public function getMemberLevel()
    {
        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order  = 'id desc';
        $data_list = MemberLevel::view('member_level')
            ->order($order)
            ->paginate($offset, false, ['query' => request()->param()]);
        if(!$data_list) return ajaxmsg('没有数据',0);

        return ajaxmsg('操作成功',200,$data_list);
    }
    public function addMemberLevel()
    {
        $data = input();
        if ( empty($data['lv'])) return ajaxmsg('缺少参数！',0);
        (new MemberLevel())->save($data);
        return  ajaxmsg('添加成功',200);
    }
    public function editMemberLevel()
    {
        $data = input();
        if (empty($data['id'])) return ajaxmsg('缺少ID参数！', 0);
        $levelInfo = (new MemberLevel())->where(['id' => $data['id']])->find();
        if (empty($levelInfo)) return ajaxmsg('非法操作', 0);
        $levelInfo->save($data);
        return ajaxmsg('编辑成功', 200);
    }
    /*
 * 更新是否分红状态
 */
    public function levelIsTrue()
    {
        $data = input();
        if (empty($data['id'])) return ajaxmsg('缺少ID参数！', 0);
        $levelInfo = (new MemberLevel())->where(['id' => $data['id']])->find();
        if (empty($levelInfo)) return ajaxmsg('非法操作', 0);
        $levelInfo->is_true = $levelInfo->is_true==1?0:1;
        $levelInfo->save();
        return ajaxmsg('操作成功', 200);
    }
    public function getMemberCommission()
    {

        $mobile = input('mobile','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $uid = input('uid','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order  = 'id desc';
        $where= [];
        if(!empty($mobile)) $where[] = ['b.mobile','=', $mobile];
        if(!empty($uid)) $where[] = ['b.uid','=', $uid];
        $data_list = MemberCommission::view('member_commission a')
            ->view('member b','uid,mobile,name','a.uid=b.id')
            ->view('member bs','mobile as send_mobile,name as send_name ,uid as send_uid','a.send_uid=bs.id')
            ->where($where)
            ->order($order)
            ->paginate($offset, false, ['query' => request()->param()])
            ->each(function ($item,$key){
//                $item['mobile'] = substr_mobile($item['mobile']);
//                $item['send_mobile'] = substr_mobile($item['send_mobile']);
                if (!empty($item['auth_time'])) $item['auth_time'] = date('Y-m-d H:i',$item['auth_time']);

            });
        if(!$data_list) return ajaxmsg('没有数据',0);

        return ajaxmsg('操作成功',200,$data_list);
    }
    
    public function editMemberCard()
    {
        $data = input();
        if (empty($data['id'])) return ajaxmsg('缺少ID参数！', 0);
        $cardInfo = (new MemberCard())->where(['id' => $data['id']])->find();
        if (empty($cardInfo)) return ajaxmsg('非法操作', 0);
//        if ($cardInfo->status !=0 ) return ajaxmsg('该订单不允许操作', 0);
        if ($data['status']==1){
            $userInfo = (new MemberModel())->where(['id'=>$cardInfo['uid']])->field('id,name,id_auth')->find();
            $userInfo->name = $cardInfo['real_name'];
            $userInfo->id_auth = 1;
            $userInfo->id_card = $cardInfo['card_num'];
            $userInfo->save();
        }
        if(!empty($data['create_time'])) {
            $data['create_time'] = strtotime($data['create_time']);
        }else{
            $data['create_time'] = time();
        }
        $cardInfo->save($data);
        return ajaxmsg('编辑成功', 200);

    }
    
}

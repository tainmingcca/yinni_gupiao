<?php

namespace app\admin\controller;


use app\admin\model\SingleSource;
use app\admin\model\StockList;
use app\apicom\model\Borrow;
use app\apicom\model\Member as MemberModel;
use app\apicom\model\Record as RecordModel;
use app\apicom\model\SingleAddmoney;
use app\apicom\model\SingleItem;
use app\apicom\model\SingleOrder;
use app\apicom\model\SingleSourceUser;
use app\apicom\model\StockDealStock;

use app\apicom\model\StockDeliveryOrder as Delivery;
use app\apicom\model\StockPosition;
use app\apicom\model\StockSubAccount;
use app\apicom\model\SubAccount;
use app\apicom\model\SubAccountMoney;
use app\apicom\model\Trust;
use app\apicom\model\Money;
use app\service\StockYinni;
use Monolog\Handler\IFTTTHandler;
use think\Exception;
use think\facade\Db;
use util\RedisUtil;
use think\facade\Queue;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

use app\apicom\model\Investitem;
use app\apicom\model\InvestitemOrder;

/**
 * 投資
 * @package app\apicom\home
 */
class Investitems extends AdminBase
{

    /*
     * 获取项目列表
     */
    public function getItemList()
    {
        $where = [];
        $title   = input('title', '');
        $id  = input('id', '');
        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order  = 'id desc';
        if(!empty($title))   $where[] = ['title'  ,'=', $title];
        if(!empty($id))   $where[] = ['id'  ,'=', $id];
        $data_list = Investitem::where($where)
            ->order($order)
            ->paginate($offset, false, ['query' => request()->param()]);
        if(!$data_list) return ajaxmsg('没有数据',0);
        return ajaxmsg('操作成功',200,$data_list);
    }
    /*
    * 新增项目
    */
    public function addItem()
    {

        $data = input();

        $res =(new Investitem())->save($data);
        if ($res) {
            return ajaxmsg('操作成功',200);
        } else {
            return ajaxmsg('操作失败',0);
        }
    }
    /*
   * 编辑项目
   */
    public function editItem()
    {

        $data   = input();
        if (empty($data['id'])) return ajaxmsg('缺少ID参数！',0);

        $res = Investitem::strict(false)->where(['id'=>$data['id']])->save($data);
        if ($res) {
            return ajaxmsg('操作成功',200);
        } else {
            return ajaxmsg('操作失败',0);
        }
    }

    /*
     * 获取项目收益率列表
     */
    public function getIncomerate()
    {
        $where = [];
        $title   = input('title', '');
        $id  = input('id', '');
        $offset = input('pageSize',200, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order  = 'id desc';
        if(!empty($id))   $where[] = ['item_id'  ,'=', $id];
        $data_list = Db::name('invest_item_income')->where($where)
            ->order($order)
            ->paginate($offset, false, ['query' => request()->param()]);
        if(!$data_list) return ajaxmsg('没有数据',0);
        return ajaxmsg('操作成功',200,$data_list);
    }
    /*
* 编辑项目收益率
*/
    public function editItemIncomerate()
    {
        $data   = input();
        if (empty($data['id'])) return ajaxmsg('缺少ID参数！',0);

        $itemId = $data['id'];

        //先刪除在插入
       // Db::name('invest_item_income')->where('item_id',$itemId)->delete();

        //$data['rateList']=[{"id":82,"item_id":3,"date":"2025-10-17","rate":"40.00","status":1},{"id":83,"item_id":3,"date":"2025-10-18","rate":"55.00","status":1}]
        $rateList = $data['rateList'];
        // 查询数据库现有的数据
        $rateList_now = Db::name('invest_item_income')->where(['item_id'=>$itemId])->select();

        // 提取接收数据中的所有ID
        $receivedIds = [];
        foreach ($rateList as $rate) {
            if (isset($rate['id'])) {
                $receivedIds[] = $rate['id'];
            }
        }

        // 提取数据库中的所有ID
        $existingIds = [];
        foreach ($rateList_now as $item) {
            if (is_array($item)) {
                $existingIds[] = $item['id'];
            } else {
                $existingIds[] = $item->id;
            }
        }

        // 找出需要删除的ID（在数据库中存在但在接收数据中不存在的ID）
        $idsToDelete = array_diff($existingIds, $receivedIds);

        // 删除多余的记录
        if (!empty($idsToDelete)) {
            Db::name('invest_item_income')->where('id', 'in', $idsToDelete)->delete();
        }

//        $insertData = [];
        foreach ($rateList as $rate) {
            if(isset($rate['id'])){
                Db::name('invest_item_income')->where(['id'=>$rate['id']])->update(['date' => $rate['date'],'rate' => $rate['rate']]);
            }else{
                $insertData = [
                    'item_id' => $itemId,
                    'date'    => $rate['date'],
                    'rate'    => $rate['rate']
                ];
                Db::name('invest_item_income')->insert($insertData);
            }
        }
//        // 批量插入
//        if (!empty($insertData)) {
//            Db::name('invest_item_income')->insertAll($insertData);
//        }
        return ajaxmsg('操作成功',200);
    }

    /*
     * 获取项目收益周期
     */
    public function getIncomeday()
    {
        $where = [];
        $title   = input('title', '');
        $id  = input('id', '');
        $offset = input('pageSize',200, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order  = 'id desc';
        if(!empty($id))   $where[] = ['item_id'  ,'=', $id];
        $data_list = Db::name('invest_item_day')->where($where)
            ->order($order)
            ->paginate($offset, false, ['query' => request()->param()]);
        if(!$data_list) return ajaxmsg('没有数据',0);
        return ajaxmsg('操作成功',200,$data_list);
    }
    /*
* 编辑项目收益周期
*/
    public function editItemIncomeday()
    {
        $data   = input();
        if (empty($data['id'])) return ajaxmsg('缺少ID参数！',0);

        $itemId = $data['id'];

        //先刪除在插入
        // Db::name('invest_item_income')->where('item_id',$itemId)->delete();

        $rateList = $data['rateList'];

        // 查询数据库现有的数据
        $rateList_now = Db::name('invest_item_day')->where(['item_id'=>$itemId])->select();

        // 提取接收数据中的所有ID
        $receivedIds = [];
        foreach ($rateList as $rate) {
            if (isset($rate['id'])) {
                $receivedIds[] = $rate['id'];
            }
        }

        // 提取数据库中的所有ID
        $existingIds = [];
        foreach ($rateList_now as $item) {
            if (is_array($item)) {
                $existingIds[] = $item['id'];
            } else {
                $existingIds[] = $item->id;
            }
        }

        // 找出需要删除的ID（在数据库中存在但在接收数据中不存在的ID）
        $idsToDelete = array_diff($existingIds, $receivedIds);

        // 删除多余的记录
        if (!empty($idsToDelete)) {
            Db::name('invest_item_day')->where('id', 'in', $idsToDelete)->delete();
        }


        // 准备批量插入数据
//        $insertData = [];
        foreach ($rateList as $rate) {
            if(isset($rate['id'])){
                Db::name('invest_item_day')->where(['id'=>$rate['id']])->update(['day' => $rate['day'],'rate' => $rate['rate']]);
            }else{
                $insertData = [
                    'item_id' => $itemId,
                    'day'    => $rate['day'],
                    'rate'    => $rate['rate'],
//                    'end_time'    => $rate['end_time']
                ];
                Db::name('invest_item_day')->insert($insertData);
            }


        }
//        // 批量插入
//        if (!empty($insertData)) {
//            Db::name('invest_item_income')->insertAll($insertData);
//        }
        return ajaxmsg('操作成功',200);
    }


    /*
     * 获取记录列表
     */
    public function getItemOrder()
    {
        $mobile   = input('mobile', '');
        $order_sn   = input('order_sn', '');
        $status   = input('status', '');
        $single_title   = input('single_title', '');
        $date  = input('date', '');
        $user_type   = input('user_type', '');
        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $single_day = input('single_day','');
         $level   = input('level', '');
        
        $order  = 'id desc';
        $where = [];
         if(!empty($level))   $where[] = ['l.id'  ,'=', $level];
        if(!empty($mobile))   $where[] = ['m.mobile'  ,'=', $mobile];
        if(!empty($user_type))   $where[] = ['m.type'  ,'=', $user_type];
        if(!empty($order_sn))   $where[] = ['r.order_sn'  ,'=', $order_sn];
        if(!empty($single_title))   $where[] = ['r.single_title'  ,'=', $single_title];
        if(!empty($status))   $where[] = ['r.status'  ,'=', $status];
        if(!empty($single_day))   $where[] = ['r.single_day'  ,'=', $single_day];
        if (!empty($date)) {
            $start_date =  $date."00:00:00";
            $end_date =  $date."23:59:59";
            $where[] = ['r.create_time' ,'>=', strtotime($start_date)];
            $where[] = ['r.create_time' ,'<=', strtotime($end_date)];
        }
        $data_list = InvestitemOrder::view('invest_order r')
            ->view('member m', 'type as user_type,mobile as u_mobile', 'm.id=r.user_id', 'left')
            ->view('member_level l', 'title as level_name', 'm.level=l.id', 'left')
            ->where($where)
            ->order($order)
            ->paginate($offset, false, ['query' => request()->param()])
            ->each( function($item, $key){
                $item['auth_time'] = date('Y-m-d H:i:s',$item['auth_time']);
                $item['money'] = format_amount($item['money']);
                $item['total_income'] = format_amount($item['total_income']);
                $item['balance'] = format_amount($item['balance']);
                if (!empty($item['end_time'])) $item['end_time'] = date('Y-m-d H:i:s',$item['end_time']);
                $item['mobile'] = $item['u_mobile'];
            });
        if(!$data_list) return ajaxmsg('没有数据',0);
        return ajaxmsg('操作成功',200,$data_list);
    }

    /*
 * 收益日志记录
 */
    public function getInvestIncome()
    {


        $order_id     = input('order_id', 0, ['trim', FILTER_SANITIZE_NUMBER_INT]);

        $list = Db::name('invest_order_log')->where(['order_id'=>$order_id])->order('id', 'asc')->select()->toArray();;

        if(!$list) return ajaxmsg(lang('data'),0);
        foreach ($list as $k => $v){
            $list[$k]['starting_amount'] = format_amount($v['starting_amount']);
            $list[$k]['ending_amount'] = format_amount($v['ending_amount']);
            $list[$k]['total_income'] = format_amount($v['total_income']);
            $list[$k]['day_income'] = format_amount($v['day_income']);

        }

        return ajaxmsg(lang('success'), 1, $list);
    }


    /*
* 审核跟投订单
*/
    public function itemOrderStatus()
    {
        $id = input('id',0, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $data = InvestitemOrder::where(['id'=>$id])->find();
        if (empty($data)) return ajaxmsg('没有数据',0);
        if ($data->status != 1) return ajaxmsg('改订单不允许操作',0);
        $invest_item = Db::name('invest_item_day')->where(['id'=>$data->invest_day_id])->find();
        $data->status = $data->status == 1 ? 2 : 1;
        $data->deal_status = 2;
        $data->auth_time = time();

        $start_time = strtotime($data['start_time']);//項目開始時間
        //根據周期天數 計算 對應 周期 結束時間
        $period_days = $invest_item['day'];
        $end_timestamp = strtotime($start_time . " +" . ($period_days - 1) . " days");
        $end_time = date('Y-m-d', $end_timestamp);
        $data->end_time = strtotime($end_time . ' 23:59:59');//订单到期时间

        $data->save();
        return ajaxmsg('操作成功',200);
    }
    /*
     * 批量通过跟投订单
     */
    public function itemOrderStatusIds()
    {
        $ids = input('ids', '');
        if (empty($ids)) return ajaxmsg('请选择通过订单',0);
        $ids = explode(',', $ids);
        foreach ($ids as $id) {
            $data = InvestitemOrder::where(['id'=>$id])->field('id,status,invest_id,invest_day_id')->find();
            $investInfo = Db::name('invest_item_day')->where('id', $data['invest_day_id'])->find();
            if ($data['status']==1){
                $data->status = 2;
                $data->deal_status = 2;
                $data->auth_time = time();

                $start_time = strtotime($data['start_time']);//項目開始時間
                //根據周期天數 計算 對應 周期 結束時間
                $period_days = $investInfo['day'];
                $end_timestamp = strtotime($start_time . " +" . ($period_days - 1) . " days");
                $end_time = date('Y-m-d', $end_timestamp);
                $data->end_time = strtotime($end_time . ' 23:59:59');//订单到期时间


                $data->save();
            }
        }
        return ajaxmsg('操作成功',200);
    }
    /*
     * 驳回订单
     */
    public function outItemOrder()
    {
        $id = input('id',0, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $data = InvestitemOrder::where(['id'=>$id])->find();
        if (empty($data)) return ajaxmsg('没有数据',0);
        if ($data->status != 1) return ajaxmsg('改订单不允许操作',0);
        $money_info = Db::name('money')->where('mid', $data['user_id'])->lock(true)->find();
        $money = $data['money'];
        try {
            // 启动事务
            Db::startTrans();
            $upMoney = bcadd(strval($money_info['account']), strval($money));   // 当前余额+驳回余额
            Db::name('money')->where('mid', $data['user_id'])->update(['account' => $upMoney]);   // 加回余额
            RecordModel::saveData($data['user_id'], $money, $upMoney, 104, '投資驳回：' . $data['order_sn']);
            $data->status = 3;
            $data->auth_time = time();
            $data->save();
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return ajaxmsg('驳回失败', $e->getMessage());
        }
        return ajaxmsg('驳回成功',200);
    }

    /*
     * 執行項目收益
     */
    public function executeInvestIncome()
    {
        //項目ID
        $id = input('id',0, ['trim', FILTER_SANITIZE_NUMBER_INT]);

        //匹配對應時間的收益率
        $current_time = date('Y-m-d',time());
        $income = Db::name('invest_item_income')->where(['item_id'=>$id,'date'=>$current_time])->find();
        if(empty($income)) {
            return ajaxmsg('今日收益率未设置',0);
        }
        if($income['status'] ==2){
            return ajaxmsg('今日已经执行收益了！ ！',0);
        }
//        $income = Db::name('invest_item_income')->where(['item_id'=>$id,'status'=>1])->order('id asc')->find();
//        if(empty($income)){
//            return ajaxmsg('收益率未设置',0);
//        }


        //投資記錄
        $orderlists = Db::name('invest_order')->where(['status'=>2,'deal_status'=>2,'invest_id'=>$id])->select();
        if ($orderlists->isEmpty()) return ajaxmsg('暂无投资记录',0);
        foreach ($orderlists as $orderlist) {
            $task = [
                'income_id' => $income['id'],
                'income_rate' => $income['rate'],
                'order_money' => $orderlist['money'],
                'order_user_id' => $orderlist['user_id'],
                'order_invest_id' => $orderlist['invest_id'],
                'order_id' => $orderlist['id'],
                'order_invest_day_id' => $orderlist['invest_day_id'],
                'order_end_time' => $orderlist['end_time'],
                'income_date' => $income['date']
            ];
            Queue::push(\app\job\InvestJob::class, $task, 'Invest');
        }

//        $task = [
//            'invest_id' => $id,
//            'income_id' => $income['id'],
//            'income_rate' => $income['rate'],
//        ];
//        Queue::push(\app\job\InvestJob::class, $task, 'Invest');
        return ajaxmsg('收益執行中',200);
    }


    //导出

    public function export()
    {
        $admin_user = Db::name('admin_user')->where(['id'=>$this->adminId])->field('id,username')->find();
        
        if ($admin_user['username']!='admin' && $admin_user['username']!='admin5' ) return ajaxmsg('当前账户不允许操作',0);
        $mobile   = input('mobile', '');
        $order_sn   = input('order_sn', '');
        $status   = input('status', '');
        $date  = input('date', '');
        $user_type   = input('user_type', '');
        $single_title   = input('single_title', '');
        $where = [];
        if(!empty($mobile))   $where[] = ['m.mobile'  ,'=', $mobile];
        if(!empty($user_type))   $where[] = ['m.type'  ,'=', $user_type];
        if(!empty($order_sn))   $where[] = ['r.order_sn'  ,'=', $order_sn];
        if(!empty($single_title))   $where[] = ['r.single_title'  ,'=', $single_title];
        if(!empty($single_day))   $where[] = ['r.single_day'  ,'=', $single_day];
        if(!empty($status))   $where[] = ['r.status'  ,'=', $status];
        if (!empty($date)) {
            $start_date =  $date."00:00:00";
            $end_date =  $date."23:59:59";
            $where[] = ['r.create_time' ,'>=', strtotime($start_date)];
            $where[] = ['r.create_time' ,'<=', strtotime($end_date)];
        }
        $list = SingleOrder::view('single_order r')
            ->view('member m', 'type as user_type', 'm.id=r.user_id', 'left')
            ->view('money y', 'account', 'm.id=y.mid', 'left')
            ->where($where)
            ->select()->toArray();
        if (empty($list)) {
            return ajaxmsg('暂无可导出的数据');
        }
        // 定义表头
        $header = [
            'ID', '订单号', '用户账户', '跟投天数', '金额', '状态', '创建时间','用户类型','账户余额'
        ];
        // 创建表格对象
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
// 写入表头
        $colIndex = 1;
        foreach ($header as $title) {
            $sheet->setCellValueByColumnAndRow($colIndex, 1, $title);
            $colIndex++;
        }
        // 写入数据
        $rowIndex = 2;
        foreach ($list as $order) {
            $sheet->setCellValueByColumnAndRow(1, $rowIndex, $order['id']);
            $sheet->setCellValueByColumnAndRow(2, $rowIndex, $order['order_sn']);
            $sheet->setCellValueByColumnAndRow(3, $rowIndex, $order['mobile']);
            $sheet->setCellValueByColumnAndRow(4, $rowIndex, $order['single_day']);
            $sheet->setCellValueByColumnAndRow(5, $rowIndex, $order['money']);
            $sheet->setCellValueByColumnAndRow(6, $rowIndex, $this->getStatusText($order['status']));
            $sheet->setCellValueByColumnAndRow(7, $rowIndex, $order['create_time']);
            $sheet->setCellValueByColumnAndRow(8, $rowIndex, $this->getUserTypeText($order['user_type']));
            $sheet->setCellValueByColumnAndRow(9, $rowIndex, $order['account']);
            $rowIndex++;
        }
        // 设置自动列宽
        foreach (range('A', 'G') as $col) {
            $sheet->getColumnDimension($col)->setAutoSize(true);
        }
        // 生成文件名
        $fileName = '订单导出_' . date('Ymd_His') . '.xlsx';
        $filePath = runtime_path() . 'export/' . $fileName;

        // 确保导出目录存在
        if (!is_dir(dirname($filePath))) {
            mkdir(dirname($filePath), 0777, true);
        }

        // 写入文件
        $writer = new Xlsx($spreadsheet);
        $writer->save($filePath);

        // 输出文件下载
        return download($filePath, $fileName)->isContent(false);
//        return ajaxmsg('操作成功',200,['file_path'=>$filePath]);
    }
    /**
     * 状态文字转换
     */
    private function getStatusText($status)
    {
        $map = [

            1 => '待审核',
            2 => '已通过',
            3 => '已驳回',
            6 => '已完成',
        ];
        return $map[$status] ?? '未知';
    }
    /**
     * 状态文字转换
     */
    private function getUserTypeText($type)
    {
        $map = [

            1 => '用户',
            2 => '营销',
            3 => '体验',
        ];
        return $map[$type] ?? '未知';
    }
    


}
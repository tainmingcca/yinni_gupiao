<?php

namespace app\admin\controller;
use app\apicom\model\Member;

/**
 * 跟单/带单项目
 */


class WithSingle extends AdminBase
{
    /*
     * 获取列表
     */
    public function getWithSingleList()
    {
        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order  = 'id desc';
        $where  = ['status'=>1];
        $res = Member::getSinglelist($where,$order,$offset);
        if($res){
            return ajaxmsg('操作成功',200, $res);
        }else {
            return ajaxmsg('操作失败',0);
        }

    }

    /*
 * 启用/禁用 状态
 */
    public function doDisable()
    {
        $id     = input('id','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $status = input('status','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $res = WithSingleModel::where('id', $id)->save(['status'=> $status]);
        if ($res) {
            return ajaxmsg('操作成功',200);
        } else {
            return ajaxmsg('操作失败',0);
        }
    }

    /**
     * 老师详情页
     */
    public function getDetail()
    {
        $id    = input('id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        if (!$id) return ajaxmsg("缺少参数",0);
        // 获取文章内容
        $info = WithSingleModel::where(['id'=> $id,'status' => 1])->find();
        $info['img_url'] = sysConfig('app_url').getFilePath($info['cover']);
        if(!$info) return ajaxmsg('查询失败',0);
        return ajaxmsg('获取成功',200,$info);
    }
    /*
 * 新增带单老师
 */
    public function addSlider()
    {
        $data = input();
        $data['create_time'] = time();
        // 验证数据
        $result = $this->validate($data, 'SithSingle.create');
        if ($result !== true) return ajaxmsg($result,0);
        //dump($data);exit;
        $res = WithSingleModel::saveData($data);
        if ($res) {
            return ajaxmsg('操作成功',200);
        } else {
            return ajaxmsg('操作失败',0);
        }
    }

}
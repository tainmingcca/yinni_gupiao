<?php

namespace app\admin\controller;


use app\admin\model\SingleSource;
use app\admin\model\StockList;
use app\apicom\model\Borrow;
use app\apicom\model\Member as MemberModel;
use app\apicom\model\Record as RecordModel;
use app\apicom\model\SingleAddmoney;
use app\apicom\model\SingleItem;
use app\apicom\model\SingleOrder;
use app\apicom\model\SingleSourceUser;
use app\apicom\model\StockDealStock;

use app\apicom\model\StockDeliveryOrder as Delivery;
use app\apicom\model\StockPosition;
use app\apicom\model\StockSubAccount;
use app\apicom\model\SubAccount;
use app\apicom\model\SubAccountMoney;
use app\apicom\model\Trust;
use app\apicom\model\Money;
use app\service\StockYinni;
use Monolog\Handler\IFTTTHandler;
use think\Exception;
use think\facade\Db;
use util\RedisUtil;
use think\facade\Queue;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

/**
 * 后台跟单操作控制
 * @package app\apicom\home
 */
class Single extends AdminBase
{

    /*
     * 获取老师列表
     */
    public function getSingleUser()
    {
        $name   = input('name', '');
        $single_name   = input('single_name', '');
        $mobile = input('mobile','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order  = 'id desc';

        if(!empty($name))   $where[] = ['a.name'  ,'=', $name];
        if(!empty($single_name))   $where[] = ['a.single_name'  ,'=', $single_name];
        if(!empty($mobile)) $where[] = ['a.mobile','=', $mobile];
        $where[]   = ['a.is_del' ,'=', 0];
        $where[]   = ['a.user_type' ,'=', 2];

        $data_list = MemberModel::view('member a')
            ->view('money b','account,freeze,operate_account,bond_account,single_money','a.id=b.mid')
            ->where($where)
            ->order($order)
            ->paginate($offset, false, ['query' => request()->param()]);
        if(!$data_list) return ajaxmsg('没有数据',0);

        return ajaxmsg('操作成功',200,$data_list);

    }


    /*
 * 新增带单老师
 */
    public function addSingleUser()
    {
        $data = input();
        $MemberModel = new MemberModel();
        if (empty($data['mobile']))
            return ajaxmsg('请输入您的手机号！',0);
        $userExist = MemberModel::where('mobile|name', '=', $data['mobile'])->column('mobile', 'id');
        if ($userExist)
            return ajaxmsg('该手机号已经注册',0);
        if (!in_array(strlen($data['mobile']), [8, 9, 11]))
            return ajaxmsg('您输入的手机号码有误!',0);
        $data['user_type'] = 2;
        isset($data['name']) ? $data['name'] : '';
        $data['create_ip']   = getClientIp();
        $data['create_time'] = date('Y-m-d H:i:s',time());
        $data['passwd'] = password_hash($data['passwd'], PASSWORD_DEFAULT);
        $data['paywd']  = password_hash(substr($data['mobile'],-6,6), PASSWORD_DEFAULT);
        $res =$MemberModel->save($data);
        if ($res) {
            Db::name('money')->insert(['mid'=>$MemberModel->id]);
            return ajaxmsg('操作成功',200);
        } else {
            return ajaxmsg('操作失败',0);
        }
    }

    /*
    * 删除会带单老师
    */
    public function delSingleUser()
    {
        $id     = input('id','', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $member = MemberModel::where('id', $id)->field('mobile, agent_id')->find();
        if(empty($member)) return ajaxmsg('查询失败',0);

        if ($member['agent_id'] > 0) {
            return ajaxmsg('操作失败,用户['. $member['mobile'].']是代理，请先取消代理资格',0);
        }
        $result = MemberModel::where('id', $id)->save(['is_del'=> 1]);
        if ($result) {
            return ajaxmsg('操作成功',200);
        } else {
            return ajaxmsg('操作失败',0);
        }
    }





    /*
   * 编辑带单老师账户
   */
    public function editSingleUser()
    {
        $data = input();
        $data['status']   = $data['status'];
        if (empty($data['id'])) return ajaxmsg('缺少ID参数！',0);

        $res = MemberModel::strict(false)->where(['id'=>$data['id']])->save($data);
        if ($res) {
            return ajaxmsg('操作成功',200);
        } else {
            return ajaxmsg('操作失败',0);
        }
    }

    /*
     * 获取项目列表
     */


    public function getSingleItem()
    {
        $where = [];
        $title   = input('title', '');
        $id  = input('id', '');
        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order  = 'id desc';
        if(!empty($title))   $where[] = ['title'  ,'=', $title];
        if(!empty($id))   $where[] = ['id'  ,'=', $id];
        $data_list = SingleItem::where($where)
            ->order($order)
            ->paginate($offset, false, ['query' => request()->param()]);
        if(!$data_list) return ajaxmsg('没有数据',0);
        return ajaxmsg('操作成功',200,$data_list);
    }
    /*
   * 编辑项目
   */


    public function editSingleItem()
    {
        $where = [];
        $data   = input();
        if (empty($data['id'])) return ajaxmsg('缺少ID参数！',0);
        $data['create_time'] = strtotime($data['create_time']);
        $data['with_name'] = (new MemberModel())->where(['id'=>$data['user_id']])->value('single_name');
        $data['min_day'] = $data['day'];
        $data_list = SingleItem::strict(false)->where(['id'=>$data['id']])->save($data);
        if(!$data_list) return ajaxmsg('没有数据',0);
        return ajaxmsg('操作成功',200,$data_list);
    }

    /*
* 新增带单项目
*/
    public function addSingleItem()
    {

        $data = input();
        if (empty($data['user_id'])) return ajaxmsg('请选择老师！',0);
        $data['with_name'] = (new MemberModel())->where(['id'=>$data['user_id']])->value('single_name');
        $data['status'] = 1;

        $res =(new SingleItem())->save($data);
        if ($res) {
            return ajaxmsg('操作成功',200);
        } else {
            return ajaxmsg('操作失败',0);
        }
    }

    /*
     * 获取跟单申请记录列表
     */
    public function getSingleOrder()
    {
        $mobile   = input('mobile', '');
        $order_sn   = input('order_sn', '');
        $status   = input('status', '');
        $single_title   = input('single_title', '');
        $date  = input('date', '');
        $user_type   = input('user_type', '');
        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $single_day = input('single_day','');
        
        $order  = 'id desc';
        $where = [];
        if(!empty($mobile))   $where[] = ['m.mobile'  ,'=', $mobile];
        if(!empty($user_type))   $where[] = ['m.type'  ,'=', $user_type];
        if(!empty($order_sn))   $where[] = ['r.order_sn'  ,'=', $order_sn];
        if(!empty($single_title))   $where[] = ['r.single_title'  ,'=', $single_title];
        if(!empty($status))   $where[] = ['r.status'  ,'=', $status];
        if(!empty($single_day))   $where[] = ['r.single_day'  ,'=', $single_day];
        if (!empty($date)) {
            $start_date =  $date."00:00:00";
            $end_date =  $date."23:59:59";
            $where[] = ['r.create_time' ,'>=', strtotime($start_date)];
            $where[] = ['r.create_time' ,'<=', strtotime($end_date)];
        }
        $data_list = SingleOrder::view('single_order r')
            ->view('member m', 'type as user_type,mobile as u_mobile', 'm.id=r.user_id', 'left')
            ->view('member_level l', 'title as level_name', 'm.level=l.id', 'left')
            ->where($where)
            ->order($order)
            ->paginate($offset, false, ['query' => request()->param()])
            ->each( function($item, $key){
                $item['auth_time'] = date('Y-m-d H:i:s',$item['auth_time']);
                $item['subaccount'] = SubAccount::where(['id'=>$item['sub_id']])->value('sub_account');
                $item['money'] = format_amount($item['money']);
                if (!empty($item['end_time'])) $item['end_time'] = date('Y-m-d H:i:s',$item['end_time']);
                $item['mobile'] = $item['u_mobile'];
            });
        if(!$data_list) return ajaxmsg('没有数据',0);
        return ajaxmsg('操作成功',200,$data_list);
    }
    
     //导出

    public function export()
    {
        $admin_user = Db::name('admin_user')->where(['id'=>$this->adminId])->field('id,username')->find();
        
        if ($admin_user['username']!='admin' && $admin_user['username']!='admin5' ) return ajaxmsg('当前账户不允许操作',0);
        $mobile   = input('mobile', '');
        $order_sn   = input('order_sn', '');
        $status   = input('status', '');
        $date  = input('date', '');
        $user_type   = input('user_type', '');
        $single_title   = input('single_title', '');
        $where = [];
        if(!empty($mobile))   $where[] = ['m.mobile'  ,'=', $mobile];
        if(!empty($user_type))   $where[] = ['m.type'  ,'=', $user_type];
        if(!empty($order_sn))   $where[] = ['r.order_sn'  ,'=', $order_sn];
        if(!empty($single_title))   $where[] = ['r.single_title'  ,'=', $single_title];
        if(!empty($single_day))   $where[] = ['r.single_day'  ,'=', $single_day];
        if(!empty($status))   $where[] = ['r.status'  ,'=', $status];
        if (!empty($date)) {
            $start_date =  $date."00:00:00";
            $end_date =  $date."23:59:59";
            $where[] = ['r.create_time' ,'>=', strtotime($start_date)];
            $where[] = ['r.create_time' ,'<=', strtotime($end_date)];
        }
        $list = SingleOrder::view('single_order r')
            ->view('member m', 'type as user_type', 'm.id=r.user_id', 'left')
            ->view('money y', 'account', 'm.id=y.mid', 'left')
            ->where($where)
            ->select()->toArray();
        if (empty($list)) {
            return ajaxmsg('暂无可导出的数据');
        }
        // 定义表头
        $header = [
            'ID', '订单号', '用户账户', '跟投天数', '金额', '状态', '创建时间','用户类型','账户余额'
        ];
        // 创建表格对象
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
// 写入表头
        $colIndex = 1;
        foreach ($header as $title) {
            $sheet->setCellValueByColumnAndRow($colIndex, 1, $title);
            $colIndex++;
        }
        // 写入数据
        $rowIndex = 2;
        foreach ($list as $order) {
            $sheet->setCellValueByColumnAndRow(1, $rowIndex, $order['id']);
            $sheet->setCellValueByColumnAndRow(2, $rowIndex, $order['order_sn']);
            $sheet->setCellValueByColumnAndRow(3, $rowIndex, $order['mobile']);
            $sheet->setCellValueByColumnAndRow(4, $rowIndex, $order['single_day']);
            $sheet->setCellValueByColumnAndRow(5, $rowIndex, $order['money']);
            $sheet->setCellValueByColumnAndRow(6, $rowIndex, $this->getStatusText($order['status']));
            $sheet->setCellValueByColumnAndRow(7, $rowIndex, $order['create_time']);
            $sheet->setCellValueByColumnAndRow(8, $rowIndex, $this->getUserTypeText($order['user_type']));
            $sheet->setCellValueByColumnAndRow(9, $rowIndex, $order['account']);
            $rowIndex++;
        }
        // 设置自动列宽
        foreach (range('A', 'G') as $col) {
            $sheet->getColumnDimension($col)->setAutoSize(true);
        }
        // 生成文件名
        $fileName = '订单导出_' . date('Ymd_His') . '.xlsx';
        $filePath = runtime_path() . 'export/' . $fileName;

        // 确保导出目录存在
        if (!is_dir(dirname($filePath))) {
            mkdir(dirname($filePath), 0777, true);
        }

        // 写入文件
        $writer = new Xlsx($spreadsheet);
        $writer->save($filePath);

        // 输出文件下载
        return download($filePath, $fileName)->isContent(false);
//        return ajaxmsg('操作成功',200,['file_path'=>$filePath]);
    }
    /**
     * 状态文字转换
     */
    private function getStatusText($status)
    {
        $map = [

            1 => '待审核',
            2 => '已通过',
            3 => '已驳回',
            6 => '已完成',
        ];
        return $map[$status] ?? '未知';
    }
    /**
     * 状态文字转换
     */
    private function getUserTypeText($type)
    {
        $map = [

            1 => '用户',
            2 => '营销',
            3 => '体验',
        ];
        return $map[$type] ?? '未知';
    }
    
    
    

    /*
     * 审核跟投订单
     */
    public function singleOrderStatus()
    {
        $id = input('id',0, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $data = SingleOrder::where(['id'=>$id])->find();
        if (empty($data)) return ajaxmsg('没有数据',0);
        if ($data->status != 1) return ajaxmsg('改订单不允许操作',0);
        $single_item = SingleItem::where(['id'=>$data->single_id])->field('id,day')->find();
        $data->status = $data->status == 1 ? 2 : 1;
        $data->auth_time = time();
        $data->end_time = strtotime(getTradeDateAfter(intval($single_item['day'])).date('H:i:s'),time());
        $data->save();
        return ajaxmsg('操作成功',200);
    }
    /*
     * 批量通过跟投订单
     */
    public function singleOrderStatusIds()
    {
        $ids = input('ids', '');
        if (empty($ids)) return ajaxmsg('请选择通过订单',0);
        $ids = explode(',', $ids);
        foreach ($ids as $id) {
            $data = SingleOrder::where(['id'=>$id])->field('id,status,single_id')->find();
            $singleInfo = (new SingleItem())->where('id', $data['single_id'])->find();
            if ($data['status']==1){
                $data->status = 2;
                $data->auth_time = time();
                $data->end_time = strtotime(getTradeDateAfter(intval($singleInfo['day'])).date('H:i:s'),time());//订单到期时间

                $data->save();
            }
        }
        return ajaxmsg('操作成功',200);
    }
    /*
     * 驳回跟投订单
     */
    public function outSingleOrder()
    {
        $id = input('id',0, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $data = SingleOrder::where(['id'=>$id])->find();
        if (empty($data)) return ajaxmsg('没有数据',0);
        if ($data->status != 1) return ajaxmsg('改订单不允许操作',0);
        $money_info = Db::name('money')->where('mid', $data['user_id'])->lock(true)->find();
        $user = MemberModel::where('id', $data['user_id'])->field('id,is_pei')->find();
        $money = $data['money'];
        try {
            // 启动事务
            Db::startTrans();
            if ($user['is_pei'] == 1){
                $money = bcsub(strval($money), strval($money_info['pei_money']));
                MemberModel::where(['id'=>$data['user_id']])->update(['is_pei'=>0]);
            }
            $upMoney = bcadd(strval($money_info['account']), strval($money));   // 当前余额+驳回余额
            Db::name('money')->where('mid', $data['user_id'])->update(['account' => $upMoney]);   // 加回余额
//            Db::name('stock_subaccount_money')->where('stock_subaccount_id',$sub_id)->inc('avail' , $money)->update(); // 更新跟投金额余额
            RecordModel::saveData($data['user_id'], $money, $upMoney, 43, '跟投驳回：' . $data['order_sn']);
            $data->status = 6;
            $data->save();
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return ajaxmsg('驳回失败', $e->getMessage());
        }
        return ajaxmsg('驳回成功',200);
    }



    /*
    * 信号源是否展示
    */
    public function singleSourceShow()
    {
        $id = input('id',0, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $data = SingleSource::where(['id'=>$id])->find();
        if (empty($data)) return ajaxmsg('没有数据',0);
        $data->is_show = $data->is_show == 1 ? 0 : 1;
        $data->save();
        return ajaxmsg('操作成功',200);
    }


    /*
 * 获取信号源
 */


    public function getSingleSource()
    {
        $where = [];
        $code   = input('code', '');
        $code_name = input('code_name', '');
        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order  = 'id desc';
        if(!empty($code))   $where[] = ['s.code'  ,'=', $code];
        if(!empty($code_name))   $where[] = ['s.code_name'  ,'=', $code_name];
        $data_list = SingleSource::view('single_source s')
            ->view('single_item i','title,day','i.id=s.single_id','left')
            ->where($where)
            ->order($order)
            ->paginate($offset, false, ['query' => request()->param()])
            ->each( function($item, $key){
                $item['buy_time'] =date('Y-m-d H:i:s',$item['buy_time']);
                $item['sell_time'] =date('Y-m-d H:i:s',$item['sell_time']);
                return $item;
            });
        if(!$data_list) return ajaxmsg('没有数据',0);
        return ajaxmsg('操作成功',200,$data_list);
    }

/*
 * 查询单只股票价格详情
 */
    public function getStockPrice()
    {
        $code = input('code','');
        $data = (new StockYinni())->getStockInfo($code);

        if (empty($data)) return ajaxmsg('没有数据',0);
        $rule = [
           'price'=>$data['data'][0]['last']
        ];
        return ajaxmsg('操作成功',1,$rule);
    }


        /*
         * 获取分笔交易数据
         */
    public function getStockFenBi()
    {
         return ajaxmsg('弃用',1);
        $code = input('code','');
        if (empty($code)) return ajaxmsg('请填入股票代码',0);
        $data =  RedisUtil::getStockFenbi($code);

        return ajaxmsg('操作成功',1,$data);
    }


    /*
     * 添加信号源 数据查询
     */

    public function totalSingleData()
    {
        $single_id = input('single_id',''); //项目id
        $buy_time = input('buy_time','');  // 1购买时间
        $buy_price = input('buy_price',0); // 购买价格
        $volume = input('volume','' ); //  仓位 0.5 0.7
        $buy_time = strtotime($buy_time);
        $data = [];
        $data['num'] = 0;
        $data['num_no'] = '';
        $SingleOrderModel = new SingleOrder();

        //当前项目总跟投人数       根据信号源选择显示时间  查询 在选择时间之前 审核通过的订单总数
        $data['userCountOrder'] = $SingleOrderModel->where(['single_id'=>$single_id,'status'=>2])->count(); // 当前项目总跟投人数





        // 当前条件可执行人数     就是 时间，价格，仓位什么的之类  能满足，还能跟上。
//        $orderList = $SingleOrderModel->where(['single_id'=>$single_id,'status'=>2])->whereTime('auth_time','<=',$buy_time)->select(); // 能满足时间的列表
        $orderList = $SingleOrderModel->where(['single_id'=>$single_id,'status'=>2])->select(); // 只要通过的就跟单

        $totalBuyPrice = bcmul($buy_price,100,2);   //购买 每手总金额
        if (!$orderList->isEmpty()) {

            foreach ($orderList as $item){
                $money = bcmul($item['money'],$volume,2);  // 根据仓位计算需要投资的金额。

                if ($money >= $totalBuyPrice) {
                    $data['num'] += 1;
                }
            }
        }

        // 当前条件不可执行人数以及点击后展开名单             根据发布时间      跟不上的时间的 通过订单，  买不了一手的订单，展示列表出来
        $orderListNo = $SingleOrderModel->where(['single_id'=>$single_id,'status'=>2])->select(); // 不能满足时间的列表

        $num_no =[];
        if (!$orderListNo->isEmpty()) {
            foreach ($orderListNo as $k=>$value){
                $money = bcmul($value['money'],$volume,2);  // 根据仓位计算需要投资的金额。
                if ($totalBuyPrice >= $money || $value['auth_time'] > $buy_time) {
                    $num_no[$k] =$SingleOrderModel->alias('s')->where(['s.id'=>$value['id']])
//                    ->join('stock_subaccount sub','sub.uid = s.user_id')
                        ->join('member m','m.id = s.user_id')
//                    ->where(['sub.type'=>2])
                        ->field('m.mobile,m.name,s.money,m.uid')
                        ->select()->toArray();
                }else{
                    unset($orderListNo[$k]);
//                    $num_no[$k] = $SingleOrderModel->alias('s')->where(['s.id'=>$value['id']])
////                    ->join('stock_subaccount sub','sub.uid = s.user_id')
//                        ->join('member m','m.id = s.user_id')
////                    ->where(['sub.type'=>2])
//                        ->field('m.mobile,m.name,s.money,m.uid')
//                        ->select()->toArray();
                }
            }
        }

        $data['num_no'] = $num_no;
        return ajaxmsg('操作成功',1,$data);

    }



    /** 添加信号源 - 跟单订单转入委托单
     * @return void
     */
    public function addSingle()
    {
        
        
        
        $SingleSourceModel = new SingleSource();
        $create_time = $SingleSourceModel->where(['status'=>1])->order('id desc')->find();
        // if (!empty($create_time))  if (time() < $create_time['create_time']+120) return ajaxmsg('请等待2分钟以上间隔', 0);

        $code = input('code',''); //股票代码
        $type = input('type','', ['trim', FILTER_SANITIZE_NUMBER_INT]); //买卖类型  1市价 2限价
        $volume = input('volume','' ); //  仓位 0.5 0.7
        $buy_price = input('buy_price',0); // 购买价格
        $single_id = input('single_id','', ['trim', FILTER_SANITIZE_NUMBER_INT]);  //项目id
        $direction = input('direction','', ['trim', FILTER_SANITIZE_NUMBER_INT]);  // 1是买涨  2买跌
        $buy_time = input('buy_time','');  // 1购买时间
        $singleInfo = (new SingleItem())->where(['id'=>$single_id])->find();
        $codeInfo = (new StockList())->where(['code|symbol'=>$code])->find();

//        $sourceInfo = $SingleSourceModel->where(['single_id'=>$single_id,'status'=>1])->count();
//        if ($sourceInfo > 0)  return ajaxmsg('该项目上笔订单未发布卖出！请勿重复添加', 0);
        if (empty($code)) return ajaxmsg('请选择股票', 0);
        if (empty($type)) return ajaxmsg('请选择类型', 0);
        if (empty($volume)) return ajaxmsg('请输入仓位', 0);
        if (empty($buy_price)) return ajaxmsg('请输入买入价格', 0);
        if (empty($singleInfo)) return ajaxmsg('请选择项目', 0);
        if (empty($codeInfo)) return ajaxmsg('股票代码不存在', 0);
        if (empty($buy_time)) return ajaxmsg('请选择发布时间', 0);

        $buy_time=  strtotime($buy_time);
        //增加信号源
        $source = [
            'volume' => $volume,
            'single_id' => $single_id,
            'code' => $code,
            'code_name' => $codeInfo['title'],
            'type' => $type,
            'buy_price' => $buy_price,
            'direction' => $direction,
            'trust_time' => time(),
            'buy_time' => $buy_time,
            'is_show' => 1,
        ];

        // 启动事务
        Db::startTrans();
        try {
            $SingleSourceModel->save($source);  //增加信号源
            $source_id = $SingleSourceModel->id;
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return ajaxmsg($e->getMessage(),0);
        }
        // push task 到 redis 队列（带 retry_count 字段）
       $task = [
            'single_id' => $single_id,
            'volume'    => $volume,
            'buy_price' => $buy_price,
            'direction' => $direction,
            'code'      => [
                'code'   => $codeInfo['code'],
                'market' => $codeInfo['market'],
                'title'  => $codeInfo['title']
            ],
            'source_id' => $source_id,
            'buy_time'  => $buy_time,
        ];
        // RedisUtil::redis()->lPush("create_single_order_queue", json_encode($task, JSON_UNESCAPED_UNICODE));
       
        Queue::push(\app\job\createTrustJob::class, $task, 'create_single_order');
        return ajaxmsg('发布信息成功,任务已加入队列后台处理',200);
    }
    
    /*
 * 根据等级统一把委托订单转入持仓
 */
    public function createLevelPositions()
    {
        set_time_limit(0);
        ini_set('memory_limit', '-1');
        $volume = input('volume',''); // 仓位比例
        $level= input('level',''); // 等级
        // if (in_volume($volume)==false)  return ajaxmsg('转入仓位不合法', 0);
        if(empty($level)) return ajaxmsg('请选择等级', 0);
        $batchSize = 100; // 每批次处理100条，自己可调节
        $page = 1;

        $StockDealStockModel = new StockDealStock();
        while (true) {
            // 每次取一批
            $list = Trust::view('stock_trust t')
                ->view('member m', 'level', 'm.id=t.uid', 'left')
                ->where(['m.level' => $level, 't.volume' => 0, 't.status' => '已委托'])
                ->field('t.*')
                ->limit(($page - 1) * $batchSize, $batchSize)
                ->select()
                ->toArray();

            if (empty($list)) {
                break; // 没有数据，跳出循环
            }
            Db::startTrans();
            try {
                foreach ($list as $item){
                    $count = intval(bcmul($item['trust_count'],$volume,2)); //根据仓位计算转入股数
                    if ($count <= 0) continue;

                    $price = $item['trust_price'];
                    if ($count > 0 && $item['status']=="已委托" ) {
                        $toal_money = bcmul($price,$count,2);  // 计算需要购买的金额
                        $stockinfo['Price']  = $price;
                        $stockinfo['code']   = $item['gupiao_code'];
                        $stockinfo['name']   = $item['gupiao_name'];
                        $stockinfo['market'] = $item['market'];

                        $commission = commission($toal_money, sysConfig('commission_scale'), 1);  // 佣金
                        $transfer   = transfer($toal_money);  // 过户费
                        $qingsuan_price = ($count*$price) + $commission + $transfer;

                        $data = [
                            'sub_id'           => $item['sub_id'],
                            'uid'              => $item['uid'],
                            'scale'            => $item['scale'],
                            'volume'           => $volume,
                            'single_id'        => $item['single_id'],
                            'source_id'        => $item['source_id'],
                            'ck_price'         => bcdiv(strval($qingsuan_price), strval($count), 3),
                            'gupiao_code'      => $item["gupiao_code"],
                            'gupiao_name'      => $item["gupiao_name"],
                            'count'            => $count,
                            'stock_count'      => $count,
                            'canbuy_count'     => $count,
                            'ck_profit_price'  => '',
                            'now_price'        => $price,
                            'market_value'     => $price * $count,
                            'ck_profit'        => $count > 0 ? bcmul(strval($stockinfo["Price"] - $price), strval($count), 2) : 0,
                            'profit_rate'      => $count > 0 && $price > 0 ? bcdiv(strval($stockinfo["Price"] - $price), strval($price), 4) : 0,
                            'buying'           => 0,
                            'selling'          => 0,
                            'gudong_code'      => "",
                            'type'             => 0,
                            'market'           => toMarket($item["gupiao_code"]),
                            'jigou_type'       => 1,
                            'jiyisuo'          => toMarket($item["gupiao_code"])=='SZ'? "深交所":"上交所",
                            'info'             => "",
                            'single_type'      => 2,
                            'single_day'       => $item['single_day'],
                            'single_order_sn'  => $item['single_order_sn'],
                            'buy_average_price'=> bcdiv(strval($price * $count), strval($count), 3),
                            'buy_time'         => $item['buy_time'],
                            'order_sn'         => $item['order_sn'],
                        ];

                        Db::name('stock_position')->insert($data);

                        $StockDealStockModel->add_m_deal_stock(
                            $stockinfo,
                            $count,
                            $price,
                            $item['sub_id'],
                            '',
                            '',
                            '',
                            $item['trust_no'],
                            $item,
                            $item['buy_time'],
                            $item['order_sn']
                        );

                        $totalCount = bcadd($item['volume'], $count, 2);
                        if ($totalCount >= $item ['trust_count']){
                            $item['status'] = '已成';
                        }

                        Db::name('stock_trust')->update([
                            'id'       => $item['id'],
                            'status'   => $item['status'],
                            'volume'   => $totalCount,
                            'amount'   => $toal_money,
                            'buy_price'=> $price,
                        ]);
                    }
                }
                Db::commit();
            } catch (\Exception $e) {
                Db::rollback();
                // 写日志，不中断整体循环
//                trace("批次 {$page} 处理失败：" . $e->getMessage(), 'error');
                return ajaxmsg($e->getMessage(), 0);
            }
            $page++;
            usleep(50000); // 每批次休眠50ms，避免数据库压力
        }

        return ajaxmsg('批量转入完成',200);
    }

   
/*
 *  批量委托订单转入持仓订单
 */

    public function createPositionsIds()
    {
        set_time_limit(0);
        ini_set('memory_limit', '-1');
        $trust_id = input('trust_id', '');
        $volume = input('volume',''); // 仓位比例
//        $buy_time = input('buy_time','');   //  转入输入时间，转入时间 前端显示
        if (empty($trust_id)) return ajaxmsg('请选择通过订单',0);
        // if (in_volume($volume)==false)  return ajaxmsg('转入仓位不合法', 0);
        $ids = explode(',', $trust_id);
        $StockDealStockModel = new StockDealStock();

         
        Db::startTrans();
        try {
            foreach ($ids as $item) {
                $data = [];
                $trustInfo = (new Trust())->where(['id'=>$item])->find();

                $count = intval( bcmul($trustInfo['trust_count'],$volume,2)) ;//根据仓位计算转入股数
                $count = ($count <= 0) ? 1 : $count;
                $price = $trustInfo['trust_price'];

                if ($count > 0 && $trustInfo['status']=="已委托" ) {

                    $toal_money = bcmul($price,$count,2);  // 计算需要购买的金额
                   
                    // $stockinfo = RedisUtil::getQuotationData($trustInfo["gupiao_code"],toMarket($trustInfo["gupiao_code"]));
                    // if(empty($stockinfo['Price'])) $stockinfo['Price'] = $trustInfo['trust_price'];
                    $stockinfo['Price'] = $price;
                    $stockinfo['code'] = $trustInfo['gupiao_code'];
                    $stockinfo['name'] = $trustInfo['gupiao_name'];
                    $stockinfo['market'] = $trustInfo['market'];
                    $commission =  commission( $toal_money,sysConfig('commission_scale'),1);  // 计算佣金
                    $transfer = transfer($toal_money);  // 计算过户费
                    $qingsuan_price = ($count*$price)+$commission+ $transfer;
                    $data = [
                        'sub_id' =>$trustInfo['sub_id'],
                        'uid' =>$trustInfo['uid'],
                        'scale' =>$trustInfo['scale'],
                        'volume' =>$volume,
                        'single_id' =>$trustInfo['single_id'],  // 项目ID
                        'source_id' =>$trustInfo['source_id'],  // 信号源ID
//            'ck_price' => StockPosition::calculate($trustInfo['sub_id'],$trustInfo['gupiao_code'],'price'),//参考成本价
                        'ck_price' => bcdiv(strval($qingsuan_price),strval($count),3),
                    ];
                    

                    $data['gupiao_code']       = $trustInfo["gupiao_code"];
                    $data['gupiao_name']       = $trustInfo["gupiao_name"];
                    $data['count']             = $count;
                    $data['stock_count']       = $count;
                    $data['canbuy_count']      = $count;
//        $data['buy_average_price'] = StockPosition::calculate($trustInfo['sub_id'],$trustInfo['gupiao_code'],'average');//买入均价

                    $data['ck_profit_price']   = '';//参考盈亏成本价
                    $data['now_price']         = $price;//'当前价'
                    $data['market_value']      = $price * $count;//最新市值
                    $data['ck_profit']         = $count > 0 ? bcmul(strval($stockinfo["Price"] - $data['ck_price']),strval($count),2) : 0; //参考浮动盈亏
                    
                    $data['profit_rate']       = $count > 0 && $data['ck_price'] > 0 ? bcdiv(strval($data['ck_profit']),strval($data['ck_price'] * $count * 100),2) : 0; //盈亏比例
                    $data['buying']            = 0;//买入成功
                    $data['selling']           = 0;//1、在途卖出
                    $data['gudong_code']       = "";//股东代码 无法模拟暂时空
                    $data['type']              = 0;//帐号类别
                    $data['market']            = toMarket($trustInfo["gupiao_code"]);//股票类别
                    $data['jigou_type']        = 1;
                    $data['jiyisuo']           = toMarket($trustInfo["gupiao_code"])=='SZ'? "深交所":"上交所";//交易所
                    $data['info']              = "";
                    $data['single_type']              = 2;
                    $data['single_day']              = $trustInfo['single_day'];
                    $data['single_order_sn']              = $trustInfo['single_order_sn'];
                    $data['buy_average_price'] = bcdiv(strval($data['market_value']),strval($count),3);//买入均价
                    $data ['buy_time'] = $trustInfo['buy_time'];
                    $data ['order_sn'] = $trustInfo['order_sn'];
                   
                    Db::name('stock_position')->insert($data);
                    $StockDealStockModel->add_m_deal_stock($stockinfo,$count,$price,$trustInfo['sub_id'],'','','',$trustInfo['trust_no'],$trustInfo,$trustInfo['buy_time'],$trustInfo['order_sn']);  //成交单
                    $totalCount = bcadd($trustInfo->volume , $count,2);
                    if ($totalCount >= $trustInfo ['trust_count']  ){
                        $trustInfo->status = '已成';
                    }
                    $trustInfo->volume = $totalCount;
                    $trustInfo->amount = $trustInfo->amount + $toal_money;
                    $trustInfo->buy_price = $price;
                    $trustInfo->save();
                }

            }
            Db::commit();
        }catch (Exception $e){
            Db::rollback();
            return ajaxmsg($e->getMessage(),0);
        }
        return ajaxmsg('转入成功',200);
    }




    /** 跟单委托 转入持仓列表
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\PDOException
     */
    public function createPositions()
    {
        set_time_limit(0);
        ini_set('memory_limit', '-1');
        $trust_id = input('trust_id','', ['trim', FILTER_SANITIZE_NUMBER_INT]);   //委托订单id
//        $count = input('count','');   //  转入数量
//        $price = input('price','');   //  转入输入价格
//        $buy_time = input('buy_time','');   //  转入输入时间，转入时间 前端显示
        $volume = input('volume',''); // 仓位比例
        $trustInfo = (new Trust())->where(['id'=>$trust_id])->find();
        if ($trustInfo['trust_count'] < 0) return ajaxmsg('委托数量有误', 0);
        if (empty($trustInfo)) return ajaxmsg('参数有误', 0);
//        if (empty($count)) return ajaxmsg('请输入转入数量', 0);
//        if (empty($price)) return ajaxmsg('请输入转入价格', 0);
//        if (empty($buy_time)) return ajaxmsg('请输入转入时间', 0);
//        if (!isMultipleOfThree($count))  return ajaxmsg('转入数量不合法', 0);
        if ($trustInfo['status']!="已委托") return ajaxmsg('该委托股票不支持转入持仓', 0);
        // if (in_volume($volume)==false)  return ajaxmsg('转入仓位不合法', 0);
//        $userMoney =Money::getMoney($trustInfo['uid']);
        $count = intval( bcmul($trustInfo['trust_count'],$volume,2)) ;//根据仓位计算转入股数
        $count = ($count <= 0) ? 1 : $count;
        $price = $trustInfo['trust_price'];
        $buy_time = $trustInfo['buy_time'];
        $toal_money = bcmul($price,$count,2);  // 计算需要购买的金额
//        if ($toal_money > $userMoney['single_money']) return ajaxmsg('用户跟投账户余额不足', 0);


        $last_count = bcsub(strval($trustInfo['trust_count']),strval($trustInfo['volume']),0); // 委托数量 - 已转入数量  =  剩余可用数量

        if ($count > $last_count) return ajaxmsg('转入数量大于可用数量', 0);

        // $stockinfo = RedisUtil::getQuotationData($trustInfo["gupiao_code"],toMarket($trustInfo["gupiao_code"]));
        $stockinfo['Price'] = $price;
        $stockinfo['code'] = $trustInfo['gupiao_code'];
        $stockinfo['name'] = $trustInfo['gupiao_name'];
        $stockinfo['market'] = $trustInfo['market'];
        $commission =  commission( $toal_money,sysConfig('commission_scale'),1);  // 计算佣金
        $transfer = transfer($toal_money);  // 计算过户费
        $qingsuan_price = ($count*$price)+$commission+ $transfer;

        $data = [
            'sub_id' =>$trustInfo['sub_id'],
            'uid' =>$trustInfo['uid'],
            'scale' =>$trustInfo['scale'],
            'volume' =>$volume,
            'single_id' =>$trustInfo['single_id'],  // 项目ID
            'source_id' =>$trustInfo['source_id'],  // 信号源ID
//            'ck_price' => StockPosition::calculate($trustInfo['sub_id'],$trustInfo['gupiao_code'],'price'),//参考成本价
            'ck_price' => bcdiv(strval($qingsuan_price),strval($count),3),
        ];


        $data['gupiao_code']       = $trustInfo["gupiao_code"];
        $data['gupiao_name']       = $trustInfo["gupiao_name"];
        $data['count']             = $count;
        $data['stock_count']       = $count;
        $data['canbuy_count']      = $count;
//        $data['buy_average_price'] = StockPosition::calculate($trustInfo['sub_id'],$trustInfo['gupiao_code'],'average');//买入均价

        $data['ck_profit_price']   = '';//参考盈亏成本价
        $data['now_price']         = $price;//'当前价'
        $data['market_value']      = $price * $count;//最新市值
        $data['ck_profit']         = $count > 0 ? bcmul(strval($trustInfo["trust_price"] - $data['ck_price']),strval($count),2) : 0; //参考浮动盈亏
        $data['profit_rate']       = $count > 0 && $data['ck_price'] > 0 ? bcdiv(strval($data['ck_profit']),strval($data['ck_price'] * $count * 100),2) : 0; //盈亏比例
        $data['buying']            = 0;//买入成功
        $data['selling']           = 0;//1、在途卖出
        $data['gudong_code']       = "";//股东代码 无法模拟暂时空
        $data['type']              = 0;//帐号类别
        $data['market']            = toMarket($trustInfo["gupiao_code"]);//股票类别
        $data['jigou_type']        = 1;
        $data['jiyisuo']           = toMarket($trustInfo["gupiao_code"])=='SZ'? "深交所":"上交所";//交易所
        $data['info']              = "";
        $data['single_type']              = 2;
        $data['single_day']              = $trustInfo['single_day'];
        $data['single_order_sn']              = $trustInfo['single_order_sn'];
        $data['buy_average_price'] = bcdiv(strval($data['market_value']),strval($count),3);//买入均价
        $data ['buy_time'] = $buy_time;
        $data ['order_sn'] = $trustInfo['order_sn'];


//        $position = StockPosition::getCodePosition($trustInfo["sub_id"], $trustInfo["gupiao_code"]);
        /***********************************************************************************/
//        if(TRUST_MODEL_TIME === 1){ // 交易模式为T+1时，不能立即更新可卖数量
//            unset($data['canbuy_count']);
//        }
//        if(!empty($position)){
//            $result = StockPosition::where(['id'=>$position['id']])->update($data);
//        }else{
//            $result = StockPosition::strict(false)->insert($data,true);
//        }


//        $money = bcmul($item['money'],$volume,2);  // 根据仓位计算需要投资的金额。
//        $shou = floor(bcdiv($money,$totalBuyPrice,0) );   //  计算最大购买手数
//        $number = bcmul($shou,100);  // 手数转换股
        Db::startTrans();
        try {
//            Db::name('money') -> where('mid', $trustInfo['uid'])->update(['single_money'=>  $userSingleMoney]); // 扣除跟投账户余额  （股票金额+佣金 + 手续费）
//            RecordModel::saveData($trustInfo['uid'],  $toal_money, $money_info['single_money'], 36, '跟投成交：'.$trustInfo['trust_no']); //写入自己变化
//            Delivery::add_m_delivery_order($trustInfo['gupiao_code'],$count,$price,$trustInfo['sub_id'],$commission,$transfer,$trustInfo['trust_no'],$userSingleMoney,$count,2); //交割单
            (new StockPosition)->save($data);
            (new StockDealStock())->add_m_deal_stock($stockinfo,$count,$price,$trustInfo['sub_id'],'','','',$trustInfo['trust_no'],$trustInfo,$buy_time,$trustInfo['order_sn']);  //成交单
            $totalCount = bcadd($trustInfo->volume , $count,2);
//            $totalPrice = bcadd($trustInfo->volume , $count,2);
            if ($totalCount >= $trustInfo ['trust_count']  ){
                $trustInfo->status = '已成';
//                $trustInfo->is_zhuan = 2;
            }
            $trustInfo->volume = $totalCount;
            $trustInfo->amount = $trustInfo->amount + $toal_money;
            $trustInfo->buy_price = $price;
            $trustInfo->save();
            // MemberModel::sendCommission($trustInfo['uid'],$toal_money,1,$trustInfo['trust_no']);
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return ajaxmsg($e->getMessage(),0);
        }
        return ajaxmsg('转入持仓成功',200);
    }

/*
 * 根据卖出信号，统一卖出该信号源下的所有持仓
 */
    public function createSellSource()
    {
       
        set_time_limit(0);
        ini_set('memory_limit', '-1');
        $SingleSourceModel = new SingleSource();
//        $single_id = input('single_id','', ['trim', FILTER_SANITIZE_NUMBER_INT]);  //项目id
        $source_id = input('source_id','', ['trim', FILTER_SANITIZE_NUMBER_INT]);  //信号源id

        $sell_price = input('sell_price',0);  //真实卖出价格
        $sell_time = input('sell_time','');  //前端显示时间
        $sell_type = input('sell_type',1);  //卖出类型 1市价 2限价
        $sell_volume = input('sell_volume','');  //卖出仓位

        $sell_price_scope = input('sell_price_scope','');  //前端显示卖出价格
        $single_type = input('single_type',1);  //卖出类型，1直接卖出，2委托卖出
        $sourceInfo = $SingleSourceModel->where(['id'=>$source_id,'status'=>1])->find();

        if (empty($sourceInfo)) return ajaxmsg('参数有误', 0);
        if (empty($sell_price)) return ajaxmsg('请输入卖出价格', 0);
        if ($sourceInfo['status']!=1) return ajaxmsg('该信号源不支持发布卖出信号', 0);
        if( empty($source_id) || empty($sell_time) || empty($sell_price_scope)) return ajaxmsg('参数有误', 0);
        $sell_time = strtotime($sell_time);


// $this->sellPosition($sourceInfo,$sell_price,$sell_time,$sell_price_scope,$single_type,$sell_volume);exit();

        Db::startTrans();
        try {
//            $this->teamDividends($sourceInfo,$sell_price,$sell_volume);
            $this->sellPosition($sourceInfo,$sell_price,$sell_time,$sell_price_scope,$single_type,$sell_volume);
            $sourceInfo->status = 2;
            $sourceInfo->sell_price = $sell_price;
            $sourceInfo->sell_type = $sell_type;
            $sourceInfo->sell_volume = $sell_volume;
            $sourceInfo->sell_time = $sell_time;
            $sourceInfo->sell_price_scope = $sell_price_scope;
            $sourceInfo->save();
            Db::commit();
        }catch (Exception $e){
            Db::rollback();
            writeLog("sell_error",$e->getMessage());
            return ajaxmsg('发布卖出信号失败',$e->getMessage());
        }

        return ajaxmsg('发布卖出信号成功',200);
    }
    /*
 * 团队分红计算
 */
//    public function teamDividends($sourceInfo,$sell_price=0,$sell_volume=0)
//    {
//        $positionModel = new StockPosition();
//        $positionOrder = $positionModel->where(['single_id'=>$sourceInfo['single_id'],'source_id'=>$sourceInfo['id'],'single_type'=>2])-> where('canbuy_count','>',0)->column('uid');
//
//        foreach ($positionOrder as $item){
//
//            MemberModel::teamDividends($item,$sourceInfo['single_id'],$sourceInfo['id'],$sell_price,$sell_volume);
//        }
//
//    }




    /*
     * 信号源发布直接卖出，统一卖出该信号源下的持仓
     */
    public function sellPosition($sourceInfo,$sell_price,$sell_time,$sell_price_scope,$single_type,$sell_volume){
        $positionModel = new StockPosition();
        $positionOrder = $positionModel
            ->where([
                'single_id'   => $sourceInfo['single_id'],
                'source_id'   => $sourceInfo['id'],
                'single_type' => 2
            ])
            ->where('stock_count', '>', 0)
            ->select();

        if ($positionOrder->isEmpty())  return ajaxmsg('暂无持仓', 0);
        $sell_volume = $sell_volume === '' || $sell_volume === null ? '1' : (string)$sell_volume;
        foreach ($positionOrder as $item) {
            $task = [
                'pos_id'          => $item['id'],
                'sell_price'      => $sell_price,
                'sell_time'       => $sell_time,
                'sell_price_scope'=> $sell_price_scope,
                'single_type'     => $single_type,
                'sell_volume'     => $sell_volume
            ];
            // RedisUtil::redis()->lPush('sell_position_queue', json_encode($task, JSON_UNESCAPED_UNICODE));
            Queue::push(\app\job\SellPositionJob::class, $task, 'sell_position');
        }
        return ajaxmsg('卖出任务已提交，后台处理中',200);
    }


    
    /*
     * 后台手动卖出委托持仓
     */
    public function sellPositionTrust()
    {
        $trustModel = new Trust();


        $id = input('id','');
        $sell_price = input('sell_price',''); //卖出价格
        $sell_time = input('sell_time','');  //卖出时间
        $sell_count = input('sell_count',''); // 卖出数量

        if (empty($id)) return ajaxmsg('参数有误',0);
        if (empty($sell_price)) return ajaxmsg('请输入价格',0);
        if (empty($sell_time)) return ajaxmsg('请输入卖出时间',0);
        if (empty($sell_count)) return ajaxmsg('请输入卖出数量',0);
        $trustOrder = $trustModel->find($id);
        if (empty($trustOrder)) return ajaxmsg('委托单不存在',0);
        if ($trustOrder['status']!='已委托') return ajaxmsg('该委托单不能卖出',0);
        if ($trustOrder->volume+$sell_count > $trustOrder->trust_count) return ajaxmsg('该委托单没有可用卖出数量',0);
        $trade_money = intval($sell_count) * intval($sell_price); //计算卖出股票总价

        $Trust_no  = mt_rand(101010, 999999).substr(strval(time()),1);
        //计算佣金
        $commission  = commission($trade_money,sysConfig('commission_scale'),1);
        //印花税
        $stamps      = stamps($trade_money);
        //计算过户费
        $transfer    = transfer($trade_money);

        $money_info =   SubAccountMoney::getAccountMoney($trustOrder['sub_id']);  // 获取自己余额

        $effectMoney = $trade_money - $transfer - $stamps - $commission; //收益金额 = 总价 - 手续费 - 印花税 - 过户费
        $avail    = $money_info["avail"] + $effectMoney;
        $positionOrder = (new StockPosition())->where(['id'=>$trustOrder['po_id']])->find();
        $ck_profit = bcmul($positionOrder['ck_price'], $sell_count,2); // 计算持仓成本
        if ($ck_profit < $effectMoney){
            $ying_kui =  bcsub($effectMoney,$ck_profit,2);
        }else{
            $ying_kui = bcsub($ck_profit,$effectMoney,2);
        }
        $stockinfo = RedisUtil::getQuotationData($positionOrder["gupiao_code"],toMarket($positionOrder["gupiao_code"]));

        try {
            Db::startTrans();
            //如果盈利的话 更新老师余额
            if ($effectMoney > $ck_profit){

                $yingli = bcsub($effectMoney,$ck_profit,2); // 总利润- 持仓成本 =收益金额
//                $scale = bcdiv($item['scale'],100,2);  //分佣百分比

                $yingli_money = bcmul($yingli,$positionOrder['scale'],2);  //  老师分佣所得金额

                $true_money = bcsub($yingli,$yingli_money,2); // 收益金额-老师分佣 == 纯利润
                $singleInfo = Db::name('single_item')->where(['id'=>$positionOrder['single_id']])->field('id,user_id')->find();

                Db::name('money')->where(['mid' => $singleInfo['user_id']])->inc('account',intval($yingli_money))->update();  //更新老师余额
                $moneyInfo = Money::getMoney($singleInfo['user_id']);  // 获取老师余额

                RecordModel::saveData($singleInfo['user_id'],  $yingli_money, $moneyInfo['account'], 38, '带单返佣：'.$yingli_money);  //写入老师资金日志


                $userYingLiMoney = bcadd($ck_profit,$true_money,2);    // 用户本身跟单收益 扣掉老师分佣后金额
                SubAccountMoney::upMoneyLog($trustOrder['sub_id'], $userYingLiMoney, 4, 0, 0, $trustOrder['gupiao_code']); //更新子账户用户跟单余额
                
//                RecordModel::saveData($positionOrder['uid'],  $userYingLiMoney, $money_info['avail'], 39, '跟单收益：'.$userYingLiMoney);
                StockDealStock::sell_m_deal_stock($stockinfo,$sell_count,$sell_price,$trustOrder['sub_id'],$trustOrder['lib'],$trustOrder['login_name'],$trustOrder['soruce'],$trustOrder['trust_no'],2,$sell_time,$positionOrder['order_sn']);  //卖出成交单
                Delivery::sell_m_delivery_order($trustOrder['gupiao_code'], $sell_count, $sell_price, $positionOrder['sub_id'], $commission, $transfer, $Trust_no, $stamps,$avail , $sell_count, 2);
                MemberModel::sendCommission($positionOrder['uid'],$true_money,2,$Trust_no);
                SingleOrder::add_user_money($positionOrder['order_sn'], $effectMoney, $yingli_money, $ck_profit, $true_money, 1);
            }else{
                Delivery::sell_m_delivery_order($trustOrder['gupiao_code'], $sell_count, $sell_price, $positionOrder['sub_id'], $commission, $transfer, $Trust_no, $stamps,$avail , $sell_count, 2);
                RecordModel::saveData($positionOrder['uid'],  $effectMoney, $avail, 37, '跟投卖出：'.$effectMoney);
//                Db::name('money')->where(['mid' => $positionOrder['uid']])->inc('single_money',intval($effectMoney))->update(); //更新用户跟单余额
                StockDealStock::sell_m_deal_stock($stockinfo,$sell_count,$sell_price,$trustOrder['sub_id'],$trustOrder['lib'],$trustOrder['login_name'],$trustOrder['soruce'],$trustOrder['trust_no'],2,$sell_time,$positionOrder['order_sn']);  //卖出成交单
                SubAccountMoney::upMoneyLog($trustOrder['sub_id'], $effectMoney, 4, 0, 0, $trustOrder['gupiao_code']); //更新子账户用户跟单余额
                // MemberModel::sendCommission($positionOrder['uid'],$effectMoney,2,$Trust_no);
//                RecordModel::saveData($positionOrder['uid'],  $effectMoney, $money_info['avail'], 39, '跟单收益：'.$effectMoney);
                SingleOrder::add_user_money($positionOrder['order_sn'], $effectMoney, 0,$ck_profit, 0, 2);
            }
            $positionOrder->canbuy_count = $positionOrder['canbuy_count'] - $sell_count;
            $positionOrder->ck_profit =$ying_kui;
            $positionOrder->stock_count = $positionOrder['stock_count'] - $sell_count;
            $positionOrder->sell_count = $positionOrder->sell_coun+$sell_count;
            $positionOrder->count = $positionOrder['count'] - $sell_count;
            $positionOrder->sell_time = strtotime($sell_time);
            $positionOrder->sell_price = $sell_price;
            $positionOrder->save();
            if ($trustOrder->volume+$sell_count < $trustOrder->trust_count  ){
                $trustOrder->status = '已委托';
            }else{
                $trustOrder->status = '已成';
            }
            $trustOrder->volume = $trustOrder->volume+$sell_count;
            $trustOrder->amount = $trustOrder->amount+$trade_money;

            $trustOrder->save();
            Db::commit();
        }catch (Exception $e){
            Db::rollback();
            return ajaxmsg('卖出失败',$e->getMessage());
        }
        return ajaxmsg('卖出成功',200);
    }

    /*
     * 委托撤单
     */

    public function cancelTrust()
    {
        $trust_no = input('trust_no', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $tempinfo = Db::name('stock_trust')->where(['trust_no' => $trust_no])->lock(true)->find();
        if (!$tempinfo) return ajaxmsg('没找到对应委托，撤单失败',0);
        if ($tempinfo['trust_count'] == $tempinfo['volume']) return ajaxmsg('当前委托不允许撤单',0);

        Db::startTrans();
        try {
            $number = bcsub($tempinfo['trust_count'],$tempinfo['volume']);  //  委托数量 - 已转持仓数量 = 剩余可撤销数量
            $trust['status'] = '已撤';
            $trust['cancel_order_flag']  = '1';
            $trust['cancel_order_count'] = $number ;
            Db::name('stock_trust')->where(['trust_no' => $trust_no])->update($trust);
            // $money = bcmul($number,$tempinfo['trust_price'],2);
            // Db::name('money')->where(['mid' => $tempinfo['uid']])->inc('single_money',intval($money))->update(); //更新用户跟单余额
            // $userMoney = Money::getMoney($tempinfo['uid']);  // 获取自己余额
             $affect = Db::name('stock_delivery_order')->where(['trust_no'=>$tempinfo['trust_no']])->value('liquidation_amount');
            SubAccountMoney::upMoneyLog($tempinfo['sub_id'], $affect, 8);
            Db::commit();
        }catch (Exception $e){
            Db::rollback();
            return ajaxmsg($e->getMessage(),0);
        }
        return ajaxmsg('撤单成功',200);



    }

    /*
     * 追投列表
     */
    public function itemAddMoneyList()
    {

        $mobile = input('mobile','');
        $status = input('status','');
        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order  = 'id desc';
        $where  = [];
        if(!empty($mobile))$where[] = ['m.mobile','=', $mobile];
        if($status !== '' && $status !== null)$where[] = ['s.status','=', $status];
        $list = SingleAddmoney::view('single_addmoney s')
            ->view('member m','mobile,name','m.id=s.user_id')
            ->where($where)
            ->order($order)
            ->paginate($offset, false, ['query' => request()->param()])
            ->each( function($item, $key){
            });
        if(!$list) return ajaxmsg('没有数据',0);
        return ajaxmsg('操作成功',200,$list);
    }
    /*
     * 审核追投
     */
    public function checkItemAddmoney()
    {
        $id = input('id','',['trim', FILTER_SANITIZE_NUMBER_INT]);
        $status = input('status',0,['trim', FILTER_SANITIZE_NUMBER_INT]);
        if (empty($id)) return ajaxmsg('缺少参数',0);
        $info = SingleAddmoney::where(['id'=>$id])->find();
        if ($info['status']!=0) return ajaxmsg('该记录已审核',0);
        $money_info = Db::name('money')->where('mid', $info['user_id'])->lock(true)->find();

        if ($status==1){

            $single_order = (new SingleOrder())->where(['order_sn' => $info['order_sn']])->find();
            if($single_order['status']!=2) return ajaxmsg('该订单不允许追加',0);
            // 後臺審核通過之後  再把追投金額添加到項目中
            $single_order->money = bcadd( $single_order->money , $info['money'],2);
            $single_order->save();
            $info->status = 1;
            $info->save();
            return ajaxmsg('审核成功,追投资金已增加', 200);
        }else{

            // 駁回返還金額給用戶
            $upMoney = bcadd(strval($money_info['account']), strval($info['money']));
            Db::name('money')->where('mid', $info['user_id'])->update(['account' => $upMoney]);   // 增加金額
            SubAccountMoney::upMoneyLog($info['sub_id'], $info['money'], 18, 0, 0, '');
            RecordModel::saveData($info['user_id'], $info['money'], $upMoney, 43, '追投驳回：' . $info['money']);   // 账户总资金明细记录


            $info->status = 2;
            $info->save();
            return ajaxmsg('追投驳回', 200);
        }


//        if ($status==1){
//             if ($money_info['account'] < $info['money']) return ajaxmsg('账户余额不足', 0);
//            // $borrow = Borrow::where(['stock_subaccount_id'=>$info['sub_id']])->find();
//            $single_order = (new SingleOrder())->where(['order_sn' => $info['order_sn']])->find();
//            if($single_order['status']!=2) return ajaxmsg('该订单不允许追加',0);
//            // 直接追加资金
//            $upMoney = bcsub(strval($money_info['account']), strval($info['money']));   // 减掉跟投金额后的余额
//            Db::name('money')->where('mid', $info['user_id'])->update(['account' => $upMoney]);   // 扣除余额
//            SubAccountMoney::upMoneyLog($info['sub_id'], $info['money'], 17, 0, 0, '');   // 子账户明细
//
//            RecordModel::saveData($info['user_id'], $info['money'], $upMoney, 42, '追加跟投：' . $info['money']);   // 账户总资金明细记录
//
////            Borrow::where(['stock_subaccount_id'=>$info['sub_id']])->update(['init_money'=> ($borrow['init_money']+$info['money']) ,'borrow_money'=>($borrow['borrow_money']+$info['money'])]);
//            $single_order->money = bcadd( $single_order->money , $info['money'],2);
//            $single_order->save();
//            $info->status = 1;
//            $info->save();
//            return ajaxmsg('审核成功,追投资金已增加', 200);
//        }else{
//            $info->status = 2;
//            $info->save();
//            return ajaxmsg('追投驳回', 200);
//        }
    }

    /*
     * 手动释放订单，订单到期，并返还本金+盈利
     */
    public function orderRelease()
    {
        $id = input('id','',['trim', FILTER_SANITIZE_NUMBER_INT]);
        if (empty($id)) return ajaxmsg('缺少参数',0);
        $info =SingleOrder::where(['id'=>$id])->find();
        if (empty($info)) return ajaxmsg('订单不存在',0);
        if ($info['status']!=2) return ajaxmsg('该订单不允许释放',0);
        $source = SingleSource::where(['id'=>$info['source_id']])->field('id,status')->find();
        if (!empty($source) && $source['status']==1) return ajaxmsg('请等待该订单完成交易',0);
        $position = StockPosition::where(['uid'=>$info['user_id'],'order_sn'=>$info['order_sn']])->where('stock_count','>',0)->count();
        if ($position>0) return ajaxmsg('该订单有持仓，不允许释放',0);
        $moneyInfo = Money::getMoney($info['user_id']);  // 获取自己余额
        $total_moeny = bcadd($info['money'],$info['ying_money'],2) ;
        $total_moeny = bcsub($total_moeny,$info['withdraw_money'],2)  ; // 去掉已经提赢的金额
        $upMoney = bcadd(strval($moneyInfo['account']), strval($total_moeny),2);   //

        Db::startTrans();
        try {
            Db::name('money')->where('mid', $info['user_id'])->update(['account' => $upMoney]);   // 加回余额
            RecordModel::saveData($info['user_id'],  $total_moeny, $moneyInfo['account'], 48, '订单到期，资金返还：'.$total_moeny);  //写入资金日志

            $info->status = 6;
            $info->save();
            Db::commit();
        }catch (Exception $e){
            Db::rollback();
            return ajaxmsg('释放失败',0);
        }
        return ajaxmsg('释放成功',200);


    }
}
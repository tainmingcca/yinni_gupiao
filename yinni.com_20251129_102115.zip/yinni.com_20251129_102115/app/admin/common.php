<?php
use think\facade\Db;
use app\admin\model\User;
use app\apicom\model\JWT;
use think\request;
use util\RedisUtil;
use util\SystemRedis;
// 这是系统自动生成的公共文件


/*
 * 输出JSON
*/
if (!function_exists('ajaxmsgnew')) {
    function ajaxmsgnew($msg = "", $type = 200,$data = '',$other = '',$is_end = true)
    {
        $json['status'] = $type;
        if (is_array($msg)) {
            foreach ($msg as $key => $v) {
                $json[$key] = $v;
            }
        } elseif (!empty($msg)) {
            $json['msg'] = $msg;
        }
        $json['data'] = $data;
        if($other) $json['other'] = $other;
        if ($is_end) {
            return json($json);
        } else {
            return json($json);
        }
    }
}


/*
 * 输出JSON
*/
if (!function_exists('ajaxmsg')) {
    function ajaxmsg($msg = "", $type = 200,$data = '',$is_end = true)
    {
        $json['status'] = $type;
        if (is_array($msg)) {
            foreach ($msg as $key => $v) {
                $json[$key] = $v;
            }
        } elseif (!empty($msg)) {
            $json['msg'] = $msg;
        }
        if($data) $json['data'] = $data;
        if ($is_end) {
            return json($json);
        } else {
            return json($json);
        }
    }
}
if (!function_exists('data_auth_sign')) {
    /*
     * 数据签名认证
     * @param array $data 被认证的数据
     * @return string
     */
    function data_auth_sign($data = [])
    {
        // 数据类型检测
        if(!is_array($data)){
            $data = (array)$data;
        }
        // 排序
        ksort($data);
        // url编码并生成query字符串
        $code = http_build_query($data);
        // 生成签名
        $sign = sha1($code);
        return $sign;
    }
}



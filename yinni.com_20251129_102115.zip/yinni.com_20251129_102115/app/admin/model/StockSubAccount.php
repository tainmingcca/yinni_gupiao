<?php

namespace app\admin\model;

use think\Model;

class StockSubAccount extends Model
{

    // 设置当前模型对应的完整数据表名称
    protected $name = 'stock_subaccount';

    // 自动写入时间戳
    protected $autoWriteTimestamp = true;
}
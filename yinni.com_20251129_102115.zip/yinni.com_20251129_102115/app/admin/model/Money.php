<?php
namespace app\admin\model;

use think\Model;
use think\facade\Db;
/**
 * 后台用户模型
 * @package app\admin\model
 */
class Money extends Model
{
     // 设置当前模型对应的完整数据表名称
    protected $name = 'admin_bank';

    // 自动写入时间戳
    protected $autoWriteTimestamp = true;
    
    public static function getBanks($map=[],$order='',$offset=20)
    {
        $data_list = self::name('admin_bank')->where($map)
            ->order($order)
            ->paginate($offset, false, ['query' => request()->param()])
            ->each( function($item, $key){
                //return $item;
            });
        return $data_list;
    }

}
<?php

namespace app\apicom\model;

use think\facade\Db;
use think\Model;
use app\apicom\model\Record as RecordModel;
class InvestitemOrder extends Model
{
    // 设置当前模型对应的完整数据表名称
    protected $name = 'invest_order';

    // 自动写入时间戳
    protected $autoWriteTimestamp = true;
    public function user()
    {
     return   $this->belongsTo(Member::class, 'user_id')->bind(['level','name']);
    }



}
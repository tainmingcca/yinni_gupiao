<?php

namespace app\apicom\model;

use think\Model;

/*
 * 用户跟投订单和信号原绑定表
 */
class SingleSourceUser extends Model
{
    // 设置当前模型对应的完整数据表名称
    protected $name = 'single_source_user';

    // 自动写入时间戳
    protected $autoWriteTimestamp = true;
}
<?php

namespace app\apicom\model;

use think\Model;

class Base extends Model 
{
    
}

<?php

namespace app\apicom\model;

use think\Model;
use think\facade\Db;
/**
 * 滚动图片模型
 */
class StockSubAccountSelf extends Base
{
    // 设置当前模型对应的完整数据表名称
    protected $name = 'stock_subaccount_self';

    // 自动写入时间戳
    protected $autoWriteTimestamp = true;
    /*
     * 添加我的自选
     * $uid 会员id
     * $name 股票名称
     * $code 股票代码
     * $sub_id 子账户id
     */
    public function addMyselect($uid,$market,$name,$code,$sub_id=0){
        $data['uid']         = $uid;
        $data['sub_id']      = $sub_id;
        $data['market']      = $market;
        $data['gupiao_name'] = $name;
        $data['gupiao_code'] = $code;
        $data['creat_time']  = time();
        $data['add_ip']      = getClientIp();
        $result = self::create($data);
        return $result;
    }
    /*
     * 删除我的自选
     * @id 我的自选股票id
     */
    public function delMyselect($id){
        $result = self::destroy($id);
        return $result;
    }
    /*
     * 查找我的自选
     */
    public function myadd($uid,$code){

        $data=Db::name('stock_subaccount_self')
            ->where(['uid'=>$uid,'gupiao_code'=>$code])
//            ->where('uid='.$uid)
//            ->where('gupiao_code='.$code)
            ->find();
        return $data;
    }
    /*
     * 删除我的自选
     */
    public function delMyselectbycode($uid,$code){
        $data=Db::name('stock_subaccount_self')
            ->where(['uid'=>$uid,'gupiao_code'=>$code])
//            ->where('uid='.$uid)
//            ->where('gupiao_code='.$code)
            ->delete();
        return $data;
    }
}
<?php

namespace app\apicom\model;

use think\Model;

class MemberCard extends Model
{
    // 设置当前模型对应的完整数据表名称
    protected $name = 'member_card';

    // 自动写入时间戳
    protected $autoWriteTimestamp = true;
    public static function saveData($data)
    {
        $result = self::create($data);
        if($result){
            return ['status'=>1, 'message'=>'提交成功'];
        }else{
            return ['status'=>0, 'message'=>'提交失败'];
        }
    }
}
<?php

namespace app\apicom\model;
use think\Model;
use think\facade\Db;
class SubAccountMoneyRecord extends Base
{
    // 设置当前模型对应的完整数据表名称
    protected $name = 'stock_submoney_record';
    // 自动写入时间戳
//    protected $autoWriteTimestamp = true;

    public static function getAll($map=[], $order='',$listRows=20)
    {
        $data_list = self::view('stock_submoney_record r', true)
            ->view('stock_subaccount s', 'uid,sub_account','r.sub_id=s.id','LEFT')
            ->view('member m', 'mobile, name', 's.uid=m.id', 'left')
            ->where($map)
            ->order($order)
            ->paginate($listRows, false, ['query' => request()->param()])
            ->each( function($item, $key){
                $item->type_name = RECORD_TYPE_NAME[$item['type']];;
//                $item->affect  = money_convert($item->affect);
//                $item->type = $item->type;
            });
        return $data_list;
    }
}
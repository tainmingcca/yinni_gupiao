<?php

namespace app\apicom\model;

use app\admin\controller\Risk;
use think\Model;
use think\facade\Db;
/**
 * 会员模型
 */
class Member extends Base
{
    // 设置当前模型对应的完整数据表名称
    protected $name = 'member';

    // 自动写入时间戳
//    protected $autoWriteTimestamp = true;

// 关闭自动时间格式化（仅当前模型）
    protected $dateFormat = false;
    
    public function getHeadImgAttr($value)

    {
        return request()->domain(true).'/'.$value;

    }




    /**
     * 根据会员ID获取会员基本信息
     * @param array $id 会员ID
     * @return mixed
     */
    public static function getMemberInfoByID($id=null)
    {
        $where['m.id'] = $id;//会员ID
        $where['m.status'] = 1;//会员状态
        $data = self::view('member m', true)
            ->view("money", 'account,freeze,operate_account,bond_account', 'money.mid=m.id', 'left')
            ->where($where)
            ->find();
        return $data;
    }
    /**
     * 根据会员手机号获取会员基本信息
     * @param array $id 会员ID
     * @return mixed
     */
    public static function getMemberInfoByMobile($mobile=null)
    {
        $where['m.mobile'] = $mobile;//会员手机号
        $where['m.status'] = 1;//会员状态
        $data = self::view('member m', true)
            ->view("money", 'account,freeze,operate_account,bond_account', 'money.mid=m.id', 'left')
            ->where($where)
            ->find();
        return $data;
    }
    /**
     * 保存注册数据
     * @param  [type] $data [description]
     * @return [type]       [description]
     */
    public static function saveData($data)
    {
        $sdata['name']   = isset($data['name']) ? $data['name'] : '';
        $sdata['mobile'] = $data['mobile'];
        $sdata['passwd'] = password_hash($data['passwd'], PASSWORD_DEFAULT);
        $sdata['paywd']  = password_hash(substr($data['mobile'],-6,6), PASSWORD_DEFAULT);
        $sdata['pid']    = 0;
        $sdata['id_auth']    = $data['id_auth'];
        $sdata['type']    = $data['type'];
		$sdata['agent_far']   = isset($data['agent_far']) ? intval($data['agent_far']) : 0;
        $sdata['create_ip']   = getClientIp();
        $sdata['create_time'] = date('d/m/Y H:i:s',time());
        $sdata['user_type']  = $data['user_type'];
        $sdata['uid'] = generate_rand_str(12,3);
        $sdata['recomed'] = generate_rand_str(5,5);
        $result = self::create($sdata); 
        if($result->id){
            Db::name('money')->insert(['mid'=>$result->id]);
            $sdata['id']=$result->id;
            return ['status'=>1, 'message'=>lang('success'),'data'=>$sdata];
        }else{
            return ['status'=>0, 'message'=>lang('failed')];
        }
    }
    /*
    * 返回代理商信息
    */
    public static function get_agents_info($mid)
    {
        $user = self::field('id,agent_id,agent_pro,agent_far,agent_rate')->where('id', $mid)->find();
        return $user;
    }
    /*
    * 返回当前用户返佣比例
    */
    public static function agents_back_rate($mid)
    {
        $user =  self::get_agents_info($mid);
        if($user['agent_rate'] && (!$user['agent_id'] || $user['agent_id']==1)){
            $rate = $user['agent_rate'];
        }else{
            if($user['agent_id'] ==2){
                $agent_1 =  self::get_agents_info($user['agent_far']);
                $rate = bcmul($agent_1['agent_rate'],$user['agent_rate'],2);
                $rate = bcdiv($rate,100,2);
            }elseif($user['agent_id']==3){
                $agent_1 =  self::get_agents_info($user['agent_far']);
                $agent_2 =  self::get_agents_info($agent_1['agent_far']);
                $agent_rate = $agent_1['agent_rate'] * $agent_2['agent_rate'];
                $rate = bcmul($agent_rate,$user['agent_rate'],2);
                $rate = bcdiv($rate,10000,2);
            }else $rate = sysConfig('member_back_rate');
        }
        return $rate;
    }
    public static function getSinglelist($where='',$order='',$offset=20)
    {
        $data_list = self::where($where)
            ->where(['user_type'=>2])
            ->order($order)
            ->field('id,label,label2,single_name,company,time,content')
            ->paginate($offset, false, ['query' => request()->param()])
            ->each( function($item, $key){

            });
        return $data_list;
    }
    /*
     * 上级分佣
     */
    public  static function sendCommission($uid,$money=0,$type=1,$order_sn ='')
    {

        $userIds = self::parentUser($uid);
        $remark = '';
        $data = [];
        $userLevelModel = new MemberLevel();
        if ($userIds!==false){
            foreach ($userIds as $item){
                $user_level =$userLevelModel->where(['id'=>$item['level']])->field('id,lv')->find();
                $lv = bcmul($money,$user_level['lv'],2);
                if ($type==1){
                    $remark = '下级持仓成功,您获得返利'.$lv.'元'.'委托单号：'.$order_sn;
                }else{
                    $remark = 'Komisi Penghasilan Tim: Rp'.$lv;
                }
                $data[]= ['uid'=>$item['id'],'send_uid'=>$uid,'money'=>$lv,'type'=>$type,'remark'=>$remark,'create_time'=>time()];
            }

            Db::name('member_commission')->insertAll($data);
            return true;
        }
        return true;
    }
    //获取上一级会员
    public  static function parentUser($uid,$num=3,$lv=1)
    {
        $pid = self::where('id',$uid)->value('agent_far');//上一级id
        $uinfo = self::where('id',$pid)->field('id,agent_far,level')->find();//上一级信息
        if($uinfo){
            if($uinfo['agent_far']&&$num>1) $data = self::parentUser($uinfo['id'],$num-1,$lv+1);
            $data[] = ['id'=>$uinfo['id'],'agent_far'=>$uinfo['agent_far'],'level'=>$uinfo['level'],'lv'=>$lv];
            return $data;
        }
        return false;
    }

    /*
     * 获取用户下级用户
     */
    public  static function getSubUsers($userId, $level = 3, &$result = [])
    {
        if ($level <= 0) {
            return $result;
        }

        // 查询当前用户的下一级用户
        $subUsers = (new Member())->where('agent_far', $userId)->field('id,level,agent_far,name')->select();

        if ($subUsers->isEmpty()) {
            return $result;
        }

        foreach ($subUsers as $user) {
            $result[] = $user; // 收集当前用户的子用户
            // 递归查询子用户的下级
            self::getSubUsers($user['id'], $level - 1, $result);

        }

        return $result;
    }
    /**
     * 获取所有下级成员（迭代查询）
     * @param int $userId 目标用户ID
     * @return \think\Collection
     */
    public static function getAllSubordinatesIterative($userId)
    {
        $members = [];
        $queue = [ [ 'id' => $userId, 'lv' => 0 ] ]; // 初始化队列，起始层级为 0
        while (!empty($queue)) {
            $current = array_shift($queue);
            $currentId = $current['id'];
            $currentLevel = $current['lv'];
            // 获取当前用户的直属下级
            $children = Db::name('member')
                ->where('agent_far', $currentId)
                ->field('id,agent_far,level,type') // 原本字段 + 你需要展示的字段
                ->select()
                ->toArray();

            foreach ($children as $child) {
                $child['lv'] = $currentLevel + 1; // 动态添加层级字段
                $members[] = $child;
                $queue[] = [ 'id' => $child['id'], 'lv' => $child['lv'] ]; // 继续遍历
            }
        }
        return $members;
    }


    public static function teamDividends($userId,$single_id=0,$source_id=0,$sell_price=0,$sell_volume=0)

    {
        $members = self::where(['id'=>$userId])->field('id,agent_far,level,is_true')->find();

        $memberLevel = Db::name('member_level')->where(['id'=>$members['level']])->field('id,lv,is_true')->find();
        $userIds = self::getAllSubordinatesIterative($userId);  // 获取该用户下所有团队成员

        if (!empty($memberLevel) && $memberLevel['is_true']==1 && !empty($userIds)&& $members['is_true']==1){
            $yingli_total = 0;
            $data=[];
            Db::startTrans();
            try {
                foreach ($userIds as $item) {
                    // 团队成员持仓信息
                    $position=  Db::name('stock_position')->where(['single_id'=>$single_id,'source_id'=>$source_id,'single_type'=>2,'uid'=>$item['id']])->field('stock_count,ck_price')->find();
                    if(!empty($position)){
                        $sell_count = bcmul($position['stock_count'],$sell_volume,0); // 持仓数量 * 仓位   该次交易的股数
                        $buy_money = bcmul($position['ck_price'], $sell_count,2); // 计算持仓成本  -  购买金额
                        $sell_money = bcmul($sell_price,$sell_count,2); //计算卖出股票总价
                        if ($sell_money > $buy_money) {
                            $yingli = bcsub($sell_money,$buy_money,2);
                        }else{
                            $yingli =0;
                        }
                        $yingli_total+=$yingli;
                    }
                }
                if ($yingli_total>0){
                    $yingli_money = bcmul($yingli_total, $memberLevel['lv'], 2);
                    $data[] = ['uid' => $members['id'], 'send_uid' => 0, 'money' => $yingli_money, 'type' => 3, 'remark' => '团队分红', 'create_time' => time()];
                }
                Db::name('member_commission')->insertAll($data);
                // 提交事务
                Db::commit();
            } catch (\Exception $e) {
                // 回滚事务
                Db::rollback();
            }
        }
    }

    public static function applySave($userId)
    {
        $Borrow = new Borrow();

        $data['rate']       = 0;
        $data['edn_time']       = time() + (60*60*24*365);
        $data['multiple']   = 0; // 倍率
        $data['loss_warn']  = 0; // 预警线
        $data['loss_close'] = 0;// 止损线
        $data['borrow_money'] = 0;
        $data['init_money'] = 0;
        $data['order_id']            = generate_rand_str(15, 3);
        $data['trading_time']        = 0;
        $data['type']                = 6;
        $data['member_id']           = $userId;
        $data['borrow_duration']     = 0; // 操盘期限
        $data['total']               = 1;
        $data['sort_order']          = 1;
        $data['deposit_money']          = 0;
             
        Db::startTrans();
        try{
            $result = $Borrow->createStock($data);
           
            if($result['status']==1){
               self:: checkBorrow($result['id']);//获取配资信息
            }
            Db::commit();
        }catch(\Exception $e){
            Db::rollback();
         return ajaxmsg($e->getMessage(),1);

        }



    }

    public static function checkBorrow ($id='')
    {
        $BorrowModel = new Borrow();
        $info = $BorrowModel->getEditBorrow($id);//获取配资信息
        $sub_count= Db::name('stock_subaccount')->where(['uid' => null, 'status' => 0])->count(); //获取空闲的子账户数量
        $subid = Db::name('stock_subaccount')->where(['uid' => null, 'status' => 0])->order('id asc')->value('id');
        if ($sub_count <=5){
            $subAccount = Db::name('stock_subaccount')->order('id desc')->value('sub_account') ?? 60753103;

            for ($i = 0; $i < 50; $i++) {
                $datas[] = [
                    'uid' => null,
                    'sub_account' => $subAccount + $i + 1,
                    'sub_pwd' => '123456',
                    'agent_id' => 1,
                    'account_id' => 3,
                    'create_time' => time(),
                ];
            }
            $sub = Db::name('stock_subaccount')->insertAll($datas);
        }
        $data['id'] = $info['id'];
        $data['member_id'] = $info['member_id'];
        $data['borrow_duration'] = $info['borrow_duration'];
        $data['type'] = $info['type'];
        $data['v_status'] = 1;
        $data['stock_subaccount_id_r'] = $subid;
        $data['contents'] = '';
        $data['init_money'] = $info['init_money'];
        $data['deposit_money'] = $info['deposit_money'];
        $data['borrow_money'] = $info['borrow_money'];
        $data['borrow_interest'] = $info['borrow_interest'];
        $data['offset_fee'] = $info['offset_fee'];
        $data['loss_warn'] = $info['loss_warn'];
        $data['loss_close'] = $info['loss_close'];
        $data['position'] = $info['position'];
        $data['prohibit_open'] = 1;
        $data['prohibit_close'] = 1;
        $data['renewal'] = 1;
        $data['autoclose'] = 1;
        $data['commission_scale'] = 3.00;
        $data['min_commission'] = 5.00;
        $data['rate_scale'] = 0.00;
        $data['profit_share_scale'] = 0.00;
        $data['stock_subaccount_id'] = $subid;
        $data['status'] = 1;
        $borrret = Db::name('stock_borrow')->where(['id' => $data['id']])->value('status');
        if ($borrret != -1) return ajaxmsg('配资已经被审核', 0);
        $counts = Db::name('stock_borrow')->where('member_id', $data['member_id'])->count();
        Db::startTrans();
        try {
            $result = $BorrowModel->saveBorrow($data);
            if ($result['status'] == 1) {
                if (sysConfig('give_open') == 1 && $counts == 1) MoneyModel::setGiveFee($data['member_id'], 'give_firstborrow', 0);
                //根据佣金比例分配佣金 用户id 配资id 配资管理费
                if ($data['borrow_interest']) {
                    $res_agent = $BorrowModel->agentToRateMoney($data['member_id'], $data['id'], $data['borrow_interest']);
                }
            }
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return false;
        }
        return true;
    }
    /*
     * 根据当前用户等级，获取项目最小投资金额
     */
    public static function user_level_min_money($user_id='',$single_id='')
    {
        $member = self::where(['id'=>$user_id])->field('id,level')->find();
        $singleItem = (new SingleItem())->where(['id'=>$single_id])->field('id,user_level,min_money')->find();
        $item_level = explode(",",$singleItem['user_level']);
        $min_money  = explode(",",$singleItem['min_money']);
        $money = 0;
        foreach ($item_level as $k=>$v){
            if ($member['level'] == $v){
                $money= $min_money[$k];
                break;
            }
        }
        return $money;
    }


}
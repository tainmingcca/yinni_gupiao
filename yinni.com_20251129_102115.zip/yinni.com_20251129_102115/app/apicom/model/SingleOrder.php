<?php

namespace app\apicom\model;

use think\facade\Db;
use think\Model;
use app\apicom\model\Record as RecordModel;
class SingleOrder extends Model
{
    // 设置当前模型对应的完整数据表名称
    protected $name = 'single_order';

    // 自动写入时间戳
    protected $autoWriteTimestamp = true;
    public function user()
    {
     return   $this->belongsTo(Member::class, 'user_id')->bind(['level','name']);
    }

    /*
     * 订单到期，把订单金额+盈利 全部返回给用户总资金账户
     */
    public static function add_user_money($order_sn='',$effectMoney='',$userYingLiMoney=0,$ck_profit=0,$true_money=0,$type=1)

    {
        $orderInfo = self::where(['order_sn'=>$order_sn])->find();

        if ($type==1){  //如果项目盈利。
            //判断订单是否到期，如果到期就返还给用户
            
            $orderEnd = strtotime(date('Y-m-d', $orderInfo['end_time']));  // 订单结束日期 00:00:00
            $moneyInfo = Money::getMoney($orderInfo['user_id']);  // 获取自己余额
            if (time() >= $orderEnd){
                
                $user = Db::name('member')->where(['id'=>$orderInfo['user_id']])->field('is_pei,pei_time')->find(); // 检测用户配额资金是否到期
                
                $total_moeny = bcadd(($orderInfo->money+$orderInfo->ying_money),strval($true_money),2);
                $total_moeny = bcsub($total_moeny,$orderInfo['withdraw_money'],2)  ; // 去掉已经提赢的金额
                
                $pei_time = strtotime(date('Y-m-d',$user['pei_time']));
                
                if ($user['is_pei'] == 1 && time() >= $pei_time && $orderInfo['single_id']==1){
                    $total_moeny = bcsub(strval($total_moeny),strval($moneyInfo['pei_money']),2)  ; // 配额到期，去掉配额金额
                    
                    Db::name('money')->where('mid', $orderInfo['user_id'])->update(['pei_money' => 0]); //  清理配额金额
                    Db::name('member')->where(['id'=>$orderInfo['user_id']])->update(['is_pei'=>0,'pei_time'=>null]);  // 恢复配额状态
                    Record::saveData($orderInfo['user_id'],  $moneyInfo['pei_money'], 0, 51, '配额到期：'.$moneyInfo['pei_money']);
                }elseif ($user['is_pei'] == 1 && time() <= $pei_time && $orderInfo['single_id']==1){  // 使用配额，配额未到期
                    $total_moeny = bcsub(strval($total_moeny),strval($moneyInfo['pei_money']),2)  ; // 配额未到期，去掉配额金额
                    Db::name('member')->where(['id'=>$orderInfo['user_id']])->update(['is_pei'=>0]);  // 恢复配额状态
                  
                }
                
                $upMoney = bcadd(strval($moneyInfo['account']), strval($total_moeny),2);   //
                
                Db::name('money')->where('mid', $orderInfo['user_id'])->update(['account' => $upMoney]);   // 加回余额

                RecordModel::saveData($orderInfo['user_id'],  $total_moeny, $moneyInfo['account'], 48, '订单到期，资金返还：'.$total_moeny);  //写入资金日志
                // SubAccountMoney::where(['stock_subaccount_id'=>$orderInfo['sub_id']])->dec('avail',$total_moeny);
                $orderInfo->status = 6;
//                $orderInfo->money = bcadd($orderInfo->money,$ck_profit,2);
                $orderInfo->ying_money = bcadd($orderInfo->ying_money,strval($true_money),2) ;
                $orderInfo->save();

            }else{
//                $orderInfo->money =  bcadd($orderInfo->money,$ck_profit,2);
                $orderInfo->ying_money = bcadd($orderInfo->ying_money,strval($true_money),2); // 更新此次盈利金额
                $orderInfo->save();
            }
        }else if ($type==2){ //项目亏钱

            if ( date('Y-m-d') >= date('Y-m-d',$orderInfo['end_time']) ){
                $kui_sun = bcsub(strval($ck_profit),strval($effectMoney),2); //成本-卖出 = 亏损金额

                $moneyInfo = Money::getMoney($orderInfo['user_id']);  // 获取自己余额
                $upMoney = bcsub(strval($moneyInfo['account']), strval($kui_sun),2);   //
                Db::name('money')->where('mid', $orderInfo['user_id'])->update(['account' => $upMoney]);   // 加回余额

                $total_moeny = bcsub(($orderInfo->money+$orderInfo->ying_money),strval($kui_sun),2) ;   //本金+盈利 -亏损  = 返还金额

                RecordModel::saveData($orderInfo['user_id'],  $total_moeny, $moneyInfo['account'], 48, '订单到期，资金返还：'.$total_moeny);  //写入资金日志
                SubAccountMoney::where(['stock_subaccount_id'=>$orderInfo['sub_id']])->dec('avail',$effectMoney);
//                $orderInfo->meony =  bcsub($orderInfo->money,$effectMoney,2);
                $orderInfo->status = 6;
                $orderInfo->save();
            }else{
                $kui_sun = bcsub(strval($ck_profit),strval($effectMoney),2); //成本-卖出 = 亏损金额
                $user_ying_kui = bcsub($orderInfo->ying_money,strval($kui_sun),2); //盈利金额-亏损金额
                if($user_ying_kui < 0){ // 如果盈利金额不够亏损，就扣除本金
                    $chazhi  = bcsub(strval($kui_sun),$orderInfo->ying_money,2);
                    $orderInfo->ying_money =  0;
                    $orderInfo->money = bcsub($orderInfo->money,$chazhi,2);
                    $orderInfo->save();
                }else{
                    $orderInfo->ying_money = bcsub($orderInfo->ying_money,strval($kui_sun),2);
                    $orderInfo->save();
                }
            }



        }

    }

}
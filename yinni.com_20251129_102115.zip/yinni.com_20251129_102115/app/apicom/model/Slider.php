<?php

namespace app\apicom\model;

use think\Model;

/**
 * 滚动图片模型
 */
class Slider extends Base
{
    // 设置当前模型对应的完整数据表名称
    protected $name = 'cms_slider';

    // 自动写入时间戳
    protected $autoWriteTimestamp = true;
}
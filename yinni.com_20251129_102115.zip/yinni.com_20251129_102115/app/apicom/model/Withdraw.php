<?php
namespace app\apicom\model;
use app\apicom\model\Role as RoleModel;
use app\apicom\model\Record;
use app\apicom\model\Bank as BankModel;
use think\Model;
use think\facade\Db;
use think\Exception;

class Withdraw extends Model
{
    
    // 设置当前模型对应的完整数据表名称
    protected $name = 'money_withdraw';

	// 自动写入时间戳
	protected $autoWriteTimestamp = true;

    public function setCreateTimeAttr()
    {
    	return time();
    }

    public function setCreateIpAttr()
    {
    	return getClientIp();
    }

    public function getStatusAttr($value, $data)
    {
    	$status = [0=>'等待处理', 1=>'提现成功', 2=>'提现失败', 3=>'失败退回',4=>'代付中',5=>'代付失败'];
    	return $status[$data['status']];
    }

    public static function  getAll($map=[], $order='',$listRows=20)
    {
        $data_list = self::view('money_withdraw w', true)
            ->view('member m', 'mobile, name,type as user_type', 'm.id=w.mid', 'left')
            ->where($map)
            ->order($order)
            ->paginate($listRows, false, ['query' => request()->param()])
            ->each( function($item, $key){
                $item->money = format_amount($item->money);
                $item->fee   = money_convert($item->fee);
                $info = Member::where('id',$item['mid'])->field('mobile,agent_far')->find();
                $item['agent_mobile'] = Member::where('id',$info['agent_far'])->value('mobile');
                $item['status_data'] = $item->getData('status');
                $item['recharge_count'] = Recharge::where(['mid'=>$item['mid'],'status'=>1])->count(); // 充值次数
                $item['withdraw_count'] = self::where(['mid'=>$item['mid'],'status'=>1])->count();  //提现次数
                $item['recharge_money'] = Recharge::where(['mid'=>$item['mid'],'status'=>1])->sum('money'); // 充值金额
                $item['withdraw_money'] = self::where(['mid'=>$item['mid'],'status'=>1])->sum('money');  //提现金额
                $item['chazhi_money']  = bcsub($item['recharge_money'],$item['withdraw_money'],2);
                $item['admin_recharge']  = Record::where(['mid'=>$item['mid'],'type'=>45])->sum('affect');
                $item['admin_withdraw']  = Record::where(['mid'=>$item['mid'],'type'=>46])->sum('affect');
            });
        return $data_list;

    }
    /**
     * 根据ID获取记录
     */
    public static function getRecordById($id,$listRows=20)
    {
        $res = self::where(['mid'=>$id])
            ->where('status','<',5)
            ->order('id desc')
            ->paginate($listRows, false, ['query' => request()->param()])
            ->each( function($item, $key){
                $item->money    = money_convert($item->money);
            });
        return $res;
    }
    
    public static function saveData($parameter)
    {
        $bank_id = $parameter['bank_id'];
//        if (empty($bank_id)){
//            $data['bank']        = $parameter['bank_name'];
//            $data['card']      = $parameter['card'];
//            $data['real_name']      = $parameter['real_name'];
//            $data['bank_code']      = $parameter['bank_code'];
//        }else{
//            $bank = BankModel::bankInfo($bank_id);
//            $data['bank']        = $bank['bank_name'];
//            $data['card']      = $bank['card'];
//            $data['real_name']      = $bank['real_name'];
//        }
        $where['id'] = $parameter['mid'];//会员ID

        $where['status'] = 1;//会员状态
        $bank = BankModel::bankInfo($bank_id);
        $data['bank']        = $bank['bank_name'];
        $data['card']      = $bank['card'];
        $data['branch']      = $bank['branch'];
        $data['real_name']      = $bank['real_name'];
        $data['mid']         = $parameter['mid'];
//        $data['pay_id']         = $parameter['pay_id'];
//        $data['pay_name']         = $parameter['pay_name'];
        $data['money']       = $parameter['money'];
        $data['order_no']    = 'tx'.generate_rand_str(23, 3);
        $data['create_time'] = time();
        $data['create_ip']   = getClientIp();
        //print_r($data);exit;
        $record = new record;
        Db::startTrans();
        $money_info = Db::name('money')->where('mid', $data['mid'])->lock(true)->find();
        $account = bcsub(strval($money_info['account']), strval($data['money']));
        $up_money['freeze']  = bcadd($money_info['freeze'], $data['money']);
        $up_money['account'] = $account;
        $info = "提现冻结金额".($data['money'])."元,提现单号：".$data['order_no'];
        try{
            $res1 = self::create($data);
            $res2 = $record->saveData($data['mid'], -$data['money'], $account, 2, $info);
            $res3 = Db::name('money')->where('mid', $data['mid'])->update($up_money); 
            if($res1 && $res2 && $res3){
                Db::commit();
                return ['status'=>1, 'message'=>'提交成功'];
            }else{
                Db::rollback();
                return ['status'=>0, 'message'=>'提交失败'];
            }
        }catch(\Exception $e){
            Db::rollback();
            return ['status'=>0, 'message'=>'数据异常'];
        }
    }

}
?>

<?php

namespace app\apicom\model;
use think\Model;
use think\facade\Db;
class SingleAddmoney extends Base
{
    // 设置当前模型对应的完整数据表名称
    protected $name = 'single_addmoney';

    // 自动写入时间戳
    protected $autoWriteTimestamp = true;

}
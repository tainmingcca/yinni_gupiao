<?php
namespace app\apicom\model;

use think\Model;
use think\facade\Db;
/**
 * 会员模型
 */
class StockAccount extends Base
{
    // 设置当前模型对应的完整数据表名称
    protected $name = 'stock_account';

    // 自动写入时间戳
    protected $autoWriteTimestamp = true;
    
    
}
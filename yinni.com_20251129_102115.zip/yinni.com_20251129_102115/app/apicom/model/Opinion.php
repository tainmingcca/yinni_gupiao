<?php

namespace app\apicom\model;

use think\Model;

class Opinion extends Model
{
    // 设置当前模型对应的完整数据表名称
    protected $name = 'opinion';

    // 自动写入时间戳
    protected $autoWriteTimestamp = true;
    
    
    /**
     * 获取列表
     * @param array $map 筛选条件
     * @param array $order 排序
     * @return mixed
     */
    public static function getList($map=[],$order='',$offset=20)
    {
        $data_list = self::where($map)
            ->order($order)
            ->paginate($offset, false, ['query' => request()->param()])
            ->each( function($item, $key){
                //$item->status_n = self::getStatusName($item->status);
            });
        return $data_list;
    }
    public static function getAll($map=[], $order='', $listRow=20)
    {
        $data_list = self::view('opinion o', true)
            ->view('member m', 'mobile, name, id_card', 'm.id = o.uid')
            ->where($map)
            ->order($order)
            ->paginate($listRow, false, [
                'query' => input('param.')
            ]);
        return $data_list;
    }
}
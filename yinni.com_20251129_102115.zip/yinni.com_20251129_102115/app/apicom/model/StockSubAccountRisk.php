<?php
namespace app\apicom\model;
use think\Model;
use think\facade\Db;

class StockSubAccountRisk extends Base
{
    // 设置当前模型对应的完整数据表名称
    protected $name = 'stock_subaccount_risk';
    // 自动写入时间戳
    protected $autoWriteTimestamp = true;
    /*
     * 返回子账号风控信息
     * $sub_id 子账号
     */
    public static function getRisk($sub_id){
        $res = self::where(['stock_subaccount_id'=>$sub_id])->find();
        return $res;
    }
    
}
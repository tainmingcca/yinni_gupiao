<?php
declare (strict_types = 1);

namespace app\apicom\controller;
use app\apicom\model\Member;
use app\apicom\model\Invite as InviteModel;
use app\apicom\model\MemberCommission;
use app\apicom\model\MemberLevel;
use think\facade\Db;

use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevelHigh;
use Endroid\QrCode\Label\Alignment\LabelAlignmentCenter;
use Endroid\QrCode\Label\Font\NotoSans;
use Endroid\QrCode\RoundBlockSizeMode\RoundBlockSizeModeMargin;
use Endroid\QrCode\Writer\PngWriter;
use app\apicom\model\Recharge;
use app\apicom\model\SingleOrder;
class Invite extends BaseController
{
    /*
     * 推广页面数据
     */
    public function getTeam()
    {
         if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $team =  Member::getAllSubordinatesIterative($this->userId); // 无限极团队人数
        
        $team_true= 0;
        $zhi_true= 0;
        if (!empty($team)) {
            $userIds = array_column($team, 'id');

            // 查所有用户的有效订单（status=2 或 6）
            $orders = SingleOrder::whereIn('user_id', $userIds)
                ->whereIn('status', [2, 6])
                ->group('user_id')
                ->column('COUNT(*)', 'user_id'); // user_id => count

            // 查所有用户的有效充值（仅针对 type=1 的用户）
            $recharges = Recharge::whereIn('mid', $userIds)
                ->where(['is_admin'=>0, 'status'=>1])
                ->group('mid')
                ->column('COUNT(*)', 'mid'); // mid => count

            $team_true = 0;
            foreach ($team as $item) {
                $uid = $item['id'];
                $hasOrder = !empty($orders[$uid]);
                $hasRecharge = !empty($recharges[$uid]);

                if ($item['type'] == 1) {
                    if ($hasRecharge && $hasOrder) {
                        $team_true++;
                    }
                } elseif ($item['type'] == 2) {
                    if ($hasOrder) {
                        $team_true++;
                    }
                }
            }
        }
      $zhi_info = (new Member())->where(['agent_far'=>$this->userId])->field('id,type')->select()->toArray();
        $userIds = array_column($zhi_info, 'id');
        if (empty($userIds)) {
            $zhi_true = 0;
        } else {
            // 查所有用户的订单数量
            $orders = SingleOrder::whereIn('user_id', $userIds)
                ->whereIn('status', [2, 6])
                ->group('user_id')
                ->column('COUNT(*)', 'user_id'); // user_id => count

            // 查所有用户的充值数量（只针对 type=1）
            $recharges = Recharge::whereIn('mid', $userIds)
                ->where(['is_admin'=>0, 'status'=>1])
                ->group('mid')
                ->column('COUNT(*)', 'mid'); // mid => count

            $zhi_true = 0;
            foreach ($zhi_info as $item) {
                $uid = $item['id'];
                $hasOrder = !empty($orders[$uid]);
                $hasRecharge = !empty($recharges[$uid]);

                if ($item['type'] == 1) {
                    if ($hasRecharge && $hasOrder) {
                        $zhi_true++;
                    }
                } elseif ($item['type'] == 2) {
                    if ($hasOrder) {
                        $zhi_true++;
                    }
                }
            }
        }
        
        $data['team_true'] = $team_true; //
        $data['zhi_count'] = (new Member())->where(['agent_far'=>$this->userId])->count();  //直推人数
        $data['zhi_true'] = $zhi_true;
        $data['commissionTotal'] = (new MemberCommission())->where(['uid'=>$this->userId])->sum('money');  //累计返佣
        $data['commission'] = (new MemberCommission())->where(['uid'=>$this->userId,'is_return'=>1])->sum('money');  //已返佣
        $data['recomed'] = $this->recomed;
        $data['term_count'] = count($team);
        $data['invite_url'] = request()->domain().'/#/pages/public/register?code='.$this->recomed;
        return  ajaxmsg(lang('success'),1,$data);
    }

/*
 * 团队返佣列表
 */
public function getTeamData()
{
    if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
    $level = input('level');
    $date = input('date');
    $listRows = input('listRows',20);
    $where = [];
//    if (!empty($date)) $where [] = ['u.create_time','<=',strtotime($date.' 00:00:00')];
//    if (!empty($level)) $where [] = ['l.id','=',$level];

    $list = (new MemberCommission())->alias('c')->field('c.id,c.send_uid,c.money,c.remark,c.is_return,c.create_time')
        ->view('member u', 'id,level,mobile,status,last_login_time,create_time as reg_time,name','c.send_uid=u.id')
        ->view('member_level l', 'title,id as level_id','l.id=u.level')
//        ->where($where)
        ->where(['c.uid'=>$this->userId])
        ->order('c.id desc')
        ->paginate($listRows, false, ['query' => request()->param()])
        ->each( function($item, $key){
            $item['mobile'] = substr_mobile($item['mobile']);
//            $item['reg_time'] = date('Y-m-d',strtotime($item['reg_time']));
        });

    if ($list->isEmpty()) return ajaxmsg(lang('success'), 1, []);

    return ajaxmsg(lang('success'),1,$list);
}

public function getMemberLevel()
{
    if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
    $list = (new MemberLevel())->where(['status'=>1])->field('id,title')->select();
    if ($list->isEmpty()) return ajaxmsg(lang('success'),1,[]);
    return ajaxmsg(lang('success'),1,$list);

}






    public function index()
    {
        if(!$this->token || $this->userId == '') return ajaxmsg('未登录',500);
        $page   = input("page",1,['trim', FILTER_SANITIZE_NUMBER_INT]);
        $offset = input("offset",20,['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order  = "r.create_time desc";
        $where  = [];
        $where[]= ['r.mid','=', $this->userId];
        //print_r($where);exit;
        $data   = InviteModel::getAll($where,$order,$offset);

        return ajaxmsg('邀请人奖励记录',1,$data);

    }

    /*
      * 需求参数
    */
    public function conf()
    {
        if(!$this->token || $this->userId == '') return ajaxmsg('未登录',500);
        $mid        = $this->userId;
        $user       = Member::get_agents_info($mid);
        $agent_pro  = $user['agent_pro'];
        $agent_rate = Member::agents_back_rate($mid);

        $count      = Db::view('member_invitation_relation r')->view('member m','id','r.invitation_mid = m.id')->where(['r.mid'=>$mid])->count();//邀请用户人数
        $money   = Db::name('agents_back_money')->where(['mid'=>$mid])->sum('affect');//已赚取佣金
        $rande   = $this->rande($mid);
        $url     = sysConfig('app_share_address');
        $url_link= sysConfig('app_url')."/wap/invite/".$rande;//邀请链接
        $qrcode  = $this->generateQrCode($rande);//二维码
        //$share   = sysConfig('share_logo') ? sysConfig('share_logo') :sysConfig('web_site_front_end_logo');
        //$qrcode=$this->view($rande);
        $url = $url ? $url : $url_link;
        $data['qrcode']     = $qrcode;
        $data['code']       = $rande;
        $data['url']        = $url;
        $data['count']      = $count ? $count : 0;
        $data['money']      = $money ? round($money,2) : 0;
        $data['agent_id']   = $user['agent_id'];
        $data['agent_rate'] = $agent_rate;
        $data['agent_pro']  = $agent_pro;
        $data['banner']     = sysConfig('share_logo');//
        //$data['share_logo'] = sysConfig('app_url').getFilePath($share);
        $data['share_title'] = sysConfig('share_title');
        $data['share_content'] = sysConfig('share_content');

        return ajaxmsg('邀请需求参数',1,$data);
    }
    /*
     *生成二维码到前端
     */
    protected function generateQrCode($data, $label = '',$size = 300, $margin = 10)
    {
        $qr = Builder::create()
            ->writer(new PngWriter())
            ->writeroptions([])
            ->data($data)
            ->encoding(new Encoding('UTF-8'))
            ->errorCorrectionLevel(new ErrorCorrectionLevelHigh())
            ->size($size)
            ->margin($margin)
            ->roundBlocksizeMode(new RoundBlockSizeModeMargin());
        if (!empty($label)){
            $qr->labelText($label)
                ->labelFont(new NotoSans(20))
                ->labelAlignment(new LabelAlignmentCenter());
        }
        return $qr->build()->getDataUri();
    }
    /*
     *保存二维码到本地
     */
    protected function savePath($data, $path, $label = '', $size = 300,$margin = 10)
    {
        $gr = Builder::create()
            ->writer(new PngWriter())
            ->writeroptions([])
            ->data($data)
            ->encoding(new Encoding('UTF-8'))
            ->errorCorrectionLevel(new ErrorCorrectionLevelHigh())
            ->size($size)
            ->margin($margin)
            ->roundBlocksizeMode(new RoundBlocksizeModeMargin());
        if (!empty($label)){
            $qr->labelText($label)
                ->labelFont(new NotoSans(20))
                ->labelAlignment(new LabelAlignmentCenter());
        }
        $result = $qr->build();
        $result->saveToFile($path);
        //todo此时已生成图片在指定的路径，根据自身业务对保存到$path的图片处理
    }
    /*
     * 产生id混淆数
     */
    protected function rande($mid){
        return mt_rand(10,99).$mid.mt_rand(100,999);
    }
    
}
<?php
declare (strict_types = 1);

namespace app\apicom\controller;
use app\apicom\model\JWT;
use app\apicom\model\MemberCard;
use app\apicom\model\Money;
use app\apicom\model\Member as MemberModel;
use app\apicom\model\Bank as BankModel;
use app\apicom\model\Opinion;
use think\facade\Db;
use think\request;
use util\RedisUtil;
use app\apicom\model\MemberLevel;


class Member extends BaseController
{
    
    //用户中心首页数据接口 登录后获取的用户信息 未登录初始化 返回 data = 0
    public function index()
    {

        if(!$this->token || $this->userId == '') return ajaxmsg(lang('login'),500);
        $money = Money::getMoney($this->userId);
        $money['account']         = format_amount($money['account']);
        // $money['freeze']          = money_convert($money['freeze']);
        $money['freeze']          = 0;
        $money['operate_account'] = format_amount($money['operate_account']);
        $money['bond_account']    = format_amount($money['bond_account']);
        $money['total']           = format_amount($money['total']);
        $money['pei_money']           = format_amount($money['pei_money']);
       
        $data['money'] = $money;

        $msg_num   = Db::name('member_message')->where(['mid'=>$this->userId,'status'=>0])->count();
        $mobile    = Db::name('member')->alias('m')->field('id,mobile,agent_id,head_img,name,recomed,head_img,level,pei_time')->where(['id'=>$this->userId,'status'=>1])->find();
        $agent_num = Db::name('member')->where(['agent_far'=>$this->userId,'status'=>1])->count();

        $other['msg_num']  = $msg_num;
        $other['mobile']   = substr_replace(strval($mobile['mobile']),'****',3,4);
        $other['agent_id'] = $mobile['agent_id'];
        $other['invite'] = $mobile['recomed'];
        $other['level_name'] = MemberLevel::where(['id'=>$mobile['level']])->value('title');
        $other['pei_time']     = $mobile['pei_time'] ? date('Y-m-d',$mobile['pei_time']) : '';
        $other['link_m']   = $agent_num;
        $other['name']     = $mobile['name'];
        $other['head_img'] = $mobile['head_img'] ? sysConfig('app_url').str_replace("'\'",'/',$mobile['head_img']) : '';

        $token = array(
            "uid"    => $mobile['id'],
            'doHost' => WS_SERVER_IP,
            'doTime' => time(),
            "mobile" => $mobile['mobile'],
        );
        $jwt = JWT::encode($token,LOCAL_TRADING_TOKEN);
        RedisUtil::cacheToken($jwt, $token);
        $other['token'] = $jwt;
        
        $data['infos']   = $other;
        return ajaxmsg(lang('success'),1,$data);
    }
    public function userInfo()
    {
        if(!$this->token || $this->userId == '') return ajaxmsg(lang('login'),500);
        $minfo = MemberModel::getMemberInfoByID($this->userId);
        unset($minfo['passwd']);
        unset($minfo['paywd']);
        $minfo['id_card']         = $minfo['id_card'] ?? '';
        $minfo['name']            = $minfo['name'] ?? '';
        $minfo['account']         = money_convert($minfo['account']);
        $minfo['freeze']          = money_convert($minfo['freeze']);
        $minfo['operate_account'] = money_convert($minfo['operate_account']);
        $minfo['bond_account']    = money_convert($minfo['bond_account']);
        $minfo['head_img']        = sysConfig('app_url').str_replace("\\",'/',$minfo['head_img']) ?? '';
        $token = array(
            "uid"    => $minfo['id'],
            'doHost' => WS_SERVER_IP,
            'doTime' => time(),
            "mobile" => $minfo['mobile'],
        );
        $jwt = JWT::encode($token,LOCAL_TRADING_TOKEN);
        RedisUtil::cacheToken($jwt, $token);
        $minfo['token'] = $jwt;
        return ajaxmsg(lang('success'), 1, $minfo);
    }
    /**省市调用**/
    public  function getArea()
    {
        $reid = input('reid', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $area = areaList($reid);
        return ajaxmsg(lang('success'),1,$area);
    }
    /**
     * 用户银行卡操作
     */
    public function bankInfo(){

        if(!$this->token || $this->userId == '') return ajaxmsg(lang('login'),500);
        $bank = sysConfig('web_bank');
        if(!$bank) return false;
        $list = explode(PHP_EOL,$bank);
        $rate_val = array();
        foreach ($list as $k => $v){
            $arr = array(
                'id'   => $k,
                'name' => preg_replace('/\|img/', '',explode(':',$v)[1]),
            );
            array_push($rate_val, $arr);
        }
//        $data['real'] = Db::name('member')->field('name,mobile,id_card')->where(['id'=>$this->userId])->find();
        $data['list'] = $rate_val;
        $data['bank'] = Db::name('member_bank')->where(['mid'=>$this->userId])->select();
        return ajaxmsg(lang('success'),1,$data);
    }
    /**
     * 用户银行卡操作
     */
    public function bankInfoData()
    {
        if(!$this->token || $this->userId == '') return ajaxmsg(lang('login'),500);
        $id  = input('id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $res = BankModel::bankInfo($id) ?? [];
        return ajaxmsg(lang('success'),1,$res);
    }
    /***
     *添加银行卡
     **/
    public function addBank()
    {
        if(!$this->token || $this->userId == '') return ajaxmsg(lang('login'),500);
        $data['mid']       = $this->userId;
        $data['id']        = input('id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $data['card']      = input('card', '');
        $data['branch']      = input('branch', '');
        $data['id_card']   = input('id_card', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $data['mobile']    = input('mobile', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $data['real_name'] = input('real_name', '');
        $data['bank_name'] = input('bank_name', '');
        $memberCard = MemberCard::where(['uid'=>$this->userId])->field('id,status,real_name')->find();
//        $name = Db::name('member')->where(['id'=>$this->userId])->update(['name'=>$data['real_name'],'id_card'=>$data['id_card'],'create_ip' => getClientIp()]);
        // 检测是否满足实名赠送管理费活动
//        if(sysConfig('give_open') == 1 && $name == 1) Money::setGiveFee($this->userId, 'give_realname', 0);
                
//        if(!$name) return ajaxmsg('实名认证失败',0);


        //添加銀行卡前 必須先實名認證
        $memberInfo = Db::name('member')->where(['id'=>$this->userId])->field('id,id_auth,name')->find();
        if ($memberInfo['id_auth']==0) return ajaxmsg(lang('id_auth'),0);

        //姓名不能修改
//        if($data['real_name'] != $memberInfo['name']){
//            return ajaxmsg(lang('Name cannot be changed'),0);
//        }
        $member_name = ltrim($memberInfo['name']);//去除左邊空格
        $member_name = rtrim($member_name);//去除右邊空格

        $data['real_name'] = ltrim($data['real_name']);//去除左邊空格
        $data['real_name'] = rtrim($data['real_name']);//去除右邊空格

        if($data['real_name'] != $member_name){
            return ajaxmsg(lang('Name cannot be changed'),0);
        }


        //判斷卡號是否正確（只能是數字，包含空格，特殊符號）
        if (empty($data['card'])) {
            return ajaxmsg(lang('missing'),0);
        }
        // 判断是否包含空格
        if (strpos($data['card'], ' ') !== false) {
            return ajaxmsg(lang('Incorrect bank card number'),0);
        }
        //只能是數字
        if (!ctype_digit($data['card'])) {
            return ajaxmsg(lang('Incorrect bank card number'),0);
        }

        $cardCount = BankModel::where(['card'=>$data['card']])->count();
        if ($cardCount >= 1) return ajaxmsg(lang('card_num_count'),0);

        if (empty($memberCard)) return ajaxmsg(lang('id_auth'),0);
        if ($memberCard->status != 1) return ajaxmsg(lang('auth_card'),0);
        $data['real_name'] = $memberCard->real_name;
        $count = BankModel::where(['mid'=>$this->userId])->count();
        if ($count >= sysConfig('bank_count'))  return ajaxmsg(lang('bank_count'),0);
        if(empty($data['bank_name']) || empty($data['card'])  || empty($data['real_name']))  return ajaxmsg(lang('missing'),0);
        $res = BankModel::saveData($data);
        return ajaxmsg($res['message'],$res['status']);
    }
    /*
     * 删除银行卡
     * id 要删除的银行卡id
     * mid 用户id
     */
    public function delBank()
    {
        if(!$this->token || $this->userId == '') return ajaxmsg(lang('login'),500);
        $id   = input('id' , '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $res  = BankModel::del_bank($id);
        if(!$res) return ajaxmsg(lang('failed'),0);
        return ajaxmsg(lang('success'),1);
    }
    /*
     * 编辑银行卡
     * id 要编辑的银行卡id
     * mid 用户id
     */
    public function editBank()
    {
        if(!$this->token || $this->userId == '') return ajaxmsg(lang('login'),500);
        $id  = input('id' , '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $BankModel = new BankModel;
        $res = $BankModel->bankInfo($id) ?? [];
        if(!$res) return ajaxmsg(lang('failed'),0);
        if($res['mid'] != $this->userId) return ajaxmsg(lang('bank'),0);
        //$name = Db::name('member')->where(['id'=>$this->userId])->value('name');
        //$data['name']     = $name;
        //$data['bank_id']  = $id;
        $data['bankinfo'] = $res;
        $bank = sysConfig('web_bank');
        if(!$bank) return false;
        $list = explode(PHP_EOL,$bank);
        $rate_val = array();
        foreach ($list as $k => $v){
            $arr = array(
                'id'   => $k,
                'name' => preg_replace('/\|img/', '',explode(':',$v)[1]),
            );
            array_push($rate_val, $arr);
        }
        $data['web_bank'] = $rate_val;
        return ajaxmsg(lang('success'),1,$data);
    }
    /*
     * 保存编辑数据
     */
    public function doEdit()
    {
        if(!$this->token || $this->userId == '') return ajaxmsg(lang('login'),500);
        $data = input();
        $result = $this->validate($data, 'BankCard.Complete');
        if($result !== true) return ajaxmsg($result,0);

        $memberInfo = Db::name('member')->where(['id'=>$this->userId])->field('id,id_auth,name')->find();
        //姓名不能修改
//        if($data['real_name'] != $memberInfo['name']){
//            return ajaxmsg(lang('Name cannot be changed'),0);
//        }

        $member_name = ltrim($memberInfo['name']);//去除左邊空格
        $member_name = rtrim($member_name);//去除右邊空格

        $data['real_name'] = ltrim($data['real_name']);//去除左邊空格
        $data['real_name'] = rtrim($data['real_name']);//去除右邊空格

        if($data['real_name'] != $member_name){
            return ajaxmsg(lang('Name cannot be changed'),0);
        }


        //判斷卡號是否正確（只能是數字，包含空格，特殊符號）
        if (empty($data['card'])) {
            return ajaxmsg(lang('missing'),0);
        }
        // 判断是否包含空格
        if (strpos($data['card'], ' ') !== false) {
            return ajaxmsg(lang('Incorrect bank card number'),0);
        }
        //只能是數字
        if (!ctype_digit($data['card'])) {
            return ajaxmsg(lang('Incorrect bank card number'),0);
        }


        $table['id']        = $data['id'] ?? '';
        $table['mid']       = $this->userId ?? '';
        $table['bank']      = $data['bank'] ?? '';
        $table['branch']    = $data['branch'] ?? '';
        $table['card']      = $data['card'] ?? '';
        $table['province']  = $data['province'] ?? '';
        $table['city']      = $data['city'] ?? '';
        $table['real_name'] = $data['real_name'] ?? '';
        $table['create_ip'] = getClientIp() ?? '';
        $res  = BankModel::upEdit($table);
        return ajaxmsg($res['message'],$res['status']);
    }
    /*
     * 添加身份证实名认证
     */
    public function addCard()
    {
        if(!$this->token || $this->userId == '') return ajaxmsg(lang('login'),500);

        $data['uid']       = $this->userId;
        $data['mobile']       =  $this->mobile;
        $data['card_num']   = input('card_num', '');
        $data['real_name'] = input('real_name', '');
        $data['card_pic_head'] = input('card_pic_head', '');
        $data['card_pic_back'] = input('card_pic_back', '');
        $result = $this->validate($data, 'Member.update_card');
        if ($result !== true) return ajaxmsg($result,0);
        $cardInfo = (new MemberCard())->where(['uid'=>$this->userId,'status'=>0])->find();
        $card_num = (new MemberCard())->where(['card_num'=>$data['card_num'],'status'=>1])->find();
        if (!empty($cardInfo)) return ajaxmsg(lang('auth_name'),0);
        if (!empty($card_num)) return ajaxmsg(lang('card_num'),0);
        if(empty($data['card_pic_head']) || empty($data['card_pic_back'])) return ajaxmsg(lang('card_image'),0);
//        if($cardInfo['status'] == 0) return ajaxmsg('正在审核中',0);
        // if($cardInfo['status'] == 1) return ajaxmsg(lang('auth_status'),0);
        $memberInfo = Db::name('member')->where(['id'=>$this->userId])->field('id,id_auth')->find();
        if ($memberInfo['id_auth']==1) return ajaxmsg(lang('auth_status'),0);
        $memberCardInfo = (new MemberCard())->where(['uid'=>$this->userId])->find();
        if (!empty($memberCardInfo)){
            $data['status']=0;
           $res= $memberCardInfo->save($data);
        }else{
           $res= (new MemberCard())->save($data);
        }
        if ($res){
            return ajaxmsg(lang('success'),1);
        }else{
            return ajaxmsg(lang('failed'),0);
        }

    }
    /*
     *  获取实名认证信息
     */
    public function getCard()
    {
        if(!$this->token || $this->userId == '') return ajaxmsg(lang('login'),500);
        $cardInfo = (new MemberCard())->where(['uid'=>$this->userId])->find();
        if (empty($cardInfo)) return  ajaxmsg('成功',1,null);
        $memberInfo = Db::name('member')->where(['id'=>$this->userId])->field('id,id_auth')->find();
        $cardInfo['id_auth'] = $memberInfo['id_auth'];
         $cardInfo['card_pic_back'] = handleImageUrl($cardInfo['card_pic_back']) ;
        $cardInfo['card_pic_head'] = handleImageUrl($cardInfo['card_pic_head']) ;
        return ajaxmsg(lang('success'),1,$cardInfo);
    }
    
    
    public function opinionList()
    {
        if(!$this->token || $this->userId == '') return ajaxmsg(lang('login'),500);
		$page      = input('page', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $offset    = ($page-1) * 20;
		$data      = Opinion::getList(['uid'=>$this->userId],"id desc",$offset);
		if(!$data) return ajaxmsg(lang('data'),0);
		return ajaxmsg(lang('success'),1,$data);
    }
    
    
    public function addOpinion()
    {
        if(!$this->token || $this->userId == '') return ajaxmsg(lang('login'),500);
        $title   = input('title', '');
        $content   = input('content', '' );
        $image  = input('image', '' );
        if (empty($title)) return ajaxmsg(lang('title'),0);
        if (empty($content)) return ajaxmsg(lang('content'),0);
        $data['uid'] = $this->userId;
        $data['mobile'] = $this->mobile;
        $data['image'] = $image;
        $data['title'] = $title;
        $data['content'] = $content;
        $res=(new Opinion())->save($data);
        if ($res){
            return ajaxmsg(lang('success'),1);
        }else{
            return ajaxmsg(lang('failed'),0);
        }
    }



}
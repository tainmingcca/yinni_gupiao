<?php
declare (strict_types = 1);

namespace app\apicom\controller;

/**
 * 測試控制器
 */
class Test extends BaseController
{
    public function index(){
        // return request()->ip();
        // return getClientIp();
        exit();
    }
}
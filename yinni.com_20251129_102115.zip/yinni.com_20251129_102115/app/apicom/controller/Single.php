<?php
declare (strict_types=1);

namespace app\apicom\controller;

use app\admin\model\SingleSource;
use app\apicom\model\Borrow;
use app\apicom\model\DealStock;
use app\apicom\model\MemberLevel;
use app\apicom\model\Record as RecordModel;
use app\apicom\model\Money;
use app\apicom\model\SingleAddmoney;
use app\apicom\model\SingleSourceUser;
use app\apicom\model\SingleUser;
use app\apicom\model\SingleOrder;
use app\apicom\model\SingleItem;
use app\apicom\model\Member;
use app\apicom\model\StockDealStock;
use app\apicom\model\StockDeliveryOrder;
use app\apicom\model\StockDeliveryOrder as Delivery;
use app\apicom\model\StockPosition;
use app\apicom\model\SubAccount;
use app\apicom\model\SubAccountMoney;
use app\apicom\model\Trust;
use think\facade\Db;
use util\RedisUtil;

class Single extends BaseController
{


    /*
     * 获取老师列表
     */
    public function getSingleUser()
    {
//        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $page = input('page', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $limit = input('limit', 10, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $keyword = input('keyword', '');
        $single_type = input('single_type', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]); // 老师分类   1稳健投资  2激进收益
        $where = [];
        if (!empty($keyword)) {
            $where[] = ['single_name|mobile', 'like', $keyword];
        }
        $list = (new Member())->where($where)->where(['user_type' => 2, 'single_type' => $single_type, 'is_del' => 0, 'status' => 1])->field('id,single_name,label,label2,company,time,content,head_img,single_type')->page($page, $limit)->select();
        if ($list->isEmpty()) return ajaxmsg(lang('success'), 1, []);
//        foreach ($list as $k => $item) {
//            $item['head_img'] = $item['head_img'] ;
//        }
        $data = [
            'list' => $list,
            'single_desc' => sysConfig('single_desc')
        ];
        return ajaxmsg(lang('success'), 1, $data);

    }

    public function getSingleItem()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $single_user_id = input('single_user_id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]); //  带单老师id
        $single_class = input('single_class', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);  //  项目所属分类， 1新手跟投  2一键跟投
        if (empty($single_user_id)) return ajaxmsg(lang('request'), 0);
        $list = (new SingleItem())->where(['user_id' => $single_user_id, 'status' => 1, 'single_class' => $single_class])->select();
        if ($list->isEmpty()) return ajaxmsg(lang('success'), 1, null);
        $user_level_name = [];
        $min_money = [];
        $max_money = [];
        foreach ($list as $item) {
            $item_level = explode(",", $item['user_level']);
            $min_money = explode(",", $item['min_money']);
            $max_money = explode(",", $item['max_money']);

            if (in_array($item['id'], [3, 4, 5, 6, 7])) {
                $item['show'] =2;
            }else{
                $item['show'] =1;
            }

        }
        foreach ($item_level as $key => $val) {
            $user_level_name[$key] = MemberLevel::where(['id' => $val])->field('id,title')->find();
        }
        foreach ($min_money as $key => $val){
            $min_money[$key] = number_format(floatval($val), 0, '', '.');;

        }
        foreach ($max_money as $key => $val){
            $max_money[$key] = number_format(floatval($val), 0, '', '.');;
        }
         $pei_money = 0 ;
        $user = Member::where(['id' => $this->userId])->field('id,is_pei')->find();
        if ($user['is_pei'] == 0) $pei_money = Money::getMoney($this->userId)['pei_money'];
        $data = [
            'list' => $list,
            'user_level_name' => $user_level_name,
            'min_money' => $min_money,
            'max_money' => $max_money,
            'user_level' => Member::where(['id' => $this->userId])->value('level'),
            'money' => Money::getMoney($this->userId)['account'],
            'pei_money' => $pei_money,
        ];
        return ajaxmsg(lang('success'), 1, $data);
    }

    /*
     * 追投
     */
    public function createSingleMoney()
    {

        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $money = input('money', '');
        $single_id = input('single_id', '');  // 项目id
        $sub_id = input('sub_id', '');  // 项目id
        $order_sn = input('order_sn', '');  // 项目id

        if (empty($single_id) || empty($sub_id)) return ajaxmsg(lang('request'), 0);

        //一键投资  除了7天 其他不能跟投
        if (in_array($single_id, [3, 4, 5, 6, 7])) {
            return ajaxmsg(lang('Position is full'), 0);
        }


        $singleInfo = (new SingleItem())->where(['id' => $single_id])->find();
        $single_order = (new SingleOrder())->where(['order_sn' => $order_sn])->find();
        if (empty($singleInfo)) return ajaxmsg(lang('item'), 0);
        if (empty($single_order)) return ajaxmsg(lang('request'), 0);
        if ($single_order['status']!=2) return ajaxmsg(lang('order_status'), 0);
        if ($singleInfo['is_up'] == 0) return ajaxmsg(lang('item_zhui'), 0);
        if (empty($money)) return ajaxmsg(lang('request'), 0);
        $money_info = Db::name('money')->where('mid', $this->userId)->lock(true)->find();
        if ($money_info['account'] < $money) return ajaxmsg(lang('money_error'), 0);
        $single_addmoney = Db::name('single_addmoney')->where(['user_id' => $this->userId, 'sub_id' => $sub_id, 'status' => 0])->find();
        if (!empty($single_addmoney)) return ajaxmsg(lang('single_addmoney'), 0);
        $user_level = explode(",", $singleInfo['user_level']);
        $min_money = explode(",", $singleInfo['min_money']);
        $max_money = explode(",", $singleInfo['max_money']);
        $user = Member::where(['id' => $this->userId])->field('id,level')->find();
        $borrow = Borrow::where(['stock_subaccount_id' => $sub_id])->find();
        if(isset($borrow['sub_account']) || empty($borrow)) $borrow['sub_account'] = 0;
        $data = [
            'user_id' => $this->userId,
            'sub_id' => $sub_id,
            'sub_account' => $borrow['sub_account'],
            'money' => $money,
            'create_time' => time(),
            'order_sn' => $order_sn,
            'status' => 2//,'single_id' => $single_id
        ];

        // 新增：等级限额校验
        $user_level = explode(",", $singleInfo['user_level']);
        $min_money = explode(",", $singleInfo['min_money']);
        $max_money = explode(",", $singleInfo['max_money']);
        foreach ($user_level as $key => $val) {
            if ($user['level'] == $val) {
                //統計對應項目已投資金額
                $count_money = SingleOrder::where(['user_id' => $this->userId])->whereIn('status','1,2')->sum('money');
                $total_money = bcadd(strval($count_money), strval($money),2);
//                if ($money < $min_money[$key]) return ajaxmsg(lang('min_item') . $min_money[$key], 0);
                //限制對應等級 對應項目最大投資
                if ($total_money > $max_money[$key]) return ajaxmsg(lang('max_item') . $max_money[$key], 0);
            }
        }

        // 直接追加资金
        $upMoney = bcsub(strval($money_info['account']), strval($money));   // 减掉跟投金额后的余额
        Db::name('money')->where('mid', $this->userId)->update(['account' => $upMoney]);   // 扣除余额
        SubAccountMoney::upMoneyLog($sub_id, $money, 17, 0, 0, '');   // 子账户明细
        RecordModel::saveData($this->userId, $money, $upMoney, 42, '追加跟投：' . $money);   // 账户总资金明细记录
        //後臺審核通過之後  再把追投金額添加到項目中
//        $single_order->money = bcadd(strval($single_order->money), strval($money));
//        $single_order->save();
        $data['status'] = 0;
        Db::name('single_addmoney')->insert($data);


//        $limitTime = strtotime(date('Y-m-d'). ' 13:30:00');
//        foreach ($user_level as $key => $val) {
//            if ($user['level'] == $val) {
//                $toatl = bcadd(strval($single_order->money), strval($money));
//                //超过项目最大金额 后台审核
//                if ($toatl >= $max_money[$key] ||  time() >= $limitTime) {
//                    $data['status'] = 0;
//                    Db::name('single_addmoney')->insert($data);
//
//                } else {
//                    // 直接追加资金
//                    $upMoney = bcsub(strval($money_info['account']), strval($money));   // 减掉跟投金额后的余额
//                    Db::name('money')->where('mid', $this->userId)->update(['account' => $upMoney]);   // 扣除余额
//                    SubAccountMoney::upMoneyLog($sub_id, $money, 17, 0, 0, '');   // 子账户明细
//                    RecordModel::saveData($this->userId, $money, $upMoney, 42, '追加跟投：' . $money);   // 账户总资金明细记录
//
////                    Borrow::where(['stock_subaccount_id'=>$sub_id])->update(['init_money'=> ($borrow['init_money']+$money)]);
//                    $single_order->money = bcadd(strval($single_order->money), strval($money));
//                    $single_order->save();
//                    $data['status'] = 1;
//                    Db::name('single_addmoney')->insert($data);
//                }
//            }
//        }
        return ajaxmsg(lang('success'), 1);
    }

    /*
     * 跟投页面 数据统计
     */
    public function singleTotalData()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $where = [
            's.uid' => $this->userId,
            's.type' => 2,
        ];
        $data = [];
        $data ['DaytotalMoney'] = 0;
        $data ['singleTotal'] = 0;
        $data ['DaysingleTotal'] = 0;
        $subaccount = SubAccount::getAllList($where, 'id desc');

        if (empty($subaccount)) $data ['DaytotalMoney'] = 0;
        $data['totalMoney'] = (new RecordModel())->where(['mid' => $this->userId, 'type' => 39])->sum('affect');  //跟投总收益
        foreach ($subaccount as $item) {
            $data ['DaytotalMoney'] += (new StockPosition())->where(['sub_id' => $item['id']])->whereDay('create_time')->sum('ck_profit');  //今日盈亏
//            $position = (new StockPosition())->where(['sub_id'=>$item['id']])->field('ck_price,stock_count')->find();
            $data ['singleTotal'] += (new StockPosition())->where(['sub_id' => $item['id']])->sum('market_value');   // 跟投总市值
            $data ['DaysingleTotal'] += (new StockPosition())->where(['sub_id' => $item['id']])->whereDay('create_time')->sum('market_value');  //今日跟投市值
//            if (!empty($position))  $data ['singleTotal']+= bcmul($position['ck_price'], strval($position['stock_count']), 2);
            $data ['singleTotal'] = money_convert($data ['singleTotal']);
        }
        return ajaxmsg(lang('success'), 1, $data);

    }

    /*
     * 跟单页面团队数据
     */
    public function getUserTeam()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $ids = Member::getSubUsers($this->userId, 3);
        $data['ids'] = [];
        $data['content'] = (new \app\apicom\model\Document())->getOne(58)['content'] ?? '';
        $data['countTotal'] = 0;
        $data['countDirect'] = 0;
        $data['daySan'] = 0;
        $data['dayCount'] = 0;

        if (empty($ids)) return ajaxmsg(lang('success'), 1, $data);
        $myTime = date('Y-m-d H:i:s', strtotime("-3 day"));
        foreach ($ids as $item) {
            $item['level_name'] = (new MemberLevel())->where(['id' => $item['level']])->value('title');
            $item['pid_name'] = (new Member())->where(['id' => $item['agent_far']])->value('name');
        }

        $data ['countTotal'] = count($ids);  //团队成员
        $data ['countDirect'] = (new Member())->where(['agent_far' => $this->userId])->count(); //直属成员
        $data['daySan'] = (new SingleOrder())->whereIn('user_id', $ids)->whereIn('status', '2,3')->whereTime('create_time', '<=', $myTime)->count();
        $data['dayCount'] = (new SingleOrder())->whereIn('user_id', $ids)->whereIn('status', '2,3')->whereDay('create_time')->count();
        $data['ids'] = $ids;


        return ajaxmsg(lang('success'), 1, $data);
    }

    public function getTeamList()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $type = input('type', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $ids = Member::getSubUsers($this->userId, 3);

        $data = [];
        $MemberLevelModel = new MemberLevel();
        $memberModel = new Member();
        if (empty($ids)) return ajaxmsg(lang('success'), 1, $data);

        if ($type == 1) { // 团队列表
            foreach ($ids as $item) {
                $item['level_name'] = $MemberLevelModel->where(['id' => $item['level']])->value('title');
                $item['pid_name'] = $memberModel->where(['id' => $item['agent_far']])->value('name');
            }
            $data ['ids'] = $ids;
        } elseif ($type == 2) {   //直属成员
            $members = (new Member())->where(['agent_far' => $this->userId])->field('id,name,level,agent_far')->select();
            if ($members->isEmpty()) $data['zhi_pid'] = [];
            foreach ($members as $item) {
                $item['level_name'] = $MemberLevelModel->where(['id' => $item['level']])->value('title');
            }
            $data ['ids'] = $members;
        } elseif ($type == 3) {  //  3日未跟人员
            $myTime = date('Y-m-d H:i:s', strtotime("-3 day"));
            $str = [];
            foreach ($ids as $k => $id) {
                $str[$k] = $id['id'];
            }
            $daySan = (new SingleOrder())->whereIn('user_id', $str)->whereTime('create_time', '<=', $myTime)->field('user_id,create_time,auth_time')->select();
            $data['daySan'] = [];
            if ($daySan->isEmpty()) return ajaxmsg(lang('success'), 1, $data);
            foreach ($daySan as $item) {
                
                $user = $memberModel->where(['id' => $item['user_id']])->field('level,name')->find();
                $item['level_name'] = $MemberLevelModel->where(['id' => $user['level']])->value('title');
                $item['name'] = $user['name'];
                $item['date_time'] = date('d/m/Y', $item['auth_time']);
               
            }
            $data['daySan'] = $daySan;
        } elseif ($type == 4) {  //  今日跟投订单
            $str = [];
            foreach ($ids as $k => $id) {
                $str[$k] = $id['id'];
            }
            $dayOrder = (new SingleOrder())->whereIn('user_id', $str)->whereDay('create_time')->field('user_id')->select();
            $data['day_order'] = [];
            if ($dayOrder->isEmpty()) return ajaxmsg(lang('success'), 1, $data);
            foreach ($dayOrder as $item) {
                $user = $memberModel->where(['id' => $item['user_id']])->field('level,name,money')->find();
                $item['level_name'] = $MemberLevelModel->where(['id' => $user['level']])->value('title');
                $item['name'] = $user['name'];


            }
            $data['day_order'] = $dayOrder;
        }

        return ajaxmsg(lang('success'), 1, $data);
    }


    /*
     * 获取用户跟投剩下中和失效的订单列表以及统计数据
     */
    public function getSingleOrderTotal()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $page = input('page', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $limit = input('limit', 50, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $list = SingleOrder::alias('s')
            ->view('single_item i', 'title', 'i.id = s.single_id')
            ->view('single_source u', 'buy_price,sell_price', 'u.id = s.source_id')
            ->where(['s.user_id' => $this->userId])->whereIn('s.status', '2,6')
            ->field('s.id,s.order_sn,s.money,s.ying_money')
            // ->page(intval($page), intval($limit))->select();
            ->order('id desc')
            ->select();
        $money = SingleOrder::where(['user_id' => $this->userId])->whereIn('status', '2,6')->sum('money');
        $ying_money = SingleOrder::where(['user_id' => $this->userId])->whereIn('status', '2,6')->sum('ying_money');
        $total = SingleOrder::where(['user_id' => $this->userId, 'status' => 2])->sum('money');  //生效中的总金额
        $level_name = MemberLevel::where(['id' => Member::where(['id' => $this->userId])->value('level')])->value('title');

        if ($list->isEmpty()) return ajaxmsg(lang('success'), 1, ['list' => [], 'count' => 0, 'ying_money' => $ying_money,
            'money' => $money, 'total_money' => $total, 'level_name' => $level_name]);
        foreach ($list as $item) {
            $chi_lv = bcmul(bcdiv(bcsub($item['sell_price'], $item['buy_price'], 2), $item['buy_price'], 2), '100', 2);
            if ($item['sell_price'] == 0) $chi_lv = 0;
            $item['chi_lv'] = $chi_lv;
            $item['money'] = format_amount($item['money']);
            $item['ying_money'] = format_amount($item['ying_money']);
            
        }


        $data = [
            'list' => $list,
            'count' => $list->count(),
            'ying_money' => format_amount($ying_money), 
            'money' => format_amount($money),
            'total_money' => $total,
            'level_name' => $level_name,
        ];
        return ajaxmsg(lang('success'), 1, $data);
    }


    /*
     * 跟投记录
     */
    public function getSingleOrderList()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $page = input('page', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $limit = input('limit', 10, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $status = input('status', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $where = [];
        if (!empty($status)) $where [] = ['status', '=', $status];


        $list = (new SingleOrder())->where(['user_id' => $this->userId])->where($where)->page(intval($page), intval($limit))->select();


        if ($list->isEmpty()) return ajaxmsg(lang('success'), 1, ['list' => [], 'count' => 0]);

        foreach ($list as $item) {
            $itemOrder = (new SingleItem())->where(['id' => $item['single_id']])->field('title,scale,single_class')->find();
//            $item['money'] = SubAccountMoney::where(['stock_subaccount_id'=>$item['sub_id']])->value('avail');
            $item['can_money'] = bcsub(strval($item['ying_money']),strval($item['withdraw_money']),2) ;
            $item['title'] = $itemOrder['title'];
            $item['scale'] = $itemOrder['scale'];
            $item['single_class'] = $itemOrder['single_class'];
            $item['user_name'] = Member::where(['id' => $item['user_id']])->value('name');
            $item['out_time'] = date('d/m/Y H:i:s', $item['out_time']);
            if ($item['end_time'] == 0) {
                $item['end_time'] = '--';
            } else {
                $item['end_time'] = date('d/m/Y', $item['end_time']);
            }
        }
        $count = (new SingleOrder())->where(['user_id' => $this->userId])->where($where)->count();
        $data = [
            'list' => $list,
            'count' => $count,
        ];
        return ajaxmsg(lang('success'), 1, $data);
    }

    /*
     * 跟投订单详情
     */
    public function SingleOrderInfo()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $order_sn = input('order_sn', '');
        $data = ['info' => [], 'list' => []];
        if (empty($order_sn)) return ajaxmsg(lang('missing'), 1, $data);
        $info = SingleOrder::where(['order_sn' => $order_sn])->field('id,order_sn,money,ying_money,source_id,create_time,auth_time,single_day,end_time,single_id,user_id')->find();
        if (empty($info)) return ajaxmsg(lang('data'), 1, $data);
        $soruce = SingleSource::where(['id' => $info['source_id']])->field('sell_price,id,buy_price,status')->find();
        $info['chi_lv'] = 0;
        $info['is_chi'] = 0;

        if (!empty($soruce)) {
            if ($soruce['status'] == 2 && $soruce['buy_price'] != 0 && $soruce['sell_price'] != 0) $info['chi_lv'] = bcmul(bcdiv(bcsub($soruce['sell_price'], $soruce['buy_price'], 2), $soruce['buy_price'], 2), '100', 2);
        }
        $singleItem = SingleItem::where(['id' => $info['single_id']])->field('title,scale,with_name,single_class')->find();
        $info ['teacher'] = $singleItem['with_name'];
        $info ['scale'] = $singleItem['scale'] . "%";
        $info ['zhui_money'] = SingleAddmoney::where(['order_sn' => $order_sn, 'status' => 1])->sum('money');
        $info['auth_time'] = date('d/m/Y H:i', $info['auth_time']);
        $info['end_time'] = date('d/m/Y H:i', $info['end_time']);
        $info['single_class'] = $singleItem['single_class'];
         $info['money']=format_amount($info['money']);
         $info['ying_money']=format_amount($info['ying_money']);
        $moneyInfo = Money::getMoney($this->userId);
        $info['account'] = format_amount($moneyInfo['account']);
        $list = StockDealStock::where(['order_sn' => $order_sn])->field('gupiao_name,status,amount,deal_date')->select()->toArray();
        $count = StockPosition::where(['order_sn' => $order_sn])->where('stock_count', '>', 0)->count();
        if ($count > 0) $info['is_chi'] = 1;
        $withdraw_ying = RecordModel::where(['mid'=>$info['user_id'],'order_sn'=>$order_sn,'type'=>49])->field('id,type,affect,create_time')->select()->toArray();  // 提赢记录
        $single_addmoney = SingleAddmoney::where(['order_sn' => $order_sn,'user_id'=>$info['user_id'],'status'=>1])->field('id,money,create_time')->select()->toArray();
        if (!empty($withdraw_ying)) {
            foreach ($withdraw_ying as $key=>$item){
                $withdraw_ying[$key]['status']= $item['type'];
                $withdraw_ying[$key]['amount']= format_amount($item['affect']);
                $withdraw_ying[$key]['deal_date']= $item['create_time'];
            }
        }
        if (!empty($single_addmoney)){
            foreach ($single_addmoney as $key=>$item){
                $single_addmoney[$key]['status']= '追加投资';
                $single_addmoney[$key]['amount']=format_amount($item['money']);
                $single_addmoney[$key]['deal_date']= $item['create_time'];
            }
        }
        if (!empty($list)){
            foreach ($list as $key=>$item){
                $list[$key]['deal_date'] = date('d/m/Y',strtotime($item['deal_date']));
                $list[$key]['amount']=format_amount($item['amount']);
                
            }
        }
        $list = array_merge($list,$withdraw_ying,$single_addmoney);
        $data = [
            'info' => $info,
            'list' => $list
        ];
        return ajaxmsg(lang('success'), 1, $data);
    }


    /*
     * 跟投信号源详情
     */
    public function SinglePositionData()
    {

        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $single_id = input('single_id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $order_sn = input('order_sn', '');
        if (empty($order_sn)) return ajaxmsg(lang('missing'), 1, []);
        $single_id = SingleOrder::where(['order_sn' => $order_sn])->value('single_id');
        $userSource = (new SingleSourceUser())->where(['single_order_sn' => $order_sn])->column('source_id'); //获取用户跟投订单所有的信号源id
        $list = (new SingleSource())->alias('s')->leftJoin('stock_list l', 's.code = l.code')
            ->where(['s.single_id' => $single_id])->whereIn('s.id', $userSource)
            ->field('s.*,l.symbol')->order('id desc')->select();
        if ($list->isEmpty()) return ajaxmsg(lang('item_source'), 1, []);
        foreach ($list as $item) {
             
            $item['code'] = $item['symbol'];
            $position = StockPosition::where(['single_id' => $single_id, 'source_id' => $item['id'], 'uid' => $this->userId])
                ->field('ck_price,volume,market_value,sell_price,sell_count,sell_price_scope,scale,stock_count')->order('id desc')->find();
               
            $item['single_name'] = (new SingleItem())->where(['id' => $item['single_id']])->value('title');
            $item['trust_price'] = floor($item['buy_price']) ;

            $item['buy_time'] = date('d/m/Y H:i', $item['buy_time']);
            $item['deal_price'] = 0;
            $item['volume'] = 0;
            $item['market_value'] = 0;
            if (!empty($position)) {
                $item['deal_price'] = floor($position['ck_price']);
                $item['volume'] = '100%';
                if ($position['volume'] > 0) $item['volume'] = bcmul($position['volume'], '100', 0) . "%";
                $item['market_value'] = floor($position['market_value']) ;
                // 卖出信息
                if ($item['status'] == 2) {
                    $yingli = 0;
                    $yingli_money = 0;
                    if ($position['sell_price_scope'] > 0) $item['sell_price'] = $position['sell_price_scope'];
                    if ($position['sell_price_scope'] > 0 && $position['sell_count'] > 0) {
                        $total_moeny = bcmul($position['sell_price_scope'], strval($position['sell_count']), 2);  //卖出金额总价
                    } else {
                        $total_moeny = bcmul(strval($position['stock_count']), strval($item['sell_price']), 2);  //卖出金额总价
                    }

                    if ($total_moeny > $position['market_value']) $yingli = bcsub($total_moeny, $position['market_value'], 2); //卖出金额 -成本  =  盈利金额
                    $item['scale'] = round($position['scale'], 0) . "%";
                    $scale = bcdiv($position['scale'], '100', 2);  //分佣百分比
                    $yingli_money =bcmul(strval($yingli), $scale, 0);  //  老师分佣所得金额
                    $item ['yingli_money'] = floor($yingli) ;
                    $item['true_yingli'] =bcsub(strval($yingli), strval($yingli_money), 0);
                    $item['sell_price'] = floor($item['sell_price']) ;
                }
            }
            if (!empty($item['sell_time'])) $item['sell_time'] = date('d/m/Y H:i', $item['sell_time']);
            // if(empty($position)) unset($item);
        }
        return ajaxmsg(lang('success'), 1, $list);
    }


   /**
     * 用户发起跟单/跟投
     */
    public function createSingle()
    {
         if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);

        $redis = cache()->handler();
        $lockKey = 'lock:order:' . $this->userId;
        $lockTtl = 3; // 秒
        $lockToken = uniqid('', true);
        // 加锁（带 token）
        $isLock = $redis->set($lockKey, $lockToken, ['nx', 'ex' => $lockTtl]);
        if (!$isLock) return ajaxmsg('请勿重复提交，请稍后再试', 0);
        $user = Member::where(['id' => $this->userId])->field('id,id_auth,level,pei_time,is_pei')->find();
        if (!$user || $user['id_auth'] == 0) return ajaxmsg(lang('id_auth'), 0);
        $sub_id     = input('sub_id', 0, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $single_id  = input('single_id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $money      = input('money', '');
        $direction  = input('direction', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $single_type = input('single_type', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);

        //一键投资  除了7天 其他不能跟投
        if (in_array($single_id, [3, 4, 5, 6, 7])) {
            return ajaxmsg(lang('Position is full'), 0);
        }


        $user_sub = Db::name('stock_subaccount')->where(['uid' => $this->userId, 'status' => 1])->find();
        if(empty($sub_id) && empty($user_sub)){
            $subid = Db::name('stock_subaccount')->where(['uid' => null, 'status' => 0])->order('id asc')->value('id');
            Db::name('stock_subaccount')->where(['id'=>$subid])->update(['uid'=>$this->userId,'status'=>1,'type'=>2]);
            $sub_id= $subid;
        }else{
            $sub_id=$user_sub['id'];
        }
        
        
        if (empty($sub_id)) return ajaxmsg(lang('account'), 0);
        $singleInfo = SingleItem::where('id', $single_id)->findOrEmpty();
        if ($singleInfo->isEmpty()) return ajaxmsg(lang('item_not_exist'), 0);
        $money_pei='0';
        $money_info = Db::name('money')->where('mid', $this->userId)->lock(true)->find();
        
         Db::startTrans();
        try {
            //新手跟投
             if ($singleInfo['id']==1 && $singleInfo['day']==1 && $user['pei_time'] >= time() && $user['is_pei']==0 && $money_info['pei_money'] > 0){
                $money_pei = $money_info['pei_money'];
                $user->is_pei = 1;
                $user->save();
                if($money > 0) {
                    if ($money_info['account'] < $money)  return ajaxmsg(lang('money_error'), 0);  
                    $upMoney = bcsub(strval($money_info['account']), strval($money), 2);
                  //  file_put_contents('$createSingle1.txt', date('Y-m-d H:i:s') . ': ' .$upMoney. "\n", FILE_APPEND);
                    Db::name('money')->where('mid', $this->userId)->update(['account' => $upMoney]);
                }
                $money = bcadd(strval($money),strval($money_pei),2);
                $upMoney = $money;
            }else{
              // 锁余额
                if ($money_info['account'] < $money)  return ajaxmsg(lang('money_error'), 0);  //可用餘額不足
                $upMoney = bcsub(strval($money_info['account']), strval($money), 2);
               // file_put_contents('$createSingle2.txt', date('Y-m-d H:i:s') . ': ' .$upMoney. "\n", FILE_APPEND);
                Db::name('money')->where('mid', $this->userId)->update(['account' => $upMoney]);
            }
            // 等级限额校验
            $user_level = explode(",", $singleInfo['user_level']);
            $min_money = explode(",", $singleInfo['min_money']);
            $max_money = explode(",", $singleInfo['max_money']);
            foreach ($user_level as $key => $val) {
                if ($user['level'] == $val) {
                    $count_money = SingleOrder::where(['user_id' => $this->userId])->whereIn('status','1,2')->sum('money');
                    $total_money = bcadd(strval($count_money), strval($money),2);
                    if ($money < $min_money[$key]) return ajaxmsg(lang('min_item') . $min_money[$key], 0);
                    if ($total_money > $max_money[$key]) return ajaxmsg(lang('max_item') . $max_money[$key], 0);
                }
            }
            // 行锁查重，兜底防重复
            $exists = SingleOrder::where([
                'single_id' => $single_id,
                'user_id'   => $this->userId
            ])->whereIn('status', [1, 2])->lock(true)->find();

            if ($exists) {
                Db::rollback();
                return ajaxmsg(lang('order_error'), 0);
            }
            // 生成唯一订单号
            $order_sn = $this->createUniqueOrderSn($this->userId);
            // 写入订单
            $orderData = [
                'user_id'       => $this->userId,
                'sub_id'        => $sub_id,
                'mobile'        => $this->mobile,
                'order_sn'      => $order_sn,
                'single_id'     => $single_id,
                'single_title'  => $singleInfo['title'],
                'single_day'    => $singleInfo['day'],
                'scale'         => $singleInfo['scale'],
                'single_type'   => $single_type,
                'direction'     => $direction,
                'type'          => $singleInfo['single_type'],
                'money'         => $money,
            ];

            // 余额扣除 + 日志
           // SubAccountMoney::upMoneyLog($sub_id, $money, 16, 0, 0, '');
            SingleOrder::create($orderData);
           // file_put_contents('$createSingle3.txt', date('Y-m-d H:i:s') . ': ' .$upMoney. "\n", FILE_APPEND);
            RecordModel::saveData($this->userId, $money, $upMoney, 35, '跟投单号：' . $order_sn);
            Db::commit();
            return ajaxmsg(lang('success'), 1);

        } catch (\Throwable $e) {
            Db::rollback();
            // 写日志
            // Log::error("用户下单异常：user_id={$this->userId}，error=" . $e->getMessage());
            return ajaxmsg($e->getMessage(), 0);
        } finally {
            // 释放锁（校验 token 防止误删别人锁）
            if ($redis->get($lockKey) === $lockToken) {
                $redis->del($lockKey);
            }
        }
    }
    /*
     * 跟投订单盈利余额 提现到总资金账户
     */
    public function depositYing()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $order_sn = input('order_sn', '');
        $money = input('money', 0);
        
        if (empty($order_sn)) return ajaxmsg(lang('missing'), 0);
        $info = SingleOrder::where(['order_sn' => $order_sn])->field('id,ying_money,status,user_id,withdraw_money')->find();
        if ($info['status'] != 2) return ajaxmsg(lang('order_ying'), 0);
        if ($money > $info['ying_money']) return ajaxmsg(lang('money_error'), 0);
       
        $total_ti = bcadd(strval($money),strval($info['withdraw_money']));
        
        if ($total_ti > $info['ying_money']) return ajaxmsg(lang('money_error'), 0);
        $money_info = Db::name('money')->where('mid', $info['user_id'])->lock(true)->find();
        
        $upMoney = bcadd(strval($money_info['account']), strval($money));   // 余额+提盈金额
        Db::startTrans();
        try {
            Db::name('money')->where('mid', $info['user_id'])->update(['account' => $upMoney]);   
            RecordModel::saveData($info['user_id'], $money, $upMoney, 49, '提取盈利：' . $money,$order_sn);
//            $info->ying_money = bcsub($info->ying_money,$money,2);
            $info->withdraw_money = bcadd(strval($info->withdraw_money), strval($money));
            $info->save();
            Db::commit();
        } catch (\Exception $e) {
            Db::rollback();
            return ajaxmsg(lang('failed'), 0);

        }
        return ajaxmsg(lang('success'), 200);
    }
    /**
     * 生成唯一订单号
     *
     * @param int $userId 用户ID
     * @return string
     */
    protected function createUniqueOrderSn($userId)
    {
        $prefix = 'OD'; // 可自定义前缀，比如订单（Order）
        $date = date('YmdHis'); // 当前时间戳，精确到秒
        $rand = mt_rand(1000, 9999); // 4位随机数
        $uid = str_pad(strval($userId % 10000), 4, '0', STR_PAD_LEFT); // 截取用户ID后四位

        // 拼接订单号
        $orderSn = $prefix . $date . $uid . $rand;

        // 检查数据库是否已经存在，避免冲突
//        $exists = Db::name('single_order')->where('order_sn', $orderSn)->value('id');
//        if ($exists) {
//            // 递归调用重新生成
//            return $this->createUniqueOrderSn($userId);
//        }

        return $orderSn;
    }


}
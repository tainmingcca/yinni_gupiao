<?php
declare (strict_types = 1);

namespace app\apicom\controller;
use app\apicom\model\MemberLevel;
use app\apicom\model\Recharge;
use app\apicom\model\SingleOrder;
use app\apicom\model\SubAccount;
use think\App;
use think\exception\ValidateException;
use think\Validate;
use think\Controller;
use think\facade\Request;
use app\apicom\model\Member;
use util\RedisUtil;

/**
 * 控制器基础类
 */
abstract class BaseController
{
    /**
     * Request实例
     * @var \think\Request
     */
    protected $request;
    /**
     * 应用实例
     * @var \think\App
     */
    protected $app;
    /**
     * 是否批量验证
     * @var bool
     */
    protected $batchValidate = false;
    /**
     * 控制器中间件
     * @var array
     */
    protected $middleware = [];
    // 当前用户的ID
    public $userId     = '';
    // 当前用户的手机号
    public $mobile     = '';
    // 当前用户实名状态
    public $id_auth     = 0;
    //用户邀请码
    public $recomed     = '';
    // 上级代理商
    public $agentid    = '';
    // token
    public $token      = null;
    /**
     * 设置无需登陆的action
     * 格式：[
     *     '控制器名称(驼峰)' => ['action1', 'action2', ...],
     *     ...
     * ]
     */
    protected $noLogin = [
        'Index'     => ['index', 'getSlider', 'getconf', 'download','test'],
        'News'      => ['getNewsDetail'],
        'User'      => ['login', 'signout', 'register', 'sendsms'],
        'Market'    => ['aliveStock','sinahy','thirdMarkets',"getApiStockList"],
        'Column'    => ['index'],
        'Ipo'       => ['getIpolimit'],
        'Crond'     => ['autoRenewal']
    ];
    /**
     * 构造方法
     * @access public
     * @param  App  $app  应用对象
     */
    public function __construct(App $app)
    {
        $this->app     = $app;
        $this->request = $this->app->request;
        // 控制器初始化
        $this->initialize();
    }

    // 初始化
    public function initialize()
    {
        $this->token  = input('token', '');
        $this->userId = input('uid', '');

        // 根据token获取用户的数据
        if(!$this->userId || $this->token) $userData = $this->token ? RedisUtil::getToken($this->token) : [];
        // 当前用户的ID
        if(!$this->userId || $this->token) $this->userId = $userData['uid'] ?? '';

        // 当前用户的手机号
        $this->mobile = isset($userData['mobile']) ? $userData['mobile'] : '';
        $this->name = isset($userData['name']) ? $userData['name'] : '';
        $this->recomed = isset($userData['recomed']) ? $userData['recomed'] : '';
        $this->id_auth = isset($userData['id_auth']) ? $userData['id_auth'] : '';
//        $this->upMemberLevel();
        /**
         * @var string $controller 当前控制器
         * @var string $action 当前方法(action)
         */
        $controller = Request::controller();
        $action     = Request::action();
        // 验证用户是否登录，排除无需登录的action
        if (!(isset($this->noLogin[$controller]) && in_array($action, $this->noLogin[$controller]))) {
            if ($this->userId == '' || empty($this->token)) {
                if(php_sapi_name() == 'cli'){
                    //echo json_encode(array('uid' => $this->userId, 'status' => 500, 'message' => '未登录'),JSON_UNESCAPED_UNICODE);
                    return false;
                }else{
                    //echo json_encode(array('uid' => $this->userId, 'status' => 500, 'message' => '未登录'),JSON_UNESCAPED_UNICODE);
                    return false;
                    exit;
                }
            }
        }

    }

    /**
     * 验证数据
     * @access protected
     * @param  array        $data     数据
     * @param  string|array $validate 验证器名或者验证规则数组
     * @param  array        $message  提示信息
     * @param  bool         $batch    是否批量验证
     * @return array|string|true
     * @throws ValidateException
     */
    protected function validate(array $data, $validate, array $message = [], bool $batch = false)
    {
        if (is_array($validate)) {
            $v = new Validate();
            $v->rule($validate);
        } else {
            if (strpos($validate, '.')) {
                // 支持场景
                [$validate, $scene] = explode('.', $validate);
            }
            $class = false !== strpos($validate, '\\') ? $validate : $this->app->parseClass('validate', $validate);
            $v     = new $class();
            if (!empty($scene)) {
                $v->scene($scene);
            }
        }
        $v->message($message);
        
        // 是否批量验证
        if ($batch || $this->batchValidate) {
            $v->batch(true);
        }
        return $v->failException(true)->check($data);
    }
    protected function swoole_exit($msg)
    {
        //php-fpm的环境
        if (ENV=='php'){
            exit($msg);
        }else{//swoole的环境
            throw new Swoole\ExitException($msg);
        }
    }

    protected function upMemberLevel()
    {
        $userId = $this->userId;

        $userInfo = Member::where(['id' => $userId])->field('id,level')->find();
        if (empty($userInfo)) return false;

        $memberLevel = MemberLevel::where(['id' => $userInfo['level']+1])->find(); //获取下一级会员等级
        if (empty($memberLevel)) return false;
        $userIds = Member::getAllSubordinatesIterative($userId);  //无限极获取所有下级用户

        if (empty($userIds)) return false;

        $userIds = array_map(function($item) {
            return $item['id'];
        }, $userIds);

        $recharge = Recharge::whereIn('mid',$userIds)->where(['status'=>1])->count(); //团队有效充值人数
        $item_order= SingleOrder::whereIn('user_id',$userIds)->where('status','>',1)->count();  //团队有效跟投订单
        $total_num = $recharge+$item_order;
       if ($total_num>=$memberLevel['min_team_num'] && $total_num<=$memberLevel['max_team_num']){
           $userInfo->level = $memberLevel['id'];
            $userInfo->save();
            return  true;
       }
       return false;
//        foreach ($userIds as $item) {
//            $money = SubAccount::getSubaccountTotal($item['id']); // 获取团队子账户资金
//            $account = \app\apicom\model\Money::where(['mid'=>$item['id']])->sum('account');  //获取用户账户余额
//            $money = $money ?? 0;
//            $account = $account ?? 0;
//
//            $total = bcadd(sprintf("%.2f", $money), sprintf("%.2f", $account), 2);   // 子账户余额+总账户余额  =  账户总资金
//            $sub_money_total += $total;
//        }
//        if ($invite_num >= $memberLevel['invite_num'] || $sub_money_total >= $memberLevel['toatl_money'] || count($userIds) >= $memberLevel['team_num']){
//            $userInfo->level = $memberLevel['id'];
//            $userInfo->save();
//            return  true;
//        }
//        return  false;

    }


}

<?php

namespace app\apicom\controller;

use app\admin\model\SingleSource;
use app\apicom\model\DealStock;
use app\apicom\model\Money;
use app\apicom\model\Recharge;
use app\apicom\model\Record as RecordModel;
use app\apicom\model\SingleOrder;
use app\apicom\model\SingleSourceUser;
use app\apicom\model\StockPosition;
use app\apicom\model\Trust;
use app\apicom\model\Withdraw;
use think\facade\Db;
use app\apicom\model\Member;
use app\service\SellService;
class Callback
{
    private $pay_code = ['htPay','hzPay','nasklPay','gPay'];

    public function a()
    {
        
        
   
           
        
    }


    public function notify()
    {
        $param =request()->param();
        // $param=[

        //     ];
       
        $code = $param['code'];
       
        unset($param['code']);

        if (in_array($code,$this->pay_code) == false) exit('fail');

        if (empty($param)) exit('fail');

        writeLog("{$code}/notify",$param);
        $className = "\\app\\apicom\\serve\\".ucfirst($code);
        $payObj = new $className;


        $verifyRes = $payObj->notify($param);
        if($verifyRes===true){
            $updateData = $payObj->getUpdateOrderData($param);
            
            $this->notifyChangeOrder($updateData);
        }
       
        exit('success');
    }
    public function cashNotify()
    {
        $param =request()->param();
//         $param=[
//                           'orderNo' => '2510035000000128306520744',
//   'orderAmount' => '157089.00',
//   'merNo' => '809100002753282',
//   'merOrderNo' => 'tx06603151667765336563960',
//   'payTime' => '2025-10-03 09:24:10',
//   'resultCode' => NULL,
//   'sign' => '0c298e590537bd37d11efe8ec64bdc27c27a10d0847ae8136a29a96af8a23407',
//   'status' => 7,
//   'resultMsg' => NULL,
//   'code'=>'nasklPay'
//             ];
        $code = $param['code'];
        unset($param['code']);
        if (in_array($code,$this->pay_code) == false) exit('fail');
        if (empty($param)) exit('fail');
        writeLog("{$code}/notify",$param);
        $className = "\\app\\apicom\\serve\\".ucfirst($code);
        $payObj = new $className;
        $verifyRes = $payObj->notify($param);

        if($verifyRes===true){
            $updateData = $payObj->getWithdrawOrderData($param);

            $this->notifyWithdraw($updateData);
        }
        exit('success');
    }


    public function returnUrl(){
        $param =request()->param();
        $code = $param['code'];
        unset($param['code']);
        // if (empty($param)) exit('fail');
        writeLog("{$code}/returnUrl",$param);

        $className = "\\app\\apicom\\serve\\".ucfirst($code);
        $payObj = new $className;
        return $payObj->returnUrl($param);
    }

    /*
     * 提现回调处理逻辑
     */
    private function notifyWithdraw($updateData)
    {

        $orderInfo = (new Withdraw())->where(['order_no'=>$updateData['order_no']])->find();

        if ($orderInfo->getData()['status']!=4) return 'fail';

        Db::startTrans();
        $money_info = Db::name('money')->where('mid', $orderInfo['mid'])->lock(true)->find();
        try {
            //失败逻辑
            if($updateData['status']!='success'){
//                $up_money['account'] = bcadd(strval($money_info['account']), strval($orderInfo['money']));
//                Db::name('money')->where('mid', $orderInfo['mid'])->update($up_money);
//                $info = "提现失败：".$orderInfo['money']."元";
//                RecordModel::saveData($orderInfo['mid'], $orderInfo['money'], $money_info['account'], 4, $info);
                $orderInfo->status=5;
                // $orderInfo->order_no= 'tx'.generate_rand_str(23, 3);
                $orderInfo->channel_id=$updateData['out_trade_no'];
                $orderInfo->save();
            }else{
                $info = "提现成功：".$orderInfo['money']."元";
                RecordModel::saveData($orderInfo['mid'], $orderInfo['money'], $money_info['account'], 3, $info);
                $orderInfo->status=1;
                $orderInfo->channel_id=$updateData['out_trade_no'];
                $orderInfo->save();
            }
            Db::commit();
        }catch(\Exception $e){
            Db::rollback();
            return ajaxmsg($e->getMessage());
        }
    }

    /*
     * 充值回调处理逻辑
     */
    private function notifyChangeOrder($updateData){
        $orderInfo = (new Recharge())->where(['order_no'=>$updateData['order_no']])->lock(true)->find();
        
        if (empty($orderInfo)) exit('fail');
        if ($orderInfo['status']!=0) exit('success'); // 告诉支付平台已经处理过了

         // 失败逻辑
        if ($updateData['status'] != 'success') {
            $orderInfo->save(['status' => 2]);
            exit('success');
        }

        // 成功邏輯
        Db::startTrans();
        try {
            $orderInfo->status=1;
            $orderInfo->money= $updateData['amount'];
            $orderInfo->channel_id= $updateData['out_trade_no'];
            $orderInfo->save();
            $account = Db::name('money')->where('mid', $orderInfo['mid'])->find();
            $upMoney = bcadd(strval($account['account']),$updateData['amount'],2);

            if($account){
                $res_m = Db::name('money')->where('mid', $orderInfo['mid'])->update(['account' => $upMoney]);
            }else{
                $res_m = Db::name('money')->insert(['mid'=>$orderInfo['mid'],'account'=>$upMoney,'status'=>'1']);
            }
            RecordModel::saveData($orderInfo['mid'],  $updateData['amount'], $upMoney, 1, '充值金额：'.$updateData['amount']);
            Db::commit();
            exit('success'); // 一定要返回 success
        }catch(\Exception $e){
            Db::rollback();
            exit('fail'); // 出错也要明确返回
        }
    }

}
<?php

// This file is auto-generated, don't edit it. Thanks.
namespace app\apicom\controller;

use AlibabaCloud\Darabonba\Env\Env;
use AlibabaCloud\SDK\Cloudauth\V20190307\Cloudauth;
use AlibabaCloud\Tea\Utils\Utils;
use AlibabaCloud\Tea\Console\Console;
use app\apicom\model\MemberCard;
use \Exception;
use AlibabaCloud\Tea\Exception\TeaError;

use Darabonba\OpenApi\Models\Config;
use AlibabaCloud\SDK\Cloudauth\V20190307\Models\InitFaceVerifyRequest;
use AlibabaCloud\SDK\Cloudauth\V20190307\Models\DescribeFaceVerifyRequest;
use think\facade\Db;

class Sample  extends BaseController
{

        protected $sceneId = 1000012112; // 认证场景ID。您必须先在智能核身控制台创建认证场景，才能获得认证场景ID。
        protected $regionId = "cn-hangzhou"; // 可用区域Id （请自行配置）
        protected $productCode = "LR_FR"; // // 认证方案。唯一取值：LR_FR。
        protected $model = "LIVENESS"; // 活体检测类型。取值：LIVENESS（默认）：动作活体检测 | PHOTINUS_LIVENESS：动作活体+炫彩活体双重检测
        protected $certType = "IDENTITY_CARD"; // 证件类型。取值：IDENTITY_CARD，表示身份证。

    /**
     * @param string[] $args
     * @return void
     */
    public  function main(){

        if(!$this->token || $this->userId == '') return ajaxmsg('未登录',500);
        $data = request()->param();
        $cardInfo = (new MemberCard())->where(['uid'=>$this->userId,'status'=>1])->find();
        $card_num = (new MemberCard())->where(['card_num'=>$data['card'],'status'=>1])->find();
        if (!empty($cardInfo)) return ajaxmsg('您已提交实名认证，请勿重复提交',0);
        if (!empty($card_num)) return ajaxmsg('身份证号已存在,请核实',0);
        $memberInfo = Db::name('member')->where(['id'=>$this->userId])->field('id,id_auth')->find();
        if ($memberInfo['id_auth']==1) return ajaxmsg('您已实名通过',0);

        // 客户服务端自定义的业务唯一标识，用于后续定位排查问题使用。值最长为32位长度的字母数字组合，请确保唯一。
        $outerOrderNo = "RZ".date("YmdHis").rand(0000000,9999999);
        // 用户的真实姓名。
        $certName = $data['name'];
        // 用户的证件号码。
        $certNo = $data['card'];
        // MetaInfo环境参数，需要通过客户端SDK获取。
        $metaInfo = $data['MetaInfo'];
        $token = md5($data['card']);
        try {
            $config = new Config([]);
            $config->accessKeyId = env("app.ALIYUNOSS_ACCESSID");
            // 您的AccessKey ID
            $config->accessKeySecret = env("app.ALIYUNOSS_ACCESSKEY");
            // 您的AccessKey Secret
            $config->regionId = $this->regionId;

            // 您的可用区ID
            $client = new Cloudauth($config);
            $requestInitFaceVerify = new InitFaceVerifyRequest([]);
            $requestInitFaceVerify->sceneId = $this->sceneId;
            $requestInitFaceVerify->outerOrderNo = $outerOrderNo;
            $requestInitFaceVerify->productCode = $this->productCode;
            $requestInitFaceVerify->model = $this->model;
            $requestInitFaceVerify->certType = $this->certType;
            $requestInitFaceVerify->certName = $certName;
            $requestInitFaceVerify->certNo = $certNo;
            $requestInitFaceVerify->metaInfo = $metaInfo;
            $requestInitFaceVerify->userId = $this->userId;
            $requestInitFaceVerify->CallbackToken = $token;
            $requestInitFaceVerify->CallbackUrl = request()->domain(true).'/apicom/Callback/notify';
            $requestInitFaceVerify->returnUrl = request()->domain(true)."/new/#/pages/result/index";
//            $requestInitFaceVerify->returnUrl = "http://192.168.31.63:8888/new/#/pages/result/index";
            $responseInitFaceVerify = $client->initFaceVerify($requestInitFaceVerify);
            // var_dump($responseInitFaceVerify->body->code); exit();
            if ($responseInitFaceVerify->body->code==200){
                $data['token'] = $token;
                $this->addCard($data);
                return ajaxmsg('获取成功',1,['url'=>$responseInitFaceVerify->body->resultObject->certifyUrl,'certifyId'=>$responseInitFaceVerify->body->resultObject->certifyId]);
            }else{
                return ajaxmsg('获取失败',0);
            }
        }
        catch (Exception $error) {
            if (!($error instanceof TeaError)) {
                return ajaxmsg('获取失败',0,$error->getMessage());
//                $error = new TeaError([], $error->getMessage(), $error->getCode(), $error);
            }
//            Console::log($error->message);
        }
    }

    public function describe()
    {

        $certifyId = request()->post('certifyId');
        if (empty($certifyId)) return ajaxmsg('获取失败',0,'非法请求');
        try {
            $config = new Config([]);
            $config->accessKeyId = env("app.ALIYUNOSS_ACCESSID");
            // 您的AccessKey ID
            $config->accessKeySecret = env("app.ALIYUNOSS_ACCESSKEY");
            // 您的AccessKey Secret
            $config->regionId = $this->regionId;

            // 您的可用区ID
            $client = new Cloudauth($config);
            $requestDescribeFaceVerify = new DescribeFaceVerifyRequest([]);
            $requestDescribeFaceVerify->sceneId = $this->sceneId;
            $requestDescribeFaceVerify->certifyId = $certifyId;
            $responseDescribeFaceVerify = $client->describeFaceVerify($requestDescribeFaceVerify);
//        file_put_contents("Notify.txt", "\n" . date('Y-m-d H:i:s') . var_export($responseDescribeFaceVerify->body,true) . "\n", FILE_APPEND);
            if ($responseDescribeFaceVerify->body->resultObject->passed =='T'){
                $info = (new MemberCard())->where(['uid'=>$this->userId,'status'=>0])->find();
                if (!empty($info)) {
                    $userInfo = (new \app\apicom\model\Member())->where(['id'=>$this->userId])->field('id,name,id_auth,id_card')->find();
                    $info->status = 1;
                    $userInfo->id_auth = 1;
                    $userInfo->name = $info['real_name'];
                    $userInfo->id_card = $info['card_num'];
                    $userInfo->save();
                }
                return ajaxmsg('认证成功',1);
            }elseif($responseDescribeFaceVerify->body->resultObject->passed =='F'){
                return ajaxmsg('认证失败',0);
            }
        }catch (Exception $error) {
            if (!($error instanceof TeaError)) {
                return ajaxmsg('认证失败',0);
//                $error = new TeaError([], $error->getMessage(), $error->getCode(), $error);
            }
//            Console::log($error->message);
        }
    }

    public function addCard($data)
    {

//        $cardInfo = (new MemberCard())->where(['uid'=>$this->userId,'status'=>1])->find();
//        $card_num = (new MemberCard())->where(['card_num'=>$data['card_num'],'status'=>1])->find();
//        if (!empty($cardInfo)) return ajaxmsg('您已提交实名认证，请勿重复提交',0);
//        if (!empty($card_num)) return ajaxmsg('身份证号已存在,请核实',0);
//        $memberInfo = Db::name('member')->where(['id'=>$this->userId])->field('id,id_auth')->find();
//        if ($memberInfo['id_auth']==1) return ajaxmsg('您已实名通过',0);
        $info = (new MemberCard())->where(['uid'=>$this->userId])->find();
        $data= [
            'uid'=>$this->userId,
            'mobile'=>$this->mobile,
            'card_num'=>$data['card'],
            'real_name'=>$data['name'],
            'card_pic_head'=>$data['card_pic_head'],
            'card_pic_back'=>$data['card_pic_back'],
            'token'=>$data['token'],
        ];
        if (!empty($info)) {
            $info->save($data);
        }else{
            (new MemberCard())->save($data);
        }
    }

}



<?php
declare (strict_types = 1);

namespace app\apicom\controller;
use app\apicom\model\MemberCard;
use app\apicom\model\Record;
use app\apicom\model\SubAccountMoneyRecord;
use app\apicom\model\Money as MoneyModel;
use app\apicom\model\Recharge;
use app\apicom\model\Bank as BankModel;
use app\apicom\model\Withdraw as WithdrawModel;
use think\facade\Db;
use  think\helper\Hash;
use app\admin\model\Money   as AdminBank;
use app\apicom\model\Member as MemberModel;
class Money extends BaseController
{
    /**
     * 资金明细
     * @return [type] [description]
     */
    public function index(){
        if(!$this->token || $this->userId == '') return ajaxmsg(lang('login'),500);
        $type  = input('type', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $start = input('start_date', '');
		$end   = input('end_date', '');
        $page  = input('page', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        // 获取查询条件
        //$endDate   = $end   ? strtotime($end) + 86400   : strtotime(date("Y-m-d 23:59:59"));
        //$startDate = $start ? strtotime($start) : strtotime(date("Y-m-d 00:00:00"));
        $end = $end . "23:59:59";
        $order  = 'id desc';
        $page   = $page ? $page : 1;
        $offset = intval($page);
        // 数据列表
        $data_list = Db::name('money_record')
            ->where('mid','=',$this->userId)
            ->whereTime('create_time','between',[$start,$end])
            ->order($order)
            ->page($offset,20)
            ->select()
            ->toArray();
        if(!$data_list) return ajaxmsg(lang('data'),0);
        foreach ($data_list as $k => $v) {
            $data_list[$k]['happend_time'] = getTimeFormt($v['create_time'],4);
            $data_list[$k]['happend_date'] = getTimeFormt($v['create_time'],5);
            $data_list[$k]['type_name']    = MONET_TYPE_NAME[$v['type']];
            $data_list[$k]['affect']       = format_amount($v['affect']);//bcdiv(strval($v['affect']),'100',2);
            $data_list[$k]['account']      = format_amount($v['account']);//bcdiv(strval($v['account']),'100',2);
            if($data_list[$k]['type']==45 || $data_list[$k]['type']==46|| $data_list[$k]['type']==52){
                unset($data_list[$k]);
            }
        }
        return ajaxmsg(lang('success'),1,$data_list);
    }

    public function subaccountRecordList()
    {
      if(!$this->token || $this->userId == '') return ajaxmsg(lang('login'),500);
        $page  = input('page', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $sub_id  = input('sub_id', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);
       
        $order  = 'id desc';
        $page   = $page ? $page : 1;
        $offset = intval($page);
        
        $data_list = SubAccountMoneyRecord::where('sub_id','=',$sub_id)
           
            ->whereMonth('create_time')
            ->order($order)
            ->paginate(20, false, ['query' => request()->param()]);
            
        if(!$data_list) return ajaxmsg(lang('data'),0);
        foreach ($data_list as $k => $v) {
            // $data_list[$k]['create_time'] = getTimeFormt($v['create_time'],3);
            if ($data_list[$k]['type']==3 || $data_list[$k]['type']==19){
                $data_list[$k]['affect']       = "-".money_convert($v['affect']);//bcdiv(strval($v['affect']),'100',2);
            }else{
                $data_list[$k]['affect']       = money_convert($v['affect']);//bcdiv(strval($v['affect']),'100',2);
            }
            $data_list[$k]['account']      = money_convert($v['account']);//bcdiv(strval($v['account']),'100',2);
        }
        return ajaxmsg(lang('success'),1,$data_list);
    }

    /*代理查询下级明细*/
    public function agent_index(){
        $id       = input('id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $type     = input('type', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $keyword  = input('keyword', '');
        if(!$id) return ajaxmsg(lang('failed'),0);
        // 获取查询条件
        $map = $this->getMap();

        if($keyword){
            $searchurl2='&_search_field=type&keyword='.$map['type'][1];
        }else{
            $searchurl2="";
        }
        if($type){
            $searchurl1='&_filter_time2=r.create_time&_filter_time_from='.$map['r.create_time'][1][0].'&_filter_time_to='.$map['r.create_time'][1][1].'&type='.$type;
        }else{
            $searchurl1="";
        }
        if(isset($map['r.create_time'][1])){
            $map['r.create_time'][1][0]=strtotime($map['r.create_time'][1][0]);
            $map['r.create_time'][1][1]=strtotime($map['r.create_time'][1][1]);
        }
        $map['mid'] = $this->userId;
        $order  = 'r.id desc';
        $page   = intval($this->request->param("page"));
        $page   = $page ? $page : 1;
        $offset = $page;
        // 数据列表
        $data_list = Db::name('money_record')
            ->alias('r')
            ->where($map)
            ->field('r.*')
            ->order($order)
            ->page($offset,10)
            ->select();
        if(empty($data_list))return ajaxmsg('未获取到数据',0);
        foreach ($data_list as $k => $v) {
            $data_list[$k]['happend_time'] = getTimeFormt($v['create_time'],4);
            $data_list[$k]['happend_date'] = getTimeFormt($v['create_time'],5);
            $data_list[$k]['type_name']    = getTypeNameForMoney($v['type']);
            $data_list[$k]['money']   = money_convert($v['money']);//bcdiv($v['money'],100,2);
            $data_list[$k]['affect']  = money_convert($v['affect']);//bcdiv($v['affect'],100,2);
            $data_list[$k]['account'] = money_convert($v['account']);//bcdiv($v['account'],100,2);
        }
        
        return ajaxmsg('数据列表',1,$data_list);
    }
    /*
     * 充值
     */
    public function recharge()
    
    {	
        if(!$this->token || $this->userId == '') return ajaxmsg(lang('login'),500);
		//$money   = MoneyModel::getMoney($this->userId);
    	$account = Db::name("admin_bank")->where(['status'=>1,'is_recharge'=>1])->withoutField('class,group_ids,is_cash,is_recharge')->order('sort desc')->select()->toArray();
        foreach($account as $k=>$v){
            if(!empty($v['image'])){
                $account[$k]['image'] =  sysConfig('app_url').getFilePath($v['image']);
            }
            $account[$k]['icon'] =  request()->domain().$v['icon'];
        }
		//$data['money']   = $money;
		//$data['offline'] = sysConfig('web_site_account');
		$data['account']  = $account;
        $data['recharge_min']  = sysConfig('recharge_min');
        $data['mtips']    = !empty(sysConfig('web_money_tip')) ? arrayEol(sysConfig('web_money_tip')) : [];
        $data['web_chat_link']    = sysConfig('web_chat_link');

		return ajaxmsg(lang('success'),1,$data);
    }
    /*
     * 充值操作
     */
	public function doCharge()
	{
	    if(!$this->token || $this->userId == '') return ajaxmsg(lang('login'),500);
        $card_id   = input('cardno', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $money     = input('money', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $form_name = input('form_name', '');
        $type      = input('transfer', ''); // transfer 线下转账支付
        $value      = input('value', 0); // transfer 线下转账支付
        $receipt   = input('receipt_img','');//转账凭证
        $type_id   = input('type_id', 0, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        if($money <= 0) return ajaxmsg(lang('recharge'),0);
        if(!$type) return ajaxmsg(lang('recharge_type'),0);

        if ($money < intval(sysConfig('recharge_min'))) return ajaxmsg(lang('recharge_min'),0);
        $line_bank = $type == 'transfer' ? '卡号：'.$card_id.'；时间：'.date('Y-m-d',time()) : '';
        $adminBank = AdminBank::where(['value'=>$value])->find();
       
        if (empty($adminBank)) return ajaxmsg(lang('recharge_type'),0);
        if ($adminBank['class']!='Bank'){
            $data = [];
            $className = '\\app\\apicom\\serve\\'.$adminBank['class'];
            $payClass = new $className();
            $data['mid']         = $this->userId;
            $data['money']       = money_convert($money);
            $data['order_no']    = 'cz'.date('YmdHis').generate_rand_str(10, 3);
            $data['type']        = $adminBank['type'];
            $data['line_bank']   = $line_bank;
            $data['create_time'] = time();
            $data['create_ip']   = getClientIp();
            $data['status']      = 0;
            $data['receipt_img'] = $receipt;
            $data['form_name']   = $form_name;
            $data['charge_type_id'] = 0;
            $data['pay_name'] =$adminBank['payee'];
            $data['mobile'] =$this->mobile;
            $rule=$payClass->pay($data,$adminBank['group_ids']);
            // halt($rule);
            if ($rule!==false){
                Recharge::create($data);
                return ajaxmsg(lang('success'),1,$rule);
            }else{
                return ajaxmsg(lang('failed'),0);
            }
        }else{
            if(empty($receipt)) return ajaxmsg(lang('receipt_img'),0);
            $order_no  = Recharge::saveData($money, $this->userId, $type, $line_bank,$receipt,$type_id,$form_name,$adminBank['payee']);
            if($order_no){
                return ajaxmsg(lang('recharge_do'),1);
            }else{
                return ajaxmsg(lang('failed'),0);
            }
        }
	}
	/*
	 * 充值记录
	 */
	public function rechargeRecord()
	{
        $page   = input('page', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $data   = Recharge::getRecordById($this->userId,$offset);
        
	    return ajaxmsg(lang('success'),1,$data);
	}
	/*
     * 提现
     */
    public function withdraw()
    {
        $money = MoneyModel::getMoney($this->userId);
        $banks = BankModel::getBank($this->userId);

        if(!empty($banks[0]) && !$money) {
            return ajaxmsg(lang('failed'),0);
        }
        $data['is_auth']=0;
        $data['real_name']='';
        $userAuth = MemberCard::where(['uid'=>$this->userId,'status'=>1])->field('id,real_name')->find();
        $user = MemberModel::where(['id'=>$this->userId])->field('id,id_auth,mobile')->find();
        if (!empty($userAuth) || $user['id_auth']==1) {
            $data['is_auth']=1;
            if(empty($userAuth)) {
                 $data['real_name'] = $user->mobile;
            }else{
                $data['real_name']= $userAuth->real_name  ;
            }
            
        }
        $data['min_deposit'] = sysConfig('low_withdrawal_amount');
        $data['money'] = money_convert($money['account']);
        $data['banks'] = $banks;
//        $data['admin_bank'] = $adminBank;
        $data['mtips'] = !empty(sysConfig('web_money_tip')) ? arrayEolTip(sysConfig('web_money_tip')) : [];
        return ajaxmsg(lang('success'),1,$data);
        
    }
    /*
     * 提现操作
     */
	/*
     * 操作提现操作
     */
    public function doWithdraw()
    {
        $data['mid']     = $this->userId;
        $data['money']   = input('money', '');
        $data['paywd']   = input('paywd', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $data['bank_id'] = input('bank_id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
//        $data['pay_id'] = input('pay_id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $data['bank_name'] = input('bank_name', '');
        $data['bank_code'] = input('bank_code', '');
        $data['card'] = input('card', '');
        $data['real_name'] = input('real_name', '');
        $result = $this->validate($data, "Withdraw.create");
        if($result !== true) return ajaxmsg($result,0);
        if(round(intval($data['money'])) < sysConfig('low_withdrawal_amount')){
            return ajaxmsg(lang('min_money').sysConfig('low_withdrawal_amount'),0);
        }
        if (empty($data['bank_id'])){
            if (empty($data['bank_code'])) return ajaxmsg(lang('bank_code'),0);
        }
        $money_res=Db::name('money')->where(['mid'=>$this->userId])->find();
        if(empty($money_res['account'])) return ajaxmsg(lang('name_money'),0);
        //print_r($money_res);exit;
        if(isset($money_res['account']) && floatval($money_res['account']) < floatval($data['money'])){
            return ajaxmsg(lang('money_error'),0);
        }
        $withdraw_info=Db::name('money_withdraw')->where(['mid' => $this->userId,'status'=>0])->find();
        if(!empty($withdraw_info)){
            return ajaxmsg(lang('deposit'),0);
        }
        $cash = Db::name('member')->where(["id"=>$this->userId])->find();
        //print_r(strval($cash['paywd']));exit;
        if(!password_verify(strval($data['paywd']), strval($cash['paywd']))) return ajaxmsg(lang('pay_password'),0);
//        $adminBank = AdminBank::where(['id'=>$data['pay_id']])->field('id,bank_name')->find(); //支付通道信息
//        halt($adminBank);
//        $data['pay_id'] = $adminBank['id'];
//        $data['pay_name'] = $adminBank['bank_name'];
        $res = WithdrawModel::saveData($data);
        if(!$res['status']) return ajaxmsg(lang('failed'),0);
        return ajaxmsg(lang('success'),1);
    }
	/*
	 * 提现记录
	 */
	public function withdrawRecord()
	{
	    $page   = input('page', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $offset = input('pageSize',20, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $data   = WithdrawModel::getRecordById($this->userId,$offset);
        
	    return ajaxmsg(lang('success'),1,$data);
	}
}
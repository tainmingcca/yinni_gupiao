<?php
declare (strict_types = 1);

namespace app\apicom\controller;
use app\apicom\model\Member;
use app\apicom\model\Money;
use app\apicom\model\Invite;
use app\apicom\model\JWT;
use app\command\Commission;
use app\command\Check as checkCommand;
use think\facade\Cache;
use think\captcha\Captcha;
use think\facade\Db;
use util\RedisUtil;
use util\SmsCodeRedis;
use sms\SmsUtil;
use think\facade\Session;
use app\apicom\serve\SendSms;

class User extends BaseController
{
    /**
     * 初始化方法
     * @author 路人甲乙
     */
    protected function _initialize()
    {
        parent::__construct();
        // 系统开关
        if (!sysConfig('web_site_status')) {
            return ajaxmsg(lang('web_false'),0);
        }
    }
    /*
    * 用户登录请求
    */
    public function login()
    {
//        halt((new checkCommand()) ->checkBorrow());
        if (!sysConfig("web_site_status")) return ajaxmsg(lang('web_false'),0);
        // 用户参数
        $data['mobile']   = input('mobile', '');
        $data['password'] = input('password', '');
        $data['sms_code'] = input('sms_code', '');
        $data['smsstat']  = input('smsstat', false);
        $data['captcha']  = input('captcha', '');

        // 验证数据
        $result = $data['smsstat'] ? $this->validate($data, 'Member.captcha') : $this->validate($data, 'Member.signin');

        //  if(!app()->make(\util\Captcha::class)->check($data['captcha'])) return ajaxmsg('验证码错误',0);
        // 查询用户
        $user = Member::where(['mobile'=>$data['mobile'],'is_del'=>0])->find();
        // 是否被禁止登录
        if($user) {
            if($user['status'] !== 1) return ajaxmsg(lang('login_status'),0);
            if($data['smsstat']==='1'){
//                //验证短信
                if(sysConfig('web_reg_code') != 1) return ajaxmsg('系统已关闭短信功能',0);
                // $check = SmsCodeRedis::isSmsCodeExist($data['mobile'], $data['sms_code']);
                // if(!$check) return ajaxmsg('验证码不正确',0);
            }else{
                if(!password_verify($data['password'], $user['passwd'])) return ajaxmsg(lang('login_paw'),0);
            }
            $datas = self::doLogin($user);
            if(!$datas) return ajaxmsg(lang('failed"'),0);
            return ajaxmsg(lang('success'),1,$datas);
        }
        return ajaxmsg(lang('mobile'),0);
    }
    public function doLogin($user)
    {
        $ret = Member::where('id',$user['id'])->update(['last_login_time'=>date('Y-m-d H:i:s'),'last_login_ip'=>getClientIp()]);
        if($ret){
            $token = array(
                "uid"    => $user['id'],
                "name"   => $user['name'],
                'doHost' => WS_SERVER_IP,
                'doTime' => time(),
                "mobile" => $user['mobile'],
                "recomed" => $user['recomed'],
                "id_auth" => $user['id_auth'],
            );

            $jwt = JWT::encode($token,LOCAL_TRADING_TOKEN);
            RedisUtil::cacheToken($jwt, $token);
            $datas['token']  = $jwt;
            $datas['mobile'] = $user['mobile'];
            $datas['uid']    = $user['id'];
            return $datas;
        }
        return false;
    }
    /*
    * 退出登录
    */
    public function signout()
    {
        if ($this->token != '') {
            RedisUtil::deleteToken($this->token);
        }
        return ajaxmsg('退出登录成功',1);
    }
    /**
     * 注册获取短信 返回 短信信息token
     * 注册
     */
    public function register()
    {
         
         
        if(sysConfig('is_reg') == 0) return ajaxmsg(lang('reg_false'),0);
        $tid              = input('code', ''); // 邀请码
		// 用户参数
        $data['mobile']   = $mobile = input('mobile', '');
        $data['passwd']   = input('password', '');
        $data['new_passwd']   = input('new_password', '');
        // $data['sms_code'] = input('sms_code', '');
        $data['captcha']  = input('captcha', '');
        // $data['sms_code']  = input('sms_code', '');
        // if(!app()->make(\util\Captcha::class)->check($data['captcha'])) return ajaxmsg('验证码错误',0);
        // if (preg_match('/^0/', $data['mobile']))  return ajaxmsg(lang('mobile_num'),0);
         if(empty($data['captcha']))  return ajaxmsg(lang('sms_code_num'),0);
        
        $sms_code = Cache::get('62'.$data['mobile']);
      
        if(empty($sms_code) || $data['captcha'] != $sms_code ) return ajaxmsg(lang('sms_code'),0);
        
        $ipCount= sysConfig('ip_count');
        $count = Member::where(['create_ip'=> getClientIp()])->count();
        if($count >= $ipCount) return  ajaxmsg(lang('ip_count'),0);
        // if (substr($data['mobile'], 0, 1)!=0) return  ajaxmsg(lang('mobile_on'),0);

        if ($data['passwd'] != $data['new_passwd']) return  ajaxmsg(lang('password'),0);
		if (empty($data['mobile'])) return ajaxmsg(lang('phone'),0);
		$userExist = Member::where('mobile|name', '=', $data['mobile'])->column('mobile', 'id');

        if ($userExist) 
            return ajaxmsg(lang('phone_true'),0);
		if (!in_array(strlen($data['mobile']), [9,10, 11, 12,13]))
		    return ajaxmsg(lang('phone_error'),0);
		if(empty($tid)) return ajaxmsg(lang('invite'),0);

		if(!empty($tid)){
            $tid_data = Member::where('recomed', $tid)->field('mobile,id,status')->find();
            if(empty($tid_data)) return ajaxmsg(lang('pid'),0);
            if($tid_data['mobile']){
                if($tid_data['mobile'] == $data['mobile']) return ajaxmsg(lang('invite_id'),0);
            }
            if ($tid_data['status']!==1) return ajaxmsg(lang('invite_error'),0);
//            if(strlen($tid)==11) {
//                $tid_data = Member::where('mobile', intval($tid))->find()->toArray();
//                if(empty($tid_data)) return ajaxmsg(lang('pid'),0);
//            }elseif(strlen($tid)<11){
////                $tid=substr($tid,2,-3);
//                $tid_data = Member::where('recomed', $tid)->field('mobile,id,status')->find();
//                  if(empty($tid_data)) return ajaxmsg(lang('pid'),0);
//                if($tid_data['mobile']){
//                    if($tid_data['mobile'] == $data['mobile']) return ajaxmsg(lang('invite_id'),0);
//                }
//                if ($tid_data['status']!==1) return ajaxmsg(lang('invite_error'),0);
//            }
            //print_r($tid_data);exit;
            $data['agent_far'] = $tid_data['id'] ?: 0;
        }
        
        // 验证数据
        $result = $this->validate($data, 'Member.create');
        if ($result !== true) return ajaxmsg($result,0);
        //验证短信
//        if(sysConfig('web_reg_code') == 1){
//            $check = SmsCodeRedis::isSmsCodeExist($data['mobile'], $data['sms_code']);
//            if(!$check) return ajaxmsg('验证码不正确',0);
//        }
        $data['user_type']= 1;
        $data['type']= 1;
        $data['id_auth']    = 0;
        try{
            $res = Member::saveData($data);
            //插入邀请码
    		$redata['id']      = $res['data']['id'];
    		$redata['recomed'] = generate_rand_str(5,5);
    		Member::update($redata); 
    		if($tid){
                $data_r['id']  = $res['data']['id'];//被邀请人id
                $data_r['mid'] = $data['agent_far'];//邀请人id
                $Inv_res       = Invite::saveData($data_r);//保存推荐关系数据
            }
            Member::applySave($res['data']['id']);

        }catch (\Exception $e) {
            DB::rollback();
            return ajaxmsg(lang('failed'),$e->getMessage());
        }
		if($res['status'] === 1){
		    // 检测是否满足注册赠送管理费活动
//            if(sysConfig('give_open') == 1) Money::setGiveFee($res['data']['id'], 'give_reg', 0);

            $token = array(
                "uid"    => $res['data']['id'],
                'doHost' => WS_SERVER_IP,
                'doTime' => time(),
                "mobile" => $res['data']['mobile'],
            );
            $jwt = JWT::encode($token,LOCAL_TRADING_TOKEN);
            RedisUtil::cacheToken($jwt, $token);
            $datas['token']  = $jwt;
            $datas['mobile'] = $res['data']['mobile'];
            $datas['uid']    = $res['data']['id'];
            return ajaxmsg($res['message'],1,$datas);
        }else{
            return ajaxmsg($res['message'],0);
        }
    }
    /**
     * 是否已登陆
     * -- 该方法不用做任何处理，BaseController 里面 initialize 方法会自动判断返回
     * -- 调用该方法前必须检测是否已登录，检测会自动进行
     */
    public function checkLogin()
    {
        $ret = Member::where(['id'=> $this->userId,'status'=>1])->find();
        if ($this->token != '' && !$ret) {
            RedisUtil::deleteToken($this->token);
        }
        return $ret ? ajaxmsg('已登录',1) : ajaxmsg('未登录',500);
    }
    
        public function sendsms()
    {
        $mobile = input('mobile');
        if (empty($mobile)) return ajaxmsg(lang('phone'),0);
        if (preg_match('/^0/', $mobile))  return ajaxmsg(lang('mobile_num'),0);
        $mobile = "62".$mobile;
        if(!empty(Cache::get($mobile))) return ajaxmsg(lang('sms_time'),1);
        $rule = (new SendSms())->sendSms($mobile);
        if ($rule === true){
            return ajaxmsg(lang('success'),1);
        }else{
            return ajaxmsg(lang('failed'),0);
        }


    }
    
    // /***
    //  ** 发送短信验证码
    //  ***/
    // public function sendsms()
    // {
    //     if (Session::has('sms_code')) {
    //         $resetFlag = Session::get('sms_code');
    //         if ((time() - $resetFlag['time']) < 60) {
    //             return ajaxmsg('操作太频繁，请一分钟之后再试',0);
    //         }
    //     }
    //     // 验证码类型
    //     $type   = input('type', '');
    //     $mobile = input('mobile');
    //     $type   = in_array($type, [SmsUtil::CAPTCHA_REGISTER, SmsUtil::CAPTCHA_RESET, SmsUtil::CAPTCHA_WITHDRAW,SmsUtil::CAPTCHA_LOGIN]) ? $type : '';
    //     if (SmsUtil::CAPTCHA_REGISTER == $type) {
    //         $user = Member::getMemberInfoByMobile($mobile);
    //         if(!empty($user)) return ajaxmsg('该手机已经注册会员,请更换手机!',0);
    //     }
    //     $result  = $this->validate(['mobile'=>$mobile], 'Member.captcha');
    //     if(!$result) return ajaxmsg($result,0);
    //     $res = SmsUtil::sendCaptcha($mobile, $type);
    //     if(!$res) return ajaxmsg('发送失败',0);
    //     //演示状态用
    //     return ajaxmsg($res,1);
    //     return ajaxmsg('发送成功',1);
    // }
    /**
     * 密码找回验证码发送
     * @return array
     */
    public function sendPassSms()
    {
        $data   = input('post', '');
        $mobile = $data['mobile'];
        $tp     = 'code';
        //验证该手机号是否存在
        $isExists = Member::where('mobile',$mobile)->value('id');
        //如果找回密码所填写的手机号不存在
        if(is_null($isExists)){
            return ajaxmsg('该手机号不存在',0);
        }
        $res = sendsms_mandao($mobile,$content,$tp);
        if($res!==true){
            return ajaxmsg('发送失败',0);
        }else{
            return ajaxmsg('发送成功',1);
        }
    }
    /**
     * 设置新密码
     */
    public function newpass()
    {
        $data   = input();

        if($data['subpwd'] != $data['newpwd']){
            return ajaxmsg(lang('password'),0);
        }
        if($data['oldpwd'] == $data['newpwd']){
            return ajaxmsg(lang('paw_error'),0);
        }
        $user = Db::name('member')->where(["id"=>$this->userId])->find();
        if(!password_verify($data['oldpwd'], $user['passwd'])){
            return ajaxmsg(lang('pay_error'),0);
        }

        $newpwd = password_hash($data['newpwd'], PASSWORD_DEFAULT);
        $res = Db::name('member')->where(["id"=>$this->userId])->update(['passwd'=>$newpwd]);
        if(!$res) return ajaxmsg(lang('failed'),0);
        return ajaxmsg(lang('success'),200);
    }
    /**
     * 忘记登录密码 重置--下一步
     */
    public function next()
    {
        $data       = input('post', '');
        $mobile     = $data['mobile'];
        $sms_code   = $data['sms_code'];
        $check_code = check_sms_code($mobile, $sms_code);
        //验证短信
        if(!$check_code) return ajaxmsg('短信验证码错误或失效',0);
        $_SESSION['sms_code'] = $sms_code;
        $_SESSION['mobile']   = $mobile;

        return ajaxmsg('通过进入下一步',1);
    }
    /*
     * 修改支付密码
     */
    public function paypass()
    {
        $data = input();
        if(!isset($data['oldpwd'])){
            return ajaxmsg(lang('missing'),0);
        } 
        if($data['subpwd'] !== $data['newpwd']){
			return ajaxmsg(lang('password'),0);
        }
        if($data['oldpwd'] === $data['newpwd']){
			return ajaxmsg(lang('paw_error'),0);
        }
        $user = Db::name('member')->where(["id"=>$this->userId])->find();
        if(!password_verify($data['oldpwd'], $user['paywd'])){
            return ajaxmsg(lang('pay_error'),0);
        }
        $newpwd = password_hash($data['newpwd'], PASSWORD_DEFAULT);
        $res = Db::name('member')->where(["id"=>$this->userId])->update(['paywd'=>$newpwd]);
        if(!$res) return ajaxmsg(lang('failed'),0);
        return ajaxmsg(lang('success'),200);
    }
    public function getCaptcha()
    {

        return app()->make(\util\Captcha::class)->create();

    }




}
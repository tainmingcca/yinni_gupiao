<?php
declare (strict_types=1);

namespace app\apicom\controller;

use app\admin\model\SingleSource;
use app\apicom\model\Borrow;
use app\apicom\model\DealStock;
use app\apicom\model\MemberLevel;
use app\apicom\model\Record as RecordModel;
use app\apicom\model\Money;

use app\apicom\model\SingleOrder;
use app\apicom\model\SingleItem;
use app\apicom\model\Member;

use app\apicom\model\Trust;
use think\facade\Db;
use util\RedisUtil;
use app\apicom\model\Investitem;
use app\apicom\model\InvestitemOrder;

class Invest extends BaseController
{


    /*
     * 獲取投資信息
     */
    public function getInvest()
    {
        $list = Db::name('invest_item')->select();//->where(['status' =>1])
        if (!$list) return ajaxmsg(lang('success'), 1, null);

        return ajaxmsg(lang('success'), 1, $list);

    }
    /*
     * 獲取投資信息
     */
    public function getInvestbyid()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $item_id = input('item_id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]); //
        $info = Db::name('invest_item')->where(['id' =>$item_id])->find();
        if (!$info) return ajaxmsg(lang('success'), 1, null);
        $info['is_money'] =  format_amount($info['is_money']);
        $info['min_money'] =  format_amount($info['min_money']);
        $info['max_money'] =  format_amount($info['max_money']);

        //收益周期
        $daylist = Db::name('invest_item_day')->where(['item_id' =>$item_id])->order('id asc')->select();
        $data = [
            'data' => $info,
            'money' => format_amount(Money::getMoney($this->userId)['account']),
            'daylist' => $daylist,
        ];
        return ajaxmsg(lang('success'), 1, $data);

    }
    /**
     * 購買
     */
    public function buyInvest()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);

        $redis = cache()->handler();
        $lockKey = 'lock:investorder:' . $this->userId;
        $lockTtl = 3; // 秒
        $lockToken = uniqid('', true);
        // 加锁（带 token）
        $isLock = $redis->set($lockKey, $lockToken, ['nx', 'ex' => $lockTtl]);
        if (!$isLock) return ajaxmsg(lang('order_error'), 0);//请勿重复提交，请稍后再试

        $user = Member::where(['id' => $this->userId])->field('id,id_auth,level,pei_time,is_pei')->find();

        if (!$user || $user['id_auth'] == 0) return ajaxmsg(lang('id_auth'), 0);

        //項目信息
        $item_id     = input('item_id', 0, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $invest = Db::name('invest_item')->where(['id' =>$item_id])->find();
        if(!$invest){
            return ajaxmsg(lang('Project does not exist'), 0);//項目不存在
        }
        if($invest['status'] == 0){
            return ajaxmsg(lang('Coming soon, stay tuned'), 0);//即将推出，敬请期待
        }
        //項目周期
        $day_id     = input('day_id', 0, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $invest_day = Db::name('invest_item_day')->where(['id' =>$day_id])->find();
        if(!$invest_day){
            return ajaxmsg(lang('Project does not exist'), 0);//項目不存在
        }


        //二星级及以上用户才能購買
        if($user['level'] < $invest['user_level']){
            if($invest['user_level'] ==2){
                return ajaxmsg(lang('Only 2 Star Investors can participate'), 0);//二星级及以上用户才能購買
            }elseif($invest['user_level'] ==6){
                return ajaxmsg(lang('Only 6 Star Investors can participate'), 0);//4星级及以上用户才能購買
            }else{
                return ajaxmsg(lang('Only 2 Star Investors can participate'), 0);//二星级及以上用户才能購買
            }

        }


        //項目 預購 截止時間
        $previous_day = date('Y-m-d', strtotime($invest['start_time'] . ' -1 day'));
        //$previous_day = date('Y-m-d', strtotime($invest['start_time']));
        $previous_day = strtotime($previous_day . ' 23:59:59');
        if(time() > $previous_day){
            return ajaxmsg(lang('The registration period has ended.'), 0);//報名時間已結束
        }

        $money = input('money', '');
        //-----------判斷項目縂額度-----------
        if($money > $invest['is_money']){
            return ajaxmsg(lang('Insufficient project funds.'), 0);//項目額度不足
        }

        //可以提交多筆，縂金額不能大於 項目個人最大投資金額
        //----------------------------限制個人最大投資----------------
        if($invest['max_money'] > 0){

            if($money > $invest['max_money']){
                return ajaxmsg(lang('Investment amount does not meet'), 0);//投資金額不符合
            }

            //已經投資的縂金額
            $where_total_money = [];
            $where_total_money[] = ['status' ,'in', '1,2'];
            $where_total_money[] = ['user_id' ,'=',$this->userId];
            $where_total_money[] = ['invest_id' ,'=',$item_id];
            $user_item_order_total_money = InvestitemOrder::where($where_total_money)->sum('money');

            if($user_item_order_total_money > $invest['max_money']){
                return ajaxmsg(lang('The maximum investment amount has been reached.'), 0);//已經達到了最大投資額度
            }
            //當前還可以投資多少
            $is_sub = bcsub(strval($invest['max_money']), strval($user_item_order_total_money), 2);

            if($money > $is_sub){
                return ajaxmsg(lang('The current available investment amount ').$is_sub, 0);//當前還可以投資金額
            }
        }
        //----------------------------個人賬戶餘額----------------
        $money_info = Db::name('money')->where('mid', $this->userId)->lock(true)->find();
        //判斷購買金額
        if ($money_info['account'] < $money)  return ajaxmsg(lang('money_error'), 0);//可用余额不足
        if ($money <=0 )  return ajaxmsg(lang('Investment amount does not meet'), 0);//投資金額不符合


        //----------------------------是否已經購買過----------------------------
        $item_order = InvestitemOrder::where(['invest_id' =>$item_id,'user_id' =>$this->userId,'invest_day_id' =>$day_id])->find();
        if($item_order){
            //後期追加 需要 10萬的倍數
            if ($money % 100000 === 0) {
            } else {
                return ajaxmsg(lang('Investment amount does not meet'), 0);//投資金額不符合
            }
        }else{
            //首次購買需按項目最低額度
            if($money < $invest['min_money']){
                return ajaxmsg(lang('Investment amount does not meet'), 0);//投資金額不符合
            }
        }

//        if($money < $invest['min_money'] || $money > $invest['max_money']){
//            return ajaxmsg(lang('Investment amount does not meet'), 0);//投資金額不符合
//        }


        Db::startTrans();
        try {
            // 锁余额
            $upMoney = bcsub(strval($money_info['account']), strval($money), 2);
            Db::name('money')->where('mid', $this->userId)->update(['account' => $upMoney]);

            // 生成唯一订单号
            $order_sn = $this->createUniqueOrderSn($this->userId);
            // 写入订单
            $orderData = [
                'user_id'       => $this->userId,
                'invest_id'        => $item_id,
                'mobile'        => $this->mobile,
                'order_sn'      => $order_sn,
                'invest_title'  => $invest['title'],
                'invest_day'    => $invest_day['day'],
                'scale'         => $invest_day['rate'],
                'money'         => $money,
                'invest_day_id'    => $invest_day['id'],
            ];
            InvestitemOrder::create($orderData);

            //余额扣除
            RecordModel::saveData($this->userId, $money, $upMoney, 101, '投資單號：' . $order_sn,$order_sn);

            //扣除項目額度
            if($invest['max_money'] > 0){
                $after = bcsub(strval($invest['is_money']), strval($money), 2);
                if($after<0){
                    $after = 0;
                }
                Db::name('invest_item')->where(['id' =>$item_id])->update(['is_money' => $after]);
            }


            Db::commit();
            return ajaxmsg(lang('success'), 1);

        } catch (\Throwable $e) {
            Db::rollback();
            // 写日志
            // Log::error("用户下单异常：user_id={$this->userId}，error=" . $e->getMessage());
            return ajaxmsg($e->getMessage(), 0);
        } finally {
            // 释放锁（校验 token 防止误删别人锁）
            if ($redis->get($lockKey) === $lockToken) {
                $redis->del($lockKey);
            }
        }
    }


    /*
     * 收益记录
     */
    public function getInvestIncome()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $item_id     = input('item_id', 0, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $day_id     = input('day_id', 0, ['trim', FILTER_SANITIZE_NUMBER_INT]);
//        $list = Db::name('invest_order_log')->where(['user_id'=>$this->userId,'invest_id'=>$item_id])->order('id', 'asc')->select()->toArray();
//        if(!$list) return ajaxmsg(lang('data'),0);
//        foreach ($list as $k => $v){
//            $list[$k]['starting_amount'] = format_amount($v['starting_amount']);
//            $list[$k]['ending_amount'] = format_amount($v['ending_amount']);
//            $list[$k]['total_income'] = format_amount($v['total_income']);
//            $list[$k]['day_income'] = format_amount($v['day_income']);
//        }

        $list = Db::name('invest_order_log')
            ->field('period, user_id, invest_id,rate, 
             SUM(starting_amount) as starting_amount, 
             SUM(ending_amount) as ending_amount, 
             SUM(total_income) as total_income, 
             SUM(day_income) as day_income')
            ->where(['user_id'=>$this->userId,'invest_id'=>$item_id,'invest_day_id'=>$day_id])
            ->group('period')
            ->order('period', 'asc')
            ->select()
            ->toArray();

        if(!$list) return ajaxmsg(lang('data'),0);

        // 格式化金额
        foreach ($list as $k => $v){
            $list[$k]['starting_amount'] = format_amount($v['starting_amount']);
            $list[$k]['ending_amount'] = format_amount($v['ending_amount']);
            $list[$k]['total_income'] = format_amount($v['total_income']);
            $list[$k]['day_income'] = format_amount($v['day_income']);
            $list[$k]['rate'] = $v['rate'];
        }

        return ajaxmsg(lang('success'), 1, $list);
    }


    /*
        *投資记录
        */
    public function getInvestOrderList1111()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $page = input('page', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $limit = input('limit', 10, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $status = input('status', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $invest_id = input('invest_id', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);
        $where = [];
        if (!empty($status)) $where [] = ['status', '=', $status];

        $list = (new InvestitemOrder())->where(['user_id' => $this->userId,'invest_id' => $invest_id])->where($where)->page(intval($page), intval($limit))->select();


//        $list = Db::name('invest_order')
//            ->field('period, user_id, invest_id,rate')
//            ->where(['user_id'=>$this->userId,'invest_id'=>$invest_id])
//            ->group('invest_id')
//            ->page(intval($page), intval($limit))->select();


        if ($list->isEmpty()) return ajaxmsg(lang('success'), 1, ['list' => [], 'count' => 0]);

        foreach ($list as $item) {
            $itemOrder = (new Investitem())->where(['id' => $item['invest_id']])->field('title,scale')->find();
//            $item['can_money'] = bcsub(strval($item['ying_money']),strval($item['withdraw_money']),2) ;
            $item['title'] = $itemOrder['title'];
            $item['scale'] = $itemOrder['scale'];
            $item['user_name'] = Member::where(['id' => $item['user_id']])->value('name');

            if ($item['end_time'] == 0) {
                $item['end_time'] = '--';
            } else {

                $item['end_time'] = date('d/m/Y H:i', $item['end_time']);
            }
            if ($item['auth_time'] == 0) {
                $item['auth_time'] = '--';
            } else {
                $item['auth_time'] = date('d/m/Y H:i', $item['auth_time']);
            }
            $item['money'] = format_amount($item['money']);
            $item['total_income'] = format_amount($item['total_income']);
            $item['balance'] = format_amount($item['balance']);

        }
        $count = (new InvestitemOrder())->where(['user_id' => $this->userId])->where($where)->count();
        $data = [
            'list' => $list,
            'count' => $count,
        ];
        return ajaxmsg(lang('success'), 1, $data);
    }
    /*
    *投資记录
    */
    public function getInvestOrderList()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);

        $invest_id = input('invest_id', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);

        $total_data = [];

        $day_id = input('day_id', 1, ['trim', FILTER_SANITIZE_NUMBER_INT]);

        if($day_id){
            //當前項目信息
            $invest = (new Investitem())->where(['id' => $invest_id])->field('title,scale,start_time,end_time')->find();
            $total_data['title'] = $invest['title'];


            //項目周期
            $invest_day = Db::name('invest_item_day')->where(['id' =>$day_id])->find();
            $total_data['scale'] = $invest_day['rate'];
            $total_data['start_time'] = date('d/m/Y H:i', strtotime($invest['start_time']));//項目開始時間
           // $total_data['end_time'] = date('d/m/Y H:i',strtotime($invest_day['end_time'] . ' 23:59:59'));//項目開始時間
            $start_time = $invest['start_time'];//項目開始時間
            $period_days = $invest_day['day'];
            $end_timestamp = strtotime($start_time . " +" . ($period_days - 1) . " days");
            $total_data['end_time'] =  date('d/m/Y',$end_timestamp). ' 23:59:59';//項目開始時間

            $await_money = (new InvestitemOrder())->where(['user_id' => $this->userId,'invest_id' => $invest_id,'invest_day_id' => $day_id,'status' => 1])->sum('money');
            $total_data['await_money'] = format_amount($await_money);//待審核金額
            $check_money = (new InvestitemOrder())->where(['user_id' => $this->userId,'invest_id' => $invest_id,'invest_day_id' => $day_id,'status' => 2])->sum('money');
            $total_data['check_money'] = format_amount($check_money);//已審核金額

            $total_data['is_show'] =0;
            $is_show = (new InvestitemOrder())->where(['user_id' => $this->userId,'invest_id' => $invest_id,'invest_day_id' => $day_id])->find();
            if($is_show){
                $total_data['is_show'] =1;
            }
            $total_data['day_id'] =$day_id;

        }else{
            //當前項目信息
//            $invest = (new Investitem())->where(['id' => $invest_id])->field('title,scale,start_time,end_time')->find();
//            $total_data['title'] = $invest['title'];
//            $total_data['scale'] = $invest['scale'];
//            $total_data['start_time'] = date('d/m/Y H:i', strtotime($invest['start_time']));//項目開始時間
//            $total_data['end_time'] = date('d/m/Y H:i',strtotime($invest['end_time'] . ' 23:59:59'));//項目開始時間

            $await_money = (new InvestitemOrder())->where(['user_id' => $this->userId,'invest_id' => $invest_id,'status' => 1])->sum('money');
            $total_data['await_money'] = format_amount($await_money);//待審核金額
            $check_money = (new InvestitemOrder())->where(['user_id' => $this->userId,'invest_id' => $invest_id,'status' => 2])->sum('money');
            $total_data['check_money'] = format_amount($check_money);//已審核金額
        }




        return ajaxmsg(lang('success'), 1, $total_data);
    }


    /*
     * 獲取當前投資訂單信息
     */
    public function getInvestOrderInfo111()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $order_id = input('order_id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);

        $info = InvestitemOrder::where(['id' =>$order_id,'user_id' =>$this->userId])->find();
        if (!$info) return ajaxmsg(lang('success'), -1, null);

        if($info['deal_status'] == 2){
            return ajaxmsg(lang('Waktu untuk mendapatkan keuntungan belum berakhir'), -1, null);//收益時間還沒結束
        }
        //獲取投資時間到期最終 獲利（100%本金 + 70%收益利潤）
        $invest = Db::name('invest_item')->where(['id' =>$info['invest_id']])->find();//項目信息
        $income = sprintf("%.0f", $info['total_income']*$invest['scale']/100);
        $total_money = $info['money'] + $income;

        return ajaxmsg(lang('success'), 1, $total_money);

    }
    public function getInvestOrderInfo()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $invest_id = input('invest_id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);//項目ID

        $day_id = input('day_id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);//周期ID

        $list = InvestitemOrder::where(['invest_id' =>$invest_id,'user_id' =>$this->userId,'status' =>2,'invest_day_id' =>$day_id])->select();
        if ($list->isEmpty()) return ajaxmsg(lang('Tidak ada data'), -1, null);//沒有數據
        $total_income = 0;//收益
        $total_money = 0;//本金
        foreach ($list as $k => $v){
            //所有訂單需要收益結束才能操作
            if($v['deal_status'] == 2){
                return ajaxmsg(lang('Waktu untuk mendapatkan keuntungan belum berakhir'), -1, null);//收益時間還沒結束
            }
            $total_income += $v['total_income'];
            $total_money += $v['money'];//本金
        }

        //獲取投資時間到期最終 獲利（100%本金 + 對應周期的收益利潤）
        $invest = Db::name('invest_item_day')->where(['item_id' =>$invest_id,'id' =>$day_id])->find();//項目信息

        $income = sprintf("%.0f", $total_income*$invest['rate']/100);
        $total_money_income = $total_money + $income;

        return ajaxmsg(lang('success'), 1, format_amount($total_money_income));

    }
    /*
     * 投資订单本金+盈利 提现到总资金账户
     */

    public function depositInvest()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $invest_id = input('invest_id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);//項目ID
        $money = input('money', 0);

        $day_id = input('day_id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);//周期ID

        if (empty($invest_id)) return ajaxmsg(lang('missing'), 0);
        $list = InvestitemOrder::where(['invest_id' =>$invest_id,'user_id' =>$this->userId,'status' =>2,'invest_day_id' =>$day_id])->select();
        $total_income = 0;//收益
        $total_money = 0;//本金
        foreach ($list as $k => $v){
            //所有訂單需要收益結束才能操作
            if($v['deal_status'] == 2){
                return ajaxmsg(lang('Waktu untuk mendapatkan keuntungan belum berakhir'), -1, null);//收益時間還沒結束
            }
            $total_income += $v['total_income'];
            $total_money += $v['money'];
        }

        //獲取投資時間到期最終 獲利（100%本金 + 70%收益利潤）
        $invest = Db::name('invest_item_day')->where(['id' =>$invest_id,'id' =>$day_id])->find();//項目信息
        $income = sprintf("%.0f", $total_income*$invest['rate']/100);
        $total_money = $total_money + $income;

       // if ($money > $total_money) return ajaxmsg(lang('money_error'), -1, null);

        $money_info = Db::name('money')->where('mid', $this->userId)->lock(true)->find();

        $upMoney = bcadd(strval($money_info['account']), strval($total_money));   // 余额+提盈金额
        Db::startTrans();
        try {
            Db::name('money')->where('mid', $this->userId)->update(['account' => $upMoney]);
            RecordModel::saveData($this->userId, $total_money, $upMoney, 103, '項目ID：'.$invest_id);
            InvestitemOrder::where(['invest_id' =>$invest_id,'user_id' =>$this->userId,'status' =>2,'invest_day_id' =>$day_id])->update(['status'=>6]);//更新對應項目所有訂單狀態
            Db::commit();
        } catch (\Exception $e) {
            Db::rollback();
            return ajaxmsg(lang('failed'), 0);

        }
        return ajaxmsg(lang('success'), 200);
    }
    /*
     * 投資页面 数据统计
     */
    public function investTotalData()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);

        $data = [];
        $data ['total_income'] = 0;//總收益
        $data ['today_income'] = 0;//今日收益
        $data ['total_invest'] = 0;//縂投資金額

        $total_invest = InvestitemOrder::where(['user_id' => $this->userId,'status' => 2])->sum('money');
        $total_income = InvestitemOrder::where(['user_id' => $this->userId,'status' => 2])->sum('total_income');
        $data ['total_invest'] = format_amount($total_invest);
        $data ['total_income'] = format_amount($total_income);
        $current_time = date('Y-m-d',time());
        $today_income = Db::name('invest_order_log')->where(['user_id' => $this->userId,'period' => $current_time])->sum('day_income');
        $data ['today_income'] = format_amount($today_income);

        return ajaxmsg(lang('success'), 1, $data);

    }
    //根據項目ID 獲取對應收益周期
    public function getInvestdaybyid()
    {
        if (!$this->token || $this->userId == '') return ajaxmsg(lang('login'), 500);
        $invest_id = input('invest_id', '', ['trim', FILTER_SANITIZE_NUMBER_INT]);//項目ID

        $list = InvestitemOrder::where(['invest_id' =>$invest_id,'user_id' =>$this->userId,'status' =>2])->select();
        if ($list->isEmpty()) return ajaxmsg(lang('Tidak ada data'), -1, null);//沒有數據
        $total_income = 0;//收益
        $total_money = 0;//本金
        foreach ($list as $k => $v){
            //所有訂單需要收益結束才能操作
            if($v['deal_status'] == 2){
                return ajaxmsg(lang('Waktu untuk mendapatkan keuntungan belum berakhir'), -1, null);//收益時間還沒結束
            }
            $total_income += $v['total_income'];
            $total_money += $v['money'];
        }

        //獲取投資時間到期最終 獲利（100%本金 + 70%收益利潤）
        $invest = Db::name('invest_item')->where(['id' =>$invest_id])->find();//項目信息
        $income = sprintf("%.0f", $total_income*$invest['scale']/100);
        $total_money_income = $total_money + $income;

        return ajaxmsg(lang('success'), 1, format_amount($total_money_income));

    }

    /**
     * 生成唯一订单号
     *
     * @param int $userId 用户ID
     * @return string
     */
    protected function createUniqueOrderSn($userId)
    {
        $prefix = 'OD'; // 可自定义前缀，比如订单（Order）
        $date = date('YmdHis'); // 当前时间戳，精确到秒
        $rand = mt_rand(1000, 9999); // 4位随机数
        $uid = str_pad(strval($userId % 10000), 4, '0', STR_PAD_LEFT); // 截取用户ID后四位

        // 拼接订单号
        $orderSn = $prefix . $date . $uid . $rand;

        // 检查数据库是否已经存在，避免冲突
//        $exists = Db::name('single_order')->where('order_sn', $orderSn)->value('id');
//        if ($exists) {
//            // 递归调用重新生成
//            return $this->createUniqueOrderSn($userId);
//        }

        return $orderSn;
    }


}
<?php
namespace app\apicom\validate;

use think\Validate;

class Member extends Validate
{
    //定义验证规则
    protected $rule = [
        'mobile|用户名/手机号' => 'require|unique:member',
        'name|姓名'            => 'require',
        'real_name|真实姓名'            => 'require',
//        'id_card' => 'require|number|length:16',

        'card_num'   => 'require|number|length:16',
        'passwd|密码'          => 'require|regex:^[a-zA-Z\d_]{6,16}$',
        'sms_code|手机验证码'  => 'require',
        'captcha|验证码'       => 'require|captcha',
        'mobiles'              => 'require',
    ];

    //定义验证提示
    protected $message = [
        'name.require'     => 'name_require',
        'real_name.require'     => 'name_require_true',
        'id_card.require'  => 'id_card_require',

        'id_card.number'   => 'id_card_unique',
        'id_card.length'    => 'id_card_regex',
        'card_num.length'    => 'id_card_regex',
        'card_num.require'  => 'card_num_require',
        'passwd.regex'     => 'passwd_regex',
        // 'mobile.regex'     => 'mobile_regex',
        'mobile.unique'    => 'mobile_unique',
        'mobile.require'   => 'mobile_require',
        'mobiles.require'  => 'mobiles_require',
        // 'mobiles.regex'    => 'mobiles_regex',

    ];

    //定义验证场景
    protected $scene = [
        //更新
        'update'      => [ 'passwd' => 'length:6,8','mobile'],
        'passwd'      => [ 'passwd'],
        'realname'    => [ 'name','id_card'],
        'urgent'      => [ 'name','mobile','captcha'],
        //登录
        'signin'      => ['mobile' => 'require', 'passwd' => 'require'],
        //注册
        'reg'         => ['mobile' => 'require',  'captcha'],
        // 身份证审核
        'update_card' => ['real_name', 'card_num'],
        //'create' => ['mobile', 'passwd', 'sms_code'],
        'create'      => ['mobile', 'passwd'],

//        'captcha'     => ['mobile'],
        'captcha'     => ['captcha'],
        'editMoblie'  => ['mobiles'],
    ];
}

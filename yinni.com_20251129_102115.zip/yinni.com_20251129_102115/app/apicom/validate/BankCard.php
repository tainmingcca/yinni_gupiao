<?php
namespace app\apicom\validate;

use think\Validate;

class BankCard extends Validate
{

    protected $rule = [
        'real_name'           => 'require',
        //'id'                  => 'require|id',
        //'mid'                 => 'require|mid',
//        'bank'                => 'require',
        'bank_name'           => 'require',
//        'province'            => 'require',
//        'city'                => 'require',
        'branch'              => 'require',
        'card'                => 'require',
        //'confirm_bank_number' => 'require|confirm:bank_number',
    ];

    protected $message = [
        'real_name.require'           => 'real_name_require',
        //'id_card_number.require'      => '请填写身份证号',
        //'id_card_number.idCard'       => '身份证号码不正确',
        //'mid.require'                 => '请填登陆后再操作',
//        'bank.require'                => 'bank_require',
        'bank_name.require'           => 'bank_require',
        'province.require'            => 'province_require',
        'city.require'                => 'city_require',
        'branch.require'              => 'branch_require',
        'card.require'                => 'card_require',
    ];

    /**
     * 完善银行卡信息的验证
     * @return UserBankCard
     */
    public function sceneComplete()
    {
        return $this->only(['id', 'mid', 'bank', 'province', 'city', 'branch', 'card', 'real_name']);
    }
    
}

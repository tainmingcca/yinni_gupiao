<?php
// 引入常量定义
include_once dirname(__DIR__) . DIRECTORY_SEPARATOR . 'define.php';

use think\facade\Db;
use util\RedisUtil;
use util\SystemRedis;
// 应用公共文件

/*
 * 输出JSON
*/
if (!function_exists('ajaxmsg')) {
    function ajaxmsg($msg = "", $type = 1,$data = '',$is_end = true)
    {
        $json['status'] = $type.'';
        if (is_array($msg)) {
            foreach ($msg as $key => $v) {
                $json[$key] = $v;
            }
        } elseif (!empty($msg)) {
            $json['message'] = $msg;
        }
//        if($data) $json['data'] = $data;
        $json['data'] = $data;
        if ($is_end) {
            return json($json);
        } else {
            return json($json);
        }
    }
}

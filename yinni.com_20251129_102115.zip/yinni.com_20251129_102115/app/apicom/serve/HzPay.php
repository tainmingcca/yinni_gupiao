<?php

namespace app\apicom\serve;

use app\apicom\model\Withdraw;

class HzPay
{
    private  $mch_id='5981008'; //正式
    private  $mch_key='ef28c4f09aa420384c0e607d5dc3b75a'; //支付
    private  $create_pay='https://hzpays.com/api/v1/payment/';  //url


    public function pay($param,$code){
        $money = sprintf("%.2f",substr(sprintf("%.3f",  $param['money']), 0, -1));
        $data = [
            'merchantId' =>$this->mch_id,
            'eventType'=>"payin.order.create",

            'reference' =>$param['order_no'],

            'amount' =>$money,
            'currency' =>'IDR',
            'payMethod' =>$code,
            'customerName' =>"zhang san",
            'customerEmail' =>"test@gmail.com",
            'customerPhone' =>"898222436779",
            'notifyUrl' => request()->domain().'/apicom/Callback/notify/code/hzPay',
        ];
        $data['sign'] = $this->sign($data,$this->mch_key);
        writeLog("HzPay/request",$data);
        $res = $this->curl($this->create_pay,$data);
        $rule =json_decode($res,true);

        writeLog("HzPay/response",$rule);

        if ($rule['statusCode']=='success' &&$rule['statusMessage']=='success' ){
            return $rule['payUrl'];
        }else{
            return false;
        }
    }


    public function cashPay($param){

        $data = [
            'merchantId' =>$this->mch_id,
            'reference' =>$param['order_no'],
            'eventType'=>'payout.order.create',
            'amount' =>$param['money'],

            'currency' =>'IDR',
            'bankCode' =>$param['bank_code'],
            'name' =>$param['real_name'],
            'accountNumber' =>$param['card'],
            'notifyUrl' =>sysConfig('app_url').'/apicom/Callback/cashNotify/code/hzPay',




        ];
        $data['sign'] = $this->sign($data,$this->mch_key);
        writeLog("HzPay/cash",$data);
        $res = $this->curl($this->create_pay,$data);
        $rule =json_decode($res,true);
        writeLog("HzPay/cash_response",$rule);
        if ($rule['statusCode'] ==='success'){
            (new Withdraw())->where(['id'=>$param['id']])->save(['channel_id'=>$rule['transactionId']]);
            return true;
        }else {
            return  $rule['statusMessage'];
        }

    }

    public function returnUrl($param){
        return redirect(request()->domain().'#/pages/user/user');
    }
    public function notify($param){
        return true;
    }
    public function getUpdateOrderData($param){
        $updateData = [
            'status'=>'success',
            'amount'=>$param['realAmount'],
            'out_trade_no'=>$param['transactionId'],
            'order_no'=>$param['reference'],
        ];
        if ($param['state']!='success') $updateData['status']='fail';
        return $updateData;
    }
    public function getWithdrawOrderData($param)
    {
        $updateData = [
            'status'=>'success',
            'amount'=>$param['realAmount'],
            'out_trade_no'=>$param['transactionId'],
            'order_no'=>$param['reference'],
        ];
        if ($param['state']!='success') $updateData['status']='fail';
        return $updateData;

    }


    public function sign($data, $key_secret){


        ksort($data);  //字典排序
        reset($data);

        $queryParts = [];
        foreach ($data as $key => $val) {
            if( strlen($key)  && strlen($val) ){
                $queryParts[] = $key . '=' . $val;
            }
        }

        $md5str= implode('&', $queryParts);
// 3. 拼接密钥，生成签名源串 stringB
        $stringB = $md5str . $key_secret;

        $sign = md5($stringB);  //签名
        return $sign;
//        return strtoupper($sign);
    }

    /**
     * @param $url
     * @param $data
     * @return bool|string
     * curl post请求
     */
    public function curl($url,$postdata=[],$post='POST') {
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL, $url);
        if ( $post== 'POST') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postdata));
        }
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch,CURLOPT_HEADER,false);
        curl_setopt($ch, CURLOPT_TIMEOUT,10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt ($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
        ]);
        $output = curl_exec($ch);
        curl_getinfo($ch);
        curl_close($ch);
        return $output;
    }
    public function http_post_res($url, $data)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 4);
        curl_setopt($ch, CURLOPT_ENCODING, "");
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 5.1; zh-CN) AppleWebKit/535.12 (KHTML, like Gecko) Chrome/22.0.1229.79 Safari/535.12");
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);

        $output = curl_exec($ch);
        curl_close($ch);

        return $output;
    }


}
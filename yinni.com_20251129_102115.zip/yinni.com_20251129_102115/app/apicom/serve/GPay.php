<?php

namespace app\apicom\serve;

class GPay
{
    private  $mch_id='1be92d65f982414498d7c1a7bea242d6'; //正式
    private  $mch_key='kKlC0D04yU1dRwyBQDie6X2EoCpgrDjbJQsRmv'; //支付
    private  $create_pay='https://www.g-pays.net/open-api/create-pay-order';  //url
    private  $cash_pay='https://www.g-pays.net/open-api/create-payout-order';  //url

    public function pay($param,$code){

        $money = sprintf("%.2f",substr(sprintf("%.3f",  $param['money']), 0, -1));
        $data = [
            'app_id' =>$this->mch_id,
            'pay_channel' =>$code,
            'amount' =>$money,
            'merchant_order_id' =>$param['order_no'],
            'notify_url' => request()->domain().'/apicom/Callback/notify/code/gPay',
            'page_return_url' => request()->domain().'/#/pages/user/user',
        ];
        $data['sign'] = $this->sign($data,$this->mch_key);
        writeLog("gPay/request",$data);
        $res = $this->curl($this->create_pay,$data);
        $rule =json_decode($res,true);
       
        writeLog("gPay/response",$rule);

        if ($rule['code']=='200'){
            return $rule['data']['pay_url'];
        }else{
            return false;
        }
    }

    public function cashPay($param){
        if($param['code'] == 'INDONESIA_PAYOUT'){
            $param['code'] = 'INDONESIA_BANK';
        }
        $data = [
            'app_id' =>$this->mch_id,
            'payout_mode' =>$param['code'],
            'amount' =>$param['money'],
            'merchant_order_id' =>$param['order_no'],
            'customer_account_no' =>$param['card'],
            'customer_account_type' =>$param['bank_code'], /// 银行编码
            'notify_url' => 'https://www.fundiqsbc.com/apicom/Callback/cashNotify/code/gPay',
        ];
        if($data['payout_mode']=='INDONESIA_EWALLET_DANA') unset($data['customer_account_type']);
        $data['sign'] = $this->sign($data,$this->mch_key);
        writeLog("gPay/cash",$data);
        $res = $this->curl($this->cash_pay,$data);
        $rule =json_decode($res,true);
        writeLog("gPay/cash_response",$rule);
        // halt($rule);
        if ($rule['code'] =='200'){
            return true;
        }else{
            return $rule['message'];
        }

    }

    public function returnUrl($param){
        return redirect(request()->domain().'#/pages/user/user');
    }
    public function notify($param){
        return true;
    }
    public function getUpdateOrderData($param){
        $updateData = [
            'status'=>'success',
            'amount'=>$param['amount'],
            'out_trade_no'=>$param['system_order_id'],
            'order_no'=>$param['merchant_order_id'],
            
        ];
        if ($param['order_status']!='PAY_SUCCESS') $updateData['status']='fail';
        return $updateData;
    }
    public function getWithdrawOrderData($param)
    {
        $updateData = [
            'status'=>'success',
            'amount'=>$param['amount'],
            'out_trade_no'=>$param['system_order_id'],
            'order_no'=>$param['merchant_order_id'],
        ];
        if ($param['order_status']!='PAY_SUCCESS') $updateData['status']='fail';
        return $updateData;

    }
    public function sign($data, $key_secret){


        ksort($data);  //字典排序
        reset($data);

        $md5str = "";
        foreach ($data as $key => $val) {
            if( strlen($key)  && strlen($val) ){
                $md5str = $md5str . $key . "=" . $val . "&";
            }
        }
        $md5str= $md5str . "key=" . $key_secret;
        //halt($md5str);
        $sign = md5($md5str);  //签名
        return $sign;
//        return strtoupper($sign);
    }
     /**
     * @param $url
     * @param $data
     * @return bool|string
     * curl post请求
     */
    public function curl($url,$postdata=[],$post='POST') {
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL, $url);
        if ( $post== 'POST') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postdata));
        }
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch,CURLOPT_HEADER,false);
        curl_setopt($ch, CURLOPT_TIMEOUT,10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt ($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
        ]);
        $output = curl_exec($ch);
        curl_getinfo($ch);
        curl_close($ch);
        return $output;
    }


}
<?php
namespace  app\apicom\serve;
class Xiongmao



{
    public  $pay_url = "";
    public  $userCode = "";
    public  $key = "";



    public function pay($data,$code)
    {
        $data = [
            'callbackUrl'=>request()->domain().'/apicom/Callback/notify/code/xiongmao', //回调地址
            'channelCode'=>$code, //支付渠道
            'orderId'=>$data['order_no'], //订单号
            'orderMoney'=>$data['money'],//订单金额
            'userCode'=>$this->userCode,//商户号
            'returnUrl'=>request()->domain().'/apicom/Callback/returnUrl/code/xiongmao',
        ];

        $data['sign'] = $this->sign($data,$this->key);
        writeLog("xiongmao/request",$data);
        $res = $this->http_post_res($this->pay_url,$data);
        $rule =json_decode($res,true);
        writeLog("xiongmao/response",$rule);
        
        if($rule['code']=='200'){
            return $rule['result'];
        }else{
            return false;
        }
    }
    public function returnUrl($param){
        return redirect(request()->domain().'#/pages/user/user');
    }
    public function notify($param){
        return true;
    }
    public function getUpdateOrderData($param){
        $updateData = [
            'status'=>'success',
            'amount'=>$param['orderMoney'],
            'out_trade_no'=>'',
            'order_no'=>$param['orderId'],
        ];
        if ($param['orderStatus']!=2) $updateData['status']='fail';
        return $updateData;
    }

    public function sign($data,$key_serve)
    {
        ksort($data);  //字典排序
        reset($data);
        $md5str = "";
        foreach ($data as $key => $val) {
            if( strlen($key)  && strlen($val) ){
                $md5str = $md5str . $key . "=" . $val . "&";
            }
        }
        $md5str= $md5str . "key=" . $key_serve;

        $sign = md5($md5str);  //签名
        return $sign;
    }

    public function http_post_res($url, $data)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 4);
        curl_setopt($ch, CURLOPT_ENCODING, "");
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 5.1; zh-CN) AppleWebKit/535.12 (KHTML, like Gecko) Chrome/22.0.1229.79 Safari/535.12");
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);

        $output = curl_exec($ch);
        curl_close($ch);

        return $output;
    }

}
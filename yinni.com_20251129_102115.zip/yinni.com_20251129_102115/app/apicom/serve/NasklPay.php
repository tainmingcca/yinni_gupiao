<?php

namespace app\apicom\serve;

class NasklPay
{
    private  $mch_id='809100002753282'; //正式
    private  $mch_key='4F6B83C83060F093F317FBE44BD7FFBAAB9ED4701065C1833D0704DD9DC7217B'; //支付
    private $mch_public_key = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCvsAOwtc/lmqk8coaczBQpq0HWGUe6JcaNEK6RlPnMYzu2+PjL1ISX+yGOj8ZRhPeEFAYNVfKynLBoxb527SHg9WGhsoylqtmcreQcjhXfE2fXHKMLIyGGLP+hPO44pM5wen+M4E1UKsEnU2nv0q3WL1ITe/7eQJJ24ZfZz3mx5wIDAQAB';  //商户公钥替换自己的
    private $mch_private_key = 'MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAK+wA7C1z+WaqTxyhpzMFCmrQdYZR7olxo0QrpGU+cxjO7b4+MvUhJf7IY6PxlGE94QUBg1V8rKcsGjFvnbtIeD1YaGyjKWq2Zyt5ByOFd8TZ9ccowsjIYYs/6E87jikznB6f4zgTVQqwSdTae/SrdYvUhN7/t5Aknbhl9nPebHnAgMBAAECgYEAjD+Jop5xGQyO/xc5yJ/NlLoG83/412vihagEg2kWxIePGvDDxAuh0aWDU0gI+/iWkpRdhHXRKa6V0P3SnyOL/7GOz8LfVdEhElQd8M13GSuwT6BKPd1pC6E7wCj28d8eLyahEErrxCU5jIgD1VZVTjRznsz2m/lxDAQTDdCPGIkCQQDtGEZHbFxyzpKb3NyDFxpwvfxx1OU6xBvHGcE6YBRovGVRrzOzVBhi6e86IQo71msaog73jnSn4f1K+gsUwGrbAkEAvbJByMcKI0bXpQPnUQ1i0ghcXVsIn5BJHiG48FUQB7ZkSnQxt3PBVQHp9eyjSPAWYAAZax6UAEY+xpvrVlMU5QJADuIhN0aUHxjclzAsH4aJwF4MxNCKez/oRn1VZea2IUUCTzhiVHWI+lyZCdsdG1iAbLGTovKsXAWRsu0zWOAjVQJBAJwjOECBjBejPOZHQ0OUqA1G8neo8X0c7wINMcMn0Mz4VK5v22grsCs/KwrP30quy0vzaPihr6JWL1+cgOWJ9v0CQGwo8LxTMFUbV8JkNVvREFgzgjGnJ7YrXX/AqnpL/SYm0/45/Nmsyx/z7BPvKma34rF9VcZNi8/H3rV6vUGk83k=';  //商户私钥替换自己的
    private  $create_pay='https://naskl.gctpk.com/payin/createOrder';  //url
    private  $cash_pay='https://taslk.gctpk.com/payout/singleOrder';  //url
    public function pay($param,$code){

        $money = sprintf("%.2f",substr(sprintf("%.3f",  $param['money']), 0, -1));
        $data = [
            'merNo' =>$this->mch_id,
            'merOrderNo' =>$param['order_no'],
            'name' =>"zhang san",
            'email' =>"test@mail.com",
            'currency' =>"IDR",
            'phone' =>$param['mobile'],
            'orderAmount' =>$money,
            'timestamp' =>msectime(),

            'busiCode' =>$code, // 支付编码


            'notifyUrl' => request()->domain().'/apicom/Callback/notify/code/nasklPay',
        ];
        $data['sign'] = $this->makeSign($data);
        //  halt($data);
        writeLog("nasklPay/request",$data);
        $res = $this->curl($this->create_pay,$data);
        $rule =json_decode($res,true);
       
        writeLog("nasklPay/response",$rule);

        if ($rule['code']=='200'){
            return $rule['data']['orderData'];
        }else{
            return false;
        }
    }
    public function cashPay($param){
        $data = [
            'bankCode' =>$param['bank_code'], /// 银行编码
            'accName' =>$param['real_name'],
            'accNo' =>$param['card'],
            'busiCode' =>'202001', //代付编码
            'currency' =>"IDR",
            'email' =>"test@mail.com",
            'merNo' =>$this->mch_id,
            'orderAmount' =>$param['money'],
            'merOrderNo' =>$param['order_no'],
            'phone' =>$param['mobile'],
            'timestamp' =>msectime(),
            'notifyUrl' => 'https://www.fundiqsbc.com/apicom/Callback/cashNotify/code/nasklPay',
        ];
        if($data['bankCode']=="IMPS") $data['province']='test';

        $data['sign'] = $this->encrypt($data);
      
        writeLog("nasklPay/cash",$data);
        $res = $this->curl($this->cash_pay,$data);
        $rule =json_decode($res,true);
        writeLog("nasklPay/cash_response",$rule);
        
        if ($rule['code'] =='200' || $rule['code'] =='500'){
            if($rule['data']['status']== 0  || $rule['data']['status']== 9 ) {
                return true;
            }else{
               $rule['msg'] = '下单失败'; 
                return $rule['msg'];
            }
            
        }else{
            return $rule['msg'];
        }

    }

    public function returnUrl($param){
        return redirect(request()->domain().'#/pages/user/user');
    }
    public function notify($param){
        return true;
    }
    public function getUpdateOrderData($param){
        $updateData = [
            'status'=>'success',
            'amount'=>$param['payAmount'],
            'out_trade_no'=>$param['orderNo'],
            'order_no'=>$param['merOrderNo'],
            
        ];
        if ($param['status']!=5) $updateData['status']='fail';
        return $updateData;
    }
    public function getWithdrawOrderData($param)
    {
        $updateData = [
            'status'=>'success',
            'amount'=>$param['orderAmount'],
            'out_trade_no'=>$param['orderNo'],
            'order_no'=>$param['merOrderNo'],
        ];
        if ($param['status']!=7) $updateData['status']='fail';
        return $updateData;

    }

















    public function encrypt($data)
    {


        //进行HamcSHA256加密
        $signA = $this->makeSign($data);
       

        //再进行rsa加密
        $encrypted = '';
        $pem = chunk_split($this->mch_private_key, 64, "\n");
       
        $pem = "-----BEGIN PRIVATE KEY-----\n" . $pem . "-----END PRIVATE KEY-----\n";
        $private_key = openssl_pkey_get_private($pem);
        openssl_private_encrypt($signA, $encryptData, $private_key);


        //base64编码
        $signB = base64_encode($encryptData);
        return $signB;

    }

    public function makeSign($data)
    {

        ksort($data);
        $str = '';
        foreach ($data as $k => $v){
            if(!empty($v)){
                $str .=(string) $k.'='.$v.'&';
            }
        }
        $str = rtrim($str,'&');
        
        //HamcSHA256加密
        $sign = hash_hmac("sha256", $str, $this->mch_key);

        return $sign;

    }
     /**
     * @param $url
     * @param $data
     * @return bool|string
     * curl post请求
     */
    public function curl($url,$postdata=[],$post='POST') {
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL, $url);
        if ( $post== 'POST') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postdata));
        }
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch,CURLOPT_HEADER,false);
        curl_setopt($ch, CURLOPT_TIMEOUT,10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt ($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
        ]);
        $output = curl_exec($ch);
        curl_getinfo($ch);
        curl_close($ch);
        return $output;
    }

}
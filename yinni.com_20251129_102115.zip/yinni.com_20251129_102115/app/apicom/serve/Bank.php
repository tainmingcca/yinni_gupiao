<?php

namespace app\apicom\serve;

class Bank
{
    public function pay()
    {
        return true;
    }
}
<?php

namespace app\apicom\serve;

use think\facade\Cache;

class SendSms
{
    private $url = "http://sms.ctg10000.com:9511/api/send-sms-single";
    private $sp_id= "255368";

    public function sendSms($mobile)
    {
        $code = rand(0000, 9999);
        $data = [
            'sp_id' => $this->sp_id,
            'mobile' => $mobile,
            'content' => "[FundIQSG] your verify code is {$code}",
            'password' => "fbf730179da7e71b183caee48379611e",
        ];
        writeLog("sms/send",$data);
        $res = $this->http_post_res($this->url,$data);
        $rule =json_decode($res,true);
        
        $rule['mobile']=$mobile;
         writeLog("sms/rule",$rule);
        if ($rule['code']==0){
            Cache::set($mobile,$code,180);
            return true;
        }else{
            return false;
        }
    }
        /**
         * @param $url
         * @param $data
         * @return bool|string
         * curl post请求
         */
        public function http_post_res($url, $data)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 4);
        curl_setopt($ch, CURLOPT_ENCODING, "");
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 5.1; zh-CN) AppleWebKit/535.12 (KHTML, like Gecko) Chrome/22.0.1229.79 Safari/535.12");
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);

        $output = curl_exec($ch);
        curl_close($ch);

        return $output;

    }

}
<?php

namespace app\apicom\serve;

class Googlepay
{
    public  $pay_url = "";
    public  $userCode = "";
    public  $md5_key = "";


    public function pay($data,$code='')
    {
        $data = [
            'merchantId'=>$this->userCode,//商户号
            'accessId'=>'1', //通道id(平台分配的通道号)
            'amount'=>$data['money'],//订单金额
            'orderNo'=>$data['order_no'], //订单号
            "timestamp"=> round(microtime(true) * 1000), //当前时间戳(毫秒)
            "nonceStr"=>"T".rand(000000,999999), //随机字符串(随机生成)
            'notifyUrl'=>request()->domain().'/apicom/Callback/notify/code/googlepay', //回调地址
        ];
        $data ["extraData"]= json_encode(['orderNo'=>$data['orderNo']]);
        $data['sign'] = $this->sign($data,$this->md5_key);
        writeLog("googlepay/request",$data);
        $res = $this->curl($this->pay_url,$data);
        $rule =json_decode($res,true);
        writeLog("googlepay/response",$rule);
        
        if($rule['code']=='200'){
            return $rule['data']['url'];
        }else{
            return false;
        }
    }
    public function returnUrl($param){
        return redirect(request()->domain().'#/pages/user/user');
    }
    public function notify($param){
        return true;
    }
    public function getUpdateOrderData($param){
        $updateData = [
            'status'=>'success',
            'amount'=>$param['amount'],
            'out_trade_no'=>$param['orderId'],
            'order_no'=>$param['orderNo'],
        ];
        if ($param['status']!='S') $updateData['status']='fail';
        return $updateData;
    }

    public function sign($data,$md5_key)
    {
        ksort($data);  //字典排序
        reset($data);
        $md5str = "";
        foreach ($data as $key => $val) {
            if( strlen($key)  && strlen($val) ){
                $md5str = $md5str . $key . "=" . $val . "&";
            }
        }
        $md5str= $md5str . "key=" . $md5_key;

        $sign = strtoupper(md5($md5str));  //签名
        return $sign;
    }


    /**
     * @param $url
     * @param $data
     * @return bool|string
     * curl post请求
     */
    public function curl($url,$postdata=[],$post='POST') {
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL, $url);
        if ( $post== 'POST') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postdata));
        }
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch,CURLOPT_HEADER,false);
        curl_setopt($ch, CURLOPT_TIMEOUT,10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt ($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
        ]);
        $output = curl_exec($ch);
        curl_getinfo($ch);
        curl_close($ch);
        return $output;
    }


}
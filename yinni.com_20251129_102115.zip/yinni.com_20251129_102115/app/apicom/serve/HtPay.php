<?php

namespace app\apicom\serve;

class HtPay
{
    private  $mch_id='m8259094445'; //正式
    private  $mch_key='4bd6162888310f9c903619d472cf324e'; //支付
    private  $create_pay='https://htapi.htsf.xyz/addons/api/collect/create';  //url
    private  $cash_pay='https://htapi.htsf.xyz/addons/api/pay/create';  //url
    public function pay($param,$code){
        $money = sprintf("%.2f",substr(sprintf("%.3f",  $param['money']), 0, -1));
        $data = [
            'mchId' =>$this->mch_id,
            'passageId' =>$code,
            'orderAmount' =>$money,
            'orderNo' =>$param['order_no'],
            'notifyUrl' => request()->domain().'/apicom/Callback/notify/code/htPay',
        ];
        $data['sign'] = $this->sign($data,$this->mch_key);
        writeLog("HtPay/request",$data);
        $res = $this->http_post_res($this->create_pay,$data);
        $rule =json_decode($res,true);
        writeLog("HtPay/response",$rule);
        if ($rule['code']=='0'){
            return $rule['data']['pay_url'];
        }else{
            return false;
        }
    }

    public function cashPay($param){

        $data = [
            'mchId' =>$this->mch_id,
            'passageId' =>$param['code'],
            'orderAmount' =>round( $param['money'], 0, PHP_ROUND_HALF_UP), // 3 ,
            'orderNo' =>$param['order_no'],
            'account' =>$param['card'],
            'userName' =>$param['real_name'],
            'remark' =>$param['bank_code'],
            'number' =>$param['bank'], /// 银行编码
            'notifyUrl' =>'https://www.fundiqsbc.com/apicom/Callback/cashNotify/code/htPay',//sysConfig('app_url').
        ];
        // halt($data);
        $data['sign'] = $this->sign($data,$this->mch_key);
        writeLog("HtPay/cash",$data);
        $res = $this->http_post_res($this->cash_pay,$data);
        $rule =json_decode($res,true);
        writeLog("HtPay/cash_response",$rule);

        if ($rule['code'] ==0){
            return true;
        }else{
            return $rule['msg'];
        }

    }

    public function returnUrl($param){
        return redirect(request()->domain().'#/pages/user/user');
    }
    public function notify($param){
        return true;
    }
    public function getUpdateOrderData($param){
        $updateData = [
            'status'=>'success',
            'amount'=>$param['realprice'],
            'out_trade_no'=>'',
            'order_no'=>$param['out_order_id'],
        ];
        if ($param['status']!='paid') $updateData['status']='fail';
        return $updateData;
    }
    public function getWithdrawOrderData($param)
    {
        $updateData = [
            'status'=>'success',
            'amount'=>$param['price'],
            'out_trade_no'=>'',
            'order_no'=>$param['tran_no'],
        ];
        if ($param['status']!=2) $updateData['status']='fail';
        return $updateData;

    }


    public function sign($data, $key_secret){


        ksort($data);  //字典排序
        reset($data);

        $md5str = "";
        foreach ($data as $key => $val) {
            if( strlen($key)  && strlen($val) ){
                $md5str = $md5str . $key . "=" . $val . "&";
            }
        }
        $md5str= $md5str . "key=" . $key_secret;
        //halt($md5str);
        $sign = md5($md5str);  //签名
        return $sign;
//        return strtoupper($sign);
    }
    /**
     * @param $url
     * @param $data
     * @return bool|string
     * curl post请求
     */
    public function http_post_res($url, $data)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 4);
        curl_setopt($ch, CURLOPT_ENCODING, "");
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 5.1; zh-CN) AppleWebKit/535.12 (KHTML, like Gecko) Chrome/22.0.1229.79 Safari/535.12");
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);

        $output = curl_exec($ch);
        curl_close($ch);

        return $output;
    }

}
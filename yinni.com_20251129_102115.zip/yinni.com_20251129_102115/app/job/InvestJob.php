<?php
namespace app\job;


use app\service\SellService;
use think\facade\Db;
use think\queue\Job;

class InvestJob
{
     public function fire(Job $job, $data)
     {


         try {
             $income_date          = $data['income_date'];
             $income_id          = $data['income_id'];
             $income_rate          = $data['income_rate'];
             $order_money          = $data['order_money'];
             $order_user_id          = $data['order_user_id'];
             $order_invest_id          = $data['order_invest_id'];
             $order_id         = $data['order_id'];
             $order_invest_day_id          = $data['order_invest_day_id'];
             $order_end_time          = $data['order_end_time'];

             $this->hand_income($income_date,$income_id, $income_rate,$order_money,$order_user_id,$order_invest_id,$order_id,$order_invest_day_id,$order_end_time);

             writeLog('InvestJob_success', "任务执行成功".$order_id);
             // 删除任务
             $job->delete();
         } catch (\Exception $e) {
             // 失败重试，超过3次放弃
             if ($job->attempts() > 3) {
                 writeLog('InvestJob_error', "任务执行失败超过3次: ".$e->getMessage());
                 $job->delete();
             } else {
                 $job->release(10); // 延迟10秒后再执行
             }
         }
     }
    /**
     * 处理单个
     */
    protected function hand_income($income_date,$income_id, $income_rate,$order_money,$order_user_id,$order_invest_id,$order_id,$order_invest_day_id,$order_end_time){
        //投資周期(每日收益的日期時間)
        $period = $income_date;
        //初期資金
        $starting_amount = $order_money;
        //當日收益
        $day_income = sprintf("%.0f", $order_money*$income_rate/100);
        //纍計收益
        $total_income = $day_income;
        //賬戶餘額
        $ending_amount = $order_money + $day_income;
        //收益率
        $rate = $income_rate;

        //判斷是否有記錄
        $log = Db::name('invest_order_log')->where(['user_id'=>$order_user_id,'invest_id'=>$order_invest_id,'order_id'=>$order_id,'invest_day_id'=>$order_invest_day_id])->order('id', 'desc')->find();
        if($log){
            //初期資金 = 前一天的初期資金
            $starting_amount = $log['ending_amount'];
            //當日收益
            $day_income = sprintf("%.0f", $starting_amount*$income_rate/100);
            //纍計收益 =  前一天的纍計收益 + 當日收益
            $total_income = $log['total_income'] + $day_income;
            //賬戶餘額 = 前一天的初期資金 + 當日收益
            $ending_amount = $starting_amount + $day_income;
        }

        //st_invest_order_log
        $logdata = [
            'user_id'       => $order_user_id,
            'invest_id'        => $order_invest_id,
            'order_id'        => $order_id,
            'period'      => $period,
            'starting_amount'  => $starting_amount,
            'ending_amount'    => $ending_amount,
            'total_income'         => $total_income,
            'rate'         => $income_rate,
            'day_income'         => $day_income,
            'invest_day_id'         => $order_invest_day_id,
        ];
        $res = Db::name('invest_order_log')->insert($logdata);
        if($res){

            $order_end_time = date('Y-m-d',$order_end_time);//項目對應訂單的結束時間
            //判斷收益時間 是否  等於 項目對應訂單的結束時間
            if($income_date == $order_end_time){
                //更新訂單記錄(纍計收益，賬戶餘額)
                Db::name('invest_order')->where(['id'=>$order_id])->update(['total_income'=>$total_income,'balance'=>$ending_amount]);
                //更新收益率標識
                Db::name('invest_item_income')->where(['id'=>$income_id])->update(['status'=>2]);
                //订单收益状态  1 待收益  2收益中3收益完成
                Db::name('invest_order')->where(['id'=>$order_id])->update(['deal_status'=>3]);
            }else{
                //更新訂單記錄(纍計收益，賬戶餘額)
                Db::name('invest_order')->where(['id'=>$order_id])->update(['total_income'=>$total_income,'balance'=>$ending_amount]);
                //更新收益率標識
                Db::name('invest_item_income')->where(['id'=>$income_id])->update(['status'=>2]);
            }

//            //更新訂單記錄(纍計收益，賬戶餘額)
//            Db::name('invest_order')->where(['id'=>$order_id])->update(['total_income'=>$total_income,'balance'=>$ending_amount]);
//            //更新收益率標識
//            Db::name('invest_item_income')->where(['id'=>$income_id])->update(['status'=>2]);
//
//            //判斷收益時間是否 到期了  收益結束了
//            //當前時間
//            $current_time = date('Y-m-d',time());
//            $end_time = date('Y-m-d',$order_end_time);
//            if($current_time == $end_time){
//                Db::name('invest_order')->where(['id'=>$order_id])->update(['deal_status'=>3]);
//            }



        }
    }



}
<?php

namespace app\job;

use app\service\SellService;
use think\queue\Job;

class createTrustJob
{
    public function fire(Job $job, $data)
    {
        $service = new SellService() ;
        try {
            // 调用原逻辑
            $service->createSingleOrder(
                $data['single_id'],
                $data['volume'],
                $data['buy_price'],
                $data['direction'],
                $data['code'],
                $data['source_id'],
                $data['buy_time']
            );
            writeLog('queue_create_order', "任务执行成功".$data['single_id']);
            // 删除任务
            $job->delete();
        } catch (\Exception $e) {
            // 失败重试，超过3次放弃
            if ($job->attempts() > 3) {
                writeLog('create_single_order_error', sprintf(
                    "single_id=%s err=%s payload=%s",
                    $data['single_id'],
                    $e->getMessage(),
                    json_encode($data, JSON_UNESCAPED_UNICODE)
                ));
                $job->delete();
            } else {
                $job->release(10); // 延迟10秒后再执行
            }
        }
    }

}
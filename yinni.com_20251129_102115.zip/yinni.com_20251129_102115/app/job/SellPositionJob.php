<?php
namespace app\job;


use app\service\SellService;
use think\queue\Job;

class SellPositionJob
{
     public function fire(Job $job, $data)
     {
         $service = new SellService() ;
         try {
             $pos_id          = $data['pos_id'];
             $sell_price      = $data['sell_price'];
             $sell_time       = $data['sell_time'];
             $sell_price_scope= $data['sell_price_scope'];
             $single_type     = $data['single_type'];
             $sell_volume     = $data['sell_volume'];

             // 调用原逻辑

             $service->processSellPositionItem(
                 $pos_id, $sell_price, $sell_time, $sell_price_scope, $single_type, $sell_volume
             );
             writeLog('queue_sell_position_id', "任务执行成功".$data['pos_id']);
             // 删除任务
             $job->delete();
         } catch (\Exception $e) {
             // 失败重试，超过3次放弃
             if ($job->attempts() > 3) {
                 writeLog('queue_sell_position', "任务执行失败超过3次: ".$e->getMessage());
                 $job->delete();
             } else {
                 $job->release(10); // 延迟10秒后再执行
             }
         }
     }

}
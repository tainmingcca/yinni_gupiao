<?php

namespace app\service;

use app\apicom\model\Money;
use app\apicom\model\SingleItem;
use app\apicom\model\StockPosition;
use app\apicom\model\Member as MemberModel;
use app\apicom\model\Record as RecordModel;
use think\facade\Db;
use app\apicom\model\SingleOrder;
use app\apicom\model\SingleSourceUser;
use app\apicom\model\StockDealStock;
use app\apicom\model\StockDeliveryOrder as Delivery;

class SellService
{
    /**
     * 队列 Worker 调用：根据信号源发布信息，生成委托单（分批）
     * 这是耗时函数，不在 web 请求里直接调用（由 Worker 调用）
     */
    public function createSingleOrder($single_id, $volume, $buy_price, $direction, $code, $source_id, $buy_time)
    {
        // 查询满足条件的跟单订单（未处理的 status=2）
        $singleOrder = (new SingleOrder())
            ->where(['single_id' => $single_id, 'status' => 2])
            // ->whereIn('id','62860')
            ->select();
        if ($singleOrder->isEmpty()) return true;

       
        $singleItem = (new SingleItem())->where(['id' => $single_id])->field('id,max_money,scale')->find();
        $totalBuyPrice = bcmul($buy_price, 1, 2); // 每股金额

        // 每批处理数量 - 可根据服务器能力调整
        $batchSize = 100;
        $orders = $singleOrder->toArray();
        $batches = array_chunk($orders, $batchSize);

        foreach ($batches as $batchIndex => $batch) {
            foreach ($batch as $item) {
                 
                try {
                    $this->processSingleOrder($item, $singleItem, $single_id, $volume, $buy_price, $code, $source_id, $buy_time, $totalBuyPrice);
                    
                } catch (\Throwable $e) {
                    // 记录日志，继续下一条
                    writeLog('create_single_order_error', sprintf(
                        "single_id=%s, order_id=%s, uid=%s, err=%s",
                        $single_id,
                        $item['id'] ?? 0,
                        $item['user_id'] ?? 0,
                        $e->getMessage()
                    ));
                    continue;
                }
            }
            // 每处理一批，释放内存并给 DB 短暂休息
             
            unset($batch);
            gc_collect_cycles();
            usleep(100000); // 100ms
        }

        return true;
    }

    /**
     * 单条跟单订单的处理逻辑（在事务中确保原子性）
     * 含幂等保护（检测是否已存在）
     */
    protected function processSingleOrder($item, $singleItem, $single_id, $volume, $buy_price, $code, $source_id, $buy_time, $totalBuyPrice)
    {
        // 幂等检查：如果已经存在该 user + source_id 的绑定或已经生成过 stock_trust（由 single_order_sn + source_id 判重），则跳过
        $existsBind = Db::name('single_source_user')
            ->where(['single_order_sn' => $item['order_sn'], 'source_id' => $source_id, 'uid' => $item['user_id']])
            ->count();
        // 已处理过，跳过
        
        if ($existsBind) return;
        $min_money = MemberModel::user_level_min_money($item['user_id'], $single_id);
        
        if ($item['money'] < $min_money) return; // 本金不足
       
        $money = bcmul($item['money'], $volume, 2);
         
        // 购买股数（向下取整）
        $shou = floor(bcdiv($money, $buy_price, 0));
       
        if ($shou <= 0) return;
        $number = $shou;
        $toal_money = bcmul($buy_price, $number, 2);
        $commission = commission($toal_money, sysConfig('commission_scale'), 1);
        $transfer   = transfer($toal_money);
        $effectMoney = bcadd(bcadd($toal_money, $commission, 2), $transfer, 2);
        

        if ($money < $totalBuyPrice || $money < $effectMoney) return; // 不够买一股或余额不足
        // 生成委托号（尽量避免重复）
        $order_sn = mt_rand(101010, 999999) . substr(strval(time()), 1);
       
        $data = [
            'uid'             => $item['user_id'],
            'single_id'       => $single_id,
            'source_id'       => $source_id,
            'sub_id'          => $item['sub_id'],
            'gupiao_code'     => $code['code'],
            'market'          => $code['market'] ?? '',
            'gupiao_name'     => $code['title'] ?? '',
            'trust_date'      => date('Y-m-d'),
            'trust_time'      => date('H:i:s'),
            'trust_no'        => $order_sn,
            'trust_price'     => $buy_price,
            'trust_count'     => $number,
            'volume'          => 0,
            'amount'          => 0,
            'flag1'           => 0,
            'flag2'           => '跟单委托',
            'status'          => '已委托',
            'beizhu'          => '跟单委托',
            'single_type'     => 2,
            'add_time'        => time(),
            'single_day'      => $item['single_day'],
            'scale'           => $singleItem['scale'] ?? 0,
            'single_order_sn' => $item['order_sn'],
            'buy_time'        => $buy_time,
            'order_sn'        => $item['order_sn'],
        ];
       
      
        
// 在事务中插入交割单、绑定关系、更新跟单订单、插入委托单，保证原子性
        Db::transaction(function () use ($data, $item, $number, $buy_price, $commission, $transfer, $effectMoney, $source_id, $buy_time) {

            // 二次幂等检查（防并发重复）
            $exists = Db::name('stock_trust')->where([
                'order_sn' => $data['order_sn'],
                'source_id' => $data['source_id']
            ])->count();
            // 已插入过
            if ($exists) return;
            // 添加交割单（你原有的方法）
            Delivery::add_m_delivery_order(
                $data['gupiao_code'], $number, $buy_price, $data['sub_id'],
                $commission, $transfer, $data['trust_no'],
                $item['money'] - $effectMoney, $number, 2, $buy_time
            );

            // 绑定关系
            (new SingleSourceUser())->save([
                'uid'             => $item['user_id'],
                'single_order_sn' => $item['order_sn'],
                'order_id'        => $item['id'],
                'source_id'       => $source_id
            ]);

            // 更新跟投订单的 source_id（表示已被绑定/已处理）
            $itemModel =SingleOrder::find($item['id']);
            if ($itemModel) {
                $itemModel->source_id = $source_id;
                $itemModel->save();
            }
            // 保存委托单
            Db::name('stock_trust')->insert($data);
        });
    }















    /**
     * 处理单条卖出任务（原子事务）
     *
     * @param int $pos_id
     * @param string $sell_price
     * @param string $sell_time
     * @param string $sell_price_scope
     * @param int $single_type
     * @param string $sell_volume 仓位，'1' 表示全部，或小数比例如 '0.5'
     * @return bool  true = 处理完成或无需处理， false = 处理失败（并已记录日志）
     */
    public function processSellPositionItem($pos_id, $sell_price, $sell_time, $sell_price_scope, $single_type, $sell_volume)
    {


        // 兼容 sell_volume 为空（默认全部仓位）
        $sell_volume = $sell_volume == '' || $sell_volume == null ? '1' : (string)$sell_volume;

        try {
            // 每条持仓单独事务，保证单条原子性
            Db::transaction(function () use ($pos_id, $sell_price, $sell_time, $sell_price_scope, $single_type, $sell_volume) {

                // 重新读取并加锁当前持仓，避免并发超卖
                $pos = StockPosition::where('id', $pos_id)->lock(true)->find();
                if (!$pos) {
                    writeLog('queue_sell_position_count', "持仓不存在 id={$pos_id}");
                   
                }
                
                $sell_count = bcmul(strval($pos['stock_count']), strval($sell_volume)); //计算 持仓数量 * 仓位 计算卖出数量
                if ($sell_count <= 0) return;
                $trade_money = bcmul(strval($sell_count), strval($sell_price)); //计算卖出股票总价
                // 唯一成交编号：时间 + 随机数，减少撞号风险
                $Trust_no = date('YmdHis') . random_int(100000, 999999);
                // 计算费用（你现有的函数）
                $commission = commission($trade_money, sysConfig('commission_scale'), 1);
                $stamps = stamps($trade_money);
                $transfer = transfer($trade_money);
                $money_info = Money::getMoney($pos['uid']);
                // 到手金额 = 成交额 - 过户 - 印花 - 手续费
               $effectMoney = bcsub(bcsub(bcsub($trade_money, (string)$transfer, 2), (string)$stamps, 2), (string)$commission, 2);
                // 成本（持仓成本 = ck_price * 卖出数量）
                $ck_profit = bcmul((string)$pos['ck_price'], (string)$sell_count);
                // 盈亏（正为用户盈利）
                $pnl = bcsub($effectMoney, $ck_profit);
                if ((int)$pos['canbuy_count'] < $sell_count) {
                     writeLog('queue_sell_position_count', "可卖数量不足 pos_id={$pos['id']} need={$sell_count} avail={$pos['canbuy_count']}");
                  
                }
               
                $pos->canbuy_count = bcsub((string)$pos['canbuy_count'], (string)$sell_count, 0);
                $pos->stock_count = bcsub((string)$pos['stock_count'], (string)$sell_count, 0);
                $pos->count = bcsub((string)$pos['count'], (string)$sell_count, 0);
                $pos->ck_profit = $pnl; // 记录真实盈亏（可能为负）
                $pos->sell_type = $single_type == 1 ? 1 : 2;
                $pos->sell_time = $sell_time;
                $pos->sell_price = $sell_price;
                $pos->sell_price_scope = $sell_price_scope;
                $pos->sell_count = $sell_count;
                $pos->save();
                // === 盈利分支 ===
                if (bccomp($pnl, '0', 2) === 1) {
                    // 用户盈利
                    $yingli = $pnl; // 盈利金额
                    $scale = bcdiv((string)$pos['scale'], '100',4); // 比如 0.20
                    $yingli_money = bcmul($yingli, $scale,2);       // 老师分佣（保留两位）
                    $true_money = bcsub($yingli, $yingli_money,2);  // 用户纯利润
                    // 给老师发放分佣（保留两位小数）
                    $singleInfo = Db::name('single_item')->where('id', $pos['single_id'])->field('id,user_id')->find();
                    if ($singleInfo && !empty($singleInfo['user_id']) && bccomp($yingli_money, '0', 2) === 1) {
                        // 用 setInc / setDec 风格的更新方法保证小数可写入（不同框架方法名差异，若不存在请替换为合适方法）
                        Db::name('money')->where('mid', $singleInfo['user_id'])->inc('account', $yingli_money);
                        $moneyInfoTeacher = Money::getMoney($singleInfo['user_id']);
                        RecordModel::saveData($singleInfo['user_id'], $yingli_money, $moneyInfoTeacher['account'], 38, '带单返佣：' . $yingli_money);
                    }
                   
                    // 返还用户资金（订单到期处理会在 add_user_money 内处理配额/返还规则）
                    $userYingLiMoney = bcadd($ck_profit, $true_money,2); // 本金 + 用户纯利润（你原来逻辑）
                    // 调用订单到期处理（type=1 表示盈利）
                    
                    SingleOrder::add_user_money($pos['order_sn'], $effectMoney, $userYingLiMoney, $ck_profit, $true_money, 1);
 
                    // 生成成交单
                    StockDealStock::sell_m_deal_stock(
                        ['code' => $pos['gupiao_code'], 'name' => $pos['gupiao_name']],
                        $sell_count,
                        $sell_price,
                        $pos['sub_id'],
                        $pos['lib'],
                        $pos['login_name'],
                        $pos['soruce'],
                        $Trust_no,
                        2,
                        $sell_time,
                        $pos['order_sn']
                    );
                    // 记资金日志 & 交割单
                    $user_money = Money::getMoney($pos['uid']);
                    RecordModel::saveData($pos['uid'], $true_money, $user_money['account'], 39, '跟单收益：' . $true_money);
                    Delivery::sell_m_delivery_order(
                        $pos['gupiao_code'],
                        $sell_count,
                        $sell_price,
                        $pos['sub_id'],
                        $commission,
                        $transfer,
                        $Trust_no,
                        $stamps,
                        bcadd($user_money['account'], $userYingLiMoney),
                        $sell_count,
                        2
                    );
                    MemberModel::sendCommission($pos['uid'], $true_money, 2, $Trust_no);
                } else {
                    $kui = bcsub($ck_profit, $effectMoney);
                    // 成交单
                    StockDealStock::sell_m_deal_stock(
                        ['code' => $pos['gupiao_code'], 'name' => $pos['gupiao_name']],
                        $sell_count,
                        $sell_price,
                        $pos['sub_id'],
                        $pos['lib'],
                        $pos['login_name'],
                        $pos['soruce'],
                        $Trust_no,
                        2,
                        $sell_time,
                        $pos['order_sn']
                    );
                    // 交割单（此处 avail 以前是 money.avail + effectMoney）
                    $user_money = Money::getMoney($pos['uid']);
                    Delivery::sell_m_delivery_order(
                        $pos['gupiao_code'],
                        $sell_count,
                        $sell_price,
                        $pos['sub_id'],
                        $commission,
                        $transfer,
                        $Trust_no,
                        $stamps,
                        bcadd($user_money['account'], $effectMoney),
                        $sell_count,
                        2
                    );
                    // 记录亏损流水
                    RecordModel::saveData($pos['uid'], $kui, $user_money['account'], 39, '跟单收益：' . $kui);

                    // 调用订单到期处理（type=2 表示亏损）
                    SingleOrder::add_user_money($pos['order_sn'], $effectMoney, '0.00', $ck_profit, '0.00', 2);
                }
            });

        } catch (\Exception $e) {
            // 单条异常不影响循环，记录日志并继续
            writeLog('sell_position_error', sprintf(
                "pos_id=%s, uid=%s, err=%s",
                $item['id'] ?? 0,
                $item['uid'] ?? 0,
                $e->getMessage()
            ));
        }
        return true;
    }

}
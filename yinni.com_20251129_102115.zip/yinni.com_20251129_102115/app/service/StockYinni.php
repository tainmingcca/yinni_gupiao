<?php
//印度尼西亚 股票行情方法
namespace app\service;



use think\facade\Db;

class StockYinni
{
    public function __construct()
    {
        $this->key = env('app.STOCK_KEY');
        $this->countryId = 48;  // 国家代码48印度尼西亚
    }
    public function stock_list()
    {
        $page = 2; // 目前更新到第2页，一共929支股票 一次500
        $url = "https://api.stocktv.top/stock/stocks?countryId={$this->countryId}&pageSize=500&page={$page}&key=".$this->key;
        $output = curl($url);
        $response = json_decode($output, true);
        if (isset($response['code']) && $response['code']!=200)  return false ;
        $data = $response['data']['records'];
        $list = [];
        foreach ($data as $key => $item) {
            $list[$key]['title']  = $item['name'];
            $list[$key]['market'] = $item['exchangeId'];
            $list[$key]['code']   = $item['id'];
            $list[$key]['symbol']   = $item['symbol'];
//            $list[$key]['pinyin'] = $item['pinyin'];
            $list[$key]['status'] = 1;
            $list[$key]['add_time']    = time();
            $list[$key]['edit_time']   = time();
            $list[$key]['target_uid']  = 1;
            $list[$key]['target_name'] = 'admin';
            $list[$key]['country_id'] = $item['countryId'];
        }
        Db::startTrans();

        try {
            $res = Db::name('stock_list')->insertAll($list);
            if($res){
                Db::commit();
                return true;
            }
        } catch (Exception $e) {
            Db::rollback();
            return false;
        }
    }
    public function getStockInfo($code)
    {
        $url = "https://api.stocktv.top/stock/queryStocks?id={$code}&key=".$this->key;
        $output = curl($url);
        $response = json_decode($output, true);
        if (isset($response['code']) && $response['code']!=200)  return false ;
       return $response;
    }

    public function getNews($page_size=10)
    {
        $url = "https://api.stocktv.top/stock/news?pageSize={$page_size}&page=1&key=".$this->key;
        $output = curl($url);
        $response = json_decode($output, true);
        if (isset($response['code']) && $response['code']!=200)  return false ;
        return $response['data']['records'];
    }
    public function getIndices()
    {
        $url = "https://api.stocktv.top/stock/indices?countryId={$this->countryId}&key=".$this->key;
        $output = curl($url);
        $response = json_decode($output, true);
        if (isset($response['code']) && $response['code']!=200)  return false ;
        return $response['data'];

    }

}
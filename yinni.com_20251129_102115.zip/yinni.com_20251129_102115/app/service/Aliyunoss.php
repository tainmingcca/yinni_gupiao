<?php

namespace app\service;




use OSS\OssClient;
use OSS\Core\OssException;

class Aliyunoss
{
    public function __construct()
    {
        $this->accessid = env('app.ALIYUNOSS_ACCESSID');
        $this->accesskey = env('app.ALIYUNOSS_ACCESSKEY');
        $this->Bucket = 'yinni-card';
        $this->Endpoint = 'oss-ap-southeast-5.aliyuncs.com';
        $this->baseDir = 'card';
    }

    public function aliossPolicy($dir)
    {
        $id = $this->accessid;
        $key = $this->accesskey;
        $Bucket = $this->Bucket;
        $Endpoint = $this->Endpoint;
        $host = request()->scheme()."://{$Bucket}.{$Endpoint}";
        $callbackUrl = request()->domain(true);//回调地址
        $callback_param = array('callbackUrl' => $callbackUrl,
            'callbackBody' => 'filename=${object}&size=${size}&mimeType=${mimeType}&height=${imageInfo.height}&width=${imageInfo.width}',
            'callbackBodyType' => "application/x-www-form-urlencoded");
        $callback_string = json_encode($callback_param);

        $base64_callback_body = base64_encode($callback_string);
        $now = time();
        $expire = 100; //设置该policy超时时间是10s. 即这个policy过了这个有效时间，将不能访问
        $end = $now + $expire;
        $expiration = $this->gmt_iso8601($end);
        $dir = $this->baseDir . "{$dir}/" . date('Ymd', time()) . "/";//文件在oss中保存目录

        //最大文件大小.用户可以自己设置
        $condition = array(0 => 'content-length-range', 1 => 0, 2 => 1048576000);
        $conditions[] = $condition;

        //表示用户上传的数据,必须是以$dir开始, 不然上传会失败,这一步不是必须项,只是为了安全起见,防止用户通过policy上传到别人的目录
        //$start = array(0=>'starts-with', 1=>'$key', 2=>$dir);
        //$conditions[] = $start;

        $arr = array('expiration' => $expiration, 'conditions' => $conditions);
        $policy = json_encode($arr);
        $base64_policy = base64_encode($policy);
        $string_to_sign = $base64_policy;
        $signature = base64_encode(hash_hmac('sha1', $string_to_sign, $key, true));

        $response = array();
        $response['host'] = $host;
        $response['accessid'] = $id;
        $response['policy'] = $base64_policy;
        $response['signature'] = $signature;
        $response['expire'] = $end;
        //$response['callback'] = $base64_callback_body;
        $response['dir'] = $dir;
        return $response;
    }

    public function deleteImg($storeFileUrl)
    {
        // 阿里云主账号AccessKey拥有所有API的访问权限，风险很高。强烈建议您创建并使用RAM账号进行API访问或日常运维，请登录 https://ram.console.aliyun.com 创建RAM账号。
        $accessKeyId = $this->accessid;
        $accessKeySecret = $this->accesskey;
        // Endpoint以杭州为例，其它Region请按实际情况填写。
        $endpoint = $this->Endpoint;
        $bucket = $this->Bucket;
        $host = "http://{$bucket}.{$endpoint}/";
        $filePath = str_replace($host, "", $storeFileUrl);
        $ossClient = new OssClient($accessKeyId, $accessKeySecret, $endpoint);
        $res = $ossClient->deleteObject($bucket, $filePath);
        //halt($res);
    }

    private function gmt_iso8601($time)
    {
        $dtStr = date("c", $time);
        $mydatetime = new \DateTime($dtStr);
        $expiration = $mydatetime->format(\DateTime::ISO8601);
        $pos = strpos($expiration, '+');
        $expiration = substr($expiration, 0, $pos);
        return $expiration . "Z";
    }


    public function callback()
    {
        $data = request()->header();
        // 1.获取OSS的签名header和公钥url header
        $authorizationBase64 = $data['authorization'];
        $pubKeyUrlBase64 = $data['x-oss-pub-key-url'];
        /*
        * 注意：如果要使用HTTP_AUTHORIZATION头，你需要先在apache或者nginx中设置rewrite，以apache为例，修改
        * 配置文件/etc/httpd/conf/httpd.conf(以你的apache安装路径为准)，在DirectoryIndex index.php这行下面增加以下两行
            RewriteEngine On
            RewriteRule .* - [env=HTTP_AUTHORIZATION:%{HTTP:Authorization},last]
        * */
        if (isset($data['Authorization'])) {
            $authorizationBase64 = $data['Authorization'];
        }
        if (isset($data['x-oss-pub-key-url'])) {
            $pubKeyUrlBase64 = $data['x-oss-pub-key-url'];
        }
        if ($authorizationBase64 == '' || $pubKeyUrlBase64 == '') {
            header("http/1.1 403 Forbidden");
            exit();
        }

        // 2.获取OSS的签名
        $authorization = base64_decode($authorizationBase64);
        //halt($authorization);

        // 3.获取公钥
        $pubKeyUrl = base64_decode($pubKeyUrlBase64);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $pubKeyUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        $pubKey = curl_exec($ch);
        halt($pubKeyUrl);
        if ($pubKey == "") {
            //header("http/1.1 403 Forbidden");
            exit();
        }

        // 4.获取回调body
        $body = file_get_contents('php://input');

        // 5.拼接待签名字符串
        $authStr = '';
        $path = $_SERVER['REQUEST_URI'];
        $pos = strpos($path, '?');
        if ($pos === false) {
            $authStr = urldecode($path) . "\n" . $body;
        } else {
            $authStr = urldecode(substr($path, 0, $pos)) . substr($path, $pos, strlen($path) - $pos) . "\n" . $body;
        }

        // 6.验证签名
        $ok = openssl_verify($authStr, $authorization, $pubKey, OPENSSL_ALGO_MD5);
        halt($ok);
        if ($ok == 1) {
            $param = request()->param();
            //根据返回的信息 $param 根据需要保存自数据库


        } else {
            exit();
        }
    }
}
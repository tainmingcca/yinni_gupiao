<?php
namespace app\agent\model;

use think\facade\Db;
use think\Model;
use think\Exception;

/**
 * 配资管理模型
 */
class Borrow extends Model
{
    // 设置当前模型对应的完整数据表名称
    protected $name = 'stock_borrow';

    public static function getBorrowCount($map=[])
    {
        //print_r($map);exit;
        $counts = self::view('stock_borrow b', true)
            ->view('member m', 'mobile,name', 'm.id=b.member_id', 'left')
            ->view('stock_subaccount s','sub_account','s.id=b.stock_subaccount_id','left')
            ->view('st_stock_subaccount_money sm','avail,freeze_amount,return_money,stock_addfinancing,stock_addmoney','sm.stock_subaccount_id=b.stock_subaccount_id','left')
            ->where($map)
            ->count();
        return $counts;
    }
    
}

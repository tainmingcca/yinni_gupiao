import{_ as r}from"./index-Dy8m1uHn.js";const c={};function e(n,t){return null}const o=r(c,[["render",e]]);export{o as default};
